-- Create subscription_plans table
CREATE TABLE public.subscription_plans
(
    id                 uuid PRIMARY KEY          DEFAULT gen_random_uuid(),
    name               varchar(255)     NOT NULL UNIQUE,
    display_name       varchar(255)     NOT NULL,
    description        text,

    max_cameras        integer          NOT NULL DEFAULT 0,
    max_nvrs           integer          NOT NULL DEFAULT 0,
    max_locations      integer          NOT NULL DEFAULT 0,
    max_members        integer          NOT NULL DEFAULT 0,
    max_floor_plans    integer          NOT NULL DEFAULT 0,
    max_storage        double precision NOT NULL DEFAULT 0,
    analytics          text[],
    desktop_app_access boolean          NOT NULL DEFAULT false,
    priority_support   boolean          NOT NULL DEFAULT false,

    price_monthly      decimal(10, 2),
    price_yearly       decimal(10, 2),

    is_active          boolean          NOT NULL DEFAULT true,

    created_at         timestamp with time zone  DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at         timestamp with time zone  DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create indexes for better performance
CREATE INDEX idx_subscription_plans_name ON public.subscription_plans (name);
CREATE INDEX idx_subscription_plans_active ON public.subscription_plans (is_active);

-- Add foreign key to groups table to link with subscription plan
ALTER TABLE public.groups
    ADD COLUMN subscription_plan_id uuid REFERENCES public.subscription_plans (id);

-- Create index on the new foreign key
CREATE INDEX idx_groups_subscription_plan ON public.groups (subscription_plan_id);

-- Add comments for documentation
COMMENT ON TABLE public.subscription_plans IS 'Defines subscription tiers and their limits for organizations';
COMMENT ON COLUMN public.subscription_plans.max_storage IS 'Maximum storage in bytes';
COMMENT ON COLUMN public.subscription_plans.analytics IS 'Array of analytic names available in this plan';
COMMENT ON COLUMN public.groups.subscription_plan_id IS 'Links group to its subscription plan';