ALTER TABLE nvrs
    DROP CONSTRAINT IF EXISTS fk_nvrs_created_by,
    DROP COLUMN IF EXISTS created_by;