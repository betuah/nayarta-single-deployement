-- Remove foreign key from groups table
DROP INDEX IF EXISTS idx_groups_subscription_plan;
ALTER TABLE public.groups DROP COLUMN IF EXISTS subscription_plan_id;

-- Drop indexes
DROP INDEX IF EXISTS idx_subscription_plans_name;
DROP INDEX IF EXISTS idx_subscription_plans_active;

-- Drop the subscription_plans table
DROP TABLE IF EXISTS public.subscription_plans;