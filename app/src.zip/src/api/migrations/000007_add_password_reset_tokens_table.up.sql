CREATE TABLE password_reset_tokens
(
    id         UUID PRIMARY KEY         DEFAULT gen_random_uuid(),
    user_id    UUID                     NOT NULL REFERENCES users (id),
    token      VARCHAR(255)             NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);