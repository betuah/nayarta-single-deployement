ALTER TABLE alerts
    ALTER COLUMN cctv_analytic_id SET NOT NULL;