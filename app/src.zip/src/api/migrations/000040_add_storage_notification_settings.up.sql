ALTER TABLE public.groups
    ADD COLUMN storage_notification_threshold INTEGER DEFAULT 80 NOT NULL,
    ADD COLUMN last_storage_notification_sent_at TIMESTAMP WITH TIME ZONE DEFAULT NULL;

COMMENT ON COLUMN public.groups.storage_notification_threshold IS 'Percentage threshold for storage usage notifications (0-100)';
COMMENT ON COLUMN public.groups.last_storage_notification_sent_at IS 'Timestamp of last storage notification email sent';

-- Add constraint to ensure threshold is between 0 and 100
ALTER TABLE public.groups
    ADD CONSTRAINT check_storage_notification_threshold
        CHECK (storage_notification_threshold >= 0 AND storage_notification_threshold <= 100);