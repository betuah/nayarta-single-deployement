ALTER TABLE public.cctvs
    ADD COLUMN recording_status integer NOT NULL DEFAULT 0;

COMMENT ON COLUMN public.cctvs.recording_status IS '0 = not recording, 1 = recording, -1 = recording error';