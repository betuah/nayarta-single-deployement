ALTER TABLE public.users
    DROP COLUMN email_verified,
    DROP COLUMN email_verification_token,
    DROP COLUMN email_verification_token_expires_at;