ALTER TABLE cctv_recording_schedules
    DROP COLUMN IF EXISTS retention_days;