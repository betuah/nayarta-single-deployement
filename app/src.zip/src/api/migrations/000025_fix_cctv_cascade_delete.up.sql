-- revert the previous NVR cascade migration
ALTER TABLE cctvs
    DROP CONSTRAINT IF EXISTS cctvs_nvr_id_fkey,
    ADD CONSTRAINT cctvs_nvr_id_fkey
        FOREIGN KEY (nvr_id)
            REFERENCES nvrs(id);

-- Set up cascade delete for files table
ALTER TABLE files
    DROP CONSTRAINT IF EXISTS files_cctv_id_fkey,
    ADD CONSTRAINT files_cctv_id_fkey
        FOREIGN KEY (cctv_id)
            REFERENCES cctvs(id)
            ON DELETE CASCADE;

-- Set up cascade delete for cctv_analytics table
ALTER TABLE cctv_analytics
    DROP CONSTRAINT IF EXISTS cctv_analytics_cctv_id_fkey,
    ADD CONSTRAINT cctv_analytics_cctv_id_fkey
        FOREIGN KEY (cctv_id)
            REFERENCES cctvs(id)
            ON DELETE CASCADE;

-- Set up cascade delete for member_alert_settings through cctv_analytics
ALTER TABLE member_alert_settings
    DROP CONSTRAINT IF EXISTS member_alert_settings_cctv_analytic_id_fkey,
    ADD CONSTRAINT member_alert_settings_cctv_analytic_id_fkey
        FOREIGN KEY (cctv_analytic_id)
            REFERENCES cctv_analytics(id)
            ON DELETE CASCADE;

-- Set up cascade delete for analytics through cctv_analytics
ALTER TABLE analytics
    DROP CONSTRAINT IF EXISTS analytics_cctv_analytic_id_fkey,
    ADD CONSTRAINT analytics_cctv_analytic_id_fkey
        FOREIGN KEY (cctv_analytic_id)
            REFERENCES cctv_analytics(id)
            ON DELETE CASCADE;

-- Set up cascade delete for alerts through cctv_analytics
ALTER TABLE alerts
    DROP CONSTRAINT IF EXISTS alerts_cctv_analytic_id_fkey,
    ADD CONSTRAINT alerts_cctv_analytic_id_fkey
        FOREIGN KEY (cctv_analytic_id)
            REFERENCES cctv_analytics(id)
            ON DELETE CASCADE;