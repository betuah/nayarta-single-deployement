BEGIN;

-- Make member_id nullable in alerts table
ALTER TABLE alerts ALTER COLUMN member_id DROP NOT NULL;

-- Add index for better performance on queries with NULL member_id
CREATE INDEX idx_alerts_member_id_null ON alerts (member_id) WHERE member_id IS NULL;

-- Add comment to explain the purpose
COMMENT ON COLUMN alerts.member_id IS 'Member ID for personal alerts. NULL for system/group alerts used for reporting.';

COMMIT;