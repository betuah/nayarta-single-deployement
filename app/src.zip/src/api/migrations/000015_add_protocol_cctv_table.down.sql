ALTER TABLE public.cctvs
    DROP COLUMN protocol;