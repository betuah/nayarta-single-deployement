
ALTER TABLE public.cctvs
    DROP COLUMN recording_status;