-- Add metadata column to files table
ALTER TABLE files ADD COLUMN metadata JSONB NOT NULL DEFAULT '{}'::jsonb;