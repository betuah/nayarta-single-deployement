CREATE TABLE public.users
(
    id          UUID PRIMARY KEY,
    email       VARCHAR(255) UNIQUE      NOT NULL,
    full_name   VARCHAR(255)             NOT NULL,
    phone       VARCHAR(255),
    password    VARCHAR(255)             NOT NULL,
    user_status public.user_status          NOT NULL DEFAULT 'pending',
    created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.groups
(
    id           UUID PRIMARY KEY,
    group_name   VARCHAR(255)             NOT NULL,
    group_status public.group_status         NOT NULL DEFAULT 'pending',
    storage_size FLOAT,
    storage_used FLOAT,
    created_at   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.locations
(
    id            UUID PRIMARY KEY,
    location_name VARCHAR(255)             NOT NULL,
    latitude      FLOAT                    NOT NULL,
    longitude     FLOAT                    NOT NULL,
    image_url     VARCHAR(255),
    address       TEXT                     NOT NULL,
    created_at    TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.nvrs
(
    id           UUID PRIMARY KEY,
    group_id     UUID                     NOT NULL REFERENCES public.groups (id),
    location_id  UUID                     NOT NULL REFERENCES public.locations (id),
    name         VARCHAR(255)             NOT NULL,
    description  TEXT                     NOT NULL,
    brand        VARCHAR(255)             NOT NULL,
    type         VARCHAR(255)             NOT NULL,
    hostname     VARCHAR(255)             NOT NULL,
    port         INTEGER                  NOT NULL,
    user_name    VARCHAR(255)             NOT NULL,
    password     VARCHAR(255)             NOT NULL,
    status       public.nvr_status           NOT NULL DEFAULT 'offline',
    last_checked TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_nvrs_group ON public.nvrs (group_id);

CREATE TABLE public.cctvs
(
    id             UUID PRIMARY KEY,
    nvr_id         UUID                     NOT NULL REFERENCES public.nvrs (id),
    name           VARCHAR(255)             NOT NULL,
    description    TEXT                     NOT NULL,
    snapshot_image VARCHAR(255),
    brand          VARCHAR(255)             NOT NULL,
    type           VARCHAR(255)             NOT NULL,
    hostname       VARCHAR(255)             NOT NULL,
    port           INTEGER                  NOT NULL,
    user_name      VARCHAR(255)             NOT NULL,
    password       VARCHAR(255)             NOT NULL,
    status         public.cctv_status          NOT NULL DEFAULT 'offline',
    last_checked   TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cctvs_nvr ON public.cctvs (nvr_id);

CREATE TABLE public.files
(
    id             UUID PRIMARY KEY,
    cctv_id        UUID                     NOT NULL REFERENCES public.cctvs (id),
    snapshot_image VARCHAR(255),
    file_type      VARCHAR(255)             NOT NULL,
    file_name      VARCHAR(255)             NOT NULL,
    file_url       VARCHAR(255)             NOT NULL,
    size           FLOAT                    NOT NULL DEFAULT 0,
    created_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_files_cctv ON public.files (cctv_id);

CREATE TABLE public.members
(
    id         UUID PRIMARY KEY,
    user_id    UUID                     NOT NULL REFERENCES public.users (id),
    group_id   UUID                     NOT NULL REFERENCES public.groups (id),
    role       public.member_role          NOT NULL DEFAULT 'member',
    status     public.member_status        NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX idx_members ON public.members (user_id, group_id);

CREATE TABLE public.analytic_types
(
    id          UUID PRIMARY KEY,
    name        VARCHAR(255)             NOT NULL,
    description TEXT                     NOT NULL,
    created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.cctv_analytics
(
    id               UUID PRIMARY KEY,
    analytic_type_id UUID                     NOT NULL REFERENCES public.analytic_types (id),
    cctv_id          UUID                     NOT NULL REFERENCES public.cctvs (id),
    enable           BOOLEAN                  NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX idx_analytics_cctv ON public.cctv_analytics (analytic_type_id, cctv_id);

CREATE TABLE public.member_alert_settings
(
    id               UUID PRIMARY KEY,
    member_id        UUID    NOT NULL REFERENCES public.members (id),
    cctv_analytic_id UUID    NOT NULL REFERENCES public.cctv_analytics (id),
    enabled          BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE UNIQUE INDEX idx_members_alert_settings ON public.member_alert_settings (member_id, cctv_analytic_id);

CREATE TABLE public.analytics
(
    id               UUID PRIMARY KEY,
    file_id          UUID                     NOT NULL REFERENCES public.files (id),
    cctv_analytic_id UUID                     NOT NULL REFERENCES public.cctv_analytics (id),
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX idx_analytics ON public.analytics (file_id, cctv_analytic_id);

CREATE TABLE public.alerts
(
    id               UUID PRIMARY KEY,
    analytic_id      UUID                     NOT NULL REFERENCES public.analytics (id),
    message          TEXT                     NOT NULL DEFAULT '-',
    member_id        UUID                     NOT NULL REFERENCES public.members (id),
    created_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cctv_analytic_id UUID                     NOT NULL REFERENCES public.cctv_analytics (id)
);

CREATE INDEX idx_analytics_alert ON public.alerts (analytic_id, member_id);
