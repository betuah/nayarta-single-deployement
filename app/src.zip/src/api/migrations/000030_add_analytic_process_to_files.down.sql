ALTER TABLE files
    DROP COLUMN analytic_process;