ALTER TABLE nvrs
    ADD COLUMN created_by UUID NOT NULL,
    ADD CONSTRAINT fk_nvrs_created_by FOREIGN KEY (created_by) REFERENCES users(id);