CREATE TABLE floor_plans (
                             id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                             location_id UUID NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
                             name VARCHAR(255) NOT NULL,
                             image_url VARCHAR(255) NOT NULL,
                             dimension_width INTEGER NOT NULL,
                             dimension_height INTEGER NOT NULL,
                             created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
                             updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX idx_floor_plans_location ON floor_plans(location_id);