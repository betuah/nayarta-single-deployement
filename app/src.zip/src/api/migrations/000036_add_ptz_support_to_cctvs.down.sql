-- Remove ptz_support column from cctvs table
ALTER TABLE cctvs DROP COLUMN IF EXISTS ptz_support;