ALTER TABLE public.groups
    DROP CONSTRAINT IF EXISTS check_storage_notification_threshold;

ALTER TABLE public.groups
    DROP COLUMN IF EXISTS storage_notification_threshold,
    DROP COLUMN IF EXISTS last_storage_notification_sent_at;