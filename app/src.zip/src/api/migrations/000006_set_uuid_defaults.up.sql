ALTER TABLE public.users
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.alerts
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.analytic_types
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.analytics
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.cctv_analytics
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.cctvs
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.files
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.groups
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.locations
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.member_alert_settings
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.members
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.nvrs
    ALTER COLUMN id SET DEFAULT gen_random_uuid();
ALTER TABLE public.refresh_tokens
    ALTER COLUMN id SET DEFAULT gen_random_uuid();