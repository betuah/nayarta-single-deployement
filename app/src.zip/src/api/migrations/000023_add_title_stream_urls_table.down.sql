ALTER TABLE public.stream_urls
    DROP COLUMN title