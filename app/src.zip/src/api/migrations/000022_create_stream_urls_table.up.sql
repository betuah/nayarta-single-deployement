CREATE TABLE IF NOT EXISTS stream_urls
(
    id         UUID PRIMARY KEY         DEFAULT gen_random_uuid(),
    cctv_id    UUID         NOT NULL,
    protocol   VARCHAR(255) NOT NULL,
    hostname   VARCHAR(255) NOT NULL,
    port       INTEGER      NOT NULL,
    username   VARCHAR(255) NOT NULL    DEFAULT '',
    password   TEXT         NOT NULL    DEFAULT '',
    path       TEXT         NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cctv_id) REFERENCES cctvs (id)
);