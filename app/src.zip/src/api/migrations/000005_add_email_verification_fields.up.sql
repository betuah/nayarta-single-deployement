ALTER TABLE public.users
    ADD COLUMN email_verified                      BOOLEAN DEFAULT FALSE,
    ADD COLUMN email_verification_token            VARCHAR(255),
    ADD COLUMN email_verification_token_expires_at TIMESTAMP WITH TIME ZONE;