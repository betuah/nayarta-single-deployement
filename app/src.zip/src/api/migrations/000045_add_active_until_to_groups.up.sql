-- Add active_until column to groups table
ALTER TABLE public.groups
    ADD COLUMN active_until TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- Add last_expiration_notification_sent_at column to track notification history
ALTER TABLE public.groups
    ADD COLUMN last_expiration_notification_sent_at TIMESTAMP WITH TIME ZONE;

-- Add index for efficient querying
CREATE INDEX idx_groups_active_until ON public.groups(active_until);

-- Add new status 'inactive' to group_status enum if not exists
DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT 1 FROM pg_type t
                              JOIN pg_enum e ON t.oid = e.enumtypid
            WHERE t.typname = 'group_status' AND e.enumlabel = 'inactive'
        ) THEN
            ALTER TYPE group_status ADD VALUE 'inactive';
        END IF;
    END $$;

-- Comment
COMMENT ON COLUMN public.groups.active_until IS 'Date when the group subscription expires and will be set to inactive';
COMMENT ON COLUMN public.groups.last_expiration_notification_sent_at IS 'Timestamp of last expiration warning notification sent';