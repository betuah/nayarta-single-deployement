ALTER TABLE groups
    DROP CONSTRAINT fk_groups_created_by,
    DROP COLUMN created_by,
    DROP COLUMN email;