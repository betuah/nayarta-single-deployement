ALTER TABLE locations
    DROP CONSTRAINT fk_locations_created_by,
    DROP CONSTRAINT fk_locations_group_id,
    DROP COLUMN created_by,
    DROP COLUMN group_id,
    ALTER COLUMN image_url SET NOT NULL;