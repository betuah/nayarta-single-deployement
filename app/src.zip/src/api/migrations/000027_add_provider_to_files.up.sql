ALTER TABLE files
    ADD COLUMN provider varchar(255) DEFAULT NULL;

-- Add check constraint to ensure provider is either 'local' or 'object_storage' when not null
ALTER TABLE files
    ADD CONSTRAINT check_provider
        CHECK (provider IS NULL OR provider IN ('local', 'object_storage'));