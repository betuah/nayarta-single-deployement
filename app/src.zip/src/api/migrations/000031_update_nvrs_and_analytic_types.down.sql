-- Remove unique constraint from user_name in nvrs table
ALTER TABLE nvrs
    DROP CONSTRAINT uk_nvrs_user_name;

-- Remove config column from analytic_types table
ALTER TABLE analytic_types
    DROP COLUMN config;