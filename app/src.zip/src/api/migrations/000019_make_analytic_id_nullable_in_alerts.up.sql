ALTER TABLE public.alerts
    ALTER COLUMN analytic_id DROP NOT NULL;