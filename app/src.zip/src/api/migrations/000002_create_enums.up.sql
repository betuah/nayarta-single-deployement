CREATE TYPE public.user_status AS ENUM ('active', 'banned', 'pending', 'disable');
CREATE TYPE public.member_status AS ENUM ('active', 'banned', 'pending', 'disable');
CREATE TYPE public.group_status AS ENUM ('active', 'banned', 'pending', 'disable');
CREATE TYPE public.member_role AS ENUM ('admin', 'member');
CREATE TYPE public.cctv_status AS ENUM ('online', 'offline', 'alert');
CREATE TYPE public.nvr_status AS ENUM ('online', 'offline');