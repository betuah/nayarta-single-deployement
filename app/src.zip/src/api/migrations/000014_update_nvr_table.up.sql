ALTER TABLE public.nvrs
    DROP COLUMN brand,
    DROP COLUMN type,
    ADD COLUMN version VARCHAR(255) DEFAULT 'n/a';