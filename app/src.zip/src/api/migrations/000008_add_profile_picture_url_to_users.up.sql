ALTER TABLE users
    ADD COLUMN profile_picture_url VARCHAR(255);