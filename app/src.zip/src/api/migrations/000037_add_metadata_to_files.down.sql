-- Remove metadata column from files table
ALTER TABLE files DROP COLUMN metadata;