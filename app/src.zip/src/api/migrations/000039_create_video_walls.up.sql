CREATE TABLE public.video_walls
(
    id         uuid                     DEFAULT gen_random_uuid() NOT NULL
        PRIMARY KEY,
    name       varchar(255)                                       NOT NULL,
    layout     varchar(255)                                       NOT NULL,
    group_id   uuid                                               NOT NULL
        CONSTRAINT fk_video_walls_group_id
            REFERENCES public.groups,
    cctv_list  text[]                   DEFAULT '{}'::text[]      NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE public.video_walls
    OWNER TO db_manager;

CREATE INDEX idx_video_walls_group_id
    ON public.video_walls (group_id);