-- Add is_admin column to users table
ALTER TABLE public.users
    ADD COLUMN is_admin boolean NOT NULL DEFAULT false;