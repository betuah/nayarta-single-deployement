BEGIN;

-- Remove system alerts (those with NULL member_id) before making column NOT NULL
DELETE FROM alerts WHERE member_id IS NULL;

-- Drop the index we created
DROP INDEX IF EXISTS idx_alerts_member_id_null;

-- Remove comment
COMMENT ON COLUMN alerts.member_id IS NULL;

-- Make member_id NOT NULL again
ALTER TABLE alerts ALTER COLUMN member_id SET NOT NULL;

COMMIT;