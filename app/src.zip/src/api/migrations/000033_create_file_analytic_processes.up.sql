CREATE TABLE file_analytic_processes
(
    id               UUID                     DEFAULT gen_random_uuid() PRIMARY KEY,
    file_id          UUID                                               NOT NULL REFERENCES files (id) ON DELETE CASCADE,
    analytic_type_id UUID                                               NOT NULL REFERENCES analytic_types (id),
    processed_at     TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status           VARCHAR(255)                                       NOT NULL DEFAULT 'completed',
    metadata         JSONB                                              NOT NULL DEFAULT '{}',
    created_at       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE (file_id, analytic_type_id)
);

CREATE INDEX idx_file_analytic_processes_file_id ON file_analytic_processes (file_id);
CREATE INDEX idx_file_analytic_processes_analytic_type_id ON file_analytic_processes (analytic_type_id);