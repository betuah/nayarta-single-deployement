-- Revert all changes
ALTER TABLE files
    DROP CONSTRAINT IF EXISTS files_cctv_id_fkey,
    ADD CONSTRAINT files_cctv_id_fkey
        FOREIGN KEY (cctv_id)
            REFERENCES cctvs(id);

ALTER TABLE cctv_analytics
    DROP CONSTRAINT IF EXISTS cctv_analytics_cctv_id_fkey,
    ADD CONSTRAINT cctv_analytics_cctv_id_fkey
        FOREIGN KEY (cctv_id)
            REFERENCES cctvs(id);

ALTER TABLE member_alert_settings
    DROP CONSTRAINT IF EXISTS member_alert_settings_cctv_analytic_id_fkey,
    ADD CONSTRAINT member_alert_settings_cctv_analytic_id_fkey
        FOREIGN KEY (cctv_analytic_id)
            REFERENCES cctv_analytics(id);

ALTER TABLE analytics
    DROP CONSTRAINT IF EXISTS analytics_cctv_analytic_id_fkey,
    ADD CONSTRAINT analytics_cctv_analytic_id_fkey
        FOREIGN KEY (cctv_analytic_id)
            REFERENCES cctv_analytics(id);

ALTER TABLE alerts
    DROP CONSTRAINT IF EXISTS alerts_cctv_analytic_id_fkey,
    ADD CONSTRAINT alerts_cctv_analytic_id_fkey
        FOREIGN KEY (cctv_analytic_id)
            REFERENCES cctv_analytics(id);