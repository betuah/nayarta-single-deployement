DROP TABLE IF EXISTS public.file_ai_summaries;
DROP TYPE IF EXISTS file_ai_summary_status;