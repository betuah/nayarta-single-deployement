ALTER TABLE public.nvrs
    ADD COLUMN brand VARCHAR(255),
    ADD COLUMN type VARCHAR(255),
    DROP COLUMN version;