ALTER TABLE public.cctvs
    DROP COLUMN path