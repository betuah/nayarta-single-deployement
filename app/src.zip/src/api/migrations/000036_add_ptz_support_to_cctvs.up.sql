-- Add ptz_support column to cctvs table
ALTER TABLE cctvs ADD COLUMN ptz_support BOOLEAN NOT NULL DEFAULT false;