CREATE TYPE file_ai_summary_status AS ENUM (
    'in_queue',
    'in_progress',
    'completed',
    'failed',
    'timed_out',
    'stale'
    );

CREATE TABLE public.file_ai_summaries (
                                          id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
                                          file_id uuid NOT NULL REFERENCES public.files(id) ON DELETE CASCADE,
                                          user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
                                          custom_prompt text NOT NULL,
                                          job_id varchar(255) NOT NULL,
                                          status file_ai_summary_status DEFAULT 'in_queue' NOT NULL,
                                          output_result jsonb DEFAULT '{}',
                                          error_message text,
                                          created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                          updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                          completed_at timestamp with time zone
);

CREATE INDEX idx_file_ai_summaries_file_user ON public.file_ai_summaries(file_id, user_id);
CREATE INDEX idx_file_ai_summaries_status_created ON public.file_ai_summaries(status, created_at);
CREATE UNIQUE INDEX idx_file_ai_summaries_job_id ON public.file_ai_summaries(job_id);

ALTER TABLE public.file_ai_summaries OWNER TO db_manager;