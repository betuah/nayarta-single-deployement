ALTER TABLE nvrs
    DROP COLUMN token,
    DROP COLUMN check_interval;