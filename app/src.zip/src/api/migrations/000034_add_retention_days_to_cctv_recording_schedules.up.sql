ALTER TABLE cctv_recording_schedules
    ADD COLUMN retention_days INTEGER NOT NULL DEFAULT 30;

