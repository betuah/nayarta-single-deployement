CREATE TABLE cctv_recording_schedules
(
    id            UUID PRIMARY KEY                  DEFAULT gen_random_uuid(),
    cctv_id       UUID                     NOT NULL,
    enabled_hours INTEGER[]                NOT NULL DEFAULT ARRAY [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],
    created_at    TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_cctv
        FOREIGN KEY (cctv_id)
            REFERENCES cctvs (id)
            ON DELETE CASCADE
);

CREATE INDEX idx_cctv_recording_schedules_cctv_id ON cctv_recording_schedules (cctv_id);