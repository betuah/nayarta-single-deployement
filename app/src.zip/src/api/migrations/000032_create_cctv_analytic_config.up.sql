-- Create cctv_analytic_configs table
CREATE TABLE cctv_analytic_configs
(
    id               UUID                     DEFAULT gen_random_uuid() PRIMARY KEY,
    cctv_analytic_id UUID                                               NOT NULL UNIQUE
        REFERENCES cctv_analytics ON DELETE CASCADE,
    config           JSONB                                              NOT NULL DEFAULT '{}',
    created_at       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create index for faster lookups
CREATE INDEX idx_cctv_analytic_configs_cctv_analytic_id ON cctv_analytic_configs (cctv_analytic_id);