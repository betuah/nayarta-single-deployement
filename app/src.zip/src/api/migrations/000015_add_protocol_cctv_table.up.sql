ALTER TABLE public.cctvs
    ADD COLUMN protocol VARCHAR(255) DEFAULT 'rtsp';