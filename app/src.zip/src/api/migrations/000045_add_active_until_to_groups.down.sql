-- Remove index
DROP INDEX IF EXISTS idx_groups_active_until;

-- Remove columns
ALTER TABLE public.groups DROP COLUMN IF EXISTS active_until;
ALTER TABLE public.groups DROP COLUMN IF EXISTS last_expiration_notification_sent_at;

-- Note: Cannot remove enum value 'inactive' from group_status type in PostgreSQL
-- It would require recreating the entire type which might affect existing data