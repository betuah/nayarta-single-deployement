ALTER TABLE public.alerts
    ALTER COLUMN analytic_id SET NOT NULL;