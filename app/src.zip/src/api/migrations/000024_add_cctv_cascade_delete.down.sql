ALTER TABLE cctvs
    DROP CONSTRAINT IF EXISTS cctvs_nvr_id_fkey,
    ADD CONSTRAINT cctvs_nvr_id_fkey
        FOREIGN KEY (nvr_id)
            REFERENCES nvrs(id);