ALTER TABLE groups
    ADD COLUMN created_by UUID,
    ADD COLUMN email      VARCHAR(255);

ALTER TABLE groups
    ADD CONSTRAINT fk_groups_created_by
        FOREIGN KEY (created_by) REFERENCES users (id);