ALTER TABLE files
    DROP CONSTRAINT check_provider;

ALTER TABLE files
    DROP COLUMN provider;