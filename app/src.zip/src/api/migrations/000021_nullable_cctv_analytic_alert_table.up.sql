ALTER TABLE alerts
    ALTER COLUMN cctv_analytic_id DROP NOT NULL;