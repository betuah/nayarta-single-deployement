ALTER TABLE locations
    ADD COLUMN created_by UUID NOT NULL,
    ADD COLUMN group_id   UUID NOT NULL,
    ALTER COLUMN image_url DROP NOT NULL;

ALTER TABLE locations
    ADD CONSTRAINT fk_locations_created_by
        FOREIGN KEY (created_by) REFERENCES users (id);

ALTER TABLE locations
    ADD CONSTRAINT fk_locations_group_id
        FOREIGN KEY (group_id) REFERENCES groups (id);