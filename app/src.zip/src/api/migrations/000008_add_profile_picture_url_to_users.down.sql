ALTER TABLE users
    DROP COLUMN profile_picture_url;