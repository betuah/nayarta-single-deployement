CREATE TABLE floor_plan_objects (
                                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                                    floor_plan_id UUID NOT NULL REFERENCES floor_plans(id) ON DELETE CASCADE,
                                    object_type VARCHAR(10) NOT NULL,
                                    object_id UUID NOT NULL,
                                    position_x DOUBLE PRECISION NOT NULL,
                                    position_y DOUBLE PRECISION NOT NULL,
                                    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                    CONSTRAINT check_object_type CHECK (object_type IN ('nvr', 'cctv'))
);

-- Indexes
CREATE INDEX idx_floor_plan_objects_floor_plan ON floor_plan_objects(floor_plan_id);
CREATE INDEX idx_floor_plan_objects_object ON floor_plan_objects(object_type, object_id);
CREATE INDEX idx_floor_plan_objects_composite ON floor_plan_objects(floor_plan_id, object_type, object_id);
