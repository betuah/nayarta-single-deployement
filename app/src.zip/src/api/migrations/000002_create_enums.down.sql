DROP TYPE IF EXISTS public.user_status;
DROP TYPE IF EXISTS public.member_status;
DROP TYPE IF EXISTS public.group_status;
DROP TYPE IF EXISTS public.member_role;
DROP TYPE IF EXISTS public.cctv_status;
DROP TYPE IF EXISTS public.nvr_status;