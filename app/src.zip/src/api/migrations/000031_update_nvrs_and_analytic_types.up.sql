-- Make user_name unique in nvrs table
ALTER TABLE nvrs
    ADD CONSTRAINT uk_nvrs_user_name UNIQUE (user_name);

-- Add config field to analytic_types table
ALTER TABLE analytic_types
    ADD COLUMN config JSONB DEFAULT '{}'::jsonb NOT NULL;