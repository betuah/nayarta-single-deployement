-- Remove is_admin column from users table
ALTER TABLE public.users
    DROP COLUMN IF EXISTS is_admin;