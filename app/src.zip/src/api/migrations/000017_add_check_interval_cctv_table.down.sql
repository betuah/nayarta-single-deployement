ALTER TABLE cctvs
    DROP COLUMN check_interval