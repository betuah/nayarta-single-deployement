package main

import (
	"flag"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"vms-be/pkg/utils"
)

func main() {
	// Define command line flags
	outputDir := flag.String("output", "config/keys", "Directory to store the generated keys")
	privateKeyName := flag.String("private", "ec_private_key.pem", "Name of the private key file")
	publicKeyName := flag.String("public", "ec_public_key.pem", "Name of the public key file")
	flag.Parse()

	// Ensure output directory exists
	if err := os.MkdirAll(*outputDir, 0755); err != nil {
		log.Fatalf("Failed to create output directory: %v", err)
	}

	// Generate the EC key pair
	privateKey, err := utils.GenerateECKeys()
	if err != nil {
		log.Fatalf("Failed to generate EC keys: %v", err)
	}

	// Construct full file paths
	privateKeyPath := filepath.Join(*outputDir, *privateKeyName)
	publicKeyPath := filepath.Join(*outputDir, *publicKeyName)

	// Save the keys
	err = utils.SaveECKeys(privateKey, privateKeyPath, publicKeyPath)
	if err != nil {
		log.Fatalf("Failed to save EC keys: %v", err)
	}

	fmt.Printf("Successfully generated and saved EC keys:\n")
	fmt.Printf("Private key: %s\n", privateKeyPath)
	fmt.Printf("Public key: %s\n", publicKeyPath)
}
