package main

import (
	"log"
	"vms-be/config"
	"vms-be/internal/api/routes"
	"vms-be/pkg/database"
	"vms-be/pkg/logger"
)

// @title VMS API
// @version 1.0
// @description VMS API Spec & doc
// @host localhost:8080
// @BasePath /api/v1
// @servers.url=http://localhost:8080 description=Local environment
// @servers.url=http://146.190.211.126:8080 description=Staging environment
// @servers.url=https://api.tekno-tools.com description=Staging environment (hostname)
func main() {
	// Load configs
	loggerConfig, err := config.LoadLoggerConfig()
	if err != nil {
		log.Fatalf("Failed to initialize logger config: %v", err)
	}
	// Initialize logger
	appLogger := logger.NewLogger(loggerConfig)

	dbConfig, err := config.LoadDBConfig()
	if err != nil {
		appLogger.WithError(err).Fatal("Failed to initialize db config")
	}

	// load db

	db, err := database.NewDatabase(dbConfig)
	if err != nil {
		appLogger.WithError(err).Fatal("Failed to initialize database")
	}

	appLogger.Info("Database connection established")

	// Initialize router and services
	r, jobService := routes.SetupRouter(db)

	// Start the job scheduler
	scheduler, err := jobService.StartScheduler()
	if err != nil {
		appLogger.WithError(err).Fatal("Failed to start job scheduler")
	}
	defer func() {
		if err := scheduler.Shutdown(); err != nil {
			appLogger.WithError(err).Error("Failed to shutdown job scheduler")
		}
	}()

	appLogger.Info("Job scheduler started")

	// Run the server
	appLogger.Info("Server starting on port 8080")
	if err := r.Run(":8080"); err != nil {
		appLogger.WithError(err).Fatal("Failed to run server")
	}
}
