package main

import (
	"fmt"
	"log"
	"os"
	"os/exec"
)

func main() {
	// Command to run swag init
	cmd := exec.Command("swag", "init", "-g", "cmd/server/main.go", "-o", "./docs")

	// Capture the output
	output, err := cmd.CombinedOutput()
	if err != nil {
		log.Fatalf("Failed to generate Swagger docs: %v\nOutput: %s", err, output)
	}

	fmt.Println("Swagger documentation generated successfully.")

	// Check if docs.go was created/updated
	if _, err := os.Stat("./docs/docs.go"); os.IsNotExist(err) {
		log.Fatal("docs.go file was not created. Check your Swagger annotations.")
	}

	fmt.Println("docs.go has been updated.")
}
