### Install swag
```
go install github.com/swaggo/swag/cmd/swag@latest
```
### Run swag generator
```
go run cmd/swag/main.go
```