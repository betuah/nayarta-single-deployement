package main

import (
	"log"
	"vms-be/config"
	"vms-be/internal/models"
	"vms-be/pkg/database"

	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

func main() {
	// Initialize database connection
	dbConfig, err := config.LoadDBConfig()
	if err != nil {
		log.Fatalf("Failed to initialize db config: %v", err)
	}
	db, err := database.NewDatabase(dbConfig)
	if err != nil {
		log.Fatalf("Failed to initialize database: %v", err)
	}

	// Run seeder
	if err := seedData(db); err != nil {
		log.Fatalf("Failed to seed data: %v", err)
	}

	log.Println("Data seeding completed successfully")
}

func seedData(db *gorm.DB) error {
	// Seed Users
	users := []models.User{
		{
			ID:         uuid.New(),
			Email:      "user1@example.com",
			FullName:   "User One",
			Phone:      "1234567890",
			UserStatus: models.UserStatusActive,
		},
		{
			ID:         uuid.New(),
			Email:      "user2@example.com",
			FullName:   "User Two",
			Phone:      "0987654321",
			UserStatus: models.UserStatusActive,
		},
	}

	for i := range users {
		// Hash password
		hashedPassword, err := bcrypt.GenerateFromPassword([]byte("password"+string(rune(i+1))), bcrypt.DefaultCost)
		if err != nil {
			log.Printf("Failed to hash password: %v", err)
			return err
		}
		users[i].Password = string(hashedPassword)

		if err := db.Create(&users[i]).Error; err != nil {
			log.Printf("Failed to seed user: %v", err)
			return err
		}
	}

	// Seed Groups
	groups := []models.Group{
		{
			ID:          uuid.New(),
			GroupName:   "Company One",
			GroupStatus: models.GroupStatusActive,
		},
		{
			ID:          uuid.New(),
			GroupName:   "Company Two",
			GroupStatus: models.GroupStatusActive,
		},
	}

	for _, group := range groups {
		if err := db.Create(&group).Error; err != nil {
			log.Printf("Failed to seed group: %v", err)
			return err
		}
	}

	// Seed Members
	members := []models.Member{
		{
			ID:      uuid.New(),
			UserID:  users[0].ID,
			GroupID: groups[0].ID,
			Role:    models.MemberRoleAdmin,
			Status:  models.MemberStatusActive,
		},
		{
			ID:      uuid.New(),
			UserID:  users[1].ID,
			GroupID: groups[0].ID,
			Role:    models.MemberRoleMember,
			Status:  models.MemberStatusActive,
		},
		{
			ID:      uuid.New(),
			UserID:  users[0].ID,
			GroupID: groups[1].ID,
			Role:    models.MemberRoleMember,
			Status:  models.MemberStatusActive,
		},
	}

	for _, member := range members {
		if err := db.Create(&member).Error; err != nil {
			log.Printf("Failed to seed member: %v", err)
			return err
		}
	}

	return nil
}
