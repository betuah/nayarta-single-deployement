### RSA Key Generator

#### Compile:
```
build -o keygen cmd/keygen/main.go
```

#### Running:
```
./keygen -out ./config/keys -size 2048
```