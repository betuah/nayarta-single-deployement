package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"flag"
	"fmt"
	"os"
	"path/filepath"
)

func main() {
	var outputDir string
	var keySize int

	flag.StringVar(&outputDir, "out", ".", "Directory to save the key files")
	flag.IntVar(&keySize, "size", 2048, "Size of the RSA key in bits")
	flag.Parse()

	// Generate RSA key pair
	privateKey, err := rsa.GenerateKey(rand.Reader, keySize)
	if err != nil {
		fmt.Printf("Failed to generate private key: %v\n", err)
		os.Exit(1)
	}

	// Create output directory if it doesn't exist
	if err := os.MkdirAll(outputDir, 0755); err != nil {
		fmt.Printf("Failed to create output directory: %v\n", err)
		os.Exit(1)
	}

	// Save private key
	privateKeyPEM := &pem.Block{
		Type:  "RSA PRIVATE KEY",
		Bytes: x509.MarshalPKCS1PrivateKey(privateKey),
	}
	privateKeyFile := filepath.Join(outputDir, "private_key.pem")
	if err := pem.Encode(createFile(privateKeyFile), privateKeyPEM); err != nil {
		fmt.Printf("Failed to save private key: %v\n", err)
		os.Exit(1)
	}

	// Save public key
	publicKeyBytes, err := x509.MarshalPKIXPublicKey(&privateKey.PublicKey)
	if err != nil {
		fmt.Printf("Failed to marshal public key: %v\n", err)
		os.Exit(1)
	}
	publicKeyPEM := &pem.Block{
		Type:  "PUBLIC KEY",
		Bytes: publicKeyBytes,
	}
	publicKeyFile := filepath.Join(outputDir, "public_key.pem")
	if err := pem.Encode(createFile(publicKeyFile), publicKeyPEM); err != nil {
		fmt.Printf("Failed to save public key: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("RSA key pair generated successfully.\n")
	fmt.Printf("Private key saved to: %s\n", privateKeyFile)
	fmt.Printf("Public key saved to: %s\n", publicKeyFile)
}

func createFile(path string) *os.File {
	file, err := os.Create(path)
	if err != nil {
		fmt.Printf("Failed to create file %s: %v\n", path, err)
		os.Exit(1)
	}
	return file
}
