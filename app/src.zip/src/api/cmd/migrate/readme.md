### Up migrations
```cli
go run cmd/migrate/main.go up
```

### Down migrations
```cli
go run cmd/migrate/main.go down
```