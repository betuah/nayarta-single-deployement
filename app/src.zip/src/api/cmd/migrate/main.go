package main

import (
	"errors"
	"fmt"
	"log"
	"os"

	"github.com/golang-migrate/migrate/v4"
	_ "github.com/golang-migrate/migrate/v4/database/postgres"
	_ "github.com/golang-migrate/migrate/v4/source/file"
	"vms-be/config"
)

func main() {
	// Load database configuration
	dbConfig, err := config.LoadDBConfig()
	if err != nil {
		log.Fatalf("Failed to load database config: %v", err)
	}

	// Construct database URL
	dbURL := fmt.Sprintf("postgres://%s:%s@%s:%s/%s?sslmode=disable",
		dbConfig.DBUser, dbConfig.DBPassword, dbConfig.DBHost, dbConfig.DBPort, dbConfig.DBName)

	// Create a new migrate instance
	m, err := migrate.New(
		"file://migrations",
		dbURL,
	)
	if err != nil {
		log.Fatalf("Failed to create migrate instance: %v", err)
	}

	// Check command line arguments
	if len(os.Args) < 2 {
		log.Fatalf("Usage: %s up|down", os.Args[0])
	}

	// Perform migration based on command line argument
	switch os.Args[1] {
	case "up":
		if err := m.Up(); err != nil && !errors.Is(err, migrate.ErrNoChange) {
			log.Fatalf("Failed to apply up migrations: %v", err)
		}
		log.Println("Successfully applied up migrations")
	case "down":
		if err := m.Down(); err != nil && !errors.Is(err, migrate.ErrNoChange) {
			log.Fatalf("Failed to apply down migrations: %v", err)
		}
		log.Println("Successfully applied down migrations")
	default:
		log.Fatalf("Invalid command. Use 'up' or 'down'")
	}
}
