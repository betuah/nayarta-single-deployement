### Documentation
http://localhost:8080/api/v1/swagger/index.html

#### Build API Contracts for frontend
```
npx swagger-typescript-api -p ./doc.json -o ./src -n myApi.ts --axios --modular --unwrap-response-data --union-enums --module-name-first-tag --route-types --extract-request-params --extract-request-body --extract-response-body --extract-response-error
```