package config

import (
	"crypto/ecdsa"
	"crypto/rsa"
	"fmt"
	"os"
	"strconv"
	"strings"
	"vms-be/pkg/utils"

	"github.com/dgrijalva/jwt-go"
	"github.com/joho/godotenv"
)

type JWTConfig struct {
	JWTExpirationMinutes          int
	RefreshTokenExpirationMinutes int
	PrivateKey                    *rsa.PrivateKey
	PublicKey                     *rsa.PublicKey
	ECPrivateKey                  *ecdsa.PrivateKey
	ECPublicKey                   *ecdsa.PublicKey
}

type DBConfig struct {
	DBHost     string
	DBPort     string
	DBUser     string
	DBPassword string
	DBName     string
}

type ClickhouseConfig struct {
	Host     string
	Port     string
	User     string
	Password string
	Database string
	Secure   bool
}

type EmailConfig struct {
	SMTPHost     string
	SMTPPort     string
	SMTPUsername string
	SMTPPassword string
	FromEmail    string
}

type TelegramConfig struct {
	BotToken string
	BaseURL  string
}

type CommonConfig struct {
	BaseUrl     string
	HomePageUrl string
}

type ObjectStoreConfig struct {
	Endpoint        string
	Region          string
	AccessKeyID     string
	SecretAccessKey string
	DefaultBucket   string
	UseSSL          bool
	UsePathStyle    bool
	Provider        string
}

type LocalFileServeConfig struct {
	LocalFileBaseUrl string
	JWTSecret        string
}

type MQTTConfig struct {
	Host           string
	Port           string
	Username       string
	Password       string
	UseTLS         bool
	RetryInterval  int // seconds between retry attempts
	MaxRetries     int // maximum number of retry attempts
	ConnectTimeout int // seconds to wait for connection
}

type LoggerConfig struct {
	Level      string
	Format     string
	Output     string
	FilePath   string
	MaxSize    int
	MaxBackups int
	MaxAge     int
	Compress   bool
}

type APIKey struct {
	Key        string
	HolderName string
	OrgID      string // Optional
}

type APIKeyConfig struct {
	Keys []APIKey
}

type FaceSearchConfig struct {
	BaseURL string
}

type VLMUnderstandingConfig struct {
	BaseURL                  string
	APIKey                   string
	WebhookURL               string
	WebhookKey               string
	S3Endpoint               string
	StaleJobThresholdHours   int
	MaxConcurrentJobsPerFile int
}

func loadEnv() {
	missing := godotenv.Load() // Ignore the error if the .env file doesn't exist
	if missing != nil {
		fmt.Println("No .env file found")
	}
}

func getEnv(key, defaultValue string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return defaultValue
}

func LoadCommonConfig() (*CommonConfig, error) {
	loadEnv()
	return &CommonConfig{
		BaseUrl:     getEnv("BASE_URL", ""),
		HomePageUrl: getEnv("HOMEPAGE_URL", "https://app.beesar.id"),
	}, nil
}

func LoadFaceSearchConfig() (*FaceSearchConfig, error) {
	loadEnv()
	return &FaceSearchConfig{
		BaseURL: getEnv("FACE_SEARCH_BASE_URL", "https://faceapi.beesar.id"),
	}, nil
}

func LoadLocalFileServeConfig() (*LocalFileServeConfig, error) {
	loadEnv()
	return &LocalFileServeConfig{
		LocalFileBaseUrl: getEnv("LOCAL_FILE_PROVIDER_URL", ""),
		JWTSecret:        getEnv("LOCAL_FILE_JWT_SECRET", ""),
	}, nil
}

func LoadObjectStorageConfig() (*ObjectStoreConfig, error) {
	loadEnv()
	return &ObjectStoreConfig{
		Endpoint:        getEnv("OBJECT_STORAGE_ENDPOINT", ""),
		Region:          getEnv("OBJECT_STORAGE_REGION", ""),
		AccessKeyID:     getEnv("OBJECT_STORAGE_ACCESS_KEY_ID", ""),
		SecretAccessKey: getEnv("OBJECT_STORAGE_ACCESS_KEY_SECRET", ""),
		DefaultBucket:   getEnv("OBJECT_STORAGE_DEFAULT_BUCKET", ""),
		UseSSL:          getEnv("OBJECT_STORAGE_USE_SSL", "true") == "true",
		UsePathStyle:    getEnv("OBJECT_STORAGE_USE_PATH_STYLE", "true") == "true",
		Provider:        getEnv("OBJECT_STORAGE_PROVIDER", "s3-compat"),
	}, nil
}

func LoadEmailConfig() (*EmailConfig, error) {
	loadEnv()
	return &EmailConfig{
		SMTPHost:     getEnv("SMTP_HOST", ""),
		SMTPPort:     getEnv("SMTP_PORT", ""),
		SMTPUsername: getEnv("SMTP_USERNAME", ""),
		SMTPPassword: getEnv("SMTP_PASSWORD", ""),
		FromEmail:    getEnv("FROM_EMAIL", ""),
	}, nil
}

func LoadTelegramConfig() (*TelegramConfig, error) {
	loadEnv()
	return &TelegramConfig{
		BotToken: getEnv("TELEGRAM_BOT_TOKEN", "7636854041:AAG1Mg-dPPWO2XGhxXeCa9NNUcogetsLWK4"),
		BaseURL:  getEnv("TELEGRAM_API_BASE_URL", "https://api.telegram.org"),
	}, nil
}

func LoadVLMUnderstandingConfig() (*VLMUnderstandingConfig, error) {
	loadEnv()

	staleThreshold, _ := strconv.Atoi(getEnv("VLM_UNDERSTANDING_STALE_JOB_THRESHOLD_HOURS", "24"))
	maxConcurrent, _ := strconv.Atoi(getEnv("VLM_UNDERSTANDING_MAX_CONCURRENT_JOBS_PER_FILE", "1"))

	return &VLMUnderstandingConfig{
		BaseURL:                  getEnv("VLM_UNDERSTANDING_BASE_URL", "https://api.runpod.ai/v2/u7sur5qjoj386s"),
		APIKey:                   getEnv("VLM_UNDERSTANDING_API_KEY", ""),
		WebhookURL:               getEnv("VLM_UNDERSTANDING_WEBHOOK_URL", ""),
		WebhookKey:               getEnv("VLM_UNDERSTANDING_WEBHOOK_KEY", ""),
		S3Endpoint:               getEnv("VLM_UNDERSTANDING_S3_ENDPOINT", "https://sgp1.digitaloceanspaces.com"),
		StaleJobThresholdHours:   staleThreshold,
		MaxConcurrentJobsPerFile: maxConcurrent,
	}, nil
}

func LoadJWTConfig() (*JWTConfig, error) {
	loadEnv()

	jwtExpiration, _ := strconv.Atoi(getEnv("JWT_EXPIRATION_MINUTES", "0"))
	refreshTokenExpiration, _ := strconv.Atoi(getEnv("REFRESH_TOKEN_EXPIRATION_MINUTES", "0"))

	privateKeyPath := "./config/keys/private_key.pem"
	publicKeyPath := "./config/keys/public_key.pem"

	ECprivateKeyPath := "./config/keys/ec_private_key.pem"
	ECpublicKeyPath := "./config/keys/ec_public_key.pem"

	privateKeyPEM, err := os.ReadFile(privateKeyPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read private key: %v", err)
	}

	publicKeyPEM, err := os.ReadFile(publicKeyPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read public key: %v", err)
	}

	privateKey, err := jwt.ParseRSAPrivateKeyFromPEM(privateKeyPEM)
	if err != nil {
		return nil, fmt.Errorf("failed to parse private key: %v", err)
	}

	publicKey, err := utils.ParsePublicKeyFromPEM(publicKeyPEM)
	if err != nil {
		return nil, fmt.Errorf("failed to parse public key: %v", err)
	}

	ECprivateKey, err := utils.LoadECKeys(ECprivateKeyPath)
	if err != nil {
		return nil, fmt.Errorf("failed to parse private key: %v", err)
	}

	ECpublicKey, err := utils.LoadECPublicKey(ECpublicKeyPath)
	if err != nil {
		return nil, fmt.Errorf("failed to parse EC public key: %v", err)
	}

	return &JWTConfig{
		JWTExpirationMinutes:          jwtExpiration,
		RefreshTokenExpirationMinutes: refreshTokenExpiration,
		PrivateKey:                    privateKey,
		PublicKey:                     publicKey,
		ECPrivateKey:                  ECprivateKey,
		ECPublicKey:                   ECpublicKey,
	}, nil
}

func LoadDBConfig() (*DBConfig, error) {
	loadEnv()
	return &DBConfig{
		DBHost:     getEnv("DB_HOST", ""),
		DBPort:     getEnv("DB_PORT", ""),
		DBUser:     getEnv("DB_USER", ""),
		DBPassword: getEnv("DB_PASSWORD", ""),
		DBName:     getEnv("DB_NAME", ""),
	}, nil
}

func LoadClickhouseConfig() (*ClickhouseConfig, error) {
	loadEnv()
	secure := getEnv("CLICKHOUSE_SECURE", "true") == "true"
	return &ClickhouseConfig{
		Host:     getEnv("CLICKHOUSE_HOST", ""),
		Port:     getEnv("CLICKHOUSE_PORT", ""),
		User:     getEnv("CLICKHOUSE_USER", ""),
		Password: getEnv("CLICKHOUSE_PASSWORD", ""),
		Database: getEnv("CLICKHOUSE_DATABASE", ""),
		Secure:   secure,
	}, nil
}

func LoadLoggerConfig() (*LoggerConfig, error) {
	loadEnv()

	maxSize, _ := strconv.Atoi(getEnv("LOG_MAX_SIZE", "100"))
	maxBackups, _ := strconv.Atoi(getEnv("LOG_MAX_BACKUPS", "3"))
	maxAge, _ := strconv.Atoi(getEnv("LOG_MAX_AGE", "28"))
	compress := getEnv("LOG_COMPRESS", "true") == "true"

	return &LoggerConfig{
		Level:      getEnv("LOG_LEVEL", "info"),
		Format:     getEnv("LOG_FORMAT", "json"),
		Output:     getEnv("LOG_OUTPUT", "stdout"),
		FilePath:   getEnv("LOG_FILE_PATH", "./logs/app.log"),
		MaxSize:    maxSize,
		MaxBackups: maxBackups,
		MaxAge:     maxAge,
		Compress:   compress,
	}, nil
}

func LoadAPIKeyConfig() (*APIKeyConfig, error) {
	loadEnv()

	// Get the API keys from environment variable
	apiKeysStr := getEnv("API_KEYS", "")
	if apiKeysStr == "" {
		return &APIKeyConfig{Keys: []APIKey{}}, nil
	}

	// Parse API keys from environment variable
	// Format: key1:holder1:orgId1,key2:holder2,key3:holder3:orgId3
	keys := strings.Split(apiKeysStr, ",")
	apiKeys := make([]APIKey, 0, len(keys))

	for _, k := range keys {
		parts := strings.Split(k, ":")
		if len(parts) < 2 {
			continue
		}

		apiKey := APIKey{
			Key:        parts[0],
			HolderName: parts[1],
		}

		if len(parts) > 2 {
			apiKey.OrgID = parts[2]
		}

		apiKeys = append(apiKeys, apiKey)
	}

	return &APIKeyConfig{Keys: apiKeys}, nil
}

func LoadMQTTConfig() (*MQTTConfig, error) {
	loadEnv()
	RetryIntervalVal, _ := strconv.Atoi(getEnv("MQTT_RETRY_INTERVAL", "5"))
	MaxRetriesVal, _ := strconv.Atoi(getEnv("MQTT_MAX_RETRIES", "3"))
	ConnectTimeoutVal, _ := strconv.Atoi(getEnv("MQTT_CONNECT_TIMEOUT", "10"))
	return &MQTTConfig{
		Host:           getEnv("MQTT_HOST", "broker.emqx.io"),
		Port:           getEnv("MQTT_PORT", "1883"),
		Username:       getEnv("MQTT_USERNAME", ""),
		Password:       getEnv("MQTT_PASSWORD", ""),
		UseTLS:         getEnv("MQTT_TLS", "false") == "true",
		RetryInterval:  RetryIntervalVal,
		MaxRetries:     MaxRetriesVal,
		ConnectTimeout: ConnectTimeoutVal,
	}, nil
}
