package models

import (
	"github.com/google/uuid"
	"time"
)

type CCTVAnalytic struct {
	ID             uuid.UUID            `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	AnalyticTypeID uuid.UUID            `gorm:"type:uuid;not null;column:analytic_type_id"`
	CCTVID         uuid.UUID            `gorm:"type:uuid;not null;column:cctv_id"`
	Enable         bool                 `gorm:"type:boolean;not null;default:true;column:status"`
	CreatedAt      time.Time            `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt      time.Time            `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	AnalyticType   AnalyticType         `gorm:"foreignKey:AnalyticTypeID"`
	CCTV           CCTV                 `gorm:"foreignKey:CCTVID"`
	AlertSettings  []MemberAlertSetting `gorm:"foreignKey:CCTVAnalyticID"`
	Analytics      []Analytic           `gorm:"foreignKey:CCTVAnalyticID"`
	Alerts         []Alert              `gorm:"foreignKey:CCTVAnalyticID"`
}

func (CCTVAnalytic) TableName() string {
	return "public.cctv_analytics"
}

type CCTVAnalyticSearchParams struct {
	Search    string `form:"search"`
	SortBy    string `form:"sort_by"`
	SortOrder string `form:"sort_order"`
}
