package models

import (
	"encoding/json"
	"github.com/google/uuid"
	"time"
)

type FileAnalyticProcess struct {
	ID             uuid.UUID       `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	FileID         uuid.UUID       `gorm:"type:uuid;not null;column:file_id"`
	AnalyticTypeID uuid.UUID       `gorm:"type:uuid;not null;column:analytic_type_id"`
	ProcessedAt    time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:processed_at"`
	Status         string          `gorm:"type:varchar(255);not null;default:'completed';column:status"`
	Metadata       json.RawMessage `gorm:"type:jsonb;not null;default:'{}';column:metadata"`
	CreatedAt      time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt      time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	File           File            `gorm:"foreignKey:FileID"`
	AnalyticType   AnalyticType    `gorm:"foreignKey:AnalyticTypeID"`
}

func (FileAnalyticProcess) TableName() string {
	return "file_analytic_processes"
}
