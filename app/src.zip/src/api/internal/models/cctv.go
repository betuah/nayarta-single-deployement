package models

import (
	"github.com/google/uuid"
	"time"
)

type CctvStatus string

const (
	CctvStatusOnline  = "online"
	CctvStatusOffline = "offline"
	CctvStatusAlert   = "alert"
)

type CCTV struct {
	ID                uuid.UUID              `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	NVRID             uuid.UUID              `gorm:"type:uuid;not null;column:nvr_id"`
	Name              string                 `gorm:"type:varchar(255);not null;column:name"`
	Description       string                 `gorm:"type:text;not null;column:description"`
	SnapshotImage     string                 `gorm:"type:varchar(255);column:snapshot_image"`
	Brand             string                 `gorm:"type:varchar(255);not null;column:brand"`
	Type              string                 `gorm:"type:varchar(255);not null;column:type"`
	Hostname          string                 `gorm:"type:varchar(255);not null;column:hostname"`
	Protocol          string                 `gorm:"type:varchar(255);not null;column:protocol;default:rtsp"`
	Port              int                    `gorm:"type:integer;not null;column:port"`
	UserName          string                 `gorm:"type:varchar(255);not null;column:username"`
	Password          string                 `gorm:"type:text;not null;column:password"`
	CheckInterval     int                    `gorm:"not null;default:5;column:check_interval"`
	LastUptimeStart   *time.Time             `gorm:"column:last_uptime_start"`
	Status            string                 `gorm:"type:app.cctv_status;not null;default:'offline';column:status"`
	LastChecked       time.Time              `gorm:"not null;default:CURRENT_TIMESTAMP;column:last_checked"`
	CreatedAt         time.Time              `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt         time.Time              `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	NVR               NVR                    `gorm:"foreignKey:NVRID"`
	Files             []File                 `gorm:"foreignKey:CCTVID;constraint:OnDelete:CASCADE"`
	CCTVAnalytics     []CCTVAnalytic         `gorm:"foreignKey:CCTVID;constraint:OnDelete:CASCADE"`
	Path              string                 `gorm:"not null;column:path"`
	PTZSupport        bool                   `gorm:"not null;default:false;column:ptz_support"`
	RecordingSchedule *CCTVRecordingSchedule `gorm:"foreignKey:CCTVID"`
	RecordingStatus   int                    `gorm:"not null;default:0;column:recording_status"` // 0 = not recording, 1 = recording, -1 = recording error
	FloorPlanObjects  []FloorPlanObject      `gorm:"foreignKey:ObjectID;constraint:OnDelete:CASCADE" gorm:"where:object_type = 'cctv'"`
}

func (CCTV) TableName() string {
	return "public.cctvs"
}

type CCTVSearchParams struct {
	Search    string     `form:"search"`
	NVRID     uuid.UUID  `form:"nvr_id"`
	Brand     string     `form:"brand"`
	Type      string     `form:"type"`
	Status    string     `form:"status"`
	StartDate *time.Time `form:"start_date" swagger:"string" format:"date-time"`
	EndDate   *time.Time `form:"end_date" swagger:"string" format:"date-time"`
	Page      int        `form:"page,default=1"`
	Size      int        `form:"size,default=10"`
	SortBy    string     `form:"sort_by"`
	SortOrder string     `form:"sort_order"`
}
