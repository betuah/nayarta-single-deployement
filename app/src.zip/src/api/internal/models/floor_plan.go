package models

import (
	"github.com/google/uuid"
	"time"
)

type FloorPlan struct {
	ID              uuid.UUID `gorm:"type:uuid;primary_key;default:gen_random_uuid()"`
	LocationID      uuid.UUID `gorm:"type:uuid;not null"`
	Name            string    `gorm:"type:varchar(255);not null"`
	ImageURL        string    `gorm:"type:varchar(255);not null"`
	DimensionWidth  int       `gorm:"type:integer;not null"`
	DimensionHeight int       `gorm:"type:integer;not null"`
	CreatedAt       time.Time `gorm:"default:CURRENT_TIMESTAMP"`
	UpdatedAt       time.Time `gorm:"default:CURRENT_TIMESTAMP"`

	// Relationships
	Location         Location          `gorm:"foreignkey:LocationID"`
	FloorPlanObjects []FloorPlanObject `gorm:"foreignkey:FloorPlanID"`
}
