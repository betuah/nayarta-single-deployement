package models

import (
	"github.com/lib/pq"
	"time"

	"github.com/google/uuid"
)

type CCTVRecordingSchedule struct {
	ID            uuid.UUID     `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	CCTVID        uuid.UUID     `gorm:"type:uuid;not null;column:cctv_id"`
	EnabledHours  pq.Int64Array `gorm:"type:integer[];column:enabled_hours"`
	RetentionDays int           `gorm:"not null;default:30;column:retention_days"`
	CreatedAt     time.Time     `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt     time.Time     `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	CCTV          CCTV          `gorm:"foreignKey:CCTVID"`
}
