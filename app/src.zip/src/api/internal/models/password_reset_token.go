package models

import (
	"time"

	"github.com/google/uuid"
)

type PasswordResetToken struct {
	ID        uuid.UUID `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	UserID    uuid.UUID `gorm:"type:uuid;not null;column:user_id"`
	Token     string    `gorm:"type:varchar(255);not null;column:token"`
	ExpiresAt time.Time `gorm:"type:timestamp with time zone;not null;column:expires_at"`
	CreatedAt time.Time `gorm:"type:timestamp with time zone;default:current_timestamp;column:created_at"`
	UpdatedAt time.Time `gorm:"type:timestamp with time zone;default:current_timestamp;column:updated_at"`
}

func (PasswordResetToken) TableName() string {
	return "public.password_reset_tokens"
}
