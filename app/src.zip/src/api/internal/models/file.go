package models

import (
	"encoding/json"
	"github.com/google/uuid"
	"time"
)

type FileType string

type Provider string

const (
	ProviderLocal         Provider = "local"
	ProviderObjectStorage Provider = "object_storage"
)

const (
	FileTypeImage FileType = "image"
	FileTypeSound FileType = "sound"
	FileTypeVideo FileType = "video"
)

type File struct {
	ID              uuid.UUID       `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	CCTVID          uuid.UUID       `gorm:"type:uuid;not null;column:cctv_id"`
	SnapshotImage   *string         `gorm:"type:varchar(255);column:snapshot_image"`
	FileType        FileType        `gorm:"type:varchar(255);not null;column:file_type"`
	FileName        string          `gorm:"type:varchar(255);not null;column:file_name"`
	FileURL         string          `gorm:"type:varchar(255);not null;column:file_url"`
	Size            float64         `gorm:"type:float;not null;default:0;column:size"`
	CreatedAt       time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt       time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	CCTV            CCTV            `gorm:"foreignKey:CCTVID"`
	Provider        *Provider       `gorm:"type:varchar(255);column:provider;default:object_storage"`
	Analytics       []Analytic      `gorm:"foreignKey:FileID"`
	AnalyticProcess bool            `gorm:"type:boolean;not null;default:false;column:analytic_process"`
	Metadata        json.RawMessage `gorm:"type:jsonb;not null;default:'{}';column:metadata"`
}

func (File) TableName() string {
	return "public.files"
}

type FileSearchParams struct {
	Search          string      `form:"search"`
	CCTVID          *uuid.UUID  `form:"cctv_id"`
	GroupID         uuid.UUID   `form:"-"`
	FileType        FileType    `form:"file_type"`
	StartDate       *time.Time  `form:"start_date" swagger:"string" format:"date-time"`
	EndDate         *time.Time  `form:"end_date" swagger:"string" format:"date-time"`
	AnalyticProcess *bool       `form:"analytic_process"`
	AnalyticTypeIDs []uuid.UUID `form:"analytic_type_ids"`
	LocationID      *uuid.UUID  `form:"location_id"`
	FloorPlanID     *uuid.UUID  `form:"floor_plan_id"`
	Page            int         `form:"page,default=1"`
	Size            int         `form:"size,default=10"`
	SortBy          string      `form:"sort_by"`
	SortOrder       string      `form:"sort_order"`
}
