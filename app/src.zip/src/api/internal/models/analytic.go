package models

import (
	"github.com/google/uuid"
	"time"
)

type Analytic struct {
	ID             uuid.UUID    `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	FileID         uuid.UUID    `gorm:"type:uuid;not null;column:file_id"`
	CCTVAnalyticID uuid.UUID    `gorm:"type:uuid;not null;column:cctv_analytic_id"`
	CreatedAt      time.Time    `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt      time.Time    `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	File           File         `gorm:"foreignKey:FileID"`
	CCTVAnalytic   CCTVAnalytic `gorm:"foreignKey:CCTVAnalyticID"`
	Alerts         []Alert      `gorm:"foreignKey:AnalyticID"`
}

func (Analytic) TableName() string {
	return "public.analytics"
}

type AnalyticSearchParams struct {
	Search    string     `json:"search"`
	CCTVID    *uuid.UUID `json:"cctv_id"`
	NVRID     *uuid.UUID `json:"nvr_id"`
	GroupID   uuid.UUID  `json:"group_id"`
	StartDate *time.Time `json:"start_date"`
	EndDate   *time.Time `json:"end_date"`
	Page      int        `json:"page"`
	Size      int        `json:"size"`
	SortBy    string     `json:"sort_by"`
	SortOrder string     `json:"sort_order"`
}

type AnalyticReportSearchParams struct {
	GroupID      uuid.UUID  `json:"group_id"`
	StartDate    *time.Time `json:"start_date"`
	EndDate      *time.Time `json:"end_date"`
	AnalyticType string     `json:"analytic_type"`
	Search       string     `json:"search"`
	SortBy       string     `json:"sort_by"`
	SortOrder    string     `json:"sort_order"`
	Page         int        `json:"page"`
	Size         int        `json:"size"`
}

type AnalyticNotificationSearchParams struct {
	GroupID      uuid.UUID  `json:"group_id"`
	MemberID     uuid.UUID  `json:"member_id"`
	StartDate    *time.Time `json:"start_date"`
	EndDate      *time.Time `json:"end_date"`
	AnalyticType string     `json:"analytic_type"`
	Search       string     `json:"search"`
	SortBy       string     `json:"sort_by"`
	SortOrder    string     `json:"sort_order"`
	Page         int        `json:"page"`
	Size         int        `json:"size"`
}
