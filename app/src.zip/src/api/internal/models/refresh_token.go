package models

import (
	"time"

	"github.com/google/uuid"
)

type RefreshToken struct {
	ID        uuid.UUID `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	UserID    uuid.UUID `gorm:"type:uuid;not null;column:user_id"`
	Token     string    `gorm:"type:varchar(255);not null;unique;column:token"`
	ExpiresAt time.Time `gorm:"not null;column:expires_at"`
	CreatedAt time.Time `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt time.Time `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	User      User      `gorm:"foreignKey:UserID"`
}

func (RefreshToken) TableName() string {
	return "public.refresh_tokens"
}
