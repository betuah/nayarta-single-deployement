package models

import (
	"github.com/google/uuid"
	"time"
)

type FloorPlanObject struct {
	ID          uuid.UUID `gorm:"type:uuid;primary_key;default:gen_random_uuid()"`
	FloorPlanID uuid.UUID `gorm:"type:uuid;not null"`
	ObjectType  string    `gorm:"type:varchar(10);not null"`
	ObjectID    uuid.UUID `gorm:"type:uuid;not null"`
	PositionX   float64   `gorm:"type:double precision;not null"`
	PositionY   float64   `gorm:"type:double precision;not null"`
	CreatedAt   time.Time `gorm:"default:CURRENT_TIMESTAMP"`
	UpdatedAt   time.Time `gorm:"default:CURRENT_TIMESTAMP"`

	// Relationships
	FloorPlan FloorPlan `gorm:"foreignkey:FloorPlanID"`
}
