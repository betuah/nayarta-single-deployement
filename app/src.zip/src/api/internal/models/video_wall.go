package models

import (
	"github.com/google/uuid"
	"github.com/lib/pq"
	"time"
)

type VideoWall struct {
	ID        uuid.UUID      `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	Name      string         `gorm:"type:varchar(255);not null;column:name"`
	Layout    string         `gorm:"type:varchar(255);not null;column:layout"`
	GroupID   uuid.UUID      `gorm:"type:uuid;not null;column:group_id"`
	CCTVList  pq.StringArray `gorm:"type:text[];not null;default:'{}';column:cctv_list"`
	CreatedAt time.Time      `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt time.Time      `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	Group     Group          `gorm:"foreignKey:GroupID"`
}

func (VideoWall) TableName() string {
	return "public.video_walls"
}

type VideoWallSearchParams struct {
	Search string `form:"search"`
	Page   int    `form:"page,default=1"`
	Size   int    `form:"size,default=10"`
}
