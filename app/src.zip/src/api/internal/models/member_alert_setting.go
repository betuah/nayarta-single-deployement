package models

import "github.com/google/uuid"

type MemberAlertSetting struct {
	ID             uuid.UUID    `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	MemberID       uuid.UUID    `gorm:"type:uuid;not null;column:member_id"`
	CCTVAnalyticID uuid.UUID    `gorm:"type:uuid;not null;column:cctv_analytic_id"`
	Enabled        bool         `gorm:"type:boolean;not null;default:true;column:enabled"`
	Member         Member       `gorm:"foreignKey:MemberID"`
	CCTVAnalytic   CCTVAnalytic `gorm:"foreignKey:CCTVAnalyticID"`
}

func (MemberAlertSetting) TableName() string {
	return "public.member_alert_settings"
}

type MemberAlertSettingSearchParams struct {
	CCTVID uuid.UUID `form:"cctv_id"`
}
