package models

import (
	"github.com/google/uuid"
	"time"
)

type Alert struct {
	ID             uuid.UUID     `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	AnalyticID     *uuid.UUID    `gorm:"type:uuid;not null;column:analytic_id"`
	Message        string        `gorm:"type:text;not null;default:'-';column:message"`
	MemberID       *uuid.UUID    `gorm:"type:uuid;column:member_id"`
	CreatedAt      time.Time     `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt      time.Time     `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	CCTVAnalyticID *uuid.UUID    `gorm:"type:uuid;not null;column:cctv_analytic_id"`
	Analytic       *Analytic     `gorm:"foreignKey:AnalyticID"`
	Member         Member        `gorm:"foreignKey:MemberID"`
	CCTVAnalytic   *CCTVAnalytic `gorm:"foreignKey:CCTVAnalyticID"`
}

func (Alert) TableName() string {
	return "public.alerts"
}

type AlertSearchParams struct {
	MemberID       uuid.UUID  `form:"member_id"`
	CCTVID         uuid.UUID  `form:"cctv_id"`
	CCTVAnalyticID uuid.UUID  `form:"cctv_analytic_id"`
	Page           int        `form:"page,default=1"`
	Size           int        `form:"size,default=10"`
	Search         string     `form:"search"`
	AnalyticType   string     `form:"analytic_type"`
	StartDate      *time.Time `form:"start_date"`
	EndDate        *time.Time `form:"end_date"`
	SortBy         string     `form:"sort_by"`
	SortOrder      string     `form:"sort_order"`
}
