package models

import (
	"github.com/google/uuid"
	"time"
)

type MemberRole string
type MemberStatus string

const (
	MemberStatusPending  = "pending"
	MemberStatusActive   = "active"
	MemberStatusBanned   = "banned"
	MemberStatusDisabled = "disabled"
)

const (
	MemberRoleAdmin  = "admin"
	MemberRoleMember = "member"
)

type Member struct {
	ID            uuid.UUID            `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	UserID        uuid.UUID            `gorm:"type:uuid;not null;column:user_id"`
	GroupID       uuid.UUID            `gorm:"type:uuid;not null;column:group_id"`
	Role          string               `gorm:"type:app.member_role;not null;default:'member';column:role"`
	Status        string               `gorm:"type:app.member_status;not null;default:'pending';column:status"`
	CreatedAt     time.Time            `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt     time.Time            `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	User          User                 `gorm:"foreignKey:UserID"`
	Group         Group                `gorm:"foreignKey:GroupID"`
	AlertSettings []MemberAlertSetting `gorm:"foreignKey:MemberID"`
	Alerts        []Alert              `gorm:"foreignKey:MemberID"`
}

func (Member) TableName() string {
	return "public.members"
}

type MemberSearchParams struct {
	Search    string     `form:"search"`
	GroupID   uuid.UUID  `form:"group_id"`
	Role      string     `form:"role"`
	Status    string     `form:"status"`
	StartDate *time.Time `form:"start_date" swagger:"string" format:"date-time"`
	EndDate   *time.Time `form:"end_date" swagger:"string" format:"date-time"`
	Page      int        `form:"page,default=1"`
	Size      int        `form:"size,default=10"`
	SortBy    string     `form:"sort_by"`
	SortOrder string     `form:"sort_order"`
}
