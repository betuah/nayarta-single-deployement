package models

import (
	"time"

	"github.com/google/uuid"
)

type StreamURL struct {
	ID        uuid.UUID `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	CCTVID    uuid.UUID `gorm:"type:uuid;not null;column:cctv_id"`
	Protocol  string    `gorm:"type:varchar(255);not null;column:protocol"`
	Hostname  string    `gorm:"type:varchar(255);not null;column:hostname"`
	Port      int       `gorm:"not null;column:port"`
	Username  string    `gorm:"type:varchar(255);not null;default:'';column:username"`
	Title     string    `gorm:"type:varchar(255);not null;default:'';column:title"`
	Password  string    `gorm:"type:text;not null;default:'';column:password"`
	Path      string    `gorm:"type:text;not null;column:path"`
	CreatedAt time.Time `gorm:"default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt time.Time `gorm:"default:CURRENT_TIMESTAMP;column:updated_at"`
	// Relationships
	CCTV CCTV `gorm:"foreignKey:CCTVID"`
}

func (StreamURL) TableName() string {
	return "public.stream_urls"
}
