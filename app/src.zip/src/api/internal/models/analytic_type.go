package models

import (
	"encoding/json"
	"github.com/google/uuid"
	"time"
)

type AnalyticType struct {
	ID            uuid.UUID       `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	Name          string          `gorm:"type:varchar(255);not null;column:name"`
	Description   string          `gorm:"type:text;not null;column:description"`
	CreatedAt     time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt     time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	CCTVAnalytics []CCTVAnalytic  `gorm:"foreignKey:AnalyticTypeID"`
	Config        json.RawMessage `gorm:"type:jsonb;not null;default:'{}';column:config"`
}

func (AnalyticType) TableName() string {
	return "public.analytic_types"
}
