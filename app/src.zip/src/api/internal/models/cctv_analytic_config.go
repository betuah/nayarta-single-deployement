package models

import "time"

import (
	"encoding/json"
	"github.com/google/uuid"
)

type CCTVAnalyticConfig struct {
	ID             uuid.UUID       `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	CCTVAnalyticID uuid.UUID       `gorm:"type:uuid;not null;uniqueIndex;column:cctv_analytic_id"`
	Config         json.RawMessage `gorm:"type:jsonb;not null;default:'{}';column:config"`
	CreatedAt      time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt      time.Time       `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	CCTVAnalytic   CCTVAnalytic    `gorm:"foreignKey:CCTVAnalyticID"`
}
