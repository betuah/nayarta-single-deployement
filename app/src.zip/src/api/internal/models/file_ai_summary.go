package models

import (
	"encoding/json"
	"github.com/google/uuid"
	"gorm.io/gorm"
	"time"
)

type FileAISummaryStatus string

const (
	FileAISummaryStatusInQueue    FileAISummaryStatus = "in_queue"
	FileAISummaryStatusInProgress FileAISummaryStatus = "in_progress"
	FileAISummaryStatusCompleted  FileAISummaryStatus = "completed"
	FileAISummaryStatusFailed     FileAISummaryStatus = "failed"
	FileAISummaryStatusTimedOut   FileAISummaryStatus = "timed_out"
	FileAISummaryStatusStale      FileAISummaryStatus = "stale"
)

type FileAISummary struct {
	ID           uuid.UUID           `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	FileID       uuid.UUID           `gorm:"type:uuid;not null;column:file_id"`
	UserID       uuid.UUID           `gorm:"type:uuid;not null;column:user_id"`
	CustomPrompt string              `gorm:"type:text;not null;column:custom_prompt"`
	JobID        string              `gorm:"type:varchar(255);not null;column:job_id"`
	Status       FileAISummaryStatus `gorm:"type:file_ai_summary_status;not null;default:in_queue;column:status"`
	OutputResult json.RawMessage     `gorm:"type:jsonb;default:'{}';column:output_result"`
	ErrorMessage *string             `gorm:"type:text;column:error_message"`
	CreatedAt    time.Time           `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt    time.Time           `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	CompletedAt  *time.Time          `gorm:"column:completed_at"`
	File         File                `gorm:"foreignKey:FileID"`
	User         User                `gorm:"foreignKey:UserID"`
}

func (f *FileAISummary) TableName() string {
	return "public.file_ai_summaries"
}

func (f *FileAISummary) BeforeCreate(tx *gorm.DB) error {
	now := time.Now().UTC()
	f.CreatedAt = now
	f.UpdatedAt = now
	return nil
}

func (f *FileAISummary) BeforeUpdate(tx *gorm.DB) error {
	f.UpdatedAt = time.Now().UTC()
	return nil
}
