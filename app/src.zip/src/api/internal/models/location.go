package models

import (
	"github.com/google/uuid"
	"time"
)

type Location struct {
	ID              uuid.UUID   `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	LocationName    string      `gorm:"type:varchar(255);not null;column:location_name"`
	Latitude        float64     `gorm:"type:float;not null;column:latitude"`
	Longitude       float64     `gorm:"type:float;not null;column:longitude"`
	ImageURL        *string     `gorm:"type:varchar(255);column:image_url"`
	Address         string      `gorm:"type:text;not null;column:address"`
	CreatedAt       time.Time   `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt       time.Time   `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	CreatedBy       uuid.UUID   `gorm:"type:uuid;not null;column:created_by"`
	GroupID         uuid.UUID   `gorm:"type:uuid;not null;column:group_id"`
	NVRs            []NVR       `gorm:"foreignKey:LocationID"`
	User            User        `gorm:"foreignKey:CreatedBy"`
	Group           Group       `gorm:"foreignKey:GroupID"`
	FloorPlans      []FloorPlan `gorm:"foreignKey:LocationID"`
	TotalNVRs       int         `gorm:"-"`
	TotalCCTVs      int         `gorm:"-"`
	TotalFloorPlans int         `gorm:"-"`
}

func (Location) TableName() string {
	return "public.locations"
}

type LocationSearchParams struct {
	Search    string `form:"search"`
	Page      int    `form:"page,default=1"`
	Size      int    `form:"size,default=10"`
	SortBy    string `form:"sort_by"`
	SortOrder string `form:"sort_order"`
}
