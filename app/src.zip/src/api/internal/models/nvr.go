package models

import (
	"github.com/google/uuid"
	"time"
)

type NvrStatus string

const (
	NvrStatusOnline  = "online"
	NvrStatusOffline = "offline"
)

type NVR struct {
	ID            uuid.UUID  `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	GroupID       uuid.UUID  `gorm:"type:uuid;not null;column:group_id"`
	LocationID    uuid.UUID  `gorm:"type:uuid;not null;column:location_id"`
	Name          string     `gorm:"type:varchar(255);not null;column:name"`
	Description   string     `gorm:"type:text;not null;column:description"`
	Version       string     `gorm:"type:varchar(255);default:'n/a';column:version"`
	Hostname      string     `gorm:"type:varchar(255);not null;column:hostname"`
	Port          int        `gorm:"type:integer;not null;column:port"`
	UserName      string     `gorm:"type:varchar(255);not null;uniqueIndex;column:user_name"`
	Password      string     `gorm:"type:varchar(255);not null;column:password"`
	Status        string     `gorm:"type:app.nvr_status;not null;default:'offline';column:status"`
	LastChecked   *time.Time `gorm:"default:CURRENT_TIMESTAMP;column:last_checked"`
	Token         string     `gorm:"type:varchar(255);column:token"`
	CheckInterval int        `gorm:"type:integer;not null;default:5;column:check_interval"`
	CreatedAt     time.Time  `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt     time.Time  `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	CreatedBy     uuid.UUID  `gorm:"type:uuid;not null;column:created_by"`
	Group         Group      `gorm:"foreignKey:GroupID"`
	User          User       `gorm:"foreignKey:CreatedBy"`
	Location      Location   `gorm:"foreignKey:LocationID"`
	CCTVs         []CCTV     `gorm:"foreignKey:NVRID"`
}

func (NVR) TableName() string {
	return "public.nvrs"
}

type NVRSearchParams struct {
	Search     string     `form:"search"`
	GroupID    uuid.UUID  `form:"group_id"`
	LocationID uuid.UUID  `form:"location_id"`
	Status     string     `form:"status"`
	StartDate  *time.Time `form:"start_date" swagger:"string" format:"date-time"`
	EndDate    *time.Time `form:"end_date" swagger:"string" format:"date-time"`
	Page       int        `form:"page,default=1"`
	Size       int        `form:"size,default=10"`
	SortBy     string     `form:"sort_by"`
	SortOrder  string     `form:"sort_order"`
}
