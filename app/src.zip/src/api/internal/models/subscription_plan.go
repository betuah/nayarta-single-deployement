package models

import (
	"github.com/google/uuid"
	"github.com/lib/pq"
	"time"
)

type SubscriptionPlan struct {
	ID               uuid.UUID      `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	Name             string         `gorm:"type:varchar(255);not null;unique;column:name"`
	DisplayName      string         `gorm:"type:varchar(255);not null;column:display_name"`
	Description      *string        `gorm:"type:text;column:description"`
	MaxCameras       int            `gorm:"type:integer;not null;default:0;column:max_cameras"`
	MaxNVRs          int            `gorm:"type:integer;not null;default:0;column:max_nvrs"`
	MaxLocations     int            `gorm:"type:integer;not null;default:0;column:max_locations"`
	MaxMembers       int            `gorm:"type:integer;not null;default:0;column:max_members"`
	MaxFloorPlans    int            `gorm:"type:integer;not null;default:0;column:max_floor_plans"`
	MaxStorage       float64        `gorm:"type:double precision;not null;default:0;column:max_storage"`
	Analytics        pq.StringArray `gorm:"type:text[];column:analytics"`
	DesktopAppAccess bool           `gorm:"type:boolean;not null;default:false;column:desktop_app_access"`
	PrioritySupport  bool           `gorm:"type:boolean;not null;default:false;column:priority_support"`
	PriceMonthly     *float64       `gorm:"type:decimal(10,2);column:price_monthly"`
	PriceYearly      *float64       `gorm:"type:decimal(10,2);column:price_yearly"`
	IsActive         bool           `gorm:"type:boolean;not null;default:true;column:is_active"`
	CreatedAt        time.Time      `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt        time.Time      `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	Groups           []Group        `gorm:"foreignKey:SubscriptionPlanID"`
}

func (SubscriptionPlan) TableName() string {
	return "public.subscription_plans"
}
