package models

import (
	"github.com/google/uuid"
	"time"
)

const (
	GroupStatusPending  = "pending"
	GroupStatusActive   = "active"
	GroupStatusBanned   = "banned"
	GroupStatusDisabled = "disabled"
	GroupStatusInactive = "inactive"
)

type Group struct {
	ID                               uuid.UUID         `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	GroupName                        string            `gorm:"type:varchar(255);not null;column:group_name"`
	GroupStatus                      string            `gorm:"type:app.group_status;not null;default:'pending';column:group_status"`
	StorageSize                      float64           `gorm:"type:float;column:storage_size"`
	StorageUsed                      float64           `gorm:"type:float;column:storage_used"`
	StorageNotificationThreshold     int               `gorm:"type:integer;not null;default:80;column:storage_notification_threshold"`
	LastStorageNotificationSentAt    *time.Time        `gorm:"type:timestamp with time zone;column:last_storage_notification_sent_at"`
	ActiveUntil                      time.Time         `gorm:"type:timestamp with time zone;not null;default:NOW();column:active_until"`
	LastExpirationNotificationSentAt *time.Time        `gorm:"type:timestamp with time zone;column:last_expiration_notification_sent_at"`
	SubscriptionPlanID               *uuid.UUID        `gorm:"type:uuid;column:subscription_plan_id"`
	CreatedAt                        time.Time         `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt                        time.Time         `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	Email                            *string           `gorm:"type:varchar(255);column:email"`
	CreatedBy                        *uuid.UUID        `gorm:"type:uuid;column:created_by"`
	CreatedByUser                    *User             `gorm:"foreignKey:CreatedBy"`
	SubscriptionPlan                 *SubscriptionPlan `gorm:"foreignKey:SubscriptionPlanID"`
	Members                          []Member          `gorm:"foreignKey:GroupID"`
	NVRs                             []NVR             `gorm:"foreignKey:GroupID"`
}

func (Group) TableName() string {
	return "public.groups"
}
