package models

import (
	"github.com/google/uuid"
	"time"
)

const (
	UserStatusPending  = "pending"
	UserStatusActive   = "active"
	UserStatusBanned   = "banned"
	UserStatusDisabled = "disabled"
)

type User struct {
	ID                              uuid.UUID      `gorm:"type:uuid;primary_key;default:gen_random_uuid();column:id"`
	Email                           string         `gorm:"type:varchar(255);unique;not null;column:email"`
	FullName                        string         `gorm:"type:varchar(255);not null;column:full_name"`
	Phone                           string         `gorm:"type:varchar(255);column:phone"`
	Password                        string         `gorm:"type:varchar(255);not null;column:password"`
	EmailVerified                   bool           `gorm:"default:false;column:email_verified"`
	EmailVerificationToken          string         `gorm:"type:varchar(255);column:email_verification_token"`
	EmailVerificationTokenExpiresAt *time.Time     `gorm:"column:email_verification_token_expires_at"`
	UserStatus                      string         `gorm:"type:app.user_status;not null;default:'pending';column:user_status"`
	CreatedAt                       time.Time      `gorm:"not null;default:CURRENT_TIMESTAMP;column:created_at"`
	UpdatedAt                       time.Time      `gorm:"not null;default:CURRENT_TIMESTAMP;column:updated_at"`
	ProfilePictureURL               *string        `gorm:"type:varchar(255);column:profile_picture_url"`
	Members                         []Member       `gorm:"foreignKey:UserID"`
	RefreshTokens                   []RefreshToken `gorm:"foreignKey:UserID"`
}

func (User) TableName() string {
	return "public.users"
}
