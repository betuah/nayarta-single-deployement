package dto

import (
	"encoding/json"
	"github.com/google/uuid"
	"time"
	"vms-be/internal/models"
)

type CreateFileAISummaryRequest struct {
	CustomPrompt string `json:"custom_prompt" binding:"required,min=10,max=1000"`
}

type FileAISummaryResponse struct {
	ID           uuid.UUID                  `json:"id"`
	FileID       uuid.UUID                  `json:"file_id"`
	UserID       uuid.UUID                  `json:"user_id"`
	CustomPrompt string                     `json:"custom_prompt"`
	JobID        string                     `json:"job_id"`
	Status       models.FileAISummaryStatus `json:"status"`
	CreatedAt    time.Time                  `json:"created_at"`
}

type FileAISummaryListItem struct {
	ID           uuid.UUID                  `json:"id"`
	CustomPrompt string                     `json:"custom_prompt"`
	Status       models.FileAISummaryStatus `json:"status"`
	CreatedAt    time.Time                  `json:"created_at"`
	CompletedAt  *time.Time                 `json:"completed_at"`
}

type FileAISummaryDetail struct {
	ID           uuid.UUID                  `json:"id"`
	FileID       uuid.UUID                  `json:"file_id"`
	UserID       uuid.UUID                  `json:"user_id"`
	CustomPrompt string                     `json:"custom_prompt"`
	JobID        string                     `json:"job_id"`
	Status       models.FileAISummaryStatus `json:"status"`
	OutputResult json.RawMessage            `json:"output_result" swaggertype:"object"`
	ErrorMessage *string                    `json:"error_message"`
	CreatedAt    time.Time                  `json:"created_at"`
	UpdatedAt    time.Time                  `json:"updated_at"`
	CompletedAt  *time.Time                 `json:"completed_at"`
	File         FileDetailSummary          `json:"file"`
}

type FileDetailSummary struct {
	ID        uuid.UUID       `json:"id"`
	FileName  string          `json:"file_name"`
	FileURL   string          `json:"file_url"`
	FileType  models.FileType `json:"file_type"`
	Size      float64         `json:"size"`
	CreatedAt time.Time       `json:"created_at"`
	UpdatedAt time.Time       `json:"updated_at"`
}
type RunPodJobRequest struct {
	Input    RunPodInput    `json:"input"`
	S3Config RunPodS3Config `json:"s3Config"`
	Webhook  string         `json:"webhook"`
}

type RunPodInput struct {
	Prompt        string  `json:"prompt"`
	FileLocation  string  `json:"fileLocation"`
	Temperature   float64 `json:"temperature"`
	MaxNewTokens  int     `json:"max_new_tokens"`
	MaxFrames     int     `json:"max_frames"`
	SegmentLength int     `json:"segment_length"`
}

type RunPodS3Config struct {
	AccessID     string `json:"accessId"`
	AccessSecret string `json:"accessSecret"`
	BucketName   string `json:"bucketName"`
	EndpointURL  string `json:"endpointUrl"`
}

type RunPodJobResponse struct {
	ID     string `json:"id"`
	Status string `json:"status"`
}
