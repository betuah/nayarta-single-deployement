package dto

import (
	"github.com/google/uuid"
)

type CreateEdgeAlertDTO struct {
	AnalyticID     uuid.UUID `json:"analytic_id" binding:"required"`
	CCTVAnalyticID uuid.UUID `json:"cctv_analytic_id" binding:"required"`
	Message        string    `json:"message" binding:"required"`
}

type CreateEdgeAlertWithoutAnalyticDTO struct {
	CCTVAnalyticID uuid.UUID `json:"cctv_analytic_id" binding:"required"`
	Message        string    `json:"message" binding:"required"`
}

type AlertCreatedResponse struct {
	AlertIDs []uuid.UUID `json:"alert_ids"`
	Message  string      `json:"message"`
}
