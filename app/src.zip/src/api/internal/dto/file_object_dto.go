package dto

type GetPresignedURLRequest struct {
	FileName      string `json:"file_name" binding:"required"`
	ContentLength int64  `json:"content_length" binding:"required"`
}

type PresignedRequest struct {
	URL     string            `json:"url"`
	Method  string            `json:"method"`
	Header  map[string]string `json:"header"`
	FileUrl string            `json:"file_url"`
}

type UploadFileResponse struct {
	FileName   string `json:"file_name"`
	ObjectName string `json:"object_name"`
	Size       int64  `json:"size"`
}
