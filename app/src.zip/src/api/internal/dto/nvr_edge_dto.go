package dto

import (
	"time"
	"vms-be/internal/models"

	"github.com/google/uuid"
)

// NVREdgeConfig represents the configuration of an NVR for edge devices
type NVREdgeConfig struct {
	ID            uuid.UUID        `json:"id"`
	Name          string           `json:"name"`
	Hostname      string           `json:"hostname"`
	Port          int              `json:"port"`
	UserName      string           `json:"user_name"`
	Status        models.NvrStatus `json:"status"`
	LastChecked   *time.Time       `json:"last_checked"`
	ActiveUntil   time.Time        `json:"active_until"`
	CheckInterval int              `json:"check_interval"`
	Version       string           `json:"version"`
	Location      string           `json:"location"`
	LocationID    uuid.UUID        `json:"location_id"`
	GroupID       uuid.UUID        `json:"group_id"`
	GroupName     string           `json:"group_name"`
}

// UpdateNVRStatusDTO represents the data for updating NVR status
type UpdateNVRStatusDTO struct {
	Status      models.NvrStatus `json:"status" binding:"required"`
	LastChecked time.Time        `json:"last_checked" binding:"required"`
}

// UpdateNVRVersionDTO represents the data for updating NVR version
type UpdateNVRVersionDTO struct {
	Version string `json:"version" binding:"required"`
}

// NVRCheckIntervalResponse represents the response for getting NVR check interval
type NVRCheckIntervalResponse struct {
	CheckInterval int `json:"check_interval"`
}

type NVREdgeOrgDetailDto struct {
	ID          uuid.UUID `json:"id"`
	GroupName   string    `json:"group_name"`
	GroupStatus string    `json:"group_status"`
	Email       *string   `json:"email"`
	CreatedAt   time.Time `json:"created_at"`
}

type NVREdgeCCTVSchedulesResponse struct {
	NVRID     uuid.UUID                   `json:"nvr_id"`
	Schedules []CCTVRecordingScheduleInfo `json:"schedules"`
}

type CCTVRecordingScheduleInfo struct {
	CCTVID        uuid.UUID `json:"cctv_id"`
	CCTVName      string    `json:"cctv_name"`
	ID            uuid.UUID `json:"id"`
	EnabledHours  []int     `json:"enabled_hours"`
	RetentionDays int       `json:"retention_days"`
	CreatedAt     time.Time `json:"created_at"`
	UpdatedAt     time.Time `json:"updated_at"`
}
