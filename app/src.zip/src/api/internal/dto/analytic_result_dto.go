package dto

import (
	"fmt"
	"strings"
	"time"
)

type PeopleCountingOverviewRequest struct {
	Date        string `json:"date"`
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
}

type PeopleCountingOverviewResponse struct {
	TotalPeople   PeopleCountData     `json:"total_people"`
	PeopleAverage PeopleCountData     `json:"people_average"`
	BusiestHour   HourlyBreakdownData `json:"busiest_hour"`
	QuietestHour  HourlyBreakdownData `json:"quietest_hour"`
}

type PeopleCountData struct {
	Count int    `json:"count"`
	Unit  string `json:"unit"`
}

type HourlyBreakdownData struct {
	Time           string  `json:"time"`
	ComparisonTime *string `json:"comparison_time"`
}

type TimeGranularity string

const (
	WeeklyGranularity  TimeGranularity = "weekly"
	MonthlyGranularity TimeGranularity = "monthly"
)

type HeatmapMetricType string

const (
	AverageMetric HeatmapMetricType = "average"
	MaximumMetric HeatmapMetricType = "maximum"
	AmountMetric  HeatmapMetricType = "amount"
)

type HeatmapAnalyticsRequest struct {
	LocationID   string            `json:"location_id"`
	FloorPlanID  string            `json:"floor_plan_id"`
	CCTVID       string            `json:"cctv_id"`
	Granularity  TimeGranularity   `json:"granularity"`   // "weekly" or "monthly"
	TimeSelector string            `json:"time_selector"` // YYYY-MM for monthly, YYYY-MM-DD for weekly (start of week)
	MetricType   HeatmapMetricType `json:"metric_type"`   // "average", "maximum", or "amount"
}

type HeatmapAnalyticsResponse struct {
	Data           [][]float64 `json:"data"`            // 2D array [day_of_week][hour] for weekly or [day_of_month][hour] for monthly
	MaxValue       float64     `json:"max_value"`       // Maximum value in the heatmap for scaling
	DayLabels      []string    `json:"day_labels"`      // Day labels (Mon-Sun for weekly, 1-31 for monthly)
	HourLabels     []int       `json:"hour_labels"`     // Hour labels (0-23)
	SelectedPeriod string      `json:"selected_period"` // Description of the selected period
	Scale          []float64   `json:"scale"`           // Scale steps for visualization (0 to max_value in 5 steps)
}

type ChartGranularity string

const (
	DaysGranularity  ChartGranularity = "days"
	HoursGranularity ChartGranularity = "hours"
)

type CountingChartRequest struct {
	LocationID  string           `json:"location_id"`
	FloorPlanID string           `json:"floor_plan_id"`
	CCTVID      string           `json:"cctv_id"`
	Granularity ChartGranularity `json:"granularity"` // "days" or "hours"
	StartDate   string           `json:"start_date"`  // YYYY-MM-DD
	EndDate     string           `json:"end_date"`    // YYYY-MM-DD (for days granularity)
	TargetDate  string           `json:"target_date"` // YYYY-MM-DD (for hours granularity)
	StartHour   int              `json:"start_hour"`  // 0-23 (for hours granularity)
	EndHour     int              `json:"end_hour"`    // 0-23 (for hours granularity)
}

type CountingChartResponse struct {
	Labels []string  `json:"labels"` // X-axis labels (dates or hours)
	Data   []float64 `json:"data"`   // Y-axis data (people count)
	Title  string    `json:"title"`  // Chart title
}

type InOutCountingOverviewRequest struct {
	LocationID  string           `json:"location_id"`
	FloorPlanID string           `json:"floor_plan_id"`
	CCTVID      string           `json:"cctv_id"`
	Granularity ChartGranularity `json:"granularity"` // "days" or "hours"
	StartDate   string           `json:"start_date"`  // YYYY-MM-DD
	EndDate     string           `json:"end_date"`    // YYYY-MM-DD (for days granularity)
	TargetDate  string           `json:"target_date"` // YYYY-MM-DD (for hours granularity)
	StartHour   int              `json:"start_hour"`  // 0-23 (for hours granularity)
	EndHour     int              `json:"end_hour"`    // 0-23 (for hours granularity)
}

type InOutCountingOverviewResponse struct {
	TotalPeopleIn  PeopleCountData `json:"total_people_in"`
	TotalPeopleOut PeopleCountData `json:"total_people_out"`
}

type InOutCountingChartRequest struct {
	LocationID  string           `json:"location_id"`
	FloorPlanID string           `json:"floor_plan_id"`
	CCTVID      string           `json:"cctv_id"`
	Granularity ChartGranularity `json:"granularity"` // "days" or "hours"
	StartDate   string           `json:"start_date"`  // YYYY-MM-DD
	EndDate     string           `json:"end_date"`    // YYYY-MM-DD (for days granularity)
	TargetDate  string           `json:"target_date"` // YYYY-MM-DD (for hours granularity)
	StartHour   int              `json:"start_hour"`  // 0-23 (for hours granularity)
	EndHour     int              `json:"end_hour"`    // 0-23 (for hours granularity)
}

type InOutCountingChartResponse struct {
	Labels    []string                   `json:"labels"`     // X-axis labels (dates or hours)
	DataIn    []int64                    `json:"data_in"`    // Y-axis data for people in
	DataOut   []int64                    `json:"data_out"`   // Y-axis data for people out
	Title     string                     `json:"title"`      // Chart title
	ChartData []InOutCountingChartDetail `json:"chart_data"` // Detailed chart data
}

type InOutCountingChartDetail struct {
	Label     string `json:"label"`      // Time label
	PeopleIn  int64  `json:"people_in"`  // People in count
	PeopleOut int64  `json:"people_out"` // People out count
}

// face search

type SearchFaceRequest struct {
	ImageLink *string               `json:"-"` // Query param only
	MaxData   *int                  `json:"-"` // Query param only
	Page      int                   `json:"-"` // Query param only
	Size      int                   `json:"-"` // Query param only
	Body      SearchFaceRequestBody `json:"-"` // Request body only
}

type SearchFaceRequestBody struct {
	OrgID       string  `json:"org_id" binding:"required"`
	LocationID  *string `json:"location_id,omitempty"`
	FloorPlanID *string `json:"floor_plan_id,omitempty"`
	CCTVID      *string `json:"cctv_id,omitempty"`
	StartDate   *string `json:"start_date,omitempty"` // YYYY-MM-DD format
	EndDate     *string `json:"end_date,omitempty"`   // YYYY-MM-DD format
}

type FaceSearchFilterRequest struct {
	OrgID       string     `json:"org_id"`
	LocationID  *string    `json:"location_id,omitempty"`
	FloorPlanID *string    `json:"floor_plan_id,omitempty"`
	CCTVID      *string    `json:"cctv_id,omitempty"`
	StartDate   *time.Time `json:"start_date,omitempty"`
	EndDate     *time.Time `json:"end_date,omitempty"`
}

type FaceDetail struct {
	EventTimestamp *CustomTime `json:"event_timestamp"`
	VideoTime      *string     `json:"video_time"`
	TrackID        *string     `json:"track_id"`
	FileID         *string     `json:"file_id"`
	CCTVID         *string     `json:"cctv_id"`
	CCTVName       *string     `json:"cctv_name"`
	FloorPlanID    *string     `json:"floor_plan_id"`
	FloorPlanName  *string     `json:"floor_plan_name"`
	LocationID     *string     `json:"location_id"`
	LocationName   *string     `json:"location_name"`
	OrgID          *string     `json:"org_id"`
	GroupName      *string     `json:"group_name"`
}

type FaceSearchResult struct {
	Similarity  float64    `json:"similarity"`
	PersonLink  *string    `json:"person_link"`
	FaceLink    *string    `json:"face_link"`
	FaceDetails FaceDetail `json:"face_details"`
}

type FaceSearchResponse struct {
	Results     []FaceSearchResult `json:"results"`
	PageNumber  int                `json:"page_number"`
	TotalPages  int                `json:"total_pages"`
	PageSize    int                `json:"page_size"`
	TotalResult int                `json:"total_result"`
}

type CustomTime struct {
	time.Time
}

func (ct *CustomTime) UnmarshalJSON(b []byte) error {
	if string(b) == "null" {
		return nil
	}

	// Remove quotes
	s := strings.Trim(string(b), "\"")
	if s == "" {
		return nil
	}

	// Try multiple timestamp formats that the Face API might return
	formats := []string{
		"2006-01-02T15:04:05",           // Without timezone - will assume UTC
		"2006-01-02T15:04:05Z",          // With Z
		"2006-01-02T15:04:05-07:00",     // With timezone offset
		"2006-01-02T15:04:05.000Z",      // With milliseconds and Z
		"2006-01-02T15:04:05.000-07:00", // With milliseconds and offset
		time.RFC3339,                    // Standard RFC3339
	}

	var err error
	for _, format := range formats {
		ct.Time, err = time.Parse(format, s)
		if err == nil {
			// If the format was without timezone (first one), assume UTC
			if format == "2006-01-02T15:04:05" {
				ct.Time = ct.Time.UTC()
			}
			return nil
		}
	}

	return fmt.Errorf("cannot parse time %q", s)
}

func (ct CustomTime) MarshalJSON() ([]byte, error) {
	if ct.Time.IsZero() {
		return []byte("null"), nil
	}
	return []byte(fmt.Sprintf("\"%s\"", ct.Time.Format(time.RFC3339))), nil
}

type RestrictedAreaChartRequest struct {
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
	Date        string `json:"date"` // YYYY-MM-DD
}

type IllegalParkingChartRequest struct {
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
	Date        string `json:"date"` // YYYY-MM-DD
}

type RestrictedAreaChartResponse struct {
	Labels []string `json:"labels"` // X-axis labels (hours 00:00-23:00)
	Data   []int64  `json:"data"`   // Y-axis data (alert count)
	Title  string   `json:"title"`  // Chart title
}

type IllegalParkingChartResponse struct {
	Labels []string `json:"labels"`
	Data   []int64  `json:"data"`
	Title  string   `json:"title"`
}

type DifferentDirectionChartRequest struct {
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
	Date        string `json:"date"` // YYYY-MM-DD
}

type DifferentDirectionChartResponse struct {
	Labels []string `json:"labels"`
	Data   []int64  `json:"data"`
	Title  string   `json:"title"`
}

type UnattendedObjectChartRequest struct {
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
	Date        string `json:"date"`
}

type UnattendedObjectChartResponse struct {
	Labels []string `json:"labels"`
	Data   []int64  `json:"data"`
	Title  string   `json:"title"`
}

type PeopleConvergeChartRequest struct {
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
	Date        string `json:"date"` // YYYY-MM-DD
}

type PeopleConvergeChartResponse struct {
	Labels []string `json:"labels"`
	Data   []int64  `json:"data"`
	Title  string   `json:"title"`
}

type FireSmokeChartRequest struct {
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
	Date        string `json:"date"`
}

type FireSmokeChartResponse struct {
	Labels []string `json:"labels"`
	Data   []int64  `json:"data"`
	Title  string   `json:"title"`
}

type PersonRunningChartRequest struct {
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
	Date        string `json:"date"` // YYYY-MM-DD
}

type HealthSafetyEnvironmentChartRequest struct {
	LocationID  string `json:"location_id"`
	FloorPlanID string `json:"floor_plan_id"`
	CCTVID      string `json:"cctv_id"`
	Date        string `json:"date"` // YYYY-MM-DD
}

type PersonRunningChartResponse struct {
	Labels []string `json:"labels"`
	Data   []int64  `json:"data"`
	Title  string   `json:"title"`
}

type HealthSafetyEnvironmentChartResponse struct {
	Labels []string `json:"labels"`
	Data   []int64  `json:"data"`
	Title  string   `json:"title"`
}

// Surrounding Vessel Overview
type SurroundingVesselOverviewRequest struct {
	LocationID  string           `json:"location_id"`
	FloorPlanID string           `json:"floor_plan_id"`
	CCTVID      string           `json:"cctv_id"`
	Granularity ChartGranularity `json:"granularity"` // "days" or "hours"
	StartDate   string           `json:"start_date"`  // YYYY-MM-DD
	EndDate     string           `json:"end_date"`    // YYYY-MM-DD (for days granularity)
	TargetDate  string           `json:"target_date"` // YYYY-MM-DD (for hours granularity)
	StartHour   int              `json:"start_hour"`  // 0-23 (for hours granularity)
	EndHour     int              `json:"end_hour"`    // 0-23 (for hours granularity)
}

type SurroundingVesselOverviewResponse struct {
	TotalBuoy      VesselCountData `json:"total_buoy"`
	TotalContainer VesselCountData `json:"total_container"`
	TotalCruise    VesselCountData `json:"total_cruise"`
	TotalFishBoat  VesselCountData `json:"total_fish_boat"`
	TotalObstacle  VesselCountData `json:"total_obstacle"`
	TotalWarship   VesselCountData `json:"total_warship"`
}

type VesselCountData struct {
	Count int    `json:"count"`
	Unit  string `json:"unit"`
}

type SurroundingVesselChartRequest struct {
	LocationID  string           `json:"location_id"`
	FloorPlanID string           `json:"floor_plan_id"`
	CCTVID      string           `json:"cctv_id"`
	Granularity ChartGranularity `json:"granularity"` // "days" or "hours"
	StartDate   string           `json:"start_date"`  // YYYY-MM-DD
	EndDate     string           `json:"end_date"`    // YYYY-MM-DD (for days granularity)
	TargetDate  string           `json:"target_date"` // YYYY-MM-DD (for hours granularity)
	StartHour   int              `json:"start_hour"`  // 0-23 (for hours granularity)
	EndHour     int              `json:"end_hour"`    // 0-23 (for hours granularity)
}

type SurroundingVesselChartResponse struct {
	Labels        []string                       `json:"labels"`         // X-axis labels (dates or hours)
	DataBuoy      []int64                        `json:"data_buoy"`      // Y-axis data for buoy
	DataContainer []int64                        `json:"data_container"` // Y-axis data for container
	DataCruise    []int64                        `json:"data_cruise"`    // Y-axis data for cruise
	DataFishBoat  []int64                        `json:"data_fish_boat"` // Y-axis data for fish boat
	DataObstacle  []int64                        `json:"data_obstacle"`  // Y-axis data for obstacle
	DataWarship   []int64                        `json:"data_warship"`   // Y-axis data for warship
	Title         string                         `json:"title"`          // Chart title
	ChartData     []SurroundingVesselChartDetail `json:"chart_data"`     // Detailed chart data
}

type SurroundingVesselChartDetail struct {
	Label     string `json:"label"`     // Time label
	Buoy      int64  `json:"buoy"`      // Buoy count
	Container int64  `json:"container"` // Container count
	Cruise    int64  `json:"cruise"`    // Cruise count
	FishBoat  int64  `json:"fish_boat"` // Fish boat count
	Obstacle  int64  `json:"obstacle"`  // Obstacle count
	Warship   int64  `json:"warship"`   // Warship count
}
