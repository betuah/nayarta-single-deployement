package dto

import (
	"time"
	"vms-be/internal/models"

	"github.com/google/uuid"
)

type NVRListItem struct {
	ID            uuid.UUID        `json:"id"`
	GroupID       uuid.UUID        `json:"group_id"`
	LocationID    uuid.UUID        `json:"location_id"`
	Name          string           `json:"name"`
	Description   string           `json:"description"`
	Version       string           `json:"version"`
	Hostname      string           `json:"hostname"`
	Port          int              `json:"port"`
	Status        models.NvrStatus `json:"status"`
	LastChecked   *time.Time       `json:"last_checked"`
	CheckInterval int              `json:"check_interval"`
	GroupName     string           `json:"group_name"`
	LocationName  string           `json:"location_name"`
	CCTVCount     int              `json:"cctv_count"`
	CreatedAt     time.Time        `json:"created_at"`
	CoverImage    *string          `json:"cover_image"`
}

type NVRConnectionDetail struct {
	ID       uuid.UUID `json:"id"`
	Hostname string    `json:"hostname"`
	Port     int       `json:"port"`
	Password string    `json:"password"`
	Token    string    `json:"token"`
	Username string    `json:"username"`
}

type NVRDetail struct {
	ID            uuid.UUID         `json:"id"`
	GroupID       uuid.UUID         `json:"group_id"`
	LocationID    uuid.UUID         `json:"location_id"`
	Name          string            `json:"name"`
	Description   string            `json:"description"`
	Version       string            `json:"version"`
	Hostname      string            `json:"hostname"`
	Port          int               `json:"port"`
	UserName      string            `json:"user_name"`
	Status        models.NvrStatus  `json:"status"`
	LastChecked   *time.Time        `json:"last_checked"`
	Token         string            `json:"token"`
	CheckInterval int               `json:"check_interval"`
	CreatedAt     time.Time         `json:"created_at"`
	UpdatedAt     time.Time         `json:"updated_at"`
	CreatedBy     uuid.UUID         `json:"created_by"`
	CreatedByUser UserDTO           `json:"created_by_user"`
	CCTVs         []NVRCCTVListItem `json:"cctvs"`
	Location      LocationDTO       `json:"location"`
	Group         GroupDTO          `json:"group"`
}

type NVRCCTVListItem struct {
	ID            uuid.UUID         `json:"id"`
	Name          string            `json:"name"`
	Description   string            `json:"description"`
	SnapshotImage string            `json:"snapshot_image"`
	Status        models.CctvStatus `json:"status"`
	LastChecked   *time.Time        `json:"last_checked"`
	CheckInterval int               `json:"check_interval"`
}

type LocationDTO struct {
	ID           uuid.UUID `json:"id"`
	LocationName string    `json:"location_name"`
	Latitude     float64   `json:"latitude"`
	Longitude    float64   `json:"longitude"`
	Address      string    `json:"address"`
	ImageURL     *string   `json:"image_url"`
}

type CreateNVRDTO struct {
	GroupID       uuid.UUID `json:"-"`
	LocationID    uuid.UUID `json:"location_id" binding:"required"`
	Name          string    `json:"name" binding:"required"`
	Description   string    `json:"description"`
	Hostname      string    `json:"hostname" binding:"required"`
	Port          int       `json:"port" binding:"required"`
	UserName      string    `json:"user_name" binding:"required"`
	Password      string    `json:"password" binding:"required"`
	CheckInterval int       `json:"check_interval" binding:"required"`
	CreatedBy     uuid.UUID `json:"-"`
}

type UpdateNVRDTO struct {
	// optional
	Name *string `json:"name,omitempty"`
	// optional
	Description *string `json:"description,omitempty"`
	// optional
	Hostname *string `json:"hostname,omitempty"`
	// optional
	Port *int `json:"port,omitempty"`
	// optional
	UserName *string `json:"user_name,omitempty"`
	// optional
	Password *string `json:"password,omitempty"`
	// optional
	Status *models.NvrStatus `json:"status,omitempty"`
	// optional
	CheckInterval *int `json:"check_interval,omitempty"`
	// optional
	Version *string `json:"version,omitempty"`
	// optional
	LocationID *uuid.UUID `json:"location_id"`
}

type ResetNVRTokenResponse struct {
	Token string `json:"token"`
}

type ListNVRsResponse struct {
	NVRs  []NVRListItem `json:"nvrs"`
	Total int64         `json:"total"`
	Page  int           `json:"page"`
	Size  int           `json:"size"`
}

type CheckUsernameResponse struct {
	Exists bool `json:"exists"`
}

type NVRTokenResponse struct {
	ID    uuid.UUID `json:"id"`
	Token string    `json:"token"`
}

type NVRSearchParams = models.NVRSearchParams
