package dto

import (
	"encoding/json"
	"github.com/google/uuid"
	"time"
)

type FileAnalyticProcessResponse struct {
	ID             uuid.UUID       `json:"id"`
	FileID         uuid.UUID       `json:"file_id"`
	AnalyticTypeID uuid.UUID       `json:"analytic_type_id"`
	ProcessedAt    time.Time       `json:"processed_at"`
	Status         string          `json:"status"`
	Metadata       json.RawMessage `json:"metadata" swaggertype:"object"`
	CreatedAt      time.Time       `json:"created_at"`
	AnalyticType   struct {
		ID          uuid.UUID `json:"id"`
		Name        string    `json:"name"`
		Description string    `json:"description"`
	} `json:"analytic_type"`
}

type CreateFileAnalyticProcessRequest struct {
	AnalyticTypeID uuid.UUID       `json:"analytic_type_id" validate:"required"`
	Metadata       json.RawMessage `json:"metadata,omitempty" swaggertype:"object"`
	Status         *string         `json:"status,omitempty" validate:"omitempty,oneof=processing completed error"`
}
