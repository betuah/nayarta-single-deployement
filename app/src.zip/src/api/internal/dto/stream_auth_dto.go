package dto

type StreamAuthRequest struct {
	User     string `json:"user"`
	Password string `json:"password"` // Contains JWT token
	IP       string `json:"ip"`
	Action   string `json:"action"`
	Path     string `json:"path"` // Contains CCTV ID
	Protocol string `json:"protocol"`
	ID       string `json:"id"`
	Query    string `json:"query"`
}

type StreamMemberInfo struct {
	GroupID   string `json:"group_id"`
	GroupName string `json:"group_name"`
	MemberID  string `json:"member_id"`
	Role      string `json:"role"`
}

type GenerateReadTokenRequest struct {
	CCTVID string `json:"cctv_id" binding:"required"`
}

type GeneratePublishTokenRequest struct {
	CCTVID    string `json:"cctv_id" binding:"required"`
	BasicAuth string `json:"basic_auth" binding:"required"` // base64(username:password)
}

type StreamTokenResponse struct {
	Token string `json:"token"`
}

type JWK struct {
	Kty string `json:"kty"` // Key Type (EC)
	Kid string `json:"kid"` // Key ID
	Use string `json:"use"` // Public key use (sig)
	Crv string `json:"crv"` // Curve (P-256)
	X   string `json:"x"`   // X coordinate
	Y   string `json:"y"`   // Y coordinate
}

type JWKSResponse struct {
	Keys []JWK `json:"keys"`
}

type ValidateStreamTokenRequest struct {
	Token string `json:"token" binding:"required"`
}

type ValidateStreamTokenResponse struct {
	Valid  bool           `json:"valid"`
	Claims map[string]any `json:"claims,omitempty"`
	Error  string         `json:"error,omitempty"`
}
