package dto

import (
	"github.com/google/uuid"
	"time"
)

type CreateFloorPlanObjectRequest struct {
	FloorPlanID uuid.UUID `json:"floor_plan_id" validate:"required"`
	ObjectType  string    `json:"object_type" validate:"required,oneof=nvr cctv"`
	ObjectID    uuid.UUID `json:"object_id" validate:"required"`
	PositionX   float64   `json:"position_x" validate:"required,min=0,max=100"`
	PositionY   float64   `json:"position_y" validate:"required,min=0,max=100"`
}

type UpdateFloorPlanObjectRequest struct {
	PositionX float64 `json:"position_x" validate:"required,min=0,max=100"`
	PositionY float64 `json:"position_y" validate:"required,min=0,max=100"`
}

type FloorPlanObjectResponse struct {
	ID         uuid.UUID `json:"id"`
	ObjectType string    `json:"object_type"`
	ObjectID   uuid.UUID `json:"object_id"`
	PositionX  float64   `json:"position_x"`
	PositionY  float64   `json:"position_y"`
	CreatedAt  time.Time `json:"created_at"`
	UpdatedAt  time.Time `json:"updated_at"`
	FloorPlan  struct {
		ID              uuid.UUID `json:"id"`
		Name            string    `json:"name"`
		ImageURL        string    `json:"image_url"`
		DimensionWidth  int       `json:"dimension_width"`
		DimensionHeight int       `json:"dimension_height"`
	} `json:"floor_plan"`
	Object struct {
		ID       uuid.UUID `json:"id"`
		Name     string    `json:"name"`
		Status   string    `json:"status"`
		ImageURL string    `json:"image_url,omitempty"`
	} `json:"object"`
}

type FloorPlanObjectListRequest struct {
	GroupID     uuid.UUID `json:"group_id" validate:"required"`
	FloorPlanID uuid.UUID `json:"floor_plan_id,omitempty"`
	ObjectType  string    `json:"object_type,omitempty" validate:"omitempty,oneof=nvr cctv"`
	ObjectID    uuid.UUID `json:"object_id,omitempty"`
	Search      string    `json:"search"`
	Offset      int       `json:"offset" validate:"min=0"`
	Limit       int       `json:"limit" validate:"required,min=1,max=100"`
}

type FloorPlanObjectListResponse struct {
	Items []struct {
		ID         uuid.UUID `json:"id"`
		ObjectType string    `json:"object_type"`
		ObjectID   uuid.UUID `json:"object_id"`
		PositionX  float64   `json:"position_x"`
		PositionY  float64   `json:"position_y"`
		FloorPlan  struct {
			ID   uuid.UUID `json:"id"`
			Name string    `json:"name"`
		} `json:"floor_plan"`
		Object struct {
			ID       uuid.UUID `json:"id"`
			Name     string    `json:"name"`
			Status   string    `json:"status"`
			ImageURL string    `json:"image_url,omitempty"`
		} `json:"object"`
		CreatedAt time.Time `json:"created_at"`
	} `json:"items"`
	Total  int64 `json:"total"`
	Offset int   `json:"offset"`
	Limit  int   `json:"limit"`
}

type AvailableNVRsResponse struct {
	Items []struct {
		ID     uuid.UUID `json:"id"`
		Name   string    `json:"name"`
		Status string    `json:"status"`
	} `json:"items"`
}

type AvailableCCTVsResponse struct {
	Items []struct {
		ID            uuid.UUID `json:"id"`
		Name          string    `json:"name"`
		Status        string    `json:"status"`
		SnapshotImage string    `json:"snapshot_image,omitempty"`
	} `json:"items"`
}
