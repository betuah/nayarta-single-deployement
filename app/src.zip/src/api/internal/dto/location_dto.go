package dto

import (
	"time"
	"vms-be/internal/models"

	"github.com/google/uuid"
)

type LocationListItem struct {
	ID           uuid.UUID `json:"id"`
	LocationName string    `json:"location_name"`
	Latitude     float64   `json:"latitude"`
	Longitude    float64   `json:"longitude"`
	ImageURL     *string   `json:"image_url"`
	Address      string    `json:"address"`
	GroupName    string    `json:"group_name"`
	CreatedAt    time.Time `json:"created_at"`
}

type LocationDetail struct {
	ID              uuid.UUID `json:"id"`
	LocationName    string    `json:"location_name"`
	Latitude        float64   `json:"latitude"`
	Longitude       float64   `json:"longitude"`
	ImageURL        *string   `json:"image_url"`
	Address         string    `json:"address"`
	CreatedBy       uuid.UUID `json:"created_by"`
	GroupID         uuid.UUID `json:"group_id"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
	CreatedByUser   UserDTO   `json:"created_by_user"`
	Group           GroupDTO  `json:"group"`
	TotalNVRs       int       `json:"total_nvrs"`
	TotalCCTVs      int       `json:"total_cctvs"`
	TotalFloorPlans int       `json:"total_floor_plans"`
}

type CreateLocationDTO struct {
	LocationName string    `json:"location_name" binding:"required"`
	Latitude     float64   `json:"latitude" binding:"required"`
	Longitude    float64   `json:"longitude" binding:"required"`
	ImageURL     *string   `json:"image_url"`
	Address      string    `json:"address" binding:"required"`
	GroupID      uuid.UUID `json:"-"`
}

type UpdateLocationDTO struct {
	// optional
	LocationName *string `json:"location_name,omitempty"`
	// optional
	Latitude *float64 `json:"latitude,omitempty"`
	// optional
	Longitude *float64 `json:"longitude,omitempty"`
	// optional
	ImageURL *string `json:"image_url,omitempty"`
	// optional
	Address *string `json:"address,omitempty"`
}

type ListLocationsResponse struct {
	Locations []LocationListItem `json:"locations"`
	Total     int64              `json:"total"`
	Page      int                `json:"page"`
	Size      int                `json:"size"`
}

type LocationSearchParams = models.LocationSearchParams
