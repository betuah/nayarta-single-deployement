package dto

import (
	"github.com/google/uuid"
)

type CreateGroupDTO struct {
	GroupName string `json:"group_name" binding:"required"`
	Email     string `json:"email" binding:"required"`
}

type GroupDetailDTO struct {
	ID                           uuid.UUID `json:"id"`
	GroupName                    string    `json:"group_name"`
	GroupStatus                  string    `json:"group_status"`
	StorageSize                  float64   `json:"storage_size"`
	StorageUsed                  float64   `json:"storage_used"`
	StorageNotificationThreshold int       `json:"storage_notification_threshold"`
	CreatedBy                    uuid.UUID `json:"created_by"`
	Email                        string    `json:"email"`
	CreatedAt                    string    `json:"created_at"`
	UpdatedAt                    string    `json:"updated_at"`
	CreatedByUser                struct {
		ID       uuid.UUID `json:"id"`
		FullName string    `json:"full_name"`
		Email    string    `json:"email"`
	} `json:"created_by_user"`
}

type GroupDTO struct {
	ID          uuid.UUID `json:"id"`
	GroupName   string    `json:"group_name"`
	GroupStatus string    `json:"group_status"`
	StorageSize float64   `json:"storage_size"`
	StorageUsed float64   `json:"storage_used"`
}

type GroupResourceCount struct {
	GroupName string `json:"group_name"`
	NVRCount  int    `json:"nvr_count"`
	CCTVCount int    `json:"cctv_count"`
}

type GroupCCTVAnalyticsResponse struct {
	Items []struct {
		OrgName string    `json:"org_name"`
		OrgID   uuid.UUID `json:"org_id"`
		CCTV    []struct {
			CCTVID    uuid.UUID `json:"cctv_id"`
			CCTVName  string    `json:"cctv_name"`
			NVRID     uuid.UUID `json:"nvr_id"`
			Analytics []struct {
				ID               uuid.UUID `json:"id"`
				AnalyticTypeName string    `json:"analytic_type_name"`
				AnalyticTypeID   uuid.UUID `json:"analytic_type_id"`
				Status           bool      `json:"status"`
			} `json:"cctv_analytics"`
		} `json:"cctv"`
	} `json:"items"`
}

type UpdateStorageSettingsDTO struct {
	StorageNotificationThreshold int `json:"storage_notification_threshold" binding:"required,min=0,max=100"`
}

type StorageUsageDTO struct {
	StorageSize                  float64 `json:"storage_size"`
	StorageUsed                  float64 `json:"storage_used"`
	StorageUsagePercentage       float64 `json:"storage_usage_percentage"`
	StorageNotificationThreshold int     `json:"storage_notification_threshold"`
	IsThresholdExceeded          bool    `json:"is_threshold_exceeded"`
}

type QuotaResponseDTO struct {
	Used       int     `json:"used"`
	Max        int     `json:"max"`
	Remaining  int     `json:"remaining"`
	Percentage float64 `json:"percentage"`
}

type StorageQuotaResponseDTO struct {
	Used       float64 `json:"used"`      // in bytes
	Max        float64 `json:"max"`       // in bytes
	Remaining  float64 `json:"remaining"` // in bytes
	Percentage float64 `json:"percentage"`
}

type AllQuotasResponseDTO struct {
	Cameras    QuotaResponseDTO        `json:"cameras"`
	NVRs       QuotaResponseDTO        `json:"nvrs"`
	Locations  QuotaResponseDTO        `json:"locations"`
	Members    QuotaResponseDTO        `json:"members"`
	FloorPlans QuotaResponseDTO        `json:"floor_plans"`
	Storage    StorageQuotaResponseDTO `json:"storage"`
	Plan       *PlanInfoDTO            `json:"plan"`
	Analytics  []string                `json:"analytics"`
}

type PlanInfoDTO struct {
	ID          *uuid.UUID `json:"id"`
	Name        *string    `json:"name"`
	DisplayName *string    `json:"display_name"`
}
