package dto

import (
	"encoding/json"
	"time"
	"vms-be/internal/models"

	"github.com/google/uuid"
)

type FileListItem struct {
	ID              uuid.UUID       `json:"id"`
	CCTVID          uuid.UUID       `json:"cctv_id"`
	CCTVName        string          `json:"cctv_name"`
	SnapshotImage   *string         `json:"snapshot_image"`
	FileType        models.FileType `json:"file_type"`
	FileName        string          `json:"file_name"`
	FileURL         string          `json:"file_url"`
	Size            float64         `json:"size"`
	CreatedAt       time.Time       `json:"created_at"`
	Provider        string          `json:"provider"`
	AnalyticProcess bool            `json:"analytic_process"`
	Analytics       []struct {
		Name string `json:"name"`
	} `json:"analytics"`
}

type FileDetail struct {
	ID            uuid.UUID                `json:"id"`
	CCTVID        uuid.UUID                `json:"cctv_id"`
	SnapshotImage *string                  `json:"snapshot_image"`
	FileType      models.FileType          `json:"file_type"`
	FileName      string                   `json:"file_name"`
	FileURL       string                   `json:"file_url"`
	Size          float64                  `json:"size"`
	CreatedAt     time.Time                `json:"created_at"`
	UpdatedAt     time.Time                `json:"updated_at"`
	CCTV          CCTVListItem             `json:"cctv"`
	Analytics     []AnalyticListItemOnCCTV `json:"analytics"`
}

type CreateFileDTO struct {
	CCTVID        uuid.UUID        `json:"cctv_id" binding:"required"`
	SnapshotImage *string          `json:"snapshot_image"`
	FileType      models.FileType  `json:"file_type" binding:"required"`
	FileName      string           `json:"file_name" binding:"required"`
	FileURL       string           `json:"file_url" binding:"required"`
	Size          float64          `json:"size" binding:"required"`
	CreatedAt     *time.Time       `json:"created_at"`
	Metadata      *json.RawMessage `json:"metadata" swaggertype:"object"`
}

type UpdateFileDTO struct {
	FileName      *string  `json:"file_name,omitempty"`
	FileURL       *string  `json:"file_url,omitempty"`
	Size          *float64 `json:"size,omitempty"`
	SnapshotImage *string  `json:"snapshot_image,omitempty"`
}

type ListFilesResponse struct {
	Files []FileListItem `json:"files"`
	Total int64          `json:"total"`
	Page  int            `json:"page"`
	Size  int            `json:"size"`
}

type PresignedURLResponse struct {
	URL string `json:"url"`
}

type GetFileURLRequest struct {
	FileURL  string `form:"fileUrl" binding:"required"`
	Provider string `form:"provider" binding:"required,oneof=object_storage local"`
}

type UpdateFileProcessingStatusRequest struct {
	AnalyticProcess bool `json:"analytic_process" binding:"required"`
}

type ListFilesWithLocationResponse struct {
	Files []FileListItemWithLocation `json:"files"`
	Total int64                      `json:"total"`
	Page  int                        `json:"page"`
	Size  int                        `json:"size"`
}

type FileListItemWithLocation struct {
	ID              uuid.UUID       `json:"id"`
	CCTVID          uuid.UUID       `json:"cctv_id"`
	CCTVName        string          `json:"cctv_name"`
	SnapshotImage   *string         `json:"snapshot_image"`
	FileType        models.FileType `json:"file_type"`
	FileName        string          `json:"file_name"`
	FileURL         string          `json:"file_url"`
	Size            float64         `json:"size"`
	CreatedAt       time.Time       `json:"created_at"`
	Provider        string          `json:"provider"`
	AnalyticProcess bool            `json:"analytic_process"`
	Analytics       []struct {
		Name string `json:"name"`
	} `json:"analytics"`
	LocationName  string  `json:"location_name"`
	FloorPlanName *string `json:"floor_plan_name"`
}

type FileDetailAdvanced struct {
	ID              uuid.UUID       `json:"id"`
	CCTVID          uuid.UUID       `json:"cctv_id"`
	SnapshotImage   *string         `json:"snapshot_image"`
	FileType        models.FileType `json:"file_type"`
	FileName        string          `json:"file_name"`
	FileURL         string          `json:"file_url"`
	DownloadURL     string          `json:"download_url"`
	Size            float64         `json:"size"`
	CreatedAt       time.Time       `json:"created_at"`
	UpdatedAt       time.Time       `json:"updated_at"`
	Provider        string          `json:"provider"`
	AnalyticProcess bool            `json:"analytic_process"`
	Metadata        json.RawMessage `json:"metadata" swaggertype:"object"`

	CCTV struct {
		ID      uuid.UUID `json:"id"`
		Name    string    `json:"name"`
		Brand   string    `json:"brand"`
		NVRID   uuid.UUID `json:"nvr_id"`
		NVRName string    `json:"nvr_name"`
	} `json:"cctv"`

	Location struct {
		ID   uuid.UUID `json:"id"`
		Name string    `json:"name"`
	} `json:"location"`

	FloorPlan *struct {
		ID   uuid.UUID `json:"id"`
		Name string    `json:"name"`
	} `json:"floor_plan,omitempty"`

	FileAnalytics []struct {
		ID             uuid.UUID `json:"id"`
		CCTVAnalyticID uuid.UUID `json:"cctv_analytic_id"`
		CreatedAt      time.Time `json:"created_at"`
		AnalyticType   struct {
			ID   uuid.UUID `json:"id"`
			Name string    `json:"name"`
		} `json:"analytic_type"`
	} `json:"file_analytics"`

	AnalyticProcesses []struct {
		ID           uuid.UUID       `json:"id"`
		Status       string          `json:"status"`
		ProcessedAt  time.Time       `json:"processed_at"`
		CreatedAt    time.Time       `json:"created_at"`
		Metadata     json.RawMessage `json:"metadata" swaggertype:"object"`
		AnalyticType struct {
			ID          uuid.UUID `json:"id"`
			Name        string    `json:"name"`
			Description string    `json:"description"`
		} `json:"analytic_type"`
	} `json:"analytic_processes"`
}

type FileLocationDetail struct {
	ID           uuid.UUID       `json:"id"`
	FileType     models.FileType `json:"file_type"`
	FileName     string          `json:"file_name"`
	FileURL      string          `json:"file_url"`
	CreatedAt    time.Time       `json:"created_at"`
	CCTVName     string          `json:"cctv_name"`
	CCTVID       uuid.UUID       `json:"cctv_id"`
	NVRName      string          `json:"nvr_name"`
	NVRID        uuid.UUID       `json:"nvr_id"`
	LocationName string          `json:"location_name"`
	LocationID   uuid.UUID       `json:"location_id"`
	FloorPlan    *struct {
		ID   uuid.UUID `json:"id"`
		Name string    `json:"name"`
	} `json:"floor_plan,omitempty"`
}

type DeleteFilesByCCTVAndDateDTO struct {
	CCTVID uuid.UUID `form:"cctv_id" binding:"required"`
	Date   string    `form:"date" binding:"required"`
}

type DeleteFilesResponse struct {
	TotalFiles         int      `json:"total_files"`
	DeletedCount       int      `json:"deleted_count"`
	SkippedCount       int      `json:"skipped_count"`
	FailedStorageCount int      `json:"failed_storage_count"`
	FailedFileIDs      []string `json:"failed_file_ids,omitempty"`
}

type GetRecordingPlaybackRequest struct {
	CCTVID    uuid.UUID `form:"cctv_id" binding:"required"`
	StartTime time.Time `form:"start_time" binding:"required" time_format:"2006-01-02T15:04:05Z07:00"`
	EndTime   time.Time `form:"end_time" binding:"required" time_format:"2006-01-02T15:04:05Z07:00"`
}

type RecordingSegment struct {
	ID              uuid.UUID `json:"id"`
	FileName        string    `json:"file_name"`
	FileURL         string    `json:"file_url"`
	StartTime       time.Time `json:"start_time"`
	Duration        float64   `json:"duration"`
	OffsetFromStart float64   `json:"offset_from_start"`
	Sequence        int       `json:"sequence"`
}

type TimelineGap struct {
	Start    float64 `json:"start"`
	Duration float64 `json:"duration"`
}

type RecordingTimeline struct {
	TotalDuration     float64       `json:"total_duration"`
	AvailableDuration float64       `json:"available_duration"`
	Gaps              []TimelineGap `json:"gaps"`
}

type RecordingPlaybackResponse struct {
	CCTVID        uuid.UUID          `json:"cctv_id"`
	StartTime     time.Time          `json:"start_time"`
	EndTime       time.Time          `json:"end_time"`
	TotalSegments int                `json:"total_segments"`
	Segments      []RecordingSegment `json:"segments"`
	Timeline      RecordingTimeline  `json:"timeline"`
}

type FileSearchParams = models.FileSearchParams

type BulkDeleteSummaryRequest struct {
	CCTVIDs   []uuid.UUID `json:"cctv_ids" binding:"required,min=1"`
	StartDate string      `json:"start_date" binding:"required"`
	EndDate   string      `json:"end_date" binding:"required"`
}

type CCTVDeletionSummary struct {
	CCTVID         uuid.UUID `json:"cctv_id"`
	CCTVName       string    `json:"cctv_name"`
	TotalFiles     int       `json:"total_files"`
	DeletableFiles int       `json:"deletable_files"`
	SkippedFiles   int       `json:"skipped_files"`
	TotalSize      float64   `json:"total_size"`     // in bytes
	DeletableSize  float64   `json:"deletable_size"` // in bytes
	SkippedSize    float64   `json:"skipped_size"`   // in bytes
}

type BulkDeleteSummaryResponse struct {
	CCTVSummaries       []CCTVDeletionSummary `json:"cctv_summaries"`
	TotalFiles          int                   `json:"total_files"`
	TotalDeletableFiles int                   `json:"total_deletable_files"`
	TotalSkippedFiles   int                   `json:"total_skipped_files"`
	TotalSize           float64               `json:"total_size"`           // in bytes
	TotalDeletableSize  float64               `json:"total_deletable_size"` // in bytes
	TotalSkippedSize    float64               `json:"total_skipped_size"`   // in bytes
}

type BulkDeleteFilesRequest struct {
	CCTVIDs   []uuid.UUID `json:"cctv_ids" binding:"required,min=1"`
	StartDate string      `json:"start_date" binding:"required"` // Change to string
	EndDate   string      `json:"end_date" binding:"required"`   // Change to string
}

type CCTVDeletionResult struct {
	CCTVID             uuid.UUID `json:"cctv_id"`
	CCTVName           string    `json:"cctv_name"`
	TotalFiles         int       `json:"total_files"`
	DeletedCount       int       `json:"deleted_count"`
	SkippedCount       int       `json:"skipped_count"`
	FailedStorageCount int       `json:"failed_storage_count"`
	FailedFileIDs      []string  `json:"failed_file_ids,omitempty"`
	DeletedSize        float64   `json:"deleted_size"` // in bytes
	SkippedSize        float64   `json:"skipped_size"` // in bytes
}

type BulkDeleteFilesResponse struct {
	CCTVResults        []CCTVDeletionResult `json:"cctv_results"`
	TotalFiles         int                  `json:"total_files"`
	TotalDeletedCount  int                  `json:"total_deleted_count"`
	TotalSkippedCount  int                  `json:"total_skipped_count"`
	TotalFailedStorage int                  `json:"total_failed_storage"`
	TotalDeletedSize   float64              `json:"total_deleted_size"` // in bytes
	TotalSkippedSize   float64              `json:"total_skipped_size"` // in bytes
}

type BulkDeleteSummaryServiceRequest struct {
	CCTVIDs   []uuid.UUID `json:"cctv_ids"`
	StartDate time.Time   `json:"start_date"`
	EndDate   time.Time   `json:"end_date"`
}

type BulkDeleteFilesServiceRequest struct {
	CCTVIDs   []uuid.UUID `json:"cctv_ids"`
	StartDate time.Time   `json:"start_date"`
	EndDate   time.Time   `json:"end_date"`
}

type StorageInfo struct {
	StorageLimitGB        float64 `json:"storage_limit_gb"`
	StorageUsedGB         float64 `json:"storage_used_gb"`
	StorageAvailableGB    float64 `json:"storage_available_gb"`
	UtilizationPercentage float64 `json:"utilization_percentage"`
	RecordingSizeGB       float64 `json:"recording_size_gb"`
	NonRecordingSizeGB    float64 `json:"non_recording_size_gb"`
}

type CCTVStorageBreakdown struct {
	CCTVID           uuid.UUID  `json:"cctv_id"`
	CCTVName         string     `json:"cctv_name"`
	NVRName          string     `json:"nvr_name"`
	LocationName     string     `json:"location_name"`
	TotalRecordings  int        `json:"total_recordings"`
	TotalStorageSize float64    `json:"total_storage_size"` // in bytes
	StorageSizeGB    float64    `json:"storage_size_gb"`    // in GB for readability
	OldestRecording  *time.Time `json:"oldest_recording"`
	LatestRecording  *time.Time `json:"latest_recording"`
	DaysOfRecording  int        `json:"days_of_recording"`
	AvgDailySize     float64    `json:"avg_daily_size_gb"` // in GB
}

type RecordingStorageBreakdownResponse struct {
	GroupID              uuid.UUID              `json:"group_id"`
	GroupName            string                 `json:"group_name"`
	TotalRecordings      int                    `json:"total_recordings"`
	TotalStorageSize     float64                `json:"total_storage_size"`    // in bytes
	TotalStorageSizeGB   float64                `json:"total_storage_size_gb"` // in GB
	TotalCCTVs           int                    `json:"total_cctvs"`
	CCTVBreakdowns       []CCTVStorageBreakdown `json:"cctv_breakdowns"`
	TopStorageCCTVs      []CCTVStorageBreakdown `json:"top_storage_cctvs"` // Top 5 by storage
	OldestRecording      *time.Time             `json:"oldest_recording"`
	LatestRecording      *time.Time             `json:"latest_recording"`
	TotalDaysOfRecording int                    `json:"total_days_of_recording"`
	StorageInfo          StorageInfo            `json:"storage_info"`
}

type RecordingStorageBreakdownRequest struct {
	GroupID uuid.UUID `form:"group_id" binding:"required"`
}

type MultiCCTVRecordingPlaybackRequest struct {
	VideoWallID uuid.UUID `form:"video_wall_id" binding:"required"`
	StartTime   time.Time `form:"start_time" binding:"required" time_format:"2006-01-02T15:04:05Z07:00"`
	EndTime     time.Time `form:"end_time" binding:"required" time_format:"2006-01-02T15:04:05Z07:00"`
}

type MultiCCTVRecordingPlaybackResponse struct {
	VideoWallID   uuid.UUID               `json:"video_wall_id"`
	VideoWallName string                  `json:"video_wall_name"`
	StartTime     time.Time               `json:"start_time"`
	EndTime       time.Time               `json:"end_time"`
	TotalCCTVs    int                     `json:"total_cctvs"`
	CCTVPlaybacks []CCTVRecordingPlayback `json:"cctv_playbacks"`
}

type CCTVRecordingPlayback struct {
	CCTVID        uuid.UUID          `json:"cctv_id"`
	CCTVName      string             `json:"cctv_name"`
	TotalSegments int                `json:"total_segments"`
	Segments      []RecordingSegment `json:"segments"`
	Timeline      RecordingTimeline  `json:"timeline"`
}
