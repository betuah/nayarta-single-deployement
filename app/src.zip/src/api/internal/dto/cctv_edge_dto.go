package dto

import (
	"github.com/google/uuid"
	"time"
	"vms-be/internal/models"
)

type EdgeCCTVConfig struct {
	ID              uuid.UUID         `json:"id"`
	Name            string            `json:"name"`
	Description     string            `json:"description"`
	Brand           string            `json:"brand"`
	Type            string            `json:"type"`
	Hostname        string            `json:"hostname"`
	Port            int               `json:"port"`
	Protocol        string            `json:"protocol"`
	Username        string            `json:"username"`
	Password        string            `json:"password"`
	Status          models.CctvStatus `json:"status"`
	CheckInterval   int               `json:"check_interval"`
	Path            string            `json:"path"`
	IsPtzSupported  bool              `json:"is_ptz_supported"`
	RecordingStatus int               `json:"recording_status"`
}

type EdgeCCTVHeartbeat struct {
	Status          models.NvrStatus `json:"status" binding:"required"`
	LastChecked     time.Time        `json:"last_checked" binding:"required"`
	RecordingStatus *int             `json:"recording_status,omitempty"`
}

type CCTVStatusResponse struct {
	Status        string    `json:"status"`
	CheckInterval int       `json:"check_interval"`
	LastChecked   time.Time `json:"last_checked"`
	UptimeSeconds int64     `json:"uptime_seconds"`
}

type EdgeCCTVCreate struct {
	Name           string     `json:"name" binding:"required"`
	Description    string     `json:"description" binding:"required"`
	Brand          string     `json:"brand" binding:"required"`
	Type           string     `json:"type" binding:"required"`
	Hostname       string     `json:"hostname" binding:"required"`
	Port           int        `json:"port" binding:"required"`
	Protocol       string     `json:"protocol" binding:"required"`
	Username       string     `json:"username" binding:"required"`
	Password       string     `json:"password" binding:"required"`
	CheckInterval  int        `json:"check_interval"`
	ID             *uuid.UUID `json:"id"`
	Path           string     `json:"path" binding:"required"`
	IsPtzSupported *bool      `json:"is_ptz_supported"`
}

type EdgeCCTVSnapshot struct {
	SnapshotImage string `json:"snapshot_image" binding:"required"`
}
