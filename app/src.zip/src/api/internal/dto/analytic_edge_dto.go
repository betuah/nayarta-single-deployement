package dto

import (
	"github.com/google/uuid"
	"time"
)

type AnalyticEdgeDetail struct {
	ID             uuid.UUID `json:"id"`
	FileID         uuid.UUID `json:"file_id"`
	CCTVAnalyticID uuid.UUID `json:"cctv_analytic_id"`
	CreatedAt      time.Time `json:"created_at"`
	CCTVName       string    `json:"cctv_name"`
}
