package dto

import (
	"github.com/google/uuid"
	"time"
	"vms-be/internal/models"
)

type AlertListItemOnAlert struct {
	ID        uuid.UUID `json:"id"`
	Message   string    `json:"message"`
	CreatedAt time.Time `json:"created_at"`
	Analytic  *struct {
		ID     uuid.UUID `json:"id"`
		Name   string    `json:"name"`
		FileID uuid.UUID `json:"file_id"`
	} `json:"analytic"`
	CCTVAnalytic *struct {
		ID     uuid.UUID `json:"id"`
		Name   string    `json:"name"`
		TypeID uuid.UUID `json:"type_id"`
		CCTV   struct {
			ID   uuid.UUID `json:"id"`
			Name string    `json:"name"`
		} `json:"cctv"`
	} `json:"cctv_analytic"`
}

type AlertDetail struct {
	ID        uuid.UUID `json:"id"`
	Message   string    `json:"message"`
	CreatedAt time.Time `json:"created_at"`
	Analytic  *struct {
		ID          uuid.UUID `json:"id"`
		Name        string    `json:"name"`
		Description string    `json:"description"`
	} `json:"analytic"`
	CCTVAnalytic struct {
		ID           uuid.UUID `json:"id"`
		AnalyticType struct {
			ID   uuid.UUID `json:"id"`
			Name string    `json:"name"`
		} `json:"analytic_type"`
		CCTV struct {
			ID          uuid.UUID `json:"id"`
			Name        string    `json:"name"`
			Description string    `json:"description"`
			Hostname    string    `json:"hostname"`
			Port        int       `json:"port"`
		} `json:"cctv"`
	} `json:"cctv_analytic"`
}

type CreateAlertDTO struct {
	Message        string     `json:"message" binding:"required"`
	AnalyticID     *uuid.UUID `json:"analytic_id" binding:"required"`
	CCTVAnalyticID *uuid.UUID `json:"cctv_analytic_id" binding:"required"`
}

type ListAlertResponse struct {
	Alerts []AlertListItemOnAlert `json:"alerts"`
	Total  int64                  `json:"total"`
	Page   int                    `json:"page"`
	Size   int                    `json:"size"`
}

type AlertSearchParams = models.AlertSearchParams
