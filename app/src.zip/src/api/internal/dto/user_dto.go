package dto

import "github.com/google/uuid"

type UserDTO struct {
	ID                uuid.UUID `json:"id"`
	Email             string    `json:"email"`
	FullName          string    `json:"full_name"`
	ProfilePictureURL *string   `json:"profile_picture_url"`
	Phone             string    `json:"phone"`
}
