package dto

import (
	"github.com/google/uuid"
	"time"
)

type CreateFloorPlanRequest struct {
	LocationID      uuid.UUID `json:"location_id" validate:"required"`
	Name            string    `json:"name" validate:"required"`
	ImageURL        string    `json:"image_url" validate:"required,url"`
	DimensionWidth  int       `json:"dimension_width" validate:"required,gt=0"`
	DimensionHeight int       `json:"dimension_height" validate:"required,gt=0"`
}

type UpdateFloorPlanRequest struct {
	Name            string `json:"name" validate:"required"`
	ImageURL        string `json:"image_url" validate:"required,url"`
	DimensionWidth  int    `json:"dimension_width" validate:"required,gt=0"`
	DimensionHeight int    `json:"dimension_height" validate:"required,gt=0"`
}

type FloorPlanResponse struct {
	ID              uuid.UUID `json:"id"`
	Name            string    `json:"name"`
	ImageURL        string    `json:"image_url"`
	DimensionWidth  int       `json:"dimension_width"`
	DimensionHeight int       `json:"dimension_height"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
	Location        struct {
		ID   uuid.UUID `json:"id"`
		Name string    `json:"name"`
	} `json:"location"`
	Objects []struct {
		ID         uuid.UUID `json:"id"`
		ObjectType string    `json:"object_type"`
		ObjectID   uuid.UUID `json:"object_id"`
		PositionX  float64   `json:"position_x"`
		PositionY  float64   `json:"position_y"`
		ObjectInfo struct {
			Name string `json:"name"`
		} `json:"object_info"`
	} `json:"objects"`
}

type FloorPlanListRequest struct {
	GroupID    uuid.UUID `json:"group_id,omitempty"`
	LocationID uuid.UUID `json:"location_id,omitempty"`
	Search     string    `json:"search"`
	Offset     int       `json:"offset" validate:"min=0"`
	Limit      int       `json:"limit" validate:"required,min=1,max=100"`
}

type FloorPlanListResponse struct {
	Items []struct {
		ID              uuid.UUID `json:"id"`
		Name            string    `json:"name"`
		ImageURL        string    `json:"image_url"`
		DimensionWidth  int       `json:"dimension_width"`
		DimensionHeight int       `json:"dimension_height"`
		Location        struct {
			ID   uuid.UUID `json:"id"`
			Name string    `json:"name"`
		} `json:"location"`
		ObjectCount int       `json:"object_count"`
		CreatedAt   time.Time `json:"created_at"`
	} `json:"items"`
	Total  int64 `json:"total"`
	Offset int   `json:"offset"`
	Limit  int   `json:"limit"`
}

type FloorPlanEdgeListResponse struct {
	Items []struct {
		ID              uuid.UUID `json:"id"`
		Name            string    `json:"name"`
		ImageURL        string    `json:"image_url"`
		DimensionWidth  int       `json:"dimension_width"`
		DimensionHeight int       `json:"dimension_height"`
		ObjectCount     int       `json:"object_count"`
	} `json:"items"`
	Location struct {
		ID   uuid.UUID `json:"id"`
		Name string    `json:"name"`
	} `json:"location"`
}
type FloorPlanDetailResponse struct {
	ID              uuid.UUID `json:"id"`
	Name            string    `json:"name"`
	ImageURL        string    `json:"image_url"`
	DimensionWidth  int       `json:"dimension_width"`
	DimensionHeight int       `json:"dimension_height"`
	Location        struct {
		ID   uuid.UUID `json:"id"`
		Name string    `json:"name"`
	} `json:"location"`
	Objects []struct {
		ID         uuid.UUID `json:"id"`
		ObjectType string    `json:"object_type"`
		ObjectID   uuid.UUID `json:"object_id"`
		PositionX  float64   `json:"position_x"`
		PositionY  float64   `json:"position_y"`
		ObjectInfo struct {
			ID            uuid.UUID `json:"id"`
			Name          string    `json:"name"`
			Status        string    `json:"status"`
			SnapshotImage string    `json:"snapshot_image,omitempty"`
		} `json:"object_info"`
	} `json:"objects"`
}
