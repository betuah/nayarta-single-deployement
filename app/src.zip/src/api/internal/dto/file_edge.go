package dto

import (
	"encoding/json"
	"github.com/google/uuid"
	"time"
	"vms-be/internal/models"
)

type EdgeFileCreate struct {
	CCTVID        uuid.UUID        `json:"cctv_id" binding:"required"`
	SnapshotImage *string          `json:"snapshot_image"`
	FileType      models.FileType  `json:"file_type" binding:"required"`
	FileName      string           `json:"file_name" binding:"required"`
	FileURL       string           `json:"file_url" binding:"required"`
	Size          float64          `json:"size" binding:"required"`
	CreatedAt     *time.Time       `json:"created_at"`
	Metadata      *json.RawMessage `json:"metadata" swaggertype:"object"`
}

type EdgeFileUpdate struct {
	FileName      *string  `json:"file_name,omitempty"`
	FileURL       *string  `json:"file_url,omitempty"`
	Size          *float64 `json:"size,omitempty"`
	SnapshotImage *string  `json:"snapshot_image,omitempty"`
}

type EdgeFileDetail struct {
	ID            uuid.UUID       `json:"id"`
	CCTVID        uuid.UUID       `json:"cctv_id"`
	SnapshotImage *string         `json:"snapshot_image"`
	FileType      models.FileType `json:"file_type"`
	FileName      string          `json:"file_name"`
	FileURL       string          `json:"file_url"`
	Size          float64         `json:"size"`
}
