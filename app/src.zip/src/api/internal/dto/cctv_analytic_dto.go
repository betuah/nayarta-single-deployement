package dto

import (
	"github.com/google/uuid"
	"time"
	"vms-be/internal/models"
)

type CCTVAnalyticListItem struct {
	ID             uuid.UUID `json:"id"`
	AnalyticTypeID uuid.UUID `json:"analytic_type_id"`
	CCTVID         uuid.UUID `json:"cctv_id"`
	Enable         bool      `json:"enable"`
	AnalyticType   struct {
		ID          uuid.UUID `json:"id"`
		Name        string    `json:"name"`
		Description string    `json:"description"`
	} `json:"analytic_type"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

type CCTVAnalyticDetail struct {
	ID             uuid.UUID `json:"id"`
	AnalyticTypeID uuid.UUID `json:"analytic_type_id"`
	CCTVID         uuid.UUID `json:"cctv_id"`
	Enable         bool      `json:"enable"`
	AnalyticType   struct {
		ID          uuid.UUID `json:"id"`
		Name        string    `json:"name"`
		Description string    `json:"description"`
	} `json:"analytic_type"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

type CreateCCTVAnalyticDTO struct {
	AnalyticTypeID uuid.UUID `json:"analytic_type_id" binding:"required"`
	CCTVID         uuid.UUID `json:"cctv_id" binding:"required"`
	Enable         bool      `json:"enable"`
}

type UpdateCCTVAnalyticDTO struct {
	Enable bool `json:"enable"`
}

type ListCCTVAnalyticsResponse struct {
	CCTVAnalytics []CCTVAnalyticListItem `json:"cctv_analytics"`
	Total         int64                  `json:"total"`
}

type CCTVAnalyticSearchParams = models.CCTVAnalyticSearchParams
