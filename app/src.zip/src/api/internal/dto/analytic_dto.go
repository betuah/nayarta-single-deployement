package dto

import (
	"github.com/google/uuid"
	"time"
	"vms-be/internal/models"
)

type AnalyticListItem struct {
	ID               uuid.UUID `json:"id"`
	FileID           uuid.UUID `json:"file_id"`
	CCTVAnalyticID   uuid.UUID `json:"cctv_analytic_id"`
	CCTVName         string    `json:"cctv_name"`
	AnalyticTypeName string    `json:"analytic_type_name"`
	CreatedAt        time.Time `json:"created_at"`
}

type AnalyticDetail struct {
	ID             uuid.UUID                    `json:"id"`
	FileID         uuid.UUID                    `json:"file_id"`
	CCTVAnalyticID uuid.UUID                    `json:"cctv_analytic_id"`
	CreatedAt      time.Time                    `json:"created_at"`
	UpdatedAt      time.Time                    `json:"updated_at"`
	CCTVName       string                       `json:"cctv_name"`
	File           FileListItemOnAnalytic       `json:"file"`
	CCTVAnalytic   CCTVAnalyticDetailOnAnalytic `json:"cctv_analytic"`
	Alerts         []AlertListItem              `json:"alerts"`
}

type FileListItemOnAnalytic struct {
	ID            uuid.UUID       `json:"id"`
	CCTVID        uuid.UUID       `json:"cctv_id"`
	SnapshotImage *string         `json:"snapshot_image"`
	FileType      models.FileType `json:"file_type"`
	FileName      string          `json:"file_name"`
	FileURL       string          `json:"file_url"`
	Size          float64         `json:"size"`
	CreatedAt     time.Time       `json:"created_at"`
}

type CreateAnalyticDTO struct {
	FileID         uuid.UUID `json:"file_id" binding:"required"`
	CCTVAnalyticID uuid.UUID `json:"cctv_analytic_id" binding:"required"`
}

type UpdateAnalyticDTO struct {
	FileID         *uuid.UUID `json:"file_id,omitempty"`
	CCTVAnalyticID *uuid.UUID `json:"cctv_analytic_id,omitempty"`
}

type ListAnalyticsResponse struct {
	Analytics []AnalyticListItem `json:"analytics"`
	Total     int64              `json:"total"`
	Page      int                `json:"page"`
	Size      int                `json:"size"`
}

type AnalyticSearchParams = models.AnalyticSearchParams

type CCTVAnalyticDetailOnAnalytic struct {
	ID             uuid.UUID          `json:"id"`
	AnalyticTypeID uuid.UUID          `json:"analytic_type_id"`
	CCTVID         uuid.UUID          `json:"cctv_id"`
	Enable         bool               `json:"enable"`
	AnalyticType   AnalyticTypeDetail `json:"analytic_type"`
}

type AnalyticTypeDetail struct {
	ID          uuid.UUID `json:"id"`
	Name        string    `json:"name"`
	Description string    `json:"description"`
}

type AlertListItem struct {
	ID        uuid.UUID `json:"id"`
	Message   string    `json:"message"`
	CreatedAt time.Time `json:"created_at"`
}

type AnalyticReportItem struct {
	AnalyticID    uuid.UUID  `json:"analytic_id"`
	AnalyticName  string     `json:"analytic_name"`
	CreatedAt     time.Time  `json:"created_at"`
	CameraID      uuid.UUID  `json:"camera_id"`
	CameraName    string     `json:"camera_name"`
	LocationID    uuid.UUID  `json:"location_id"`
	LocationName  string     `json:"location_name"`
	FloorPlanID   *uuid.UUID `json:"floor_plan_id"`
	FloorPlanName *string    `json:"floor_plan_name"`
	Message       string     `json:"message"`
	FileID        uuid.UUID  `json:"file_id"`
	DownloadURL   string     `json:"download_url"`
}

type ListAnalyticReportsResponse struct {
	Analytics []AnalyticReportItem `json:"analytics"`
	Total     int64                `json:"total"`
	Page      int                  `json:"page"`
	Size      int                  `json:"size"`
}

type AnalyticReportSearchParams struct {
	GroupID      uuid.UUID  `form:"group_id"`
	StartDate    *time.Time `form:"start_date"`
	EndDate      *time.Time `form:"end_date"`
	AnalyticType string     `form:"analytic_type"`
	Search       string     `form:"search"`
	SortBy       string     `form:"sort_by"`
	SortOrder    string     `form:"sort_order"`
	Page         int        `form:"page,default=1"`
	Size         int        `form:"size,default=10"`
}

type AnalyticNotificationSearchParams struct {
	GroupID      uuid.UUID  `form:"group_id"`
	MemberID     uuid.UUID  `form:"-"` // from session, not query param
	StartDate    *time.Time `form:"start_date"`
	EndDate      *time.Time `form:"end_date"`
	AnalyticType string     `form:"analytic_type"`
	Search       string     `form:"search"`
	SortBy       string     `form:"sort_by"`
	SortOrder    string     `form:"sort_order"`
	Page         int        `form:"page,default=1"`
	Size         int        `form:"size,default=10"`
}

type ListAnalyticNotificationsResponse struct {
	Analytics []AnalyticReportItem `json:"analytics"`
	Total     int64                `json:"total"`
	Page      int                  `json:"page"`
	Size      int                  `json:"size"`
}
