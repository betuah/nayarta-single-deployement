package dto

import (
	"time"
	"vms-be/internal/models"

	"github.com/google/uuid"
)

type VideoWallListItem struct {
	ID     uuid.UUID `json:"id"`
	Name   string    `json:"name"`
	Layout string    `json:"layout"`
}

type VideoWallCCTVItem struct {
	ID              uuid.UUID               `json:"id"`
	Name            string                  `json:"name"`
	StreamURLs      *CCTVStreamURLsResponse `json:"stream_urls"`
	SnapshotImage   string                  `json:"snapshot_image"`
	Status          models.CctvStatus       `json:"status"`
	RecordingStatus int                     `json:"recording_status"`
	CheckInterval   int                     `json:"check_interval"`
	LastChecked     *time.Time              `json:"last_checked"`
}

type VideoWallDetail struct {
	ID        uuid.UUID           `json:"id"`
	Name      string              `json:"name"`
	Layout    string              `json:"layout"`
	GroupID   uuid.UUID           `json:"group_id"`
	CCTVList  []VideoWallCCTVItem `json:"cctv_list"`
	CreatedAt time.Time           `json:"created_at"`
	UpdatedAt time.Time           `json:"updated_at"`
}

type CreateVideoWallDTO struct {
	Name     string      `json:"name" binding:"required"`
	Layout   string      `json:"layout" binding:"required,oneof=1+3 1+5 1+8 1+12 2x2 3x3 4x4 5x5"`
	GroupID  uuid.UUID   `json:"group_id" binding:"required"`
	CCTVList []uuid.UUID `json:"cctv_list" binding:"required"`
}

type UpdateVideoWallDTO struct {
	Name     *string      `json:"name,omitempty"`
	Layout   *string      `json:"layout,omitempty" binding:"omitempty,oneof=1+3 1+5 1+8 1+12 2x2 3x3 4x4 5x5"`
	CCTVList *[]uuid.UUID `json:"cctv_list,omitempty"`
}

type ListVideoWallsResponse struct {
	VideoWalls []VideoWallListItem `json:"video_walls"`
	Total      int64               `json:"total"`
	Page       int                 `json:"page"`
	Size       int                 `json:"size"`
}

type VideoWallSearchParams = models.VideoWallSearchParams
