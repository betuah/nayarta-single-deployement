package dto

import (
	"encoding/json"
	"github.com/google/uuid"
)

// CCTVAnalyticConfigResponse response model for CCTV analytic config
type CCTVAnalyticConfigResponse struct {
	ID             uuid.UUID       `json:"id"`
	CCTVAnalyticID uuid.UUID       `json:"cctv_analytic_id"`
	Config         json.RawMessage `json:"config" swaggertype:"object"`
}

// UpdateCCTVAnalyticConfigRequest request model for updating CCTV analytic config
type UpdateCCTVAnalyticConfigRequest struct {
	Config json.RawMessage `json:"config" validate:"required" swaggertype:"object"`
}
