package dto

import (
	"time"
	"vms-be/internal/models"

	"github.com/google/uuid"
)

type CCTVListItem struct {
	ID              uuid.UUID         `json:"id"`
	NVRID           uuid.UUID         `json:"nvr_id"`
	Name            string            `json:"name"`
	Description     string            `json:"description"`
	SnapshotImage   string            `json:"snapshot_image"`
	Brand           string            `json:"brand"`
	Type            string            `json:"type"`
	Hostname        string            `json:"hostname"`
	Protocol        string            `json:"protocol"`
	NVRName         string            `json:"nvr_name"`
	Port            int               `json:"port"`
	Status          models.CctvStatus `json:"status"`
	LastChecked     *time.Time        `json:"last_checked"`
	CreatedAt       time.Time         `json:"created_at"`
	Path            string            `json:"path"`
	CheckInterval   int               `json:"check_interval"`
	UptimeSeconds   int64             `json:"uptime_seconds"`
	RecordingStatus int               `json:"recording_status"`
}

type CCTVConnectionDetail struct {
	ID       uuid.UUID `json:"id"`
	Hostname string    `json:"hostname"`
	Port     int       `json:"port"`
	Protocol string    `json:"protocol"`
	Username string    `json:"username"`
	Password string    `json:"password"`
	Path     string    `json:"path"`
}

type CCTVDetail struct {
	ID              uuid.UUID                `json:"id"`
	NVRID           uuid.UUID                `json:"nvr_id"`
	Name            string                   `json:"name"`
	Description     string                   `json:"description"`
	SnapshotImage   string                   `json:"snapshot_image"`
	Brand           string                   `json:"brand"`
	Type            string                   `json:"type"`
	Hostname        string                   `json:"hostname"`
	Port            int                      `json:"port"`
	Protocol        string                   `json:"protocol"`
	Username        string                   `json:"username"`
	Status          models.CctvStatus        `json:"status"`
	LastChecked     *time.Time               `json:"last_checked"`
	CreatedAt       time.Time                `json:"created_at"`
	UpdatedAt       time.Time                `json:"updated_at"`
	NVR             CCTVNVRListItem          `json:"nvr"`
	Analytics       []AnalyticListItemOnCCTV `json:"analytics"`
	Path            string                   `json:"path"`
	CheckInterval   int                      `json:"check_interval"`
	UptimeSeconds   int64                    `json:"uptime_seconds"`
	IsPtzSupported  bool                     `json:"is_ptz_supported"`
	RecordingStatus int                      `json:"recording_status"`
}

type CreateCCTVDTO struct {
	NVRID         uuid.UUID `json:"nvr_id" binding:"required"`
	Name          string    `json:"name" binding:"required"`
	Description   string    `json:"description"`
	Brand         string    `json:"brand" binding:"required"`
	Type          string    `json:"type" binding:"required"`
	Hostname      string    `json:"hostname" binding:"required"`
	Port          int       `json:"port" binding:"required"`
	Protocol      string    `json:"Protocol" binding:"required"`
	Username      string    `json:"username"`
	Password      string    `json:"password"`
	Path          string    `json:"path"`
	CheckInterval int       `json:"check_interval" binding:"required"`
}

type UpdateCCTVDTO struct {
	Name            *string            `json:"name,omitempty"`
	Description     *string            `json:"description,omitempty"`
	Brand           *string            `json:"brand,omitempty"`
	Type            *string            `json:"type,omitempty"`
	Hostname        *string            `json:"hostname,omitempty"`
	Port            *int               `json:"port,omitempty"`
	Protocol        *string            `json:"protocol,omitempty"`
	Username        *string            `json:"username,omitempty"`
	Password        *string            `json:"password,omitempty"`
	Status          *models.CctvStatus `json:"status,omitempty"`
	SnapshotImage   *string            `json:"snapshot_image,omitempty"`
	Path            *string            `json:"path,omitempty"`
	CheckInterval   *int               `json:"check_interval,omitempty"`
	NVRID           *uuid.UUID         `json:"nvr_id,omitempty"`
	IsPtzSupported  *bool              `json:"is_ptz_supported,omitempty"`
	RecordingStatus *int               `json:"recording_status,omitempty"`
}

type ListCCTVsResponse struct {
	CCTVs []CCTVListItem `json:"cctvs"`
	Total int64          `json:"total"`
	Page  int            `json:"page"`
	Size  int            `json:"size"`
}

type CCTVNVRListItem struct {
	ID          uuid.UUID        `json:"id"`
	GroupID     uuid.UUID        `json:"group_id"`
	LocationID  uuid.UUID        `json:"location_id"`
	Name        string           `json:"name"`
	Description string           `json:"description"`
	Version     string           `json:"version"`
	Status      models.NvrStatus `json:"status"`
	LastChecked *time.Time       `json:"last_checked"`
}

type CCTVSearchParams = models.CCTVSearchParams

type AnalyticListItemOnCCTV struct {
	ID             uuid.UUID `json:"id"`
	AnalyticTypeID uuid.UUID `json:"analytic_type_id"`
	Enable         bool      `json:"enable"`
	Name           string    `json:"name"`
}

type CreateStreamURLDTO struct {
	CCTVID   uuid.UUID `json:"-"`
	GroupID  uuid.UUID `json:"-"`
	Protocol string    `json:"protocol" binding:"required"`
	Hostname string    `json:"hostname" binding:"required"`
	Port     int       `json:"port" binding:"required"`
	Username string    `json:"username"`
	Password string    `json:"password"`
	Path     string    `json:"path" binding:"required"`
	Title    string    `json:"title" binding:"required"`
}

type StreamURLResponse struct {
	ID        uuid.UUID `json:"id"`
	CCTVID    uuid.UUID `json:"cctv_id"`
	Protocol  string    `json:"protocol"`
	Hostname  string    `json:"hostname"`
	Port      int       `json:"port"`
	Username  string    `json:"username"`
	Path      string    `json:"path"`
	Title     string    `json:"title"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

type StreamURLDetailResponse struct {
	ID        uuid.UUID `json:"id"`
	Title     string    `json:"title"`
	CCTVID    uuid.UUID `json:"cctv_id"`
	Protocol  string    `json:"protocol"`
	Hostname  string    `json:"hostname"`
	Port      int       `json:"port"`
	Username  string    `json:"username"`
	Password  string    `json:"password"`
	Path      string    `json:"path"`
	URL       string    `json:"url"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

type CCTVStreamURLsResponse struct {
	CCTVID     uuid.UUID                 `json:"cctv_id"`
	Name       string                    `json:"name"`
	MainStream *StreamURLDetailResponse  `json:"main_stream"`
	Streams    []StreamURLDetailResponse `json:"streams"`
}

type UpdateCCTVRecordingScheduleRequest struct {
	EnabledHours  []int `json:"enabled_hours" validate:"required,dive,min=0,max=23"`
	RetentionDays *int  `json:"retention_days" validate:"omitempty,min=1"`
}

type CCTVRecordingScheduleResponse struct {
	ID            uuid.UUID `json:"id"`
	CCTVID        uuid.UUID `json:"cctv_id"`
	EnabledHours  []int     `json:"enabled_hours"`
	RetentionDays int       `json:"retention_days"`
	CreatedAt     time.Time `json:"created_at"`
	UpdatedAt     time.Time `json:"updated_at"`
}

type CCTVSnapshotResponse struct {
	SnapshotURL string `json:"snapshot_url,omitempty"`
}

type PTZCommandRequest struct {
	CCTVID    uuid.UUID `json:"cctv_id" binding:"required"`
	Direction string    `json:"direction" binding:"required,oneof=up down left right zoomin zoomout"`
}

type PTZCommandResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message,omitempty"`
}
