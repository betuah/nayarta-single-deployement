package dto

import (
	"github.com/google/uuid"
)

type LocationSearchResult struct {
	ID   uuid.UUID `json:"id"`
	Name string    `json:"name"`
}

type FloorPlanSearchResult struct {
	ID   uuid.UUID `json:"id"`
	Name string    `json:"name"`
}

type CameraSearchResult struct {
	ID   uuid.UUID `json:"id"`
	Name string    `json:"name"`
}

type LocationSearchResponse struct {
	Locations []LocationSearchResult `json:"locations"`
}

type FloorPlanSearchResponse struct {
	FloorPlans []FloorPlanSearchResult `json:"floor_plans"`
}

type CameraSearchResponse struct {
	Cameras []CameraSearchResult `json:"cameras"`
}
