package dto

import (
	"time"
	"vms-be/internal/models"

	"github.com/google/uuid"
)

type MemberListItem struct {
	ID                uuid.UUID           `json:"id"`
	UserID            uuid.UUID           `json:"user_id"`
	GroupID           uuid.UUID           `json:"group_id"`
	Role              models.MemberRole   `json:"role"`
	Status            models.MemberStatus `json:"status"`
	UserName          string              `json:"user_name"`
	UserEmail         string              `json:"user_email"`
	ProfilePictureURL *string             `json:"profile_picture_url"`
	GroupName         string              `json:"group_name"`
	CreatedAt         time.Time           `json:"created_at"`
}

type MemberDetail struct {
	ID        uuid.UUID `json:"id"`
	UserID    uuid.UUID `json:"user_id"`
	GroupID   uuid.UUID `json:"group_id"`
	Role      string    `json:"role"`
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
	User      UserDTO   `json:"user"`
}

type CreateMemberDTO struct {
	Email   string            `json:"email" binding:"required"`
	GroupID uuid.UUID         `json:"-"`
	Role    models.MemberRole `json:"role" binding:"required,oneof=admin member"`
}

type JoinGroupMemberDTO struct {
	Email string `json:"email" binding:"required"`
}

type UpdateMemberDTO struct {
	// optional
	Role *string `json:"role,omitempty" binding:"omitempty,oneof=admin member"`
	// optional
	Status *string `json:"status,omitempty" binding:"omitempty,oneof=active pending banned disabled"`
}

type MembershipList struct {
	Memberships []MembershipListItem `json:"memberships"`
}

type MembershipListItem struct {
	ID          uuid.UUID         `json:"id"`
	UserID      uuid.UUID         `json:"user_id"`
	GroupID     uuid.UUID         `json:"group_id"`
	GroupName   string            `json:"group_name"`
	Role        models.MemberRole `json:"role"`
	Status      string            `json:"status"`
	GroupStatus string            `json:"group_status"`
}

type UpdateUserDTO struct {
	// optional
	Name *string `json:"name,omitempty"`
	// optional
	Phone *string `json:"phone,omitempty"`
	// optional
	ProfilePictureURL *string `json:"profile_picture_url,omitempty"`
}

type ChangePasswordDTO struct {
	CurrentPassword string `json:"current_password" binding:"required"`
	NewPassword     string `json:"new_password" binding:"required,min=8"`
}

type ListMembersResponse struct {
	Members []MemberListItem `json:"members"`
	Total   int64            `json:"total"`
	Page    int              `json:"page"`
	Size    int              `json:"size"`
}

type MemberSearchParams = models.MemberSearchParams
