package dto

import (
	"github.com/google/uuid"
	"vms-be/internal/models"
)

type MemberAlertSettingListItem struct {
	ID             uuid.UUID `json:"id"`
	CCTVAnalyticID uuid.UUID `json:"cctv_analytic_id"`
	Enabled        bool      `json:"enabled"`
	CCTVAnalytic   struct {
		ID           uuid.UUID `json:"id"`
		AnalyticType struct {
			ID   uuid.UUID `json:"id"`
			Name string    `json:"name"`
		} `json:"analytic_type"`
		CCTV struct {
			ID   uuid.UUID `json:"id"`
			Name string    `json:"name"`
		} `json:"cctv"`
	} `json:"cctv_analytic"`
}

type MemberAlertSettingDetail struct {
	ID             uuid.UUID `json:"id"`
	CCTVAnalyticID uuid.UUID `json:"cctv_analytic_id"`
	Enabled        bool      `json:"enabled"`
	CCTVAnalytic   struct {
		ID           uuid.UUID `json:"id"`
		AnalyticType struct {
			ID          uuid.UUID `json:"id"`
			Name        string    `json:"name"`
			Description string    `json:"description"`
		} `json:"analytic_type"`
		CCTV struct {
			ID          uuid.UUID `json:"id"`
			Name        string    `json:"name"`
			Description string    `json:"description"`
			Hostname    string    `json:"hostname"`
			Port        int       `json:"port"`
		} `json:"cctv"`
	} `json:"cctv_analytic"`
}

type CreateMemberAlertSettingDTO struct {
	CCTVAnalyticID uuid.UUID `json:"cctv_analytic_id" binding:"required"`
}

type UpdateMemberAlertSettingDTO struct {
	Enabled bool `json:"enabled"`
}

type ListMemberAlertSettingsResponse struct {
	MemberAlertSettings []MemberAlertSettingListItem `json:"member_alert_settings"`
}

type CreateAllMemberAlertSettingsDTO struct {
	CCTVID uuid.UUID `json:"cctv_id" binding:"required"`
}

type MemberAlertSettingSearchParams = models.MemberAlertSettingSearchParams
