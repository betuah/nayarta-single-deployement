package dto

import "time"

type DashboardStatsResponse struct {
	TotalLocation int64 `json:"total_location"`
	TotalNVR      int64 `json:"total_nvr"`
	NVROnline     int64 `json:"nvr_online"`
	NVROffline    int64 `json:"nvr_offline"`
	TotalCamera   int64 `json:"total_camera"`
	CameraOnline  int64 `json:"camera_online"`
	CameraOffline int64 `json:"camera_offline"`
}

type GroupOverviewResponse struct {
	// Group Information
	GroupName   string    `json:"group_name"`
	GroupStatus string    `json:"group_status"`
	Email       string    `json:"email"`
	CreatedAt   time.Time `json:"created_at"`
	ActiveUntil time.Time `json:"active_until"`

	// Statistics
	TotalLocations       int64   `json:"total_locations"`
	TotalMembers         int64   `json:"total_members"`
	TotalStorageUsed     float64 `json:"total_storage_used"`
	ActiveRecordingCCTVs int64   `json:"active_recording_cctvs"`
	TotalFloorPlans      int64   `json:"total_floor_plans"`
	CCTVsOnFloorPlans    int64   `json:"cctvs_on_floor_plans"`
	NVRsOnFloorPlans     int64   `json:"nvrs_on_floor_plans"`
}

// StorageDetailsResponse represents the storage statistics for a group
type StorageDetailsResponse struct {
	TotalStorage float64 `json:"total_storage"` // in MB

	// Storage breakdown by file types
	StorageBreakdown struct {
		Recording float64 `json:"recording"` // in MB
		Video     float64 `json:"video"`     // in MB
		Image     float64 `json:"image"`     // in MB
	} `json:"storage_breakdown"`

	// Chart data for usage over time
	ChartData []StorageChartPoint `json:"chart_data"`
}

// StorageChartPoint represents a single point in the storage usage chart
type StorageChartPoint struct {
	TimeLabel string  `json:"time_label"` // Could be day, week, or month depending on range
	Usage     float64 `json:"usage"`      // Storage used in MB
}

// StorageDetailsParams defines the query parameters for retrieving storage details
type StorageDetailsParams struct {
	GroupID   string     `form:"group_id" binding:"required"`
	RangeType string     `form:"range_type" binding:"required,oneof=last_3_days last_week last_4_months custom"`
	StartDate *time.Time `form:"start_date,omitempty" time_format:"2006-01-02" swagger:"string,format:date"`
	EndDate   *time.Time `form:"end_date,omitempty" time_format:"2006-01-02" swagger:"string,format:date"`
}
