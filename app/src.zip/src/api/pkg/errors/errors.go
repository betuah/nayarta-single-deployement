package errors

import (
	"errors"
	"fmt"
	"net/http"
)

type AppError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func (e *AppError) Error() string {
	return fmt.Sprintf("error code %d: %s", e.Code, e.Message)
}

func NewNotFoundError(resource string) *AppError {
	return &AppError{
		Code:    http.StatusNotFound,
		Message: fmt.Sprintf("%s not found", resource),
	}
}

func NewBadRequestError(message string) *AppError {
	return &AppError{
		Code:    http.StatusBadRequest,
		Message: message,
	}
}

func NewInternalServerError() *AppError {
	return &AppError{
		Code:    http.StatusInternalServerError,
		Message: "internal server error",
	}
}

func NewInternalServerErrorCustomized(message string) *AppError {
	return &AppError{
		Code:    http.StatusInternalServerError,
		Message: message,
	}
}

func NewUnauthorizedError() *AppError {
	return &AppError{
		Code:    http.StatusUnauthorized,
		Message: "unauthorized access",
	}
}

func NewUnauthorizedErrorCustomized(message string) *AppError {
	return &AppError{
		Code:    http.StatusUnauthorized,
		Message: message,
	}
}

func NewForbiddenError(message string) *AppError {
	return &AppError{
		Code:    http.StatusForbidden,
		Message: message,
	}
}

var ErrNoQuota = errors.New("no quota available for this group")
