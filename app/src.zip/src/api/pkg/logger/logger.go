package logger

import (
	"io"
	"os"
	"path/filepath"
	"vms-be/config"

	"github.com/sirupsen/logrus"
)

type Logger struct {
	*logrus.Logger
}

func NewLogger(cfg *config.LoggerConfig) *Logger {
	log := logrus.New()

	// Set log level
	level, err := logrus.ParseLevel(cfg.Level)
	if err != nil {
		level = logrus.InfoLevel
	}
	log.SetLevel(level)

	// Set JSON formatter with additional fields for Grafana
	if cfg.Format == "json" {
		log.SetFormatter(&logrus.JSONFormatter{
			TimestampFormat: "2006-01-02T15:04:05.000Z07:00", // ISO 8601 for better parsing
			FieldMap: logrus.FieldMap{
				logrus.FieldKeyTime:  "timestamp",
				logrus.FieldKeyLevel: "level",
				logrus.FieldKeyMsg:   "message",
			},
		})
	} else {
		log.SetFormatter(&logrus.TextFormatter{
			FullTimestamp:   true,
			TimestampFormat: "2006-01-02T15:04:05.000Z07:00",
		})
	}

	// Add default fields that will appear in every log
	log = log.WithFields(logrus.Fields{
		"service":     getEnv("APP_NAME", "vms-backend"),
		"version":     getEnv("APP_VERSION", "unknown"),
		"environment": getEnv("APP_ENVIRONMENT", "development"),
	}).Logger

	// Set output
	switch cfg.Output {
	case "file":
		if err := setupFileOutput(log, cfg.FilePath); err != nil {
			log.Warn("Failed to setup file output, falling back to stdout")
			log.SetOutput(os.Stdout)
		}
	case "both":
		if fileWriter, err := getFileWriter(cfg.FilePath); err == nil {
			log.SetOutput(io.MultiWriter(os.Stdout, fileWriter))
		} else {
			log.Warn("Failed to setup file output, using stdout only")
			log.SetOutput(os.Stdout)
		}
	default:
		log.SetOutput(os.Stdout)
	}

	return &Logger{Logger: log}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func setupFileOutput(log *logrus.Logger, filePath string) error {
	// Create directory if it doesn't exist
	dir := filepath.Dir(filePath)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}

	file, err := os.OpenFile(filePath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		return err
	}

	log.SetOutput(file)
	return nil
}

func getFileWriter(filePath string) (io.Writer, error) {
	dir := filepath.Dir(filePath)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, err
	}

	return os.OpenFile(filePath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
}

// Structured logging methods
func (l *Logger) WithField(key string, value interface{}) *logrus.Entry {
	return l.Logger.WithField(key, value)
}

func (l *Logger) WithFields(fields logrus.Fields) *logrus.Entry {
	return l.Logger.WithFields(fields)
}

func (l *Logger) WithError(err error) *logrus.Entry {
	return l.Logger.WithError(err)
}

// HTTP-specific logging
func (l *Logger) LogHTTPRequest(method, path, userAgent, clientIP string, statusCode int, latency string) {
	l.WithFields(logrus.Fields{
		"method":      method,
		"path":        path,
		"status_code": statusCode,
		"latency":     latency,
		"user_agent":  userAgent,
		"client_ip":   clientIP,
	}).Info("HTTP Request")
}

func (l *Logger) LogError(err error, context string) {
	l.WithError(err).Error(context)
}

func (l *Logger) LogDatabaseOperation(operation, table string, duration string, err error) {
	fields := logrus.Fields{
		"operation": operation,
		"table":     table,
		"duration":  duration,
	}

	if err != nil {
		l.WithFields(fields).WithError(err).Error("Database operation failed")
	} else {
		l.WithFields(fields).Debug("Database operation completed")
	}
}
