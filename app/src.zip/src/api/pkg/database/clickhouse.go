package database

import (
	"context"
	"crypto/tls"
	"fmt"
	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"time"

	"vms-be/config"
)

func NewClickhouseDatabase(cfg *config.ClickhouseConfig) (driver.Conn, error) {
	conn, err := clickhouse.Open(&clickhouse.Options{
		Addr: []string{fmt.Sprintf("%s:%s", cfg.Host, cfg.Port)},
		Auth: clickhouse.Auth{
			Database: cfg.Database,
			Username: cfg.User,
			Password: cfg.Password,
		},
		Settings: clickhouse.Settings{
			"max_execution_time": 60 * 5,
		},
		DialTimeout:     time.Second * 60 * 3,
		MaxOpenConns:    10,
		MaxIdleConns:    5,
		ConnMaxLifetime: time.Minute * 30,
		Compression: &clickhouse.Compression{
			Method: clickhouse.CompressionLZ4,
		},
		TLS: &tls.Config{
			//InsecureSkipVerify: true,
		},
		Protocol: clickhouse.Native,
		//Debug:    true,
	})

	if err != nil {
		return nil, fmt.Errorf("failed to connect to Clickhouse: %v", err)
	}

	// Test the connection
	ctx := context.Background()
	if err := conn.Ping(ctx); err != nil {
		return nil, fmt.Errorf("failed to ping Clickhouse: %v", err)
	}

	return conn, nil
}
