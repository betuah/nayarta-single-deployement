package utils

import "github.com/lib/pq"

// IntSliceToInt64Array converts []int to pq.Int64Array
func IntSliceToInt64Array(ints []int) pq.Int64Array {
	int64Arr := make(pq.Int64Array, len(ints))
	for i, v := range ints {
		int64Arr[i] = int64(v)
	}
	return int64Arr
}

// Int64ArrayToIntSlice converts pq.Int64Array back to []int
func Int64ArrayToIntSlice(int64Arr pq.Int64Array) []int {
	ints := make([]int, len(int64Arr))
	for i, v := range int64Arr {
		ints[i] = int(v)
	}
	return ints
}
