package utils

import (
	"encoding/json"
	"fmt"
)

// MergeJSON merges two JSON objects where values in the second JSON override the first
func MergeJSON(original, new json.RawMessage) (json.RawMessage, error) {
	if len(original) == 0 || string(original) == "{}" {
		return new, nil
	}

	if len(new) == 0 || string(new) == "{}" {
		return original, nil
	}

	// Unmarshal both JSON objects
	var originalMap map[string]interface{}
	var newMap map[string]interface{}

	if err := json.Unmarshal(original, &originalMap); err != nil {
		return nil, fmt.Errorf("failed to unmarshal original JSON: %w", err)
	}

	if err := json.Unmarshal(new, &newMap); err != nil {
		return nil, fmt.Errorf("failed to unmarshal new JSON: %w", err)
	}

	// Merge new data into original
	for key, val := range newMap {
		originalMap[key] = val // Replace original value with new value
	}

	// Marshal the merged map
	result, err := json.Marshal(originalMap)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal merged JSON: %w", err)
	}

	return result, nil
}
