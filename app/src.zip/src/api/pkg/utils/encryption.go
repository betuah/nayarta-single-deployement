package utils

import (
	"crypto/rand"
	"crypto/rsa"
	"encoding/base64"
)

func EncryptPassword(publicKey *rsa.PublicKey, password string) (string, error) {
	encryptedBytes, err := rsa.EncryptPKCS1v15(rand.Reader, publicKey, []byte(password))
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(encryptedBytes), nil
}

func DecryptPassword(privateKey *rsa.PrivateKey, encryptedPassword string) (string, error) {
	decodedBytes, err := base64.StdEncoding.DecodeString(encryptedPassword)
	if err != nil {
		return "", err
	}
	decryptedBytes, err := rsa.DecryptPKCS1v15(rand.Reader, privateKey, decodedBytes)
	if err != nil {
		return "", err
	}
	return string(decryptedBytes), nil
}
