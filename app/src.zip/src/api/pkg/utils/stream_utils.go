package utils

import (
	"fmt"
	"strings"
)

// BuildStreamURL constructs a complete streaming URL from components
func BuildStreamURL(protocol, hostname string, port int, username, password, path string) string {
	// Handle authentication part
	auth := ""
	if username != "" && username != "-" {
		if password != "" && password != "-" {
			auth = fmt.Sprintf("%s:%s@", username, password)
		} else {
			auth = fmt.Sprintf("%s@", username)
		}
	}

	// Handle path
	cleanPath := path
	if path != "" && !strings.HasPrefix(path, "/") {
		cleanPath = "/" + path
	}

	var baseURL = fmt.Sprintf("%s://%s%s:%d%s", protocol, auth, hostname, port, cleanPath)

	return baseURL
}
