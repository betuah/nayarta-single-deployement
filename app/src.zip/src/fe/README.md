Notes:

for build from .env to replace --build-arg
```sh
docker build $(cat .env | sed 's/^/--build-arg /') -t beesar/beesar-vms-admin .
```