self.onmessage = function(e) {
    const { jsonlText, chunkSize = 500 } = e.data;

    try {
        // Send initial progress
        self.postMessage({
            type: 'progress',
            data: { percentage: 0, message: 'Starting to parse annotation data...' }
        });

        const lines = jsonlText.split('\n').filter(line => line.trim());
        const totalLines = lines.length;

        console.log(`Worker: Processing ${totalLines} lines`);

        if (totalLines === 0) {
            self.postMessage({
                type: 'error',
                data: { error: 'No valid annotation data found' }
            });
            return;
        }
        // Parse metadata from first line BEFORE chunking
        let metadata = null;
        const frames = new Map();
        let processedLines = 0;

        try {
            const firstLineData = JSON.parse(lines[0]);
            if (firstLineData.video_metadata || firstLineData.video_meatdata) {
                metadata = firstLineData.video_metadata || firstLineData.video_meatdata;
                console.log('Worker: Found metadata in first line:', metadata);
                console.log('Worker: Metadata keys:', Object.keys(metadata));
                console.log('Worker: Has regions?', !!metadata.regions, metadata.regions?.length || 0);
            }
        } catch (error) {
            console.warn('Worker: Failed to parse first line for metadata:', error);
        }

        // Process in chunks to avoid blocking
        const processChunk = (startIndex) => {
            const endIndex = Math.min(startIndex + chunkSize, totalLines);

            for (let i = startIndex; i < endIndex; i++) {
                const line = lines[i].trim();
                if (!line) continue;

                try {
                    const data = JSON.parse(line);

                    // More flexible metadata detection
                    if (data.type === 'metadata' ||
                        (data.data && data.data.width && data.data.height && data.data.fps)) {
                        metadata = data.data || data;
                        console.log('Worker: Found metadata at line', i + 1, metadata);
                    }
                    // Try to detect metadata by structure if no explicit type
                    else if (!metadata && metadataAttempts < 10 &&
                        (data.width && data.height && data.fps)) {
                        metadata = data;
                        console.log('Worker: Inferred metadata from structure at line', i + 1, metadata);
                    }
                    // Frame data detection
                    else if (data.type === 'frame' ||
                        (data.data && typeof data.data.frame_id === 'number' && Array.isArray(data.data.detections))) {
                        const frameData = data.data || data;
                        if (typeof frameData.frame_id === 'number' && Array.isArray(frameData.detections)) {
                            frames.set(frameData.frame_id, frameData.detections);
                        }
                    }
                    // Try to detect frame data by structure
                    else if (typeof data.frame_id === 'number' && Array.isArray(data.detections)) {
                        frames.set(data.frame_id, data.detections);
                    }

                    metadataAttempts++;

                } catch (parseError) {
                    console.warn(`Worker: Failed to parse line ${i + 1}:`, parseError.message);
                    // Log the problematic line for debugging
                    if (i < 5) {
                        console.warn('Problematic line content:', line.substring(0, 200));
                    }
                }

                processedLines++;
            }

            const percentage = Math.round((processedLines / totalLines) * 100);

            // Send progress update
            self.postMessage({
                type: 'progress',
                data: {
                    percentage,
                    message: `Processing annotations... ${processedLines.toLocaleString()}/${totalLines.toLocaleString()} lines`,
                    processed: processedLines,
                    total: totalLines
                }
            });

            if (endIndex < totalLines) {
                // Schedule next chunk with a small delay to prevent blocking
                setTimeout(() => processChunk(endIndex), 1);
            } else {
                // Finished processing
                console.log('Worker: Parsing complete', {
                    metadata: metadata,
                    framesCount: frames.size,
                    totalProcessed: processedLines,
                    hasRegions: metadata && metadata.regions ? metadata.regions.length : 0
                });

                if (!metadata) {
                    if (frames.size > 0) {
                        console.log('Worker: No metadata found');
                    } else {
                        self.postMessage({
                            type: 'error',
                            data: { error: 'No metadata found and no frame data to infer from' }
                        });
                        return;
                    }
                }

                // Convert Map to plain object for transfer
                const framesObject = {};
                for (const [key, value] of frames.entries()) {
                    framesObject[key] = value;
                }

                self.postMessage({
                    type: 'complete',
                    data: {
                        metadata,
                        frames: framesObject,
                        totalFrames: frames.size
                    }
                });
            }
        };

        // Start processing
        processChunk(0);

    } catch (error) {
        console.error('Worker: Fatal error', error);
        self.postMessage({
            type: 'error',
            data: { error: error.message || 'Failed to parse annotation data' }
        });
    }
};
