export interface VideoMetadata {
    width: number;
    height: number;
    fps: number;
    regions?: number[][][]; // Array of polygon regions
    color_scheme?: {
        region?: string;
        text?: string;
        normal?: string;
        pre_event?: string;
        event?: string;
    };
}

export interface Detection {
    track_id: number;
    class_id: number;
    class_name: string;
    bbox: [number, number, number, number]; // [x1, y1, x2, y2]
    confidence: number;
    object_point: [number, number];
    status?: 'normal' | 'pre_event' | 'event'; // Optional status
}

export interface FrameData {
    frame_id: number;
    detections: Detection[];
}

export interface AnnotationData {
    metadata: VideoMetadata;
    frames: Map<number, Detection[]>;
}
