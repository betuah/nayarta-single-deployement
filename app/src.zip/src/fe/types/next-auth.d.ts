import {DefaultSession} from "next-auth"

type GroupMember = {
    group_id: string;
    member_id: string;
    group_name: string;
    role: string;
}

declare module "next-auth" {
    interface Session {
        error?: string
        user: {
            id: string;
            name: string;
            email: string;
            accessToken: string;
            refreshToken: string;
            profilePicture: string | null;
            members: GroupMember[];
        } & DefaultSession["user"]
    }

    interface User {
        id: string;
        name: string;
        email: string;
        access_token: string;
        refresh_token: string;
        profile_picture: string | null;
        members: GroupMember[];
    }
}

declare module "next-auth/jwt" {
    interface JWT {
        email: string;
        userId: string;
        members: GroupMember[];
        accessToken: string;
        refreshToken: string;
    }
}
