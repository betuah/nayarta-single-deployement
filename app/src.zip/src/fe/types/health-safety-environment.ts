export interface Point {
    x: number;
    y: number;
}

export interface ThresholdTime {
    value: number;
    unit: 'Seconds' | 'Minutes';
}

export interface DetectionConfig {
    threshold_time: ThresholdTime;
    object_types: string[];
}

export interface Zone {
    id: string;
    name: string;
    shape: ShapeType;
    coordinates: Point[];
}

export interface HSEDetectionData {
    health_safety_environment: {
        zones: Zone[];
        created_at: string;
        updated_at: string;
        detection_config: DetectionConfig;
    };
}

export type ShapeType = 'custom' | 'rectangle' | 'fullscreen';

export type Mode = 'view' | 'drawing' | 'editing';

export const MODES: Record<string, Mode> = {
    VIEW: 'view',
    DRAWING: 'drawing',
    EDITING: 'editing',
};

export const AVAILABLE_SAFETY_EQUIPMENT = [
    { name: "Helmet", label: "Safety Helmet" },
    { name: "Vest", label: "Safety Vest" },
    { name: "Glasses", label: "Safety Glasses" },
    { name: "Gloves", label: "Safety Gloves" },
    { name: "Boots", label: "Safety Boots" },
    { name: "Mask", label: "Safety Mask" }
];
