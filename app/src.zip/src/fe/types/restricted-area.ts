export type Point = {
    x: number;
    y: number;
};
export type ShapeType = 'custom' | 'rectangle' | 'triangle' | 'hexagon' | 'circle' | 'pentagon';

export type Zone = {
    id: string;
    shape: ShapeType;
    coordinates: Point[];
    name: string
};

export type Duration = {
    unit: 'milliseconds' | 'seconds';
    after_event: number;
    before_event: number;
};

export type DetectionConfig = {
    duration: Duration;
    object_types: string[];
};

export type RestrictedArea = {
    zones: Zone[];
    created_at: string;
    updated_at: string;
    detection_config: DetectionConfig;
};

export type DetectionData = {
    restricted_area: RestrictedArea;
};

export const MODES = {
    VIEW: 'view',
    DRAWING: 'drawing',
    EDITING: 'editing'
} as const;

export type Mode = typeof MODES[keyof typeof MODES];
