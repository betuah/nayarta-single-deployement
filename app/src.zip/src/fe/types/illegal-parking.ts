export type ShapeType = 'custom' | 'rectangle';

export type DurationUnit = 'second' | 'minute';

export interface Point {
    x: number;
    y: number;
}

export interface Zone {
    id: string;
    name: string;
    shape: ShapeType;
    coordinates: Point[];
}

export interface DetectionConfig {
    duration: number;
    duration_unit: DurationUnit;
    object_types: string[];
}

export interface IllegalParkingData {
    illegal_parking: {
        zones: Zone[];
        created_at: string;
        updated_at: string;
        detection_config: DetectionConfig;
    };
}

export type Mode = 'VIEW' | 'DRAWING' | 'EDITING';

export const MODES = {
    VIEW: 'VIEW' as Mode,
    DRAWING: 'DRAWING' as Mode,
    EDITING: 'EDITING' as Mode,
};
