import {getDictionary, Locale} from "@/app/dictionaries";
import {Dictionary} from "@/app/dictionaries/dictionary.types";
import NotificationsClient from "@/app/[lang]/notifications/notifications.client";


const NotificationsPage = async ({params: {lang}}: { params: { lang: Locale } }) => {
    const trans: Dictionary = await getDictionary(lang);
    return(<>
        <NotificationsClient trans={trans} />
    </>)
}

export default NotificationsPage
