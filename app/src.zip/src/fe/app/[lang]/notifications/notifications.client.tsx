"use client"

import React from "react";
import {Dictionary} from "@/app/dictionaries/dictionary.types";
import {BreadcrumbItem, Breadcrumbs} from "@/components/ui/breadcrumbs";
import NotificationList from "@/components/notification/notification-list";


export interface NotificationsClientProps {
    trans: Dictionary
}

const NotificationsClient: React.FC<NotificationsClientProps> = (props) => {
    return(<>
        <Breadcrumbs>
            <BreadcrumbItem href="/">Home</BreadcrumbItem>
            <BreadcrumbItem className="text-primary">Notification History</BreadcrumbItem>
        </Breadcrumbs>
        <div className="flex flex-row items-center justify-between">
            <div className="mt-5 ml-2 text-2xl font-medium text-default-900">Notification History</div>

        </div>
        <div className='my-6'>
            <NotificationList />
        </div>
    </>)
}

export default NotificationsClient
