"use client"

import React from "react";
import {BreadcrumbItem, Breadcrumbs} from "@/components/ui/breadcrumbs";
import FileStorage from "@/components/file-storage/file-storage";

export interface FileStorageClientProps {

}

const FileStorageClient: React.FC<FileStorageClientProps> = (props) => {
    return (<>
        <Breadcrumbs>
            <BreadcrumbItem href="/">Home</BreadcrumbItem>
            <BreadcrumbItem className="text-primary">File Storage</BreadcrumbItem>
        </Breadcrumbs>
        <div className="flex flex-row justify-between items-center">
            <div className="mt-5 ml-2 text-2xl font-medium text-default-900">File Storage</div>
        </div>
        <div className='my-6'>
            <FileStorage />
        </div>
    </>)
}

export default FileStorageClient
