import {Locale} from "@/app/dictionaries";
import FileStorageClient from "@/app/[lang]/file-storage/file-storage.client";

const FileStoragePage = ({params: {lang}}: { params: { lang: Locale } }) => {
    return (
        <div>
            <FileStorageClient />
        </div>
    );
};

export default FileStoragePage;
