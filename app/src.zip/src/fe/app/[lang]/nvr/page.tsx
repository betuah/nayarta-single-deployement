import {getDictionary, Locale} from "@/app/dictionaries";
import {Dictionary} from "@/app/dictionaries/dictionary.types";
import NvrClient from "@/app/[lang]/nvr/nvr.client";


const NvrPage = async ({params: {lang}}: { params: { lang: Locale } }) => {

    const trans: Dictionary = await getDictionary(lang);

    return (<>
        <NvrClient trans={trans}/>
    </>)
}

export default NvrPage
