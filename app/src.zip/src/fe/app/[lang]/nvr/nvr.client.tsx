"use client"

import React from "react";
import {Dictionary} from "@/app/dictionaries/dictionary.types";
import {BreadcrumbItem, Breadcrumbs} from "@/components/ui/breadcrumbs";
import {Button} from "@/components/ui/button";
import Link from "next/link";
import NvrList from "@/components/nvr/nvr-list";


export interface NvrClientProps {
    trans: Dictionary
}
const NvrClient: React.FC<NvrClientProps> = () => {
  return(<>
      <Breadcrumbs>
          <BreadcrumbItem href="/">Home</BreadcrumbItem>
          <BreadcrumbItem className="text-primary">NVR Management</BreadcrumbItem>
      </Breadcrumbs>
      <div className="flex flex-row justify-between items-center ">
          <div className=" flex items-center mt-5 text-2xl font-medium text-default-900">NVR Management</div>
          <Button type="button" className='flex items-center' asChild><Link href="/nvr/add">Add NVR</Link></Button>
      </div>
      <div className='my-6 p-6'>
          <NvrList />
      </div>
  </>)
}

export default NvrClient
