"use client"

import React from "react";
import {Progress} from "@/components/ui/progress";

import DashboardBasicData from "@/components/dashboard/dashboard-basic-data";
import DashboardGroupOverview from "@/components/dashboard/dashboard-group-overview";
import DashboardPlanQuota from "@/components/dashboard/dashboard-plan-quota";
import DashboardRefreshControls from "@/components/dashboard/dashboard-refresh-controls";
import {useDashboardAutoRefresh} from "@/hooks/use-dashboard-auto-refresh";
import {useCCTVAnalyticsModuleStore} from "@/store/dashboard-module-store";
import {useGroupModuleStore} from "@/store/group-module-store";

export interface DashboardClientProps {

}

const DashboardClient: React.FC<DashboardClientProps> = (props) => {
    const {
        isLoading,
        isLoadingGroupOverview,
        isAutoRefreshing
    } = useCCTVAnalyticsModuleStore();

    const {
        isLoadingQuotaAll
    } = useGroupModuleStore();

    // Initialize auto-refresh functionality
    const { setUserInteracting, resetTimer } = useDashboardAutoRefresh({
        enabledSections: {
            basicData: true,
            groupOverview: true,
            planQuota: true,
            storageOverview: false // Set to true if you want to include storage overview
        },
        refreshInterval: 300000, // 5 minutes
        enabled: true
    });

    const isAnyLoading = isLoading || isLoadingGroupOverview || isLoadingQuotaAll;

    // Handle user interaction events to pause auto-refresh temporarily
    const handleUserInteraction = () => {
        setUserInteracting(true, 3000); // Pause for 3 seconds
        resetTimer();
    };

    // Handle section interactions
    const handleSectionClick = () => {
        handleUserInteraction();
    };

    return (<>
            {/* Loading indicators */}
            {isAnyLoading && !isAutoRefreshing && (
                <Progress value={70} color="primary" isInfinite size="xs"/>
            )}

            {isAutoRefreshing && !isAnyLoading && (
                <Progress value={30} color="primary" isInfinite size="xs"/>
            )}

            {/* Refresh Controls */}
            <div className='p-6'>
                <DashboardRefreshControls
                    enabledSections={{
                        basicData: true,
                        groupOverview: true,
                        planQuota: true,
                        storageOverview: false
                    }}
                />
            </div>

            <div className='p-6 space-y-12'>
                {/* Group Overview Section */}
                <div onClick={handleSectionClick}>
                    <DashboardGroupOverview/>
                </div>

                {/* Basic Data Section */}
                <div onClick={handleSectionClick}>
                    <DashboardBasicData/>
                </div>

                {/* Plan & Quota Section */}
                <div onClick={handleSectionClick}>
                    <DashboardPlanQuota/>
                </div>
            </div>
        </>
    )
}

export default DashboardClient
