import React from "react";
import {Locale} from "@/app/dictionaries";
import DashboardClient from "@/app/[lang]/dashboard/dashboard.client";
import {checkServerSession} from "@/lib/utils/check-session";

const DashboardPage = async ({params: {lang}}: { params: { lang: Locale } }) => {
    await checkServerSession()
    return (
        <div>
            <DashboardClient/>
        </div>
    );
};

export default DashboardPage;
