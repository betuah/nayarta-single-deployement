import {getDictionary, Locale} from "@/app/dictionaries";
import {Dictionary} from "@/app/dictionaries/dictionary.types";
import CameraClient from "@/app/[lang]/camera/camera.client";


const AiAnalyticsPage = async ({params: {lang}}: { params: { lang: Locale } }) => {
    const trans: Dictionary = await getDictionary(lang);
    return (<div/>)
}


export default AiAnalyticsPage
