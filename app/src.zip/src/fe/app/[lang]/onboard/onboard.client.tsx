"use client"
import React from "react";
import {useSession} from "next-auth/react";
import {useRouter} from "next/navigation";
import {useUserStore} from "@/store/user-store";
import LayoutLoader from "@/components/layout-loader";
import JoinGroupForm from "@/components/group-form";
import FrontHeader from "@/components/landing-page/header";
import Image from "next/image";
import auth3Dark from "@/public/images/auth/auth3-dark.png";
import auth3Light from "@/public/images/auth/auth3-light.png";
import {Alert, AlertDescription} from "@/components/ui/alert";

export const OnboardClient: React.FC = () => {

    const {data: session} = useSession()
    const router = useRouter();
    const {
        initializeUser,
        initializeMembers,
    } = useUserStore()

    React.useEffect(() => {
        if (session === undefined)
            return
        if (session?.user) {
            initializeUser(session.user)
            initializeMembers(session.user.members)
            if (session.user.members.length === 0) {
                // redirect to register member
            } else {
                // go to first member
                router.push(`/dashboard`);
            }
        } else {
            // no session
            router.push(`/auth/login`);
        }
    }, [session])

    if (session?.user.members.length === 0) {
        return (
            <>
                <FrontHeader showLoginButton={false}/>
                <div className="loginwrapper mt-20 flex justify-center items-center relative overflow-hidden">
                    <Image
                        src={auth3Dark}
                        alt="background image"
                        className="absolute top-0 left-0 w-full h-full light:hidden"/>
                    <Image
                        src={auth3Light}
                        alt="background image"
                        className="absolute top-0 left-0 w-full h-full dark:hidden"/>
                    <div className="w-full bg-card   max-w-xl  rounded-xl relative z-10 2xl:p-16 xl:p-12 p-10 m-4 ">
                        <Alert color="warning" variant="soft" dismissible className="mb-6">
                            <AlertDescription>
                                You have no active membership, please request to join an organization or create one
                            </AlertDescription>
                        </Alert>
                        <JoinGroupForm/>
                    </div>
                </div>
            </>
        )
    }

    return (<LayoutLoader/>)
}

export default OnboardClient
