import React from "react";
import {Locale} from "@/app/dictionaries";
import {checkServerSession} from "@/lib/utils/check-session";
import OnboardClient from "@/app/[lang]/onboard/onboard.client";

const OnboardPage = async ({params: {lang}}: { params: { lang: Locale } }) => {
    await checkServerSession()
    return (
        <div>
            <OnboardClient />
        </div>
    );
};

export default OnboardPage;
