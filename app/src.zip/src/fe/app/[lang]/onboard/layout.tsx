import DashBoardLayoutProvider from "@/provider/dashboard.layout.provider";

import {getDictionary} from "@/app/dictionaries";
import React from "react";

export const metadata = {
    title: "VMS Web - Onboard",
};

const layout = async ({children, params: {lang}}: { children: React.ReactNode; params: { lang: any } }) => {

    return (
        <>{children}</>
    );
};

export default layout;
