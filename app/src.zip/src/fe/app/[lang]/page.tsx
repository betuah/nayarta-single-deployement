"use client"
import { Breadcrumbs, BreadcrumbItem } from "@/components/ui/breadcrumbs";
import LandingPageView from "@/components/landing-page";
const IndexPage = () => {
    return (
        <div>
            <LandingPageView />
        </div>
    );
};

export default IndexPage;
