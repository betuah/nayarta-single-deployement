"use client"

import React from "react";
import {Dictionary} from "@/app/dictionaries/dictionary.types";
import {BreadcrumbItem, Breadcrumbs} from "@/components/ui/breadcrumbs";
import {Button} from "@/components/ui/button";
import Link from "next/link";
import NvrList from "@/components/nvr/nvr-list";
import CameraList from "@/components/camera/camera-list";

export interface CameraClientProps {
    trans: Dictionary
}
const CameraClient: React.FC<CameraClientProps> = (props) => {
    return(<>
        <Breadcrumbs>
            <BreadcrumbItem href="/">Home</BreadcrumbItem>
            <BreadcrumbItem className="text-primary">Camera Management</BreadcrumbItem>
        </Breadcrumbs>
        <div className="flex flex-row justify-between items-center ">
            <div className=" flex items-center mt-5 text-2xl font-medium text-default-900">Camera Management</div>
            {/*<Button type="button" className='flex items-center' asChild><Link href="/camera/add">Add Camera</Link></Button>*/}
        </div>
        <div className='my-6'>
            <CameraList />
        </div>
    </>)
}

export default CameraClient
