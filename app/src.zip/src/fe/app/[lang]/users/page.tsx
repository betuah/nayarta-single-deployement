import React from "react";
import UsersClient from "@/app/[lang]/users/users.client";
import {getDictionary, Locale} from "@/app/dictionaries";
import {Dictionary} from "@/app/dictionaries/dictionary.types";

const UsersPage = async ({params: {lang}}: { params: { lang: Locale } }) => {

    const trans: Dictionary = await getDictionary(lang);

    return (<>
        <UsersClient trans={trans}/>
    </>)
}

export default UsersPage
