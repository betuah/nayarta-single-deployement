"use client"

import React from "react";
import {BreadcrumbItem, Breadcrumbs} from "@/components/ui/breadcrumbs";
import {Dictionary} from "@/app/dictionaries/dictionary.types";
import UserList from "@/components/user/user-list";
import {Button} from "@/components/ui/button";
import Link from "next/link";

export interface UsersClientProps {
    trans: Dictionary
}

const UsersClient: React.FC<UsersClientProps> = (props) => {
    return (<>
        <Breadcrumbs>
            <BreadcrumbItem href="/">Home</BreadcrumbItem>
            <BreadcrumbItem className="text-primary">{props.trans.page_users_title}</BreadcrumbItem>
        </Breadcrumbs>

        <div className="flex flex-wrap items-center gap-4 mb-1 mt-5">
            <div className="flex-1">
                <div className="mt-5 text-2xl font-medium text-default-900">{props.trans.page_users_title}</div>
            </div>
            <div className="flex-none">
                <Button type="button" asChild><Link href="/users/add">Add User</Link></Button>
            </div>
        </div>
        <div className='my-6'>
            <UserList/>
        </div>
    </>)
}

export default UsersClient
