import React from "react";
import {Locale} from "@/app/dictionaries";
import {checkServerSession} from "@/lib/utils/check-session";
import DownloadClient from "@/app/[lang]/download/download.client";

const DownloadPage = async ({params: {lang}}: { params: { lang: Locale } }) => {
    await checkServerSession()
    return (
        <div>
            <DownloadClient/>
        </div>
    );
};

export default DownloadPage;
