"use client"

import React from "react";
import {BreadcrumbItem, Breadcrumbs} from "@/components/ui/breadcrumbs";
import {useSession} from "next-auth/react";

import DashboardBasicData from "@/components/dashboard/dashboard-basic-data";
import DashboardGroupOverview from "@/components/dashboard/dashboard-group-overview";
import DownloadPageComponent from "@/components/download";

export interface DownloadClientProps {

}

const DownloadClient: React.FC<DownloadClientProps> = (props) => {

    return (<>
        <div className='my-6 p-6'>
            <DownloadPageComponent />
        </div>
    </>)
}

export default DownloadClient
