"use client"

import React from "react";
import {BreadcrumbItem, Breadcrumbs} from "@/components/ui/breadcrumbs";
import {Layers} from "lucide-react"
import CrowdDetection from "@/components/camera/analytics/crowd-detection/crowd-detection";
import {HiMiniUserGroup} from "react-icons/hi2";
import RealtimeCounting from "@/components/analytic/realtime-counting/realtime-counting";
import {PiClockCountdownFill} from "react-icons/pi";
import VideoWall from "@/components/video-wall/video-wall";

export interface VideoWallClientProps {
}

const VideoWallClient: React.FC<VideoWallClientProps> = (props) => {
    return (<>
        <Breadcrumbs>
            <BreadcrumbItem href="/">Home</BreadcrumbItem>
            <BreadcrumbItem className="text-primary">Video Wall</BreadcrumbItem>
        </Breadcrumbs>
        <div className='my-6'>
            <VideoWall />
        </div>
    </>)
}

export default VideoWallClient
