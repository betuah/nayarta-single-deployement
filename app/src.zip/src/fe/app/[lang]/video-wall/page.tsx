import {getDictionary, Locale} from "@/app/dictionaries";
import VideoWallClient from "@/app/[lang]/video-wall/video-wall.client";

const VideoWallPage = async (
    {params: {lang}}: { params: { lang: Locale } }
) => {
    return (<>
        <VideoWallClient />
    </>)
}

export default VideoWallPage
