import {Locale} from "@/app/dictionaries";
import FloorPlanClient from "@/app/[lang]/floor-plans/floor-plan.client";

const FloorPlanPage = ({params: {lang}}: { params: { lang: Locale } }) => {
    return (
        <div>
            <FloorPlanClient/>
        </div>
    );
};

export default FloorPlanPage;
