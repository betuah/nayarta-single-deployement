"use client"

import React from "react";
import {BreadcrumbItem, Breadcrumbs} from "@/components/ui/breadcrumbs";
import FloorPlanList from "@/components/floor-plan/floor-plan-list";
import Link from "next/link";
import {Button} from "@/components/ui/button";

export interface FloorPlanClientProps {

}
const FloorPlanClient: React.FC<FloorPlanClientProps> = (props) => {
    return(<>
        <Breadcrumbs>
            <BreadcrumbItem href="/">Home</BreadcrumbItem>
            <BreadcrumbItem className="text-primary">Floor Plans</BreadcrumbItem>
        </Breadcrumbs>
        <div className="flex flex-row justify-between items-center">
            <div className="mt-5 ml-2 text-2xl font-medium text-default-900">Floor Plans</div>
            <Button type="button"  asChild><Link href="/floor-plans/add">Add New Floor
                Plan</Link></Button>
        </div>
        <div className='my-6'>
            <FloorPlanList/>
        </div>
    </>)
}

export default FloorPlanClient
