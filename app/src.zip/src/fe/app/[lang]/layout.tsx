import "../assets/scss/globals.scss";
import "../assets/scss/theme.scss";
import {Inter} from "next/font/google";
import {siteConfig} from "@/config/site";
import Providers from "@/provider/providers";
import "simplebar-react/dist/simplebar.min.css";
import AuthProvider from "@/provider/auth.provider";
import "flatpickr/dist/themes/light.css";
import DirectionProvider from "@/provider/direction.provider";
import {SessionProvider} from "next-auth/react";
import {NextAuthSessionProviders} from "@/lib/next-auth-session-provider";

const inter = Inter({subsets: ["latin"]});

export const metadata = {
    title: {
        default: siteConfig.name,
        template: `%s - ${siteConfig.name}`,
    },
    description: siteConfig.description,
};

export default function RootLayout({children, params: {lang}}: {
    children: React.ReactNode;
    params: { lang: string }
}) {
    return (
        <html lang={lang}>
        <AuthProvider>
            <Providers>
                <NextAuthSessionProviders>
                    <DirectionProvider lang={lang}>{children}</DirectionProvider>
                </NextAuthSessionProviders>
            </Providers>
        </AuthProvider>
        </html>
    );
}
