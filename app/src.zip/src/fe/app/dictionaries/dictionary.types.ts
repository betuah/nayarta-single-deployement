export type Dictionary = {
    dashboard: string;
    menu: string;
    menu_user: string;
    menu_user_add: string;
    menu_user_list: string;
    menu_nvr: string;
    menu_nvr_location: string;
    menu_nvr_location_list: string;
    menu_nvr_location_add: string;
    menu_nvr_list: string;
    menu_nvr_add: string;
    menu_nvr_backup: string;
    menu_settings: string;
    menu_logout: string;
    page_users_title: string;
    page_users_add_title: string;
    page_nvr_location_list_title: string
    page_nvr_location_add_title: string
};
