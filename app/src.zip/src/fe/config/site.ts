export const siteConfig = {
  name: "Nayarta",
  description: null,
  theme: "blue",
  radius: 0.5,
};
