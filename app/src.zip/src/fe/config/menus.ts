import {FaUsersCog} from "react-icons/fa";
import {BiCctv, BiSolidCctv} from "react-icons/bi";
import {TbDeviceAnalytics, TbDeviceIpadHorizontalPin} from "react-icons/tb";
import {FiUsers} from "react-icons/fi";
import {AiOutlineLogout} from "react-icons/ai";
import {RxDashboard} from "react-icons/rx";
import {SiBlueprint} from "react-icons/si";
import {LuUserCog} from "react-icons/lu";
import {SlLocationPin} from "react-icons/sl";
import {IoNotificationsOutline, IoSettingsOutline} from "react-icons/io5";
import {BsFolder} from "react-icons/bs";
import {PiMonitorPlayLight} from "react-icons/pi";


export interface MenuItemProps {
    title: string;
    icon: any;
    href?: string;
    child?: MenuItemProps[];
    megaMenu?: MenuItemProps[];
    multi_menu?: MenuItemProps[]
    nested?: MenuItemProps[]
    onClick: () => void;


}

export const menusConfig = {
    sidebarNav: {
        default: [
            {
                isHeader: true,
                title: "menu",
            },
            {
                title: "Video Wall",
                icon: PiMonitorPlayLight,
                href: "/video-wall"
            },
            {
                title: "Control Center",
                icon: RxDashboard,
                href: "/dashboard"
            },
            {
                title: "Management",
                icon: IoSettingsOutline ,
                href: "/dashboard",
                child: [
                    {
                        title: "menu_user_list",
                        href: "/users",
                        icon: FiUsers,
                    },
                    {
                        title: "Locations",
                        icon: SlLocationPin,
                        href: '/nvr/locations',
                    },
                    {
                        title: "Floor Plans",
                        icon: SiBlueprint,
                        href: '/floor-plans',
                    }
                ]
            },
            {
                title: "NVR",
                icon: TbDeviceIpadHorizontalPin,
                href: '/nvr',
            },
            {
                title: "Camera",
                icon: BiCctv,
                href: '/camera',
            },
            {
                title: "File Storage",
                icon: BsFolder,
                href: '/file-storage',
                child: [
                    {
                        title: "File Explorer",
                        href: "/file-storage",
                        icon: undefined,
                    },
                    {
                        title: "Storage Management",
                        href: "/file-storage/manage",
                        icon: undefined,
                    },
                ]
            },
            {
                title: "AI Analytics",
                icon: TbDeviceAnalytics,
                href: '/analytics',
                child: [
                    {
                        title: "Restricted Area",
                        href: "/ai-analytics/restricted-area",
                        icon: undefined,
                    },
                    {
                        title: "Counting Realtime",
                        href: "/ai-analytics/realtime-counting",
                        icon: undefined,
                    },
                    {
                        title: "Counting In and Out",
                        href: "/ai-analytics/in-out-counting",
                        icon: undefined,
                    },
                    {
                        title: "Different Direction",
                        href: "/ai-analytics/different-direction",
                        icon: undefined,
                    },
                    {
                        title: "Fire and Smoke",
                        href: "/ai-analytics/fire-smoke",
                        icon: undefined,
                    },
                    {
                        title: "People Converge",
                        href: "/ai-analytics/people-converge",
                        icon: undefined,
                    },
                    {
                        title: "Face Searching",
                        href: "/ai-analytics/face-search",
                        icon: undefined,
                    },
                    {
                        title: "Person Running",
                        href: "/ai-analytics/person-running",
                        icon: undefined,
                    },
                    {
                        title: "Unattended Object",
                        href: "/ai-analytics/unattended-object",
                        icon: undefined,
                    },
                    {
                        title: "Surrounding Vessel",
                        href: "/ai-analytics/surrounding-vessel",
                        icon: undefined,
                    },
                    {
                        title: "HSE",
                        href: "/ai-analytics/health-safety-environment",
                        icon: undefined,
                    },
                    {
                        title: "Illegal Parking",
                        href: "/ai-analytics/illegal-parking",
                        icon: undefined,
                    },
                ]
            },
            {
                title: "menu_logout",
                icon: AiOutlineLogout,
                href: '/logout',
            }
        ],
    },
};


export type ClassicNavType = (typeof menusConfig.sidebarNav.default)[number]
