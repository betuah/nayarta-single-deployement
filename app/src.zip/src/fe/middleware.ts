import { NextResponse, type NextMiddleware, type NextRequest } from "next/server";
import { match } from "@formatjs/intl-localematcher";
import Negotiator from "negotiator";

// Internationalization settings
const defaultLocale = "en";
const locales = ["en"];


function getLocale(request: Request) {
    const acceptedLanguage = request.headers.get("accept-language") ?? undefined;
    let headers = {"accept-language": acceptedLanguage};
    let languages = new Negotiator({headers}).languages();
    return match(languages, locales, defaultLocale);
}

export const middleware: NextMiddleware = async (request: NextRequest) => {
    const pathname = request.nextUrl.pathname;

    // Internationalization logic
    const pathnameIsMissingLocale = locales.every(
        (locale) => !pathname.startsWith(`/${locale}/`) && pathname !== `/${locale}`
    );

    let response = NextResponse.next();

    if (pathnameIsMissingLocale) {
        const locale = getLocale(request);
        return NextResponse.redirect(new URL(`/${locale}${pathname}`, request.url));
    }

    return response;
};

export const config = {
    matcher: [
        "/((?!api|assets|docs|.*\\..*|_next).*)",
    ],
};
