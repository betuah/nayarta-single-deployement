"use client";
import React from "react";
import Header from "@/components/partials/header";
import Sidebar from "@/components/partials/sidebar";
import {cn} from "@/lib/utils";
import {motion,} from "framer-motion";
import {useRouter, usePathname} from "next/navigation";
import Footer from "@/components/partials/footer";
import {useMediaQuery} from "@/hooks/use-media-query";
import MobileSidebar from "@/components/partials/sidebar/mobile-sidebar";
import {useMounted} from "@/hooks/use-mounted";
import LayoutLoader from "@/components/layout-loader";
import {useSidebar} from "@/store/theme";
import 'react-toastify/dist/ReactToastify.css';
import {ToastContainer} from "react-toastify";
import {useSession} from "next-auth/react";
import {useUserStore} from "@/store/user-store";
import MobileAiChat from "@/components/partials/ai-chat/mobile-chat";

const DashBoardLayoutProvider = ({children, trans}: { children: React.ReactNode, trans: any }) => {
    const {collapsed, setCollapsed, subMenu, chatOpen} = useSidebar();
    const [open, setOpen] = React.useState(false);
    const {data: session} = useSession()
    const {setMemberList} = useUserStore()
    const location = usePathname();
    const isMobile = useMediaQuery("(min-width: 768px)");
    const mounted = useMounted();

    // refresh member list
    React.useEffect(() => {
        if (session === undefined)
            return
        if (session?.user)
            setMemberList(session.user.members)
    }, [session])

    if (!mounted) {
        return <LayoutLoader/>;
    }

    return (
        <>
            <Header handleOpenSearch={() => setOpen(true)} trans={trans}/>
            <Sidebar trans={trans}/>
            {!isMobile && <MobileAiChat />}

            <div
                className={cn("content-wrapper transition-all duration-150 ", {
                    "ltr:xl:ml-[72px] rtl:xl:mr-[72px]": collapsed && !chatOpen,
                    "ltr:xl:ml-[272px] rtl:xl:mr-[272px]": !collapsed && !chatOpen,
                    "ltr:xl:ml-[344px] rtl:xl:mr-[344px]": chatOpen,
                })}
            >
                <div
                    className={cn(
                        "pt-6 pb-8 px-4  page-min-height-semibox ",
                    )}
                >
                    <div className="semibox-content-wrapper ">
                        <LayoutWrapper
                            isMobile={isMobile}
                            setOpen={setOpen}
                            open={open}
                            location={location}
                            trans={trans}
                        >
                            {children}
                        </LayoutWrapper>
                    </div>
                </div>
                <ToastContainer
                    style={{ fontSize: "14px", zIndex: 999999999999999 }}
                />
            </div>
            <Footer handleOpenSearch={() => setOpen(true)}/>
        </>
    );

};

export default DashBoardLayoutProvider;

const LayoutWrapper = ({children, isMobile, setOpen, open, location, trans}: {
    children: React.ReactNode,
    isMobile: boolean,
    setOpen: any,
    open: boolean,
    location: any,
    trans: any
}) => {
    return (
        <>
            <motion.div
                key={location}
                initial="pageInitial"
                animate="pageAnimate"
                exit="pageExit"
                variants={{
                    pageInitial: {
                        opacity: 0,
                        y: 50,
                    },
                    pageAnimate: {
                        opacity: 1,
                        y: 0,
                    },
                    pageExit: {
                        opacity: 0,
                        y: -50,
                    },
                }}
                transition={{
                    type: "tween",
                    ease: "easeInOut",
                    duration: 0.5,
                }}
            >
                <main>{children}</main>
            </motion.div>

            <MobileSidebar trans={trans} className="left-[300px]"/>
        </>
    );
};
