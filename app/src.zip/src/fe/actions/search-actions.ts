'use server'

import {
    CamerasListData, CamerasListParams, CamerasListError,
    FloorPlansListParams2, FloorPlansListResult, FloorPlansListFail,
    LocationsListParams2, LocationsListResult, LocationsListFail
} from "@/lib/api/data-contracts";
import { getAuthenticatedApi } from "@/lib/utils/get-authenticated-api";

export async function getCamerasList(params: CamerasListParams): Promise<CamerasListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.search.camerasList(params)
    } catch (error) {
        console.error('Error fetching cameras:', error)
        throw new Error('Failed to fetch cameras')
    }
}

export async function getFloorPlansList(params: FloorPlansListParams2): Promise<FloorPlansListResult> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.search.floorPlansList(params)
    } catch (error) {
        console.error('Error fetching floor plans:', error)
        throw new Error('Failed to fetch floor plans')
    }
}

export async function getLocationsList(params: LocationsListParams2): Promise<LocationsListResult> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.search.locationsList(params)
    } catch (error) {
        console.error('Error fetching locations:', error)
        throw new Error('Failed to fetch locations')
    }
}
