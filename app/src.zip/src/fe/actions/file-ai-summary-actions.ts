'use server'

import {
    AiSummarySummaryDetailParams, AiSummarySummaryDetailData,
    AiSummaryDetailParams, AiSummaryDetailData,
    AiSummaryCreateParams, AiSummaryCreateData,
    DtoCreateFileAISummaryRequest
} from "@/lib/api/data-contracts";
import { getAuthenticatedApi } from "@/lib/utils/get-authenticated-api";

export async function getFileAiSummaryList(params: AiSummaryDetailParams): Promise<AiSummaryDetailData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.fileAiSummary.aiSummaryDetail(params)
    } catch (error) {
        console.error('Error fetching file AI summaries:', error)
        throw new Error('Failed to fetch file AI summaries')
    }
}

export async function getFileAiSummaryDetail(params: AiSummarySummaryDetailParams): Promise<AiSummarySummaryDetailData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.fileAiSummary.aiSummarySummaryDetail(params)
    } catch (error) {
        console.error('Error get file AI summary:', error)
        throw new Error('Failed to get file AI summary')
    }
}

export async function createFileAiSummary(params: AiSummaryCreateParams, data: DtoCreateFileAISummaryRequest): Promise<AiSummaryCreateData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.fileAiSummary.aiSummaryCreate(params, data)
    } catch (error) {
        console.error('Error create file AI summary:', error)
        throw new Error('Failed to create file AI summary')
    }
}
