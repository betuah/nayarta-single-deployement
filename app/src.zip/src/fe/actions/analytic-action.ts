'use server'

import {
    ReportsNotificationsListData,
    ReportsNotificationsListParams
} from "@/lib/api/data-contracts";
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";

export async function getAnalyticNotificationList(params: ReportsNotificationsListParams): Promise<ReportsNotificationsListData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.alerts.reportsList(params)
        // return await api.analytics.reportsNotificationsList(params)
    } catch (error) {
        console.error('Error fetching notification list data:', error)
        throw new Error('Failed to fetch notification list data')
    }
}
