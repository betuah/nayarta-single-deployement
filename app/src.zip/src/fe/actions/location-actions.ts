'use server'

import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {
    DtoCreateLocationDTO, DtoUpdateLocationDTO, LocationsCreateData,
    LocationsCreateParams,
    LocationsDeleteData,
    LocationsDetailData,
    LocationsDetailParams,
    LocationsListData,
    LocationsListParams, LocationsUpdateData, LocationsUpdateParams
} from "@/lib/api/data-contracts";


export async function getAllLocation(query: LocationsListParams): Promise<LocationsListData> {
    const {api} = await getAuthenticatedApi()

    try {
        return await api.locations.locationsList(query)
    } catch (e) {
        console.error('Error fetching locations:', e)
        throw new Error('Failed to fetch locations')
    }
}


export async function getLocationDetails(params: LocationsDetailParams): Promise<LocationsDetailData> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.locations.locationsDetail(params)
    } catch (e) {
        console.error('Error fetching location details:', e)
        throw new Error('Failed to fetch location details')
    }
}


export async function deleteLocation(params: LocationsDetailParams): Promise<LocationsDeleteData> {
    const {api} = await getAuthenticatedApi()
    try {
        await api.locations.locationsDelete(params)
    } catch (e) {
        console.error('Error delete location data:', e)
        throw new Error('Failed to delete location')
    }
}


export async function createLocation(query: LocationsCreateParams, location: DtoCreateLocationDTO): Promise<LocationsCreateData> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.locations.locationsCreate(query, location)
    } catch (e) {
        console.error('Error creating location :', e)
        throw new Error('Failed to create location')
    }
}

export async function updateLocation(query: LocationsUpdateParams, location: DtoUpdateLocationDTO): Promise<LocationsUpdateData> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.locations.locationsUpdate(query, location)
    }catch (e) {
        console.error('Error updating location :', e)
        throw new Error('Failed to update location')
    }
}
