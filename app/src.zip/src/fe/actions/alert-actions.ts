'use server'
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {AlertsListData, AlertsListParams} from "@/lib/api/data-contracts";

export async function getAlerts(params: AlertsListParams): Promise<AlertsListData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.alerts.alertsList(params)
    } catch (error) {
        console.error('Error fetching alerts:', error)
        throw new Error('Failed to fetch alerts')
    }
}
