'use server'


import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {
    CheckUsernameListData,
    CheckUsernameListParams,
    DtoCreateNVRDTO, DtoUpdateNVRDTO, NvrsCreateData,
    NvrsCreateParams,
    NvrsDeleteParams,
    NvrsDetailData,
    NvrsDetailParams,
    NvrsListData,
    NvrsListParams, NvrsUpdateData, NvrsUpdateParams, TokenListData, TokenListParams
} from "@/lib/api/data-contracts";

export const getAllNvr = async (query: NvrsListParams): Promise<NvrsListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.nvrs.nvrsList(query)
    } catch (e) {
        console.error('Error fetching nvr list:', e)
        throw new Error('Failed to fetch nvr list')
    }
}

export const getNvrDetail = async (query: NvrsDetailParams): Promise<NvrsDetailData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.nvrs.nvrsDetail(query)
    } catch (e) {
        console.error('Error fetching nvr:', e)
        throw new Error('Failed to fetch nvr')
    }
}

export const getNvrToken = async (query: TokenListParams): Promise<TokenListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.nvrs.tokenList(query)
    } catch (e) {
        console.error('Error fetching nvr token:', e)
        throw new Error('Failed to fetch nvr token')
    }
}

export const deleteNVR = async (query: NvrsDeleteParams): Promise<void> => {
    const {api} = await getAuthenticatedApi()
    try {
        await api.nvrs.nvrsDelete(query)
    } catch (e) {
        console.error('Error delete nvr:', e)
        throw new Error('Failed to delete nvr')
    }
}

export const addNvr = async (query: NvrsCreateParams, data: DtoCreateNVRDTO): Promise<NvrsCreateData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.nvrs.nvrsCreate(query, data)
    } catch (e) {
        console.error('Error add nvr:', e)
        throw new Error('Failed to add nvr')
    }
}

export const updateNvr = async (query: NvrsUpdateParams, data: DtoUpdateNVRDTO): Promise<NvrsUpdateData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.nvrs.nvrsUpdate(query, data)
    } catch (e) {
        console.error('Error add nvr:', e)
        throw new Error('Failed to add nvr')
    }
}


export const checkNVRUsername = async (query: CheckUsernameListParams,): Promise<CheckUsernameListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.nvrs.checkUsernameList(query)
    } catch (e) {
        console.error('Error checking username:', e)
        throw new Error('Failed to checking username')
    }
}
