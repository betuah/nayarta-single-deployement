'use server'

import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {
    DtoStorageDetailsResponse,
    GroupOverviewListData,
    StatsListData,
    StorageDetailsListParams
} from "@/lib/api/data-contracts";

export const getDashboardState = async (groupId: string): Promise<StatsListData> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.dashboard.statsList({group_id: groupId})
    } catch (e) {
        console.error('Error get stats : ', e)
        throw new Error('Failed to get stats')
    }
}


export const getGroupOverview = async (groupId: string): Promise<GroupOverviewListData> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.dashboard.groupOverviewList({group_id: groupId})
    } catch (e) {
        console.error('Error get stats : ', e)
        throw new Error('Failed to get stats')
    }
}


export const getStorageDetails = async (params: StorageDetailsListParams): Promise<DtoStorageDetailsResponse> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.dashboard.storageDetailsList(params)
    } catch (e) {
        console.error('Error get file stats : ', e)
        throw new Error('Failed to get file stats')
    }
}
