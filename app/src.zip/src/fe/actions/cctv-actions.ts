'use server'

import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {
    CctvsCreateParams,
    CctvsDeleteParams,
    CctvsDetailData,
    CctvsDetailParams,
    CctvsListData,
    CctvsListParams,
    CctvsUpdateParams, ConnectionListData, ConnectionListParams,
    // ConnectionDetailData,
    // ConnectionDetailParams,
    DtoCreateCCTVDTO,
    DtoCreateStreamURLDTO, DtoPTZCommandRequest, DtoPTZCommandResponse,
    DtoUpdateCCTVDTO,
    DtoUpdateCCTVRecordingScheduleRequest, PostCctvsParams, ScheduleListData, ScheduleListParams,
    // ScheduleDetailData,
    // ScheduleDetailParams,
    ScheduleUpdateData,
    ScheduleUpdateParams, SnapshotsDetailData, SnapshotsDetailParams,
    StreamUrlsCreateData,
    StreamUrlsCreateParams, StreamUrlsListData, StreamUrlsListParams,
    // StreamUrlsDeleteParams,
    // StreamUrlsDetailData,
    // StreamUrlsDetailParams,
    StreamUrlsUrlIdDeleteParams
} from "@/lib/api/data-contracts";

export const getAllCCTV = async (query: CctvsListParams): Promise<CctvsListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.cctvs.cctvsList(query)
    } catch (e) {
        console.error('Error fetching cctv list:', e)
        throw new Error('Failed to fetch cctv list')
    }
}

export const deleteCctv = async (query: CctvsDeleteParams) => {
    const {api} = await getAuthenticatedApi()
    try {
        await api.cctvs.cctvsDelete(query)
    } catch (e) {
        console.error('Error fetching cctv list:', e)
        throw new Error('Failed to fetch cctv list')
    }
}


export const getCctvDetail = async (query: CctvsDetailParams): Promise<CctvsDetailData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.cctvs.cctvsDetail(query)
    } catch (e) {
        console.error('Error fetching cctv detail:', e)
        throw new Error('Failed to fetch cctv detail')
    }
}

export const getCctvConnection = async (query: ConnectionListParams): Promise<ConnectionListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.cctvs.connectionList(query)
    } catch (e) {
        console.error('Error fetching cctv connection:', e)
        throw new Error('Failed to fetch camera connection')
    }
}


export const addNewCCTV = async (query: CctvsCreateParams, data: DtoCreateCCTVDTO): Promise<void> => {
    try {
        const {api} = await getAuthenticatedApi()
        await api.cctvs.cctvsCreate(query, data)
    } catch (e) {
        console.error('Error add new camera:', e)
        throw new Error('Failed to add camera')
    }
}

export const editCctv = async (query: CctvsUpdateParams, data: DtoUpdateCCTVDTO): Promise<void> => {
    try {
        const {api} = await getAuthenticatedApi()
        await api.cctvs.cctvsUpdate(query, data)
    } catch (e) {
        console.error('Error edit camera:', e)
        throw new Error('Failed to edit camera')
    }
}

export const addNewStreamUrl = async (query: StreamUrlsCreateParams, data: DtoCreateStreamURLDTO): Promise<StreamUrlsCreateData> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.cctvs.streamUrlsCreate(query, data)
    } catch (e) {
        console.error('Error add new stream url:', e)
        throw new Error('Failed to edit camera')
    }
}

export const getStreamUrl = async (query: StreamUrlsListParams): Promise<StreamUrlsListData> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.cctvs.streamUrlsList(query)
    } catch (e) {
        console.error('Error edit camera:', e)
        throw new Error('Failed to edit camera')
    }
}


export const deleteStreamUrl = async (query: StreamUrlsUrlIdDeleteParams): Promise<void> => {
    try {
        const {api} = await getAuthenticatedApi()
        await api.cctvs.streamUrlsUrlIdDelete(query)
    } catch (e) {
        console.error('Error delete camera:', e)
        throw new Error('Failed to delete camera')
    }
}


export const getScheduleDetail = async (query: ScheduleListParams): Promise<ScheduleListData> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.cctvs.scheduleList(query)
    } catch (e) {
        console.error('Error get camera record schedule:', e)
        throw new Error('Failed to get camera record schedule')
    }
}


export const updateSchedule = async (query: ScheduleUpdateParams, data: DtoUpdateCCTVRecordingScheduleRequest): Promise<ScheduleUpdateData> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.cctvs.scheduleUpdate(query, data)
    } catch (e) {
        console.error('Error update camera record schedule:', e)
        throw new Error('Failed to update camera record schedule')
    }
}

export const sendPtz = async (query: PostCctvsParams, data: DtoPTZCommandRequest): Promise<DtoPTZCommandResponse> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.cctvs.postCctvs(query, data)
    } catch (e) {
        console.error('Error send ptz command:', e)
        throw new Error('Failed to send ptz command')
    }
}


export const getSnapshotUrl = async (query: SnapshotsDetailParams): Promise<SnapshotsDetailData> => {
    try {
        const {api} = await getAuthenticatedApi()
        return await api.cctvs.snapshotsDetail(query)
    } catch (e) {
        console.error('Error get camera record schedule:', e)
        throw new Error('Failed to get camera record schedule')
    }
}
