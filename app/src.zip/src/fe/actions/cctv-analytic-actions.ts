'use server'
import {
    AnalyticTypesListData,
    CctvAnalyticsUpdateParams,
    DtoUpdateCCTVAnalyticDTO,
    FilesListData,
    FilesListParams, PostCctvAnalyticsParams
} from "@/lib/api/data-contracts";
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";

export const updateAnalytics = async (query: CctvAnalyticsUpdateParams, data: DtoUpdateCCTVAnalyticDTO): Promise<void> => {
    const {api} = await getAuthenticatedApi()
    try {
        await api.cctvAnalytics.cctvAnalyticsUpdate(query, data)
    } catch (e) {
        console.error('Error update cctv analytic:', e)
        throw new Error('Failed update cctv analytic')
    }
}


export const syncAnalyticsType = async (query: PostCctvAnalyticsParams) => {
    const {api} = await getAuthenticatedApi()
    try {
        await api.cctvAnalytics.postCctvAnalytics(query)
    }catch (e) {
        console.error('Error sync cctv analytic:', e)
        throw new Error('Failed sync camera analytic')
    }
}

export const getAnalyticsType = async (): Promise<AnalyticTypesListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.analyticType.analyticTypesList()
    }catch (e) {
        console.error('Error get analytic type :', e)
        throw new Error('Failed get analytic type')
    }
}

