'use server'

import {
    DifferentDirectionChartListData,
    DifferentDirectionChartListParams,
    DtoSearchFaceRequestBody,
    InOutCountChartListData,
    InOutCountChartListParams,
    InOutCountOverviewListData,
    InOutCountOverviewListParams,
    ObjectCountCountingChartListData,
    ObjectCountCountingChartListParams,
    ObjectCountHeatmapListData,
    ObjectCountHeatmapListParams,
    ObjectCountPeopleCountingOverviewListData,
    ObjectCountPeopleCountingOverviewListParams,
    SearchFaceCreateData,
    SearchFaceCreateParams,
    FireSmokeChartListData,
    FireSmokeChartListParams,
    PeopleConvergeChartListData,
    PeopleConvergeChartListParams,
    PersonRunningChartListData,
    PersonRunningChartListParams,
    RestrictedAreaChartListData,
    RestrictedAreaChartListParams,
    SurroundingVesselChartListData,
    SurroundingVesselChartListParams,
    SurroundingVesselOverviewListData,
    SurroundingVesselOverviewListParams,
    UnattendedObjectChartListData,
    UnattendedObjectChartListParams,
    HseChartListParams,
    HseChartListData,
    IllegalParkingChartListParams,
    IllegalParkingChartListData
} from "@/lib/api/data-contracts";
import { getAuthenticatedApi } from "@/lib/utils/get-authenticated-api";

export async function getObjectCountCountingChart(params: ObjectCountCountingChartListParams): Promise<ObjectCountCountingChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.objectCountCountingChartList(params)
    } catch (error) {
        console.error('Error fetching counting chart data:', error)
        throw new Error('Failed to fetch counting chart data')
    }
}

export async function getObjectCountHeatmap(params: ObjectCountHeatmapListParams): Promise<ObjectCountHeatmapListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.objectCountHeatmapList(params)
    } catch (error) {
        console.error('Error fetching heatmap data:', error)
        throw new Error('Failed to fetch heatmap data')
    }
}

export async function getObjectCountPeopleCountingOverview(params: ObjectCountPeopleCountingOverviewListParams): Promise<ObjectCountPeopleCountingOverviewListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.objectCountPeopleCountingOverviewList(params)
    } catch (error) {
        console.error('Error fetching people counting overview:', error)
        throw new Error('Failed to fetch people counting overview')
    }
}


export async function getInOutPeopleCountingOverview(params: InOutCountOverviewListParams): Promise<InOutCountOverviewListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.inOutCountOverviewList(params)
    } catch (error) {
        console.error('Error fetching people in-out counting overview:', error)
        throw new Error('Failed to fetch people in-out counting overview')
    }
}


export async function getInOutCountCountingChart(params: InOutCountChartListParams): Promise<InOutCountChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.inOutCountChartList(params)
    } catch (error) {
        console.error('Error fetching in-out counting chart data:', error)
        throw new Error('Failed to fetch in-out counting chart data')
    }
}


export async function doFaceSearch(params: SearchFaceCreateParams, data: DtoSearchFaceRequestBody): Promise<SearchFaceCreateData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.searchFaceCreate(params, data)
    } catch (error) {
        console.error('Error search matching face:', error)
        throw new Error('Error search matching face')
    }
}


export async function getDifferentDirectionChart(params: DifferentDirectionChartListParams): Promise<DifferentDirectionChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.differentDirectionChartList(params)
    } catch (error) {
        console.error('Error fetching different direction chart data:', error)
        throw new Error('Failed to fetch different direction chart data')
    }
}

export async function getFireSmokeChart(params: FireSmokeChartListParams): Promise<FireSmokeChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.fireSmokeChartList(params)
    } catch (error) {
        console.error('Error fetching fire smoke chart data:', error)
        throw new Error('Failed to fetch fire smoke chart data')
    }
}

export async function getPeopleConvergeChart(params: PeopleConvergeChartListParams): Promise<PeopleConvergeChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.peopleConvergeChartList(params)
    } catch (error) {
        console.error('Error fetching people converge chart data:', error)
        throw new Error('Failed to fetch people converge chart data')
    }
}

export async function getPersonRunningChart(params: PersonRunningChartListParams): Promise<PersonRunningChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.personRunningChartList(params)
    } catch (error) {
        console.error('Error fetching person running chart data:', error)
        throw new Error('Failed to fetch person running chart data')
    }
}

export async function getRestrictedAreaChart(params: RestrictedAreaChartListParams): Promise<RestrictedAreaChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.restrictedAreaChartList(params)
    } catch (error) {
        console.error('Error fetching restricted area chart data:', error)
        throw new Error('Failed to fetch restricted area chart data')
    }
}

export async function getIllegalParkingChart(params: IllegalParkingChartListParams): Promise<IllegalParkingChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.illegalParkingChartList(params)
    } catch (error) {
        console.error('Error fetching restricted area chart data:', error)
        throw new Error('Failed to fetch restricted area chart data')
    }
}

export async function getSurroundingVesselChart(params: SurroundingVesselChartListParams): Promise<SurroundingVesselChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.surroundingVesselChartList(params)
    } catch (error) {
        console.error('Error fetching surrounding vessel chart data:', error)
        throw new Error('Failed to fetch surrounding vessel chart data')
    }
}

export async function getSurroundingVesselOverview(params: SurroundingVesselOverviewListParams): Promise<SurroundingVesselOverviewListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.surroundingVesselOverviewList(params)
    } catch (error) {
        console.error('Error fetching surrounding vessel overview:', error)
        throw new Error('Failed to fetch surrounding vessel overview')
    }
}

export async function getUnattendedObjectChart(params: UnattendedObjectChartListParams): Promise<UnattendedObjectChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.unattendedObjectChartList(params)
    } catch (error) {
        console.error('Error fetching unattended object chart data:', error)
        throw new Error('Failed to fetch unattended object chart data')
    }
}


export async function getHseChart(params: HseChartListParams): Promise<HseChartListData> {
    const { api, session } = await getAuthenticatedApi()

    try {
        return await api.analyticResult.hseChartList(params)
    } catch (error) {
        console.error('Error fetching HSE chart data:', error)
        throw new Error('Failed to fetch HSE chart data')
    }
}
