'use server'

import {
    DtoGeneratePublishTokenRequest,
    DtoGenerateReadTokenRequest,
    DtoValidateStreamTokenRequest,
    PublishCreateData,
    PublishCreateError,
    ReadCreateData,
    ReadCreateError,
    VerifyCreateData,
    VerifyCreateError,
    WellKnownJwksJsonListData,
    WellKnownJwksJsonListError
} from "@/lib/api/data-contracts";
import { getAuthenticatedApi } from "@/lib/utils/get-authenticated-api";

/**
 * Generate a publish token for streaming
 */
export async function generatePublishToken(
    data: DtoGeneratePublishTokenRequest
): Promise<PublishCreateData> {
    const { api } = await getAuthenticatedApi();

    try {
        return await api.streamAuth.publishCreate(data);
    } catch (error) {
        console.error('Error generating publish token:', error);
        throw new Error('Failed to generate publish token');
    }
}

/**
 * Generate a read token for accessing streams
 */
export async function generateReadToken(
    data: DtoGenerateReadTokenRequest
): Promise<ReadCreateData> {
    const { api } = await getAuthenticatedApi();

    try {
        return await api.streamAuth.readCreate( data);
    } catch (error) {
        console.error('Error generating read token:', error);
        throw new Error('Failed to generate read token');
    }
}

/**
 * Verify a stream token
 */
export async function verifyStreamToken(
    data: DtoValidateStreamTokenRequest
): Promise<VerifyCreateData> {
    const { api } = await getAuthenticatedApi();

    try {
        return await api.streamAuth.verifyCreate(data);
    } catch (error) {
        console.error('Error verifying stream token:', error);
        throw new Error('Failed to verify stream token');
    }
}

/**
 * Get JWKS (JSON Web Key Set) for stream authentication
 */
export async function getStreamAuthJwks(
): Promise<WellKnownJwksJsonListData> {
    const { api } = await getAuthenticatedApi();

    try {
        return await api.streamAuth.wellKnownJwksJsonList();
    } catch (error) {
        console.error('Error fetching stream auth JWKS:', error);
        throw new Error('Failed to fetch stream auth JWKS');
    }
}
