'use server'

import {
    AvailableCctvsDetailData,
    AvailableCctvsDetailParams, AvailableNvrsDetailData, AvailableNvrsDetailParams,
    DtoCreateFloorPlanObjectRequest,
    DtoUpdateFloorPlanObjectRequest,
    FloorPlanObjectsCreateData,
    FloorPlanObjectsCreateParams, FloorPlanObjectsDeleteData, FloorPlanObjectsDeleteParams,
    FloorPlanObjectsDetailData,
    FloorPlanObjectsDetailParams,
    FloorPlanObjectsListData,
    FloorPlanObjectsListParams,
    FloorPlanObjectsUpdateData,
    FloorPlanObjectsUpdateParams,
    ObjectDetailData,
    ObjectDetailParams,
} from "@/lib/api/data-contracts";
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";

export async function getFloorPlanList(params: FloorPlanObjectsListParams): Promise<FloorPlanObjectsListData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlanObject.floorPlanObjectsList(params)
    } catch (error) {
        console.error('Error fetching floor plan objects:', error)
        throw new Error('Failed to fetch floor plan')
    }
}


export async function createFloorPlanObjects(params: FloorPlanObjectsCreateParams, data: DtoCreateFloorPlanObjectRequest): Promise<FloorPlanObjectsCreateData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlanObject.floorPlanObjectsCreate(params, data)
    } catch (error) {
        console.error('Error create floor plan object:', error)
        throw new Error('Failed to create floor plan object')
    }
}

export async function getFloorPlanObjectDetailByObject(params: ObjectDetailParams): Promise<ObjectDetailData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlanObject.objectDetail(params)
    } catch (error) {
        console.error('Error create floor plan object:', error)
        throw new Error('Failed to create floor plan object')
    }
}


export async function getFloorPlanObjectDetailById(params: FloorPlanObjectsDetailParams): Promise<FloorPlanObjectsDetailData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlanObject.floorPlanObjectsDetail(params)
    } catch (error) {
        console.error('Error create floor plan object:', error)
        throw new Error('Failed to create floor plan object')
    }
}


export async function updateFloorPlanObject(params: FloorPlanObjectsUpdateParams, data: DtoUpdateFloorPlanObjectRequest): Promise<FloorPlanObjectsUpdateData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlanObject.floorPlanObjectsUpdate(params, data)
    } catch (error) {
        console.error('Error create floor plan object:', error)
        throw new Error('Failed to create floor plan object')
    }
}


export async function deleteFloorPlanObjects(params: FloorPlanObjectsDeleteParams): Promise<FloorPlanObjectsDeleteData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlanObject.floorPlanObjectsDelete(params)
    } catch (error) {
        console.error('Error create floor plan object:', error)
        throw new Error('Failed to create floor plan object')
    }
}


export async function getAvailableCCTV(params: AvailableCctvsDetailParams): Promise<AvailableCctvsDetailData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlanObject.availableCctvsDetail(params)
    } catch (error) {
        console.error('Error get available camera:', error)
        throw new Error('Error get available camera')
    }
}


export async function getAvailableNVR(params: AvailableNvrsDetailParams): Promise<AvailableNvrsDetailData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlanObject.availableNvrsDetail(params)
    } catch (error) {
        console.error('Error get available NVR:', error)
        throw new Error('Error get available NVR')
    }
}
