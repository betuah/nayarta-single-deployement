'use server'

import {
    DtoCreateFloorPlanRequest, DtoUpdateFloorPlanRequest, FloorPlansCreateData,
    FloorPlansCreateParams, FloorPlansDeleteData, FloorPlansDeleteParams, FloorPlansDetailData, FloorPlansDetailParams,
    FloorPlansListData,
    FloorPlansListParams, FloorPlansUpdateData, FloorPlansUpdateParams
} from "@/lib/api/data-contracts";
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";

export async function getFloorPlanList(params: FloorPlansListParams): Promise<FloorPlansListData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlan.floorPlansList(params)
    } catch (error) {
        console.error('Error fetching floor plan:', error)
        throw new Error('Failed to fetch floor plan')
    }
}

export async function createFloorPlans(params: FloorPlansCreateParams, data: DtoCreateFloorPlanRequest): Promise<FloorPlansCreateData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlan.floorPlansCreate(params, data)
    } catch (error) {
        console.error('Error create floor plan:', error)
        throw new Error('Failed to create floor plan')
    }
}

export async function getFloorPlansDetail(params: FloorPlansDetailParams): Promise<FloorPlansDetailData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlan.floorPlansDetail(params)
    } catch (error) {
        console.error('Error get floor plan:', error)
        throw new Error('Failed to get floor plan')
    }
}


export async function updateFloorPlans(params: FloorPlansUpdateParams, data: DtoUpdateFloorPlanRequest): Promise<FloorPlansUpdateData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlan.floorPlansUpdate(params, data)
    } catch (error) {
        console.error('Error update floor plan:', error)
        throw new Error('Failed to update floor plan')
    }
}


export async function deleteFloorPlan(params: FloorPlansDeleteParams): Promise<FloorPlansDeleteData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.floorPlan.floorPlansDelete(params)
    } catch (error) {
        console.error('Error delete floor plan:', error)
        throw new Error('Failed to delete floor plan')
    }
}
