'use server'

import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {
    DtoChangePasswordDTO,
    DtoCreateGroupDTO,
    DtoCreateMemberDTO,
    DtoJoinGroupMemberDTO, DtoMembershipList,
    DtoRegisterRequest,
    DtoRegisterResponse,
    DtoUpdateMemberDTO,
    MembersCreateData,
    MembersCreateParams,
    MembersDeleteParams,
    MembersDetailData,
    MembersDetailParams,
    MembersListData,
    MembersListParams,
    MembersUpdateData,
    MembersUpdateParams, PasswordUpdateData, UserUpdateData
} from "@/lib/api/data-contracts";

export async function getAllMembers(params: MembersListParams): Promise<MembersListData> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.members.membersList(params)
    } catch (e) {
        console.error('Error fetching members:', e)
        throw new Error('Failed to fetch members')
    }
}


export async function registerNewUser(data: DtoRegisterRequest): Promise<DtoRegisterResponse> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.auth.registerCreate(data)
    } catch (e) {
        console.error('Error creating user:', e)
        throw new Error('Error creating user')
    }
}

export async function createMember(query: MembersCreateParams, data: DtoCreateMemberDTO): Promise<MembersCreateData> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.members.membersCreate(query, data)
    } catch (e) {
        console.error('Error create member:', e)
        throw new Error('Failed to create a member')
    }
}


export async function getMemberDetail(params: MembersDetailParams): Promise<MembersDetailData> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.members.membersDetail(params)
    } catch (e) {
        console.error('Error get member detail:', e)
        throw new Error('Failed to get a member')
    }
}


export async function updateMember(params: MembersUpdateParams, data: DtoUpdateMemberDTO): Promise<MembersUpdateData> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.members.membersUpdate(params, data)
    } catch (e) {
        console.error('Error update member:', e)
        throw new Error('Failed to update member')
    }
}


export async function createGroup(data: DtoCreateGroupDTO): Promise<void> {
    const {api} = await getAuthenticatedApi()
    try {
        await api.groups.groupsCreate(data)
    } catch (e) {
        console.error('Error create group:', e)
        throw new Error('Failed to create group')
    }
}


export async function joinGroup(data: DtoJoinGroupMemberDTO): Promise<void> {
    const {api} = await getAuthenticatedApi()
    try {
        await api.members.joinCreate(data)
    } catch (e) {
        console.error('Error join group:', e)
        throw new Error('Failed to join group')
    }
}


export async function getUserMemberships(): Promise<DtoMembershipList> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.members.getMembers()
    } catch (e) {
        console.error('Error get memberships:', e)
        throw new Error('Failed to get memberships')
    }
}

export async function deleteMember(params: MembersDeleteParams): Promise<boolean> {
    const {api} = await getAuthenticatedApi()
    try {
        await api.members.membersDelete(params)
        return true
    } catch (e) {
        console.error('Error update member:', e)
        return false
    }
}

export async function updateUser(data: UserUpdateData): Promise<void> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.members.userUpdate(data)
    } catch (e) {
        console.error('Error update user:', e)
        throw new Error('Failed to update user detail')
    }
}

export async function updateUserPassword(data: PasswordUpdateData): Promise<void> {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.members.passwordUpdate(data)
    } catch (e) {
        console.error('Error update user password:', e)
        throw new Error('Failed to update user password')
    }
}
