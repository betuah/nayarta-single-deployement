'use server'

import {
    DtoCreateGroupDTO,
    DtoUpdateStorageSettingsDTO,
    GroupsCreateData,
    QuotaAllListData,
    QuotaAllListParams,
    QuotaCamerasListData,
    QuotaCamerasListParams,
    QuotaFloorPlansListData,
    QuotaFloorPlansListParams,
    QuotaLocationsListData,
    QuotaLocationsListParams,
    QuotaMembersListData,
    QuotaMembersListParams,
    QuotaNvrsListData,
    QuotaNvrsListParams,
    QuotaStorageListData,
    QuotaStorageListParams,
    ResourcesCountListData,
    StorageSettingsUpdateData,
    StorageSettingsUpdateParams,
    StorageUsageListData,
    StorageUsageListParams
} from "@/lib/api/data-contracts";
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";

export async function updateNotificationThreshold(params: StorageSettingsUpdateParams, data: DtoUpdateStorageSettingsDTO): Promise<StorageSettingsUpdateData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.storageSettingsUpdate(params, data)
    } catch (error) {
        console.error('Error update notification threshold:', error)
        throw new Error('Failed to update notification threshold')
    }
}

export async function getStorageUsageInfo(params: StorageUsageListParams): Promise<StorageUsageListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.storageUsageList(params)
    } catch (error) {
        console.error('Error get storage info:', error)
        throw new Error('Failed to get storage info')
    }
}


export async function createGroup(data: DtoCreateGroupDTO): Promise<GroupsCreateData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.groupsCreate(data)
    } catch (error) {
        console.error('Error creating group:', error)
        throw new Error('Failed to create group')
    }
}

export async function getQuotaAll(params: QuotaAllListParams): Promise<QuotaAllListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.quotaAllList(params)
    } catch (error) {
        console.error('Error getting all quota information:', error)
        throw new Error('Failed to get all quota information')
    }
}

export async function getQuotaCameras(params: QuotaCamerasListParams): Promise<QuotaCamerasListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.quotaCamerasList(params)
    } catch (error) {
        console.error('Error getting camera quota information:', error)
        throw new Error('Failed to get camera quota information')
    }
}

export async function getQuotaFloorPlans(params: QuotaFloorPlansListParams): Promise<QuotaFloorPlansListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.quotaFloorPlansList(params)
    } catch (error) {
        console.error('Error getting floor plan quota information:', error)
        throw new Error('Failed to get floor plan quota information')
    }
}

export async function getQuotaLocations(params: QuotaLocationsListParams): Promise<QuotaLocationsListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.quotaLocationsList(params)
    } catch (error) {
        console.error('Error getting location quota information:', error)
        throw new Error('Failed to get location quota information')
    }
}

export async function getQuotaMembers(params: QuotaMembersListParams): Promise<QuotaMembersListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.quotaMembersList(params)
    } catch (error) {
        console.error('Error getting member quota information:', error)
        throw new Error('Failed to get member quota information')
    }
}

export async function getQuotaNvrs(params: QuotaNvrsListParams): Promise<QuotaNvrsListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.quotaNvrsList(params)
    } catch (error) {
        console.error('Error getting NVR quota information:', error)
        throw new Error('Failed to get NVR quota information')
    }
}

export async function getQuotaStorage(params: QuotaStorageListParams): Promise<QuotaStorageListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.quotaStorageList(params)
    } catch (error) {
        console.error('Error getting storage quota information:', error)
        throw new Error('Failed to get storage quota information')
    }
}

export async function getResourcesCount(): Promise<ResourcesCountListData> {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.groups.resourcesCountList()
    } catch (error) {
        console.error('Error getting resources count:', error)
        throw new Error('Failed to get resources count')
    }
}
