'use server'

import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {
    CreateAllCreateParams, DtoCreateAllMemberAlertSettingsDTO, DtoUpdateMemberAlertSettingDTO,
    MemberAlertSettingsListData,
    MemberAlertSettingsListParams, MemberAlertSettingsUpdateParams
} from "@/lib/api/data-contracts";

export const getAlertSetting = async (query: MemberAlertSettingsListParams): Promise<MemberAlertSettingsListData> => {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.memberAlertSettings.memberAlertSettingsList(query)
    } catch (e) {
        console.error('Error fetching settings:', e)
        throw new Error('Failed to fetch settings')
    }
}


export const addAllSettings = async (query: CreateAllCreateParams, data: DtoCreateAllMemberAlertSettingsDTO): Promise<void> => {
    const {api, session} = await getAuthenticatedApi()
    try {
        return await api.memberAlertSettings.createAllCreate(query, data)
    } catch (e) {
        console.error('Error fetching settings:', e)
        throw new Error('Failed to fetch settings')
    }
}


export const updateAlertSetting = async (query: MemberAlertSettingsUpdateParams, data: DtoUpdateMemberAlertSettingDTO): Promise<void> => {
    const {api, session} = await getAuthenticatedApi()
    try {
        await api.memberAlertSettings.memberAlertSettingsUpdate(query, data)
    } catch (e) {
        console.error('Error fetching settings:', e)
        throw new Error('Failed to fetch settings')
    }
}
