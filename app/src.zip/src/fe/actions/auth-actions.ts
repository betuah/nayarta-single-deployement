'use server'


import {ApiInstance} from "@/lib/utils/api-instance";
import {DtoForgotPasswordRequest, DtoRegisterRequest} from "@/lib/api/data-contracts";

export const registerUser = async (data: DtoRegisterRequest): Promise<void> => {
    try {
        const api = ApiInstance("");
        await api.auth.registerCreate(data)
    }catch (error) {
        console.error('Error register user:', error)
        throw new Error('Failed to register user')
    }
}

export const forgotPassword = async (data: DtoForgotPasswordRequest): Promise<void> => {
  try {
      const api = ApiInstance("");
      await api.auth.forgotPasswordCreate(data)
  }catch (error) {
      console.error('Error forgot password:', error)
      throw new Error('Failed to forgot password')
  }
}
