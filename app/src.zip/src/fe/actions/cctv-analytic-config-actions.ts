'use server'

import {
    ConfigDetailData,
    ConfigDetailParams, ConfigResetCreateData,
    ConfigResetCreateParams,
    ConfigUpdateData,
    ConfigUpdateParams,
    DtoUpdateCCTVAnalyticConfigRequest,
} from "@/lib/api/data-contracts";
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";

export const getConfig = async (query: ConfigDetailParams): Promise<ConfigDetailData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return api.cctvAnalyticConfigs.configDetail(query)
    } catch (e) {
        console.log('Error get cctv analytic config:', e)
        throw new Error('Failed get cctv analytic config')
    }
}

export const updateConfig = async (query: ConfigUpdateParams, data: DtoUpdateCCTVAnalyticConfigRequest): Promise<ConfigUpdateData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return api.cctvAnalyticConfigs.configUpdate(query, data)
    } catch (e) {
        console.error('Error update cctv analytic config:', e)
        throw new Error('Failed update cctv analytic config')
    }
}


export const resetConfig = async (query: ConfigResetCreateParams): Promise<ConfigResetCreateData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return api.cctvAnalyticConfigs.configResetCreate(query)
    } catch (e) {
        console.error('Error reset cctv analytic config:', e)
        throw new Error('Failed reset cctv analytic config')
    }
}
