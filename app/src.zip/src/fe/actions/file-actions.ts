'use server'
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {
    AnalyticsListParams2,
    BatchDeleteRecordingDeleteData,
    BatchDeleteRecordingDeleteParams, BulkDeleteByRangeDeleteData, BulkDeleteByRangeDeleteParams,
    BulkDeleteSummaryCreateData,
    BulkDeleteSummaryCreateParams, DtoBulkDeleteFilesRequest,
    DtoBulkDeleteSummaryRequest,
    DtoFileDetailAdvanced,
    FilesDeleteParams,
    FilesDetailData,
    FilesDetailParams,
    FilesListData,
    FilesListParams,
    RecordingPlaybackListData,
    RecordingPlaybackListParams, RecordingPlaybackMultiListData, RecordingPlaybackMultiListParams,
    RecordingStorageBreakdownListData,
    RecordingStorageBreakdownListParams,
    WithLocationListData,
    WithLocationListParams
} from "@/lib/api/data-contracts";


export const getFileList = async (query: FilesListParams): Promise<FilesListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.filesList(query)
    } catch (e) {
        console.error('Error fetching file list:', e)
        throw new Error('Failed to fetch file list')
    }
}

export const getFileListWithLocation = async (query: WithLocationListParams): Promise<WithLocationListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.withLocationList(query)
    } catch (e) {
        console.error('Error fetching file list:', e)
        throw new Error('Failed to fetch file list')
    }
}

export const deleteFile = async (query: FilesDeleteParams): Promise<void> => {
    const {api} = await getAuthenticatedApi()
    try {
        await api.files.filesDelete(query)
    } catch (e) {
        console.error('Error delete file : ', e)
        throw new Error('Failed to delete')
    }
}

export const getFileById = async (query: FilesDetailParams): Promise<FilesDetailData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.filesDetail(query)
    } catch (e) {
        console.error('Error get file : ', e)
        throw new Error('Failed to get file')
    }
}

export const generateDownloadUrl = async (url: string, provider: string): Promise<string> => {
    const {api} = await getAuthenticatedApi()
    try {
        const data = await api.files.accessDownloadUrlList({
            provider: provider,
            fileUrl: url
        })
        return data.url
    } catch (e) {
        console.error('Error get file : ', e)
        throw new Error('Failed to get file')
    }
}


export const getFileAndAnalyticById = async (query: AnalyticsListParams2): Promise<DtoFileDetailAdvanced> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.analyticsList(query)
    } catch (e) {
        console.error('Error get file : ', e)
        throw new Error('Failed to get file')
    }
}


export const BatchDeleteRecordings = async (query: BatchDeleteRecordingDeleteParams): Promise<BatchDeleteRecordingDeleteData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.batchDeleteRecordingDelete(query)
    } catch (e) {
        console.error('Error delete batch recordings : ', e)
        throw new Error('Error delete batch recordings')
    }
}


export const recordingPlaybackList = async (query: RecordingPlaybackListParams): Promise<RecordingPlaybackListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.recordingPlaybackList(query)
    } catch (e) {
        console.error('Error get playback : ', e)
        throw new Error('Error get playback')
    }
}

export const recordingPlaybackListMulti = async (query: RecordingPlaybackMultiListParams): Promise<RecordingPlaybackMultiListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.recordingPlaybackMultiList(query)
    } catch (e) {
        console.error('Error get playback : ', e)
        throw new Error('Error get playback')
    }
}


export const getRecordingBreakdown = async (query: RecordingStorageBreakdownListParams): Promise<RecordingStorageBreakdownListData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.recordingStorageBreakdownList(query)
    } catch (e) {
        console.error('Error get storage breakdown: ', e)
        throw new Error('Error get storage breakdown')
    }
}

export const bulkDeleteSummary = async (
    query: BulkDeleteSummaryCreateParams,
    data: DtoBulkDeleteSummaryRequest,
): Promise<BulkDeleteSummaryCreateData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.bulkDeleteSummaryCreate(query, data)
    } catch (e) {
        console.error('Error get bulk delete summary: ', e)
        throw new Error('Error get bulk delete summary')
    }
}


export const bulkDelete = async (
    query: BulkDeleteByRangeDeleteParams,
    data: DtoBulkDeleteFilesRequest,
): Promise<BulkDeleteByRangeDeleteData> => {
    const {api} = await getAuthenticatedApi()
    try {
        return await api.files.bulkDeleteByRangeDelete(query, data)
    } catch (e) {
        console.error('Error get bulk delete recordings: ', e)
        throw new Error('Error get bulk delete recordings')
    }
}
