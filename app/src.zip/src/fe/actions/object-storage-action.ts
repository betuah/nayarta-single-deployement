'use server'

import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";
import {
    DtoGetPresignedURLRequest,
    PublicUploadUrlCreateData,
    PublicUploadUrlCreateParams
} from "@/lib/api/data-contracts";
import axios, {AxiosError} from "axios";

export async function createPublicPresignedUrl(query: PublicUploadUrlCreateParams, file: DtoGetPresignedURLRequest): Promise<PublicUploadUrlCreateData> {
    const {api} = await getAuthenticatedApi()
    try {
        const resp = await api.fileObjects.publicUploadUrlCreate(query, file)
        console.log(resp)
        return resp
    } catch (error) {
        if (axios.isAxiosError(error) && error.response?.status === 403) {
            throw new Error('FORBIDDEN')
        } else throw new Error('Failed upload file')
    }
}
