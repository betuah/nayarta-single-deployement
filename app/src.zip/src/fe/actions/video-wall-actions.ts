'use server'

import {
    DtoCreateVideoWallDTO, DtoUpdateVideoWallDTO, VideoWallsCreateData,
    VideoWallsCreateParams, VideoWallsDeleteData, VideoWallsDeleteParams, VideoWallsDetailData, VideoWallsDetailParams,
    VideoWallsListData,
    VideoWallsListParams, VideoWallsUpdateData, VideoWallsUpdateParams
} from "@/lib/api/data-contracts";
import {getAuthenticatedApi} from "@/lib/utils/get-authenticated-api";

export async function getVideoWallList(params: VideoWallsListParams): Promise<VideoWallsListData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.videoWalls.videoWallsList(params)
    } catch (error) {
        console.error('Error fetching video walls:', error)
        throw new Error('Failed to fetch video walls')
    }
}

export async function createVideoWall(params: VideoWallsCreateParams, data: DtoCreateVideoWallDTO): Promise<VideoWallsCreateData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.videoWalls.videoWallsCreate(params, data)
    } catch (error) {
        console.error('Error create video wall:', error)
        throw new Error('Failed to create video wall')
    }
}

export async function getVideoWallDetail(params: VideoWallsDetailParams): Promise<VideoWallsDetailData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.videoWalls.videoWallsDetail(params)
    } catch (error) {
        console.error('Error get video wall:', error)
        throw new Error('Failed to get video wall')
    }
}

export async function updateVideoWall(params: VideoWallsUpdateParams, data: DtoUpdateVideoWallDTO): Promise<VideoWallsUpdateData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.videoWalls.videoWallsUpdate(params, data)
    } catch (error) {
        console.error('Error update video wall:', error)
        throw new Error('Failed to update video wall')
    }
}

export async function deleteVideoWall(params: VideoWallsDeleteParams): Promise<VideoWallsDeleteData> {
    const {api, session} = await getAuthenticatedApi()

    try {
        return await api.videoWalls.videoWallsDelete(params)
    } catch (error) {
        console.error('Error delete video wall:', error)
        throw new Error('Failed to delete video wall')
    }
}
