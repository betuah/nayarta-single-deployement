import { useState, useCallback } from 'react';

interface FetchProgress {
    loaded: number;
    total: number;
    percentage: number;
}

interface UseFetchWithProgressReturn {
    fetchWithProgress: (url: string) => Promise<string>;
    progress: FetchProgress;
    isLoading: boolean;
    error: string | null;
}

export const useFetchWithProgress = (): UseFetchWithProgressReturn => {
    const [progress, setProgress] = useState<FetchProgress>({
        loaded: 0,
        total: 0,
        percentage: 0
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const fetchWithProgress = useCallback(async (url: string): Promise<string> => {
        setIsLoading(true);
        setError(null);
        setProgress({ loaded: 0, total: 0, percentage: 0 });

        try {
            const response = await fetch(url);

            if (!response.ok) {
                throw new Error(`Failed to fetch: ${response.statusText}`);
            }

            const contentLength = response.headers.get('Content-Length');
            const total = contentLength ? parseInt(contentLength, 10) : 0;

            if (!response.body) {
                throw new Error('Response body is not available');
            }

            const reader = response.body.getReader();
            const chunks: Uint8Array[] = [];
            let loaded = 0;

            while (true) {
                const { done, value } = await reader.read();

                if (done) break;

                if (value) {
                    chunks.push(value);
                    loaded += value.length;

                    const percentage = total > 0 ? Math.round((loaded / total) * 100) : 0;

                    setProgress({
                        loaded,
                        total,
                        percentage
                    });

                    // Allow UI to update
                    await new Promise(resolve => setTimeout(resolve, 0));
                }
            }

            // Convert chunks to string efficiently
            const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
            const combined = new Uint8Array(totalLength);
            let offset = 0;

            for (const chunk of chunks) {
                combined.set(chunk, offset);
                offset += chunk.length;
            }

            const decoder = new TextDecoder();
            const text = decoder.decode(combined);

            setIsLoading(false);
            return text;

        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
            setError(errorMessage);
            setIsLoading(false);
            throw err;
        }
    }, []);

    return {
        fetchWithProgress,
        progress,
        isLoading,
        error
    };
};
