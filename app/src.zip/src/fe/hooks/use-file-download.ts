"use client"

import { useFileModuleStore } from "@/store/file-module-store";
import { toast } from "react-toastify";

/**
 * Custom hook for handling file downloads
 * @returns Functions for downloading files
 */
export const useFileDownload = () => {
    const { generateDownloadUrlFile, currentFileUrl, isUrlLoading } = useFileModuleStore();

    /**
     * Trigger a file download
     * @param fileUrl The URL of the file to download
     * @param fileName The name to save the file as
     * @param provider The file provider (object_storage or local)
     */
    const downloadFile = async (fileUrl: string, fileName: string, provider: string) => {
        try {
            // Check if it's a public file
            if (fileUrl.includes('/public/')) {
                // For public files, download directly
                startDownload(fileUrl, fileName);
            } else {
                // For private files, get a presigned URL first
                const downloadFileUrl = await generateDownloadUrlFile(fileUrl, provider);

                // Wait for the presigned URL to be generated
                if (!downloadFileUrl) {
                    // If there's no URL after waiting, something went wrong
                    toast.error("Failed to generate download URL. Please try again.");
                    return;
                }

                // Start the download with the presigned URL
                startDownload(downloadFileUrl, fileName);
            }
        } catch (error) {
            console.error("Download error:", error);
            toast.error("An error occurred while downloading the file. Please try again.");
        }
    };

    /**
     * Start the actual download process
     * @param url The URL to download from
     * @param fileName The name to save the file as
     */
    const startDownload = (url: string, fileName: string) => {
        // Create a hidden anchor element
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);

        // Trigger the download
        a.click();

        // Clean up
        document.body.removeChild(a);
    };

    return {
        downloadFile,
        isDownloading: isUrlLoading
    };
};
