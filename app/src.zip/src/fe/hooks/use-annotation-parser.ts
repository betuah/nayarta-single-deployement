import { useState, useCallback, useRef } from 'react';
import type { AnnotationData } from '@/types/annotations';

interface ParseProgress {
    percentage: number;
    message: string;
    processed?: number;
    total?: number;
}

interface UseAnnotationParserReturn {
    parseAnnotations: (jsonlText: string) => Promise<AnnotationData>;
    isParsingAnnotations: boolean;
    parsingProgress: ParseProgress;
    parsingError: string | null;
}

export const useAnnotationParser = (): UseAnnotationParserReturn => {
    const [isParsingAnnotations, setIsParsingAnnotations] = useState(false);
    const [parsingProgress, setParsingProgress] = useState<ParseProgress>({
        percentage: 0,
        message: ''
    });
    const [parsingError, setParsingError] = useState<string | null>(null);
    const workerRef = useRef<Worker | null>(null);

    const parseAnnotations = useCallback(async (jsonlText: string): Promise<AnnotationData> => {
        return new Promise((resolve, reject) => {
            setIsParsingAnnotations(true);
            setParsingError(null);
            setParsingProgress({ percentage: 0, message: 'Initializing parser...' });

            // Terminate existing worker if any
            if (workerRef.current) {
                workerRef.current.terminate();
            }

            // Create new worker
            try {
                workerRef.current = new Worker('/workers/annotation-parser.worker.js');
            } catch (error) {
                setIsParsingAnnotations(false);
                setParsingError('Failed to initialize annotation parser');
                reject(new Error('Failed to initialize annotation parser'));
                return;
            }

            const worker = workerRef.current;

            worker.onmessage = (e) => {
                const { type, data } = e.data;

                switch (type) {
                    case 'progress':
                        setParsingProgress(data);
                        break;

                    case 'complete':
                        // Convert frames object back to Map
                        const framesMap = new Map();
                        for (const [key, value] of Object.entries(data.frames)) {
                            framesMap.set(parseInt(key), value as any);
                        }

                        const result: AnnotationData = {
                            metadata: data.metadata,
                            frames: framesMap
                        };

                        setIsParsingAnnotations(false);
                        setParsingProgress({ percentage: 100, message: 'Parsing complete!' });
                        worker.terminate();
                        workerRef.current = null;
                        resolve(result);
                        break;

                    case 'error':
                        setIsParsingAnnotations(false);
                        setParsingError(data.error);
                        worker.terminate();
                        workerRef.current = null;
                        reject(new Error(data.error));
                        break;
                }
            };

            worker.onerror = (error) => {
                setIsParsingAnnotations(false);
                setParsingError('Worker error occurred');
                worker.terminate();
                workerRef.current = null;
                reject(new Error('Worker error occurred'));
            };

            // Start parsing
            worker.postMessage({
                jsonlText,
                chunkSize: 500 // Process 500 lines at a time
            });
        });
    }, []);

    return {
        parseAnnotations,
        isParsingAnnotations,
        parsingProgress,
        parsingError
    };
};
