import { useEffect, useRef, useCallback } from 'react';
import { useCCTVAnalyticsModuleStore } from '@/store/dashboard-module-store';
import { useGroupModuleStore } from '@/store/group-module-store';

interface UseDashboardAutoRefreshOptions {
    enabledSections?: {
        basicData?: boolean;
        groupOverview?: boolean;
        planQuota?: boolean;
        storageOverview?: boolean;
    };
    refreshInterval?: number; // in milliseconds
    enabled?: boolean;
}

export const useDashboardAutoRefresh = (options: UseDashboardAutoRefreshOptions = {}) => {
    const {
        enabledSections = {
            basicData: true,
            groupOverview: true,
            planQuota: true,
            storageOverview: false
        },
        refreshInterval = 300000, // 5 minutes default
        enabled = true
    } = options;

    const {
        isLoading,
        isLoadingGroupOverview,
        isLoadingStorageOverview,
        getDashboardBasicData,
        getGroupOverviewData,
        getStorageOverviewData
    } = useCCTVAnalyticsModuleStore();

    const {
        isLoadingQuotaAll,
        fetchQuotaAll
    } = useGroupModuleStore();

    const refreshTimerRef = useRef<NodeJS.Timeout | null>(null);
    const userInteractingRef = useRef(false);
    const userInteractionTimeoutRef = useRef<NodeJS.Timeout | null>(null);

    const isAnyLoading = isLoading || isLoadingGroupOverview || isLoadingStorageOverview || isLoadingQuotaAll;

    const refreshAllSections = useCallback(async () => {
        if (userInteractingRef.current || isAnyLoading || !enabled) {
            return;
        }

        try {
            const promises: Promise<void>[] = [];

            if (enabledSections.basicData) {
                promises.push(getDashboardBasicData());
            }

            if (enabledSections.groupOverview) {
                promises.push(getGroupOverviewData());
            }

            if (enabledSections.planQuota) {
                promises.push(fetchQuotaAll());
            }

            if (enabledSections.storageOverview) {
                // Use default parameters for storage overview
                promises.push(getStorageOverviewData("last_week", undefined, undefined));
            }

            await Promise.all(promises);
        } catch (error) {
            console.error('Dashboard auto-refresh failed:', error);
        }
    }, [
        enabledSections,
        enabled,
        isAnyLoading,
        getDashboardBasicData,
        getGroupOverviewData,
        fetchQuotaAll,
        getStorageOverviewData
    ]);

    const startTimer = useCallback(() => {
        if (!enabled) return;

        // Clear existing timer
        if (refreshTimerRef.current) {
            clearInterval(refreshTimerRef.current);
        }

        // Set new timer
        refreshTimerRef.current = setInterval(refreshAllSections, refreshInterval);
    }, [refreshAllSections, refreshInterval, enabled]);

    const stopTimer = useCallback(() => {
        if (refreshTimerRef.current) {
            clearInterval(refreshTimerRef.current);
            refreshTimerRef.current = null;
        }
    }, []);

    const resetTimer = useCallback(() => {
        if (enabled) {
            stopTimer();
            startTimer();
        }
    }, [enabled, stopTimer, startTimer]);

    const setUserInteracting = useCallback((interacting: boolean, duration: number = 5000) => {
        userInteractingRef.current = interacting;

        if (interacting) {
            // Clear any existing timeout
            if (userInteractionTimeoutRef.current) {
                clearTimeout(userInteractionTimeoutRef.current);
            }

            // Set timeout to automatically reset user interaction
            userInteractionTimeoutRef.current = setTimeout(() => {
                userInteractingRef.current = false;
            }, duration);
        }
    }, []);

    // Initialize timer when component mounts or settings change
    useEffect(() => {
        if (enabled) {
            startTimer();
        } else {
            stopTimer();
        }

        return () => {
            stopTimer();
            if (userInteractionTimeoutRef.current) {
                clearTimeout(userInteractionTimeoutRef.current);
            }
        };
    }, [enabled, startTimer, stopTimer]);

    // Reset timer when refresh interval changes
    useEffect(() => {
        if (enabled) {
            resetTimer();
        }
    }, [refreshInterval, resetTimer, enabled]);

    return {
        setUserInteracting,
        resetTimer,
        refreshAllSections,
        isAutoRefreshActive: enabled && !userInteractingRef.current && !isAnyLoading
    };
};
