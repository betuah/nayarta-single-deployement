import { useEffect, useRef, useCallback } from 'react';
import { useCCTVModuleStore } from '@/store/cctv-module-store';

export const useCameraDetailsAutoRefresh = (cameraId: string) => {
    const intervalRef = useRef<NodeJS.Timeout | null>(null);
    const isUserInteractingRef = useRef(false);

    const {
        isAutoRefreshEnabled,
        refreshInterval,
        refreshCameraDetails,
        isLoading,
        isAutoRefreshing
    } = useCCTVModuleStore();

    // Reset auto-refresh timer
    const resetTimer = useCallback(() => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
        }

        if (isAutoRefreshEnabled && !isLoading && !isAutoRefreshing && cameraId) {
            intervalRef.current = setInterval(() => {
                // Only refresh if user is not actively interacting and page is visible
                if (!isUserInteractingRef.current && !document.hidden) {
                    refreshCameraDetails(cameraId);
                }
            }, refreshInterval);
        }
    }, [isAutoRefreshEnabled, refreshInterval, refreshCameraDetails, isLoading, isAutoRefreshing, cameraId]);

    // Handle page visibility changes
    const handleVisibilityChange = useCallback(() => {
        if (document.hidden) {
            // Page is hidden, pause auto-refresh
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
                intervalRef.current = null;
            }
        } else {
            // Page is visible again, resume auto-refresh
            resetTimer();
        }
    }, [resetTimer]);

    // Track user interaction to pause auto-refresh temporarily
    const setUserInteracting = useCallback((interacting: boolean) => {
        isUserInteractingRef.current = interacting;

        if (interacting) {
            // User is interacting, pause auto-refresh temporarily
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
                intervalRef.current = null;
            }
        } else {
            // User stopped interacting, resume auto-refresh after a delay
            setTimeout(() => {
                if (!isUserInteractingRef.current) {
                    resetTimer();
                }
            }, 2000); // 2 second delay before resuming
        }
    }, [resetTimer]);

    // Initialize and cleanup auto-refresh
    useEffect(() => {
        // Set up page visibility listener
        document.addEventListener('visibilitychange', handleVisibilityChange);

        // Start initial timer
        resetTimer();

        return () => {
            // Cleanup
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
            document.removeEventListener('visibilitychange', handleVisibilityChange);
        };
    }, [handleVisibilityChange, resetTimer]);

    // Reset timer when settings change
    useEffect(() => {
        resetTimer();
    }, [resetTimer]);

    return {
        setUserInteracting,
        resetTimer
    };
};
