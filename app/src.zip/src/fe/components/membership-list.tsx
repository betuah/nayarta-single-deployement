import {useEffect} from 'react';
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
} from '@/components/ui/card';
import {Badge} from '@/components/ui/badge';
import {Button} from '@/components/ui/button';
import {Loader2, CheckCircle2, Building2, Plus, UserCircle, AlertCircle} from 'lucide-react';
import {useMemberModuleStore} from "@/store/member-module-store";
import {useUserStore} from "@/store/user-store";
import {cn} from "@/lib/utils";
import {CreateOrgDialog} from "@/components/org/create-org-dialog";
import {JoinOrgDialog} from "@/components/org/join-org-dialog";
import {ChangeOrgDialog} from "@/components/org/change-org-dialog";
import {useRouter} from "next/navigation";
import {GroupMember} from "@/types/next-auth";

export default function MembershipList() {
    const {
        memberships,
        isLoading,
        error,
        fetchMemberships,
        createOrganization,
        joinOrganization,
        showCreateOrgDialog,
        showJoinOrgDialog,
        showChangeOrgDialog,
        setShowCreateOrgDialog,
        setShowJoinOrgDialog,
        setShowChangeOrgDialog,
        isCreatingOrg,
        isJoiningOrg
    } = useMemberModuleStore();

    const {selectedGroupMember, switchOrganization} = useUserStore();
    const router = useRouter();

    useEffect(() => {
        fetchMemberships();
    }, []);

    const getStatusBadgeVariant = (status: string) => {
        switch (status.toLowerCase()) {
            case 'active':
                return undefined;
            case 'pending':
                return 'warning';
            case 'suspended':
                return 'destructive';
            default:
                return 'warning';
        }
    };

    const getRoleBadgeVariant = (role: string) => {
        switch (role.toLowerCase()) {
            case 'admin':
                return undefined;
            case 'member':
                return 'soft';
            default:
                return 'outline';
        }
    };

    const getOrgStatusIndicator = (status: string) => {
        switch (status.toLowerCase()) {
            case 'active':
                return <CheckCircle2 className="h-4 w-4 text-green-600" />;
            case 'pending':
                return <AlertCircle className="h-4 w-4 text-yellow-600" />;
            case 'suspended':
                return <AlertCircle className="h-4 w-4 text-red-600" />;
            default:
                return <Building2 className="h-4 w-4 text-gray-400" />;
        }
    };

    const isActiveMembership = (membershipId: string) => {
        return selectedGroupMember?.member_id === membershipId;
    };

    const canSwitchToOrg = (membership: any) => {
        return membership.group_status === "active" && membership.status === "active";
    };

    if (error) {
        return (
            <Card className="w-full">
                <CardContent className="p-6">
                    <div className="text-center text-red-500">
                        {error}
                    </div>
                </CardContent>
            </Card>
        );
    }

    return (
        <>
            <Card className="w-full border">
                <CardHeader>
                    <div className="flex flex-col sm:flex-row justify-between gap-4">
                        <CardTitle className="text-xl font-semibold">
                            Your Memberships
                        </CardTitle>
                        <div className="flex flex-col sm:flex-row gap-2">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setShowChangeOrgDialog(true)}
                            >
                                <Building2 className="h-4 w-4 mr-2"/>
                                Switch Organization
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setShowCreateOrgDialog(true)}
                            >
                                <Plus className="h-4 w-4 mr-2"/>
                                Create New Organization
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setShowJoinOrgDialog(true)}
                            >
                                <UserCircle className="h-4 w-4 mr-2"/>
                                Request Join Organization
                            </Button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    {isLoading ? (
                        <div className="flex justify-center p-4">
                            <Loader2 className="h-6 w-6 animate-spin"/>
                        </div>
                    ) : memberships?.length === 0 ? (
                        <div className="text-center text-gray-500 p-4">
                            No memberships found
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {memberships?.map((membership) => {
                                const isActive = isActiveMembership(membership.id!);
                                const canSwitch = canSwitchToOrg(membership);

                                return (
                                    <div
                                        key={membership.id}
                                        className={cn(
                                            "relative flex flex-col p-4 rounded-lg border",
                                            "transition-all duration-200",
                                            isActive
                                                ? "bg-primary/5 border-primary shadow-sm"
                                                : "bg-card hover:bg-accent/10"
                                        )}
                                    >
                                        {isActive && (
                                            <div className="absolute -left-0.5 top-0 h-full w-1 bg-primary rounded-l-lg"/>
                                        )}

                                        {/* Header Row */}
                                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-3">
                                            <div className="space-y-2">
                                                {/* Organization Name with Status */}
                                                <div className="flex items-center gap-2">
                                                    {getOrgStatusIndicator(membership.group_status!)}
                                                    <h4 className={cn(
                                                        "text-base font-medium",
                                                        canSwitch && "cursor-pointer hover:text-primary",
                                                        isActive && "text-primary"
                                                    )}
                                                        onClick={canSwitch ? () => {
                                                            switchOrganization({
                                                                ...membership,
                                                                member_id: selectedGroupMember?.member_id!
                                                            } as GroupMember)
                                                            router.push("/dashboard")
                                                        } : undefined}
                                                    >
                                                        {membership.group_name}
                                                    </h4>
                                                    {isActive && (
                                                        <Badge className="text-xs">
                                                            Current
                                                        </Badge>
                                                    )}
                                                </div>

                                                {/* Member ID */}
                                                <p className="text-xs text-muted-foreground">
                                                    Member ID: {membership.id}
                                                </p>
                                            </div>

                                            {/* Role Badge */}
                                            <Badge
                                                variant={getRoleBadgeVariant(membership.role!)}
                                                className="capitalize self-start"
                                            >
                                                {membership.role}
                                            </Badge>
                                        </div>

                                        {/* Status Information Row */}
                                        <div className="flex flex-col sm:flex-row gap-4 pt-2 border-t border-border/50">
                                            <div className="flex items-center gap-2">
                                                <span className="text-xs font-medium text-muted-foreground">
                                                    Organization:
                                                </span>
                                                <Badge
                                                    color={getStatusBadgeVariant(membership.group_status!)}
                                                    className="text-xs capitalize"
                                                    variant="soft"
                                                >
                                                    {membership.group_status}
                                                </Badge>
                                            </div>

                                            <div className="flex items-center gap-2">
                                                <span className="text-xs font-medium text-muted-foreground">
                                                    Your Membership:
                                                </span>
                                                <Badge
                                                    color={getStatusBadgeVariant(membership.status!)}
                                                    className="text-xs capitalize"
                                                    variant="soft"
                                                >
                                                    {membership.status}
                                                </Badge>
                                            </div>
                                        </div>

                                        {/* Helpful message for non-active items */}
                                        {!canSwitch && (
                                            <div className="mt-2 text-xs text-muted-foreground">
                                                {membership.group_status !== 'active' && membership.status !== 'active'
                                                    ? "Cannot switch: Organization and membership are not active"
                                                    : membership.group_status !== 'active'
                                                        ? "Cannot switch: Organization is not active"
                                                        : "Cannot switch: Your membership is not active"
                                                }
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </CardContent>
            </Card>

            <CreateOrgDialog
                open={showCreateOrgDialog}
                onOpenChange={setShowCreateOrgDialog}
                onSubmit={createOrganization}
                isLoading={isCreatingOrg}
            />

            <JoinOrgDialog
                open={showJoinOrgDialog}
                onOpenChange={setShowJoinOrgDialog}
                onSubmit={joinOrganization}
                isLoading={isJoiningOrg}
            />

            <ChangeOrgDialog
                open={showChangeOrgDialog}
                onOpenChange={setShowChangeOrgDialog}
            />
        </>
    );
}
