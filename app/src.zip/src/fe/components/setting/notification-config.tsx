import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface NotificationConfig {
    email: boolean;
    sms: boolean;
    push: boolean;
    wa: boolean
}

interface AnomalyNotification {
    id: string;
    name: string;
    enabled: boolean;
    config: NotificationConfig;
}

const RealtimeNotificationConfig = () => {
    const [anomalyNotifications, setAnomalyNotifications] = useState<AnomalyNotification[]>([
        { id: 'smoke', name: 'Smoke Detection', enabled: true, config: { email: true, sms: false, push: true, wa: true } },
        { id: 'fire', name: 'Fire Detection', enabled: true, config: { email: true, sms: true, push: true, wa: true } },
        { id: 'motion', name: 'Motion Detection', enabled: false, config: { email: false, sms: false, push: false, wa: true } },
    ]);

    const [emailRecipients, setEmailRecipients] = useState<string[]>(['admin@example.com']);
    const [phoneNumbers, setPhoneNumbers] = useState<string[]>(['+1234567890']);
    const [newRecipient, setNewRecipient] = useState('');
    const [recipientType, setRecipientType] = useState<'email' | 'phone'>('email');

    const updateAnomalyNotification = (id: string, updates: Partial<AnomalyNotification>) => {
        setAnomalyNotifications(anomalyNotifications.map(anomaly =>
            anomaly.id === id ? { ...anomaly, ...updates } : anomaly
        ));
    };

    const toggleNotificationType = (id: string, type: keyof NotificationConfig) => {
        setAnomalyNotifications(anomalyNotifications.map(anomaly =>
            anomaly.id === id ? { ...anomaly, config: { ...anomaly.config, [type]: !anomaly.config[type] } } : anomaly
        ));
    };

    const addRecipient = () => {
        if (newRecipient.trim() !== '') {
            if (recipientType === 'email') {
                setEmailRecipients([...emailRecipients, newRecipient.trim()]);
            } else {
                setPhoneNumbers([...phoneNumbers, newRecipient.trim()]);
            }
            setNewRecipient('');
        }
    };

    const removeRecipient = (type: 'email' | 'phone', recipient: string) => {
        if (type === 'email') {
            setEmailRecipients(emailRecipients.filter(email => email !== recipient));
        } else {
            setPhoneNumbers(phoneNumbers.filter(phone => phone !== recipient));
        }
    };

    return (
        <Card className="w-full border border-default-200">
            <CardHeader>
                <CardTitle>Real-time Notification Configuration</CardTitle>
                <CardDescription>Configure notifications for anomaly detection</CardDescription>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="anomalies">
                    <TabsList>
                        <TabsTrigger value="anomalies">Anomalies</TabsTrigger>
                        <TabsTrigger value="recipients">Recipients</TabsTrigger>
                    </TabsList>
                    <TabsContent value="anomalies">
                        {anomalyNotifications.map(anomaly => (
                            <div key={anomaly.id} className="mb-4 p-4 border rounded-md">
                                <div className="flex items-center justify-between mb-2">
                                    <Label htmlFor={`${anomaly.id}-switch`}>{anomaly.name}</Label>
                                    <Switch
                                        id={`${anomaly.id}-switch`}
                                        checked={anomaly.enabled}
                                        onCheckedChange={(checked) => updateAnomalyNotification(anomaly.id, { enabled: checked })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <div className="flex items-center space-x-2">
                                        <Checkbox
                                            id={`${anomaly.id}-email`}
                                            checked={anomaly.config.email}
                                            onCheckedChange={() => toggleNotificationType(anomaly.id, 'email')}
                                        />
                                        <label htmlFor={`${anomaly.id}-email`}>Email</label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox
                                            id={`${anomaly.id}-sms`}
                                            checked={anomaly.config.sms}
                                            onCheckedChange={() => toggleNotificationType(anomaly.id, 'sms')}
                                        />
                                        <label htmlFor={`${anomaly.id}-sms`}>SMS</label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox
                                            id={`${anomaly.id}-wa`}
                                            checked={anomaly.config.wa}
                                            onCheckedChange={() => toggleNotificationType(anomaly.id, 'wa')}
                                        />
                                        <label htmlFor={`${anomaly.id}-wa`}>WhatsApp</label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox
                                            id={`${anomaly.id}-push`}
                                            checked={anomaly.config.push}
                                            onCheckedChange={() => toggleNotificationType(anomaly.id, 'push')}
                                        />
                                        <label htmlFor={`${anomaly.id}-push`}>Push Notification</label>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </TabsContent>
                    <TabsContent value="recipients">
                        <div className="mt-4">
                            <div>
                                <Label className='mb-2'>Email Recipients</Label>
                                {emailRecipients.map(email => (
                                    <div key={email} className="flex items-center justify-between py-0">
                                        <div className='border-2 border-primary-200 p-1 rounded-md text-sm bg-primary-100 text-primary dark:bg-card dark:border-default-200'>{email}</div>
                                        <Button variant="ghost" color='destructive' onClick={() => removeRecipient('email', email)}>Remove</Button>
                                    </div>
                                ))}
                            </div>
                            <div className='mt-6'>
                                <Label className='mb-2'>Phone Numbers (for SMS & WhatsApp)</Label>
                                {phoneNumbers.map(phone => (
                                    <div key={phone} className="flex items-center justify-between py-0">
                                        <div className='border-2 border-primary-200 p-1 rounded-md text-sm bg-primary-100 text-primary dark:bg-card dark:border-default-200'>{phone}</div>
                                        <Button variant="ghost" color='destructive' onClick={() => removeRecipient('phone', phone)}>Remove</Button>
                                    </div>
                                ))}
                            </div>
                            <div className="flex space-x-2 mt-6">
                                <Select value={recipientType} onValueChange={(value: 'email' | 'phone') => setRecipientType(value)}>
                                    <SelectTrigger className="w-[180px]">
                                        <SelectValue placeholder="Select type" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="email">Email</SelectItem>
                                        <SelectItem value="phone">Phone</SelectItem>
                                    </SelectContent>
                                </Select>
                                <Input
                                    size='lg'
                                    placeholder={recipientType === 'email' ? "Enter email" : "Enter phone number"}
                                    value={newRecipient}
                                    onChange={(e) => setNewRecipient(e.target.value)}
                                />
                                <Button onClick={addRecipient}>Add</Button>
                            </div>
                        </div>
                    </TabsContent>
                </Tabs>
            </CardContent>
            <CardFooter>
                <Button>Save Configuration</Button>
            </CardFooter>
        </Card>
    );
};

export default RealtimeNotificationConfig;
