import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from 'lucide-react';

interface CustomAnomaly {
    id: string;
    name: string;
    enabled: boolean;
    threshold: number;
}

const TriggerDetectionConfig = () => {
    const [smokeThreshold, setSmokeThreshold] = useState(50);
    const [fireThreshold, setFireThreshold] = useState(50);
    const [motionThreshold, setMotionThreshold] = useState(50);
    const [isSmokeEnabled, setIsSmokeEnabled] = useState(true);
    const [isFireEnabled, setIsFireEnabled] = useState(true);
    const [isMotionEnabled, setIsMotionEnabled] = useState(true);
    const [customAnomalies, setCustomAnomalies] = useState<CustomAnomaly[]>([]);
    const [newAnomalyName, setNewAnomalyName] = useState("");

    const handleSave = () => {
        console.log("Saving configuration...");
    };

    const addCustomAnomaly = () => {
        if (newAnomalyName.trim() !== "") {
            setCustomAnomalies([
                ...customAnomalies,
                {
                    id: Date.now().toString(),
                    name: newAnomalyName.trim(),
                    enabled: true,
                    threshold: 50,
                },
            ]);
            setNewAnomalyName("");
        }
    };

    const removeCustomAnomaly = (id: string) => {
        setCustomAnomalies(customAnomalies.filter((anomaly) => anomaly.id !== id));
    };

    const updateCustomAnomaly = (id: string, updates: Partial<CustomAnomaly>) => {
        setCustomAnomalies(
            customAnomalies.map((anomaly) =>
                anomaly.id === id ? { ...anomaly, ...updates } : anomaly
            )
        );
    };

    return (
        <div className="container mx-auto">
            <Card className="w-full border border-default-200">
                <CardHeader>
                    <CardTitle>Anomaly Detection Configuration</CardTitle>
                    <CardDescription>Configure rules for detecting smoke, fire, and other anomalies</CardDescription>
                </CardHeader>
                <CardContent>
                    <Tabs defaultValue="smoke">
                        <TabsList className="grid w-full grid-cols-3">
                            <TabsTrigger value="smoke">Smoke Detection</TabsTrigger>
                            <TabsTrigger value="fire">Fire Detection</TabsTrigger>
                            <TabsTrigger value="motion">Motion Detection</TabsTrigger>
                        </TabsList>
                        <TabsContent value="smoke">
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <Label htmlFor="smoke-switch">Enable Smoke Detection</Label>
                                    <Switch
                                        id="smoke-switch"
                                        checked={isSmokeEnabled}
                                        onCheckedChange={setIsSmokeEnabled}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Smoke Detection Threshold</Label>
                                    <Slider
                                        value={[smokeThreshold]}
                                        onValueChange={(value) => setSmokeThreshold(value[0])}
                                        max={100}
                                        step={1}
                                    />
                                    <div className="text-sm text-gray-500">
                                        Current threshold: {smokeThreshold}%
                                    </div>
                                </div>
                            </div>
                        </TabsContent>
                        <TabsContent value="fire">
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <Label htmlFor="fire-switch">Enable Fire Detection</Label>
                                    <Switch
                                        id="fire-switch"
                                        checked={isFireEnabled}
                                        onCheckedChange={setIsFireEnabled}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Fire Detection Threshold</Label>
                                    <Slider
                                        value={[fireThreshold]}
                                        onValueChange={(value) => setFireThreshold(value[0])}
                                        max={100}
                                        step={1}
                                    />
                                    <div className="text-sm text-gray-500">
                                        Current threshold: {fireThreshold}%
                                    </div>
                                </div>
                            </div>
                        </TabsContent>
                        <TabsContent value="motion">
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <Label htmlFor="motion-switch">Enable Motion Detection</Label>
                                    <Switch
                                        id="motion-switch"
                                        checked={isMotionEnabled}
                                        onCheckedChange={setIsMotionEnabled}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Motion Detection Sensitivity</Label>
                                    <Slider
                                        value={[motionThreshold]}
                                        onValueChange={(value) => setMotionThreshold(value[0])}
                                        max={100}
                                        step={1}
                                    />
                                    <div className="text-sm text-gray-500">
                                        Current sensitivity: {motionThreshold}%
                                    </div>
                                </div>
                            </div>
                        </TabsContent>
                    </Tabs>
                    <div className="mt-6 space-y-4">
                        <Label>Custom Anomaly Detection</Label>
                        <div className="flex space-x-2">
                            <Input
                                placeholder="Enter custom anomaly type"
                                value={newAnomalyName}
                                onChange={(e) => setNewAnomalyName(e.target.value)}
                            />
                            <Button onClick={addCustomAnomaly} size="icon">
                                <Plus className="h-4 w-4" />
                            </Button>
                        </div>
                        {customAnomalies.map((anomaly) => (
                            <div key={anomaly.id} className="space-y-2 border p-4 rounded-md">
                                <div className="flex items-center justify-between">
                                    <Label>{anomaly.name}</Label>
                                    <div className="flex items-center space-x-2">
                                        <Switch
                                            checked={anomaly.enabled}
                                            onCheckedChange={(checked) =>
                                                updateCustomAnomaly(anomaly.id, { enabled: checked })
                                            }
                                        />
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => removeCustomAnomaly(anomaly.id)}
                                        >
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </div>
                                <Slider
                                    value={[anomaly.threshold]}
                                    onValueChange={(value) =>
                                        updateCustomAnomaly(anomaly.id, { threshold: value[0] })
                                    }
                                    max={100}
                                    step={1}
                                />
                                <div className="text-sm text-gray-500">
                                    Threshold: {anomaly.threshold}%
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={handleSave}>Save Configuration</Button>
                </CardFooter>
            </Card>
        </div>
    );
};

export default TriggerDetectionConfig;
