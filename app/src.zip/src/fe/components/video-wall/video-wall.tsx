import React, {useState} from "react";
import {Card, CardContent} from "@/components/ui/card";
import {DtoVideoWallDetail} from "@/lib/api/data-contracts";
import VideoWallLayoutSelector from "@/components/video-wall/video-wall-layout-selector";
import {LayoutType} from "@/components/video-wall/constants";

export interface VideoWallProps {
}

const VideoWall: React.FC<VideoWallProps> = (props) => {

    const [selectedLayout, setSelectedLayout] = useState<LayoutType>("1+3");
    const [selectedVideoWall, setSelectedVideoWall] = useState<DtoVideoWallDetail | null>(null);

    return (
        <div className="w-full">
            <Card className="border p-6">
                <CardContent className="p-0">
                    <VideoWallLayoutSelector
                        selectedLayout={selectedLayout}
                        onLayoutChange={setSelectedLayout}
                        selectedVideoWall={selectedVideoWall}
                        onVideoWallChange={setSelectedVideoWall}
                    />
                </CardContent>
            </Card>
        </div>
    );
};

export default VideoWall;
