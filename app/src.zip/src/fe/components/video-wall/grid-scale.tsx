import React from 'react';
import { Slider } from '@/components/ui/slider';
import { ZoomIn, ZoomOut, Monitor } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface GridScaleSliderProps {
    scale: number;
    onScaleChange: (scale: number) => void;
    disabled?: boolean;
}

export const GridScaleSlider: React.FC<GridScaleSliderProps> = ({
                                                                    scale,
                                                                    onScaleChange,
                                                                    disabled = false
                                                                }) => {
    const handleSliderChange = (values: number[]) => {
        onScaleChange(values[0]);
    };

    const handlePresetScale = (presetScale: number) => {
        onScaleChange(presetScale);
    };

    const getScaleLabel = () => {
        if (scale >= 90) return "Full Size";
        if (scale >= 70) return "Large";
        if (scale >= 50) return "Medium";
        if (scale >= 30) return "Small";
        return "Compact";
    };

    const getScaleColor = () => {
        if (scale >= 90) return "text-green-600";
        if (scale >= 70) return "text-blue-600";
        if (scale >= 50) return "text-yellow-600";
        return "text-orange-600";
    };

    return (
        <div className="bg-default border rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                    <Monitor className="h-4 w-4 text-default-600" />
                    <label className="text-sm font-medium text-default-700">
                        Adjust Grid Scale
                    </label>
                </div>
                <div className="flex items-center gap-2">
                    <span className={`text-sm font-medium ${getScaleColor()}`}>
                        {getScaleLabel()}
                    </span>
                    <span className="text-sm text-default-500 bg-default-100 px-2 py-1 rounded">
                        {Math.round(scale)}%
                    </span>
                </div>
            </div>

            <div className="flex items-center gap-3 mb-3">
                <ZoomOut className="h-4 w-4 text-default-400 flex-shrink-0" />

                <div className="flex-1">
                    <Slider
                        value={[scale]}
                        onValueChange={handleSliderChange}
                        min={25}
                        max={100}
                        step={5}
                        disabled={disabled}
                        className="w-full"
                    />
                </div>

                <ZoomIn className="h-4 w-4 text-gray-400 flex-shrink-0" />
            </div>

            {/* Quick preset buttons */}
            <div className="flex justify-between items-center">
                <div className="flex gap-1">
                    {[25, 50, 75, 100].map((preset) => (
                        <Button
                            key={preset}
                            variant={scale === preset ? undefined : "outline"}
                            size="sm"
                            onClick={() => handlePresetScale(preset)}
                            disabled={disabled}
                            className="h-6 text-xs px-2"
                        >
                            {preset}%
                        </Button>
                    ))}
                </div>

                <div className="text-xs text-gray-400">
                    Scale Grid
                </div>
            </div>
        </div>
    );
};
