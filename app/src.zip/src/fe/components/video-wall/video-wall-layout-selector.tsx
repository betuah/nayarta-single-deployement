import React, {useState, useEffect, useMemo} from 'react';
import {useVideoWallModuleStore} from '@/store/video-wall-module-store';
import {DtoVideoWallDetail, DtoUpdateVideoWallDTO, DtoCreateVideoWallDTO} from '@/lib/api/data-contracts';
import {CameraAssignmentDialog} from "@/components/video-wall/camera-dialog-assignment";
import {CreateVideoWallDialog} from "@/components/video-wall/create-video-wall-dialog";
import DeleteConfirmationDialog from "@/components/delete-confirmation-dialog";
import {getGridContainerClass, getGridItemClass, getLayoutGrids, LayoutType, VideoWallMode} from './constants';
import {GridItemData} from "@/components/video-wall/streaming-grid-cell";
import {ErrorDisplay} from "@/components/video-wall/error-display";
import {VideoWallSelectorControls} from "@/components/video-wall/video-wall-selector-controls";
import {ModeIndicatorAndActions} from "@/components/video-wall/mode-indicator-and-actions";
import {VideoWallLayoutPreview} from "@/components/video-wall/video-wall-layout-preview";
import {GlobalLoadingIndicator} from "@/components/video-wall/loading-indicator";
import {GridScaleSlider} from "@/components/video-wall/grid-scale";
import {Accordion, AccordionContent, AccordionItem, AccordionTrigger} from "@/components/ui/accordion";
import {VideoWallModeSelector} from "@/components/video-wall/video-wall-mode-selector";
import {MultiCameraPlaybackContainer} from "@/components/video-wall/playback/multi-camera-playback-container";

import {AspectRatioSelector} from "@/components/video-wall/aspect-ratio-selector";
import {AspectRatioType} from "@/components/video-wall/constants";

interface CCTVInfo {
    id: string;
    name: string;
    status?: string;
    last_checked?: string;
    check_interval?: number;
    recording_status?: number;
    snapshot_image?: string;
}

interface VideoWallLayoutSelectorProps {
    selectedLayout: LayoutType;
    onLayoutChange: (layout: LayoutType) => void;
    selectedVideoWall?: DtoVideoWallDetail | null;
    onVideoWallChange?: (videoWall: DtoVideoWallDetail | null) => void;
}

const VideoWallLayoutSelector: React.FC<VideoWallLayoutSelectorProps> = ({
                                                                             selectedLayout,
                                                                             onLayoutChange,
                                                                             selectedVideoWall,
                                                                             onVideoWallChange,
                                                                         }) => {
    const {
        videoWalls,
        currentVideoWall,
        isLoading,
        isLoadingDetail,
        isUpdating,
        isCreating,
        isDeleting,
        error,
        detailError,
        updateError,
        createError,
        deleteError,
        fetchVideoWalls,
        fetchVideoWallDetail,
        updateVideoWall,
        createVideoWall,
        deleteVideoWall,
        clearErrors,
        videoWallMode,
        setVideoWallMode,
        playbackDate,
        setPlaybackDate,
        currentPlaybackData,
        isLoadingPlaybackData,
        playbackError,
        loadPlaybackData,
        clearPlaybackData
    } = useVideoWallModuleStore();

    const [mode, setMode] = useState<'view' | 'create' | 'edit'>('view');
    const [selectedVideoWallId, setSelectedVideoWallId] = useState<string>('');
    const [isProcessingSelection, setIsProcessingSelection] = useState(false);
    const [isInitialLoad, setIsInitialLoad] = useState(true);

    const [isAssignmentDialogOpen, setIsAssignmentDialogOpen] = useState(false);
    const [selectedPosition, setSelectedPosition] = useState<number | null>(null);
    const [localCCTVAssignments, setLocalCCTVAssignments] = useState<{ [position: number]: CCTVInfo }>({});
    const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

    const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

    const [gridScale, setGridScale] = useState<number>(100);

    const [globalAspectRatio, setGlobalAspectRatio] = useState<AspectRatioType>("1:1");


    useEffect(() => {
        const initializeComponent = async () => {
            clearErrors();
            await fetchVideoWalls();
            setIsInitialLoad(false);
        };
        initializeComponent().then();
    }, [fetchVideoWalls, clearErrors]);

    useEffect(() => {
        if (!isInitialLoad && !isLoading && videoWalls?.video_walls) {
            if (videoWalls.video_walls.length > 0) {
                const firstVideoWall = videoWalls.video_walls[0];
                if (firstVideoWall.id) {
                    setSelectedVideoWallId(firstVideoWall.id);
                    handleVideoWallSelect(firstVideoWall.id, 'view').then();
                }
            } else {
                setMode('create');
                setSelectedVideoWallId('new');
                onVideoWallChange?.(null);
                setLocalCCTVAssignments({});
                setHasUnsavedChanges(false);
            }
        }
    }, [isInitialLoad, isLoading, videoWalls, onVideoWallChange]);

    useEffect(() => {
        if (videoWallMode === 'playback' && currentVideoWall?.id && playbackDate) {
            const startTime = new Date(playbackDate);
            startTime.setHours(0, 0, 0, 0);

            const endTime = new Date(playbackDate);
            endTime.setHours(23, 59, 59, 999);

            loadPlaybackData(currentVideoWall.id, startTime.toISOString(), endTime.toISOString()).then();
        } else if (videoWallMode === 'live') {
            clearPlaybackData();
        }
    }, [videoWallMode, currentVideoWall?.id, playbackDate, loadPlaybackData, clearPlaybackData]);

    useEffect(() => {
        if (currentVideoWall && (mode === 'edit' || mode === 'view')) {
            onVideoWallChange?.(currentVideoWall);
            if (currentVideoWall.layout && currentVideoWall.layout !== selectedLayout) {
                onLayoutChange(currentVideoWall.layout as LayoutType);
            }

            const assignments: { [position: number]: CCTVInfo } = {};
            if (currentVideoWall.cctv_list) {
                currentVideoWall.cctv_list.forEach((cctv, index) => {
                    if (cctv.id) {
                        assignments[index] = {
                            id: cctv.id,
                            name: cctv.name || `Camera ${cctv.id}`,
                            status: cctv.status,
                            last_checked: cctv.last_checked,
                            check_interval: cctv.check_interval,
                            recording_status: cctv.recording_status,
                            snapshot_image: cctv.snapshot_image
                        };
                    }
                });
            }
            setLocalCCTVAssignments(assignments);
            setHasUnsavedChanges(false);
            setIsProcessingSelection(false);
        }
    }, [currentVideoWall, mode, onVideoWallChange, onLayoutChange, selectedLayout]);

    const handleVideoWallSelect = async (videoWallId: string, targetMode?: 'view' | 'edit' | 'create') => {
        setSelectedVideoWallId(videoWallId);

        if (videoWallId === 'new') {
            setMode('create');
            setIsProcessingSelection(false);
            onVideoWallChange?.(null);
            setLocalCCTVAssignments({});
            setHasUnsavedChanges(false);
            return;
        }

        const newMode = targetMode || 'view';
        setMode(newMode);
        setIsProcessingSelection(true);
        clearErrors();

        try {
            await fetchVideoWallDetail(videoWallId);
        } catch (fetchError) {
            console.error('Error fetching video wall detail:', fetchError);
            setIsProcessingSelection(false);
            if (mode === 'create') {
                setMode('create');
                setSelectedVideoWallId('new');
                onVideoWallChange?.(null);
                setLocalCCTVAssignments({});
            }
        }
    };

    const handleLayoutSelectorChange = (layout: LayoutType) => {
        setMode('create');
        setSelectedVideoWallId('new');
        onLayoutChange(layout);
        onVideoWallChange?.(null);
        setLocalCCTVAssignments({});
        setHasUnsavedChanges(false);
        setGridScale(100);
        setGlobalAspectRatio("1:1");
        clearErrors();
    };

    const handleModeSwitch = (newMode: 'view' | 'create' | 'edit') => {
        if (newMode === 'create') {
            setMode('create');
            setSelectedVideoWallId('new');
            setVideoWallMode('live')
            onVideoWallChange?.(null);
            setLocalCCTVAssignments({});
            setHasUnsavedChanges(false);
            setGridScale(100);
            setGlobalAspectRatio("1:1");
            clearErrors();
        } else if (newMode === 'edit' && currentVideoWall) {
            setMode('edit');
            setVideoWallMode('live')
        } else if (newMode === 'view') {
            setMode('view');
            setHasUnsavedChanges(false);

            if (mode === 'create' && videoWalls?.video_walls && videoWalls.video_walls.length > 0) {
                const firstVideoWall = videoWalls.video_walls[0];
                if (firstVideoWall.id) {
                    setSelectedVideoWallId(firstVideoWall.id);
                    handleVideoWallSelect(firstVideoWall.id, 'view').then();
                    return;
                }
            }

            if (currentVideoWall?.id) {
                fetchVideoWallDetail(currentVideoWall.id).then();
            }
        }
    };

    const handleVideoWallModeChange = (newMode: VideoWallMode) => {
        setVideoWallMode(newMode);
        if (newMode === 'playback' && !playbackDate) {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            setPlaybackDate(yesterday);
        }
    };

    const handlePlaybackDateChange = (date: Date) => {
        setPlaybackDate(date);
    };

    const getCCTVAtPosition = (position: number): CCTVInfo | null => {
        return localCCTVAssignments[position] || null;
    };

    const handleAddCamera = (position: number) => {
        if (mode === 'view') return;
        setSelectedPosition(position);
        setIsAssignmentDialogOpen(true);
    };

    const handleCameraAssign = (filter: {
        locationId?: string;
        locationName?: string;
        floorPlanId?: string;
        floorPlanName?: string;
        cameraId?: string;
        cameraName?: string
    }) => {
        if (selectedPosition !== null && filter.cameraId && filter.cameraName) {
            const cctvInfo: CCTVInfo = {
                id: filter.cameraId,
                name: filter.cameraName
            };

            setLocalCCTVAssignments(prev => ({
                ...prev,
                [selectedPosition]: cctvInfo
            }));
            setHasUnsavedChanges(true);
            setIsAssignmentDialogOpen(false);
            setSelectedPosition(null);
        }
    };

    const handleRemoveCamera = (position: number) => {
        if (mode === 'view') return;

        setLocalCCTVAssignments(prev => {
            const newAssignments = {...prev};
            delete newAssignments[position];
            return newAssignments;
        });
        setHasUnsavedChanges(true);
    };

    const handleSaveChanges = async () => {
        if (mode === 'edit') {
            const wallToUpdate = currentVideoWall || selectedVideoWall;
            if (!wallToUpdate?.id || !hasUnsavedChanges) return;
            const cctvList = Object.entries(localCCTVAssignments)
                .sort(([a], [b]) => parseInt(a) - parseInt(b))
                .map(([, cctvInfo]) => cctvInfo.id);

            const updateData: DtoUpdateVideoWallDTO = {
                cctv_list: cctvList,
                layout: selectedLayout,
                name: wallToUpdate.name
            };

            try {
                await updateVideoWall(wallToUpdate.id, updateData);
                await fetchVideoWallDetail(wallToUpdate.id);
                setHasUnsavedChanges(false);
                setMode('view');
            } catch (error) {
                console.error('Failed to save changes:', error);
            }
        } else if (mode === 'create') {
            setIsCreateDialogOpen(true);
        }
    };

    const handleCreateVideoWall = async (name: string) => {
        const cctvList = Object.entries(localCCTVAssignments)
            .sort(([a], [b]) => parseInt(a) - parseInt(b))
            .map(([, cctvInfo]) => cctvInfo.id);

        const createData: DtoCreateVideoWallDTO = {
            name,
            layout: selectedLayout,
            cctv_list: cctvList,
            group_id: ''
        };

        try {
            await createVideoWall(createData);
            setIsCreateDialogOpen(false);
            setLocalCCTVAssignments({});
            setHasUnsavedChanges(false);
            await fetchVideoWalls();
            if (videoWalls?.video_walls && videoWalls.video_walls.length > 0) {
                const firstVideoWall = videoWalls.video_walls[0];
                if (firstVideoWall.id) {
                    setSelectedVideoWallId(firstVideoWall.id);
                    await handleVideoWallSelect(firstVideoWall.id, 'view');
                }
            }
        } catch (error) {
            console.error('Failed to create video wall:', error);
        }
    };

    const handleDeleteVideoWall = async () => {
        const wallToDelete = currentVideoWall || selectedVideoWall;
        if (!wallToDelete?.id) return;

        try {
            await deleteVideoWall(wallToDelete.id);
            await fetchVideoWalls();
            if (videoWalls?.video_walls && videoWalls.video_walls.length > 0) {
                const firstVideoWall = videoWalls.video_walls[0];
                if (firstVideoWall.id) {
                    setSelectedVideoWallId(firstVideoWall.id);
                    await handleVideoWallSelect(firstVideoWall.id, 'view');
                }
            } else {
                setMode('create');
                setSelectedVideoWallId('new');
                onVideoWallChange?.(null);
                setLocalCCTVAssignments({});
                setHasUnsavedChanges(false);
            }
        } catch (error) {
            console.error('Failed to delete video wall:', error);
        }
    };

    const handleScaleChange = (scale: number) => {
        setGridScale(scale);
    };

    const handleAspectRatioChange = (aspectRatio: AspectRatioType) => {
        setGlobalAspectRatio(aspectRatio);
    };

    const computedGrids = useMemo(() => getLayoutGrids(selectedLayout), [selectedLayout]);
    const computedGridContainerClass = getGridContainerClass(selectedLayout);
    const getGridItemComputedClass = (grid: GridItemData) => getGridItemClass(grid, selectedLayout, globalAspectRatio);
    const isLoaderActiveForControls = isLoading || isLoadingDetail || isProcessingSelection;
    const displayVideoWall = (mode === 'edit' || mode === 'view') ? (currentVideoWall || selectedVideoWall) : null;
    const hasCreateModeChanges = mode === 'create' && Object.keys(localCCTVAssignments).length > 0;
    const showSaveButton = (mode === 'edit' && hasUnsavedChanges) || hasCreateModeChanges;

    if (isInitialLoad && isLoading) {
        return (
            <div className="space-y-6">
                <GlobalLoadingIndicator
                    isLoading={true}
                    message="Initializing video wall..."
                />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <ErrorDisplay
                error={error}
                detailError={detailError}
                updateError={updateError}
                createError={createError}
                deleteError={deleteError}
            />
            <VideoWallModeSelector
                mode={videoWallMode}
                onModeChange={handleVideoWallModeChange}
                playbackDate={playbackDate}
                onPlaybackDateChange={handlePlaybackDateChange}
                disabled={isLoaderActiveForControls}
                hasVideoWall={!!displayVideoWall}
            />
            <div className="grid grid-cols-1 lg:grid-cols-1 gap-4">
                <div className="lg:col-span-2">
                    <VideoWallSelectorControls
                        videoWalls={videoWalls?.video_walls}
                        selectedVideoWallId={selectedVideoWallId}
                        onVideoWallSelect={(id) => handleVideoWallSelect(id)}
                        selectedLayout={selectedLayout}
                        onLayoutSelectChange={handleLayoutSelectorChange}
                        isLoaderActive={isLoaderActiveForControls}
                        isLoadingVideoWalls={isLoading}
                        mode={mode}
                        onModeSwitch={handleModeSwitch}
                        hasUnsavedChanges={hasUnsavedChanges}
                    />
                </div>
            </div>

            <Accordion type="single" collapsible>
                <AccordionItem className="border shadow-none bg-card" value="item-1">
                    <AccordionTrigger>Advanced</AccordionTrigger>
                    <AccordionContent>
                        <div className="flex flex-col gap-y-6">
                            <div className="lg:col-span-1">
                                <GridScaleSlider
                                    scale={gridScale}
                                    onScaleChange={handleScaleChange}
                                    disabled={isLoaderActiveForControls}
                                />
                            </div>
                            <div className="lg:col-span-1">
                                <AspectRatioSelector
                                    aspectRatio={globalAspectRatio}
                                    onAspectRatioChange={handleAspectRatioChange}
                                    disabled={isLoaderActiveForControls}
                                />
                            </div>
                            <ModeIndicatorAndActions
                                mode={mode}
                                selectedVideoWall={displayVideoWall}
                                isProcessingSelection={isProcessingSelection && (mode === 'edit' || mode === 'view')}
                                hasUnsavedChanges={showSaveButton}
                                onSaveChanges={handleSaveChanges}
                                onDeleteVideoWall={() => setIsDeleteDialogOpen(true)}
                                isUpdating={isUpdating || isCreating}
                                isDeleting={isDeleting}
                                onModeSwitch={handleModeSwitch}
                            />
                        </div>
                    </AccordionContent>
                </AccordionItem>
            </Accordion>
            {videoWallMode === 'live' ? (
                <VideoWallLayoutPreview
                    videoWallName={displayVideoWall?.name}
                    selectedLayout={selectedLayout}
                    isProcessingSelection={isProcessingSelection && (mode === 'edit' || mode === 'view')}
                    gridContainerClass={computedGridContainerClass}
                    grids={computedGrids}
                    getGridItemComputedClass={getGridItemComputedClass}
                    mode={mode}
                    getCCTVAtPosition={getCCTVAtPosition}
                    onAddCamera={handleAddCamera}
                    onRemoveCamera={handleRemoveCamera}
                    isUpdating={isUpdating || isCreating}
                    gridScale={gridScale}
                    currentVideoWall={currentVideoWall || undefined}
                    globalAspectRatio={globalAspectRatio}
                />
            ) : (
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold text-default-800">
                            {displayVideoWall?.name ? `${displayVideoWall.name} - Playback` : 'Playback Mode'}
                        </h3>
                        {playbackDate && (
                            <div className="text-sm text-default-600">
                                {playbackDate.toLocaleDateString()}
                            </div>
                        )}
                    </div>

                    {isLoadingPlaybackData ? (
                        <GlobalLoadingIndicator
                            isLoading={true}
                            message="Loading playback data..."
                        />
                    ) : playbackError ? (
                        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                            <p className="text-red-700">{playbackError}</p>
                        </div>
                    ) : currentPlaybackData && displayVideoWall ? (
                        <MultiCameraPlaybackContainer
                            playbackData={currentPlaybackData}
                            grids={computedGrids}
                            cctvAssignments={localCCTVAssignments}
                            gridContainerClass={computedGridContainerClass}
                            getGridItemComputedClass={getGridItemComputedClass}
                            gridScale={gridScale}
                            globalAspectRatio={globalAspectRatio}
                            className="w-full"
                        />
                    ) : (
                        <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 text-center">
                            <p className="text-gray-600">
                                {!displayVideoWall
                                    ? "Please select a video wall to view playback"
                                    : !playbackDate
                                        ? "Please select a date for playback"
                                        : "No playback data available for the selected date"
                                }
                            </p>
                        </div>
                    )}
                </div>
            )}
            <GlobalLoadingIndicator
                isLoading={isLoading && !videoWalls?.video_walls?.length && !isInitialLoad}
                message="Loading video walls..."
            />
            {mode !== 'view' && (
                <CameraAssignmentDialog
                    isOpen={isAssignmentDialogOpen}
                    onClose={() => {
                        setIsAssignmentDialogOpen(false);
                        setSelectedPosition(null);
                    }}
                    onAssign={handleCameraAssign}
                    position={selectedPosition || 0}
                    isLoading={isUpdating || isCreating}
                />
            )}
            <CreateVideoWallDialog
                isOpen={isCreateDialogOpen}
                onClose={() => setIsCreateDialogOpen(false)}
                onSave={handleCreateVideoWall}
                isLoading={isCreating}
            />
            <DeleteConfirmationDialog
                open={isDeleteDialogOpen}
                onClose={() => setIsDeleteDialogOpen(false)}
                onConfirm={handleDeleteVideoWall}
                message={`This action cannot be undone. This will permanently delete the video wall "${displayVideoWall?.name}" and remove all its camera assignments.`}
                toastMessage="Video wall deleted successfully"
            />
        </div>
    );
};

export default VideoWallLayoutSelector;
