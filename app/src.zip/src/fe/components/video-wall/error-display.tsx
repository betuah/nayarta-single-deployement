import React from 'react';
import { AlertCircle } from 'lucide-react';

interface ErrorDisplayProps {
    error?: string | null;
    detailError?: string | null;
    updateError?: string | null;
    createError?: string | null;
    deleteError?: string | null;
}

export const ErrorDisplay: React.FC<ErrorDisplayProps> = ({
                                                              error,
                                                              detailError,
                                                              updateError,
                                                              createError,
                                                              deleteError
                                                          }) => {
    const errorMessage = error || detailError || updateError || createError || deleteError;

    if (!errorMessage) {
        return null;
    }

    return (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0" />
            <div className="text-sm text-red-700">
                {errorMessage}
            </div>
        </div>
    );
};
