import React from 'react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { VideoIcon, Calendar as CalendarIcon, Play } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { VideoWallMode } from './constants';

interface VideoWallModeSelectorProps {
    mode: VideoWallMode;
    onModeChange: (mode: VideoWallMode) => void;
    playbackDate: Date | null;
    onPlaybackDateChange: (date: Date) => void;
    disabled?: boolean;
    hasVideoWall?: boolean;
}

export const VideoWallModeSelector: React.FC<VideoWallModeSelectorProps> = ({
                                                                                mode,
                                                                                onModeChange,
                                                                                playbackDate,
                                                                                onPlaybackDateChange,
                                                                                disabled = false,
                                                                                hasVideoWall = false
                                                                            }) => {
    const [isCalendarOpen, setIsCalendarOpen] = React.useState(false);

    const handleModeToggle = (newMode: VideoWallMode) => {
        if (newMode === mode || disabled) return;
        if (newMode === 'playback' && !hasVideoWall) {
            return;
        }

        onModeChange(newMode);
    };

    const handleDateSelect = (date: Date | undefined) => {
        if (date) {
            onPlaybackDateChange(date);
            setIsCalendarOpen(false);
        }
    };

    return (
        <div className="md:flex md:flex-row md:justify-center items-center gap-4 grid grid-cols-1">
            <div className="flex items-center gap-2">
                <Button
                    variant={mode === 'live' ? undefined : 'outline'}
                    size="sm"
                    onClick={() => handleModeToggle('live')}
                    disabled={disabled}
                    className="flex items-center gap-2"
                >
                    <VideoIcon className="h-4 w-4" />
                    Live Stream
                </Button>

                <Button
                    variant={mode === 'playback' ? undefined : 'outline'}
                    size="sm"
                    onClick={() => handleModeToggle('playback')}
                    disabled={disabled || !hasVideoWall}
                    className="flex items-center gap-2"
                    title={!hasVideoWall ? "Select a video wall to enable playback mode" : "Switch to playback mode"}
                >
                    <Play className="h-4 w-4" />
                    Playback
                </Button>
            </div>
            {mode === 'playback' && (
                <div className="flex items-center gap-2">
                    <span className="text-sm text-default-600">Date:</span>
                    <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                        <PopoverTrigger asChild>
                            <Button
                                variant="outline"
                                className={cn(
                                    "w-[200px] justify-start text-left font-normal",
                                    !playbackDate && "text-muted-foreground"
                                )}
                                disabled={disabled}
                            >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {playbackDate ? format(playbackDate, 'PPP') : <span>Pick a date</span>}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                            <Calendar
                                mode="single"
                                selected={playbackDate || undefined}
                                onSelect={handleDateSelect}
                                initialFocus
                                disabled={(date) => {
                                    // Disable future dates
                                    return date > new Date();
                                }}
                            />
                        </PopoverContent>
                    </Popover>
                </div>
            )}
            <div className="flex items-center gap-2">
                <div className={cn(
                    "w-2 h-2 rounded-full",
                    mode === 'live' ? "bg-red-500 animate-pulse" : "bg-blue-500"
                )} />
                <span className="text-xs text-default-500">
                    {mode === 'live' ? 'Live' : 'Playback'}
                    {mode === 'playback' && playbackDate && (
                        <span className="ml-1">
                            ({format(playbackDate, 'dd/MM/yyyy')})
                        </span>
                    )}
                </span>
            </div>
        </div>
    );
};
