import {GridItemData} from "@/components/video-wall/streaming-grid-cell";

export type LayoutType = "1+3" | "1+5" | "1+8" | "1+12" | "2x2" | "3x3" | "4x4" | "5x5";

export type VideoWallMode = 'live' | 'playback';

export type AspectRatioType = "1:1" | "16:9" | "4:3" | "3:2" | "21:9";

export const layoutOptions = [
    {value: "1+3", label: "1+3 Layout"},
    {value: "1+5", label: "1+5 Layout"},
    {value: "1+8", label: "1+8 Layout"},
    {value: "1+12", label: "1+12 Layout"},
    {value: "2x2", label: "2x2 Grid"},
    {value: "3x3", label: "3x3 Grid"},
    {value: "4x4", label: "4x4 Grid"},
    {value: "5x5", label: "5x5 Grid"},
] as const;


export const aspectRatioOptions = [
    {value: "1:1", label: "1:1 (Square)", ratio: 1},
    {value: "16:9", label: "16:9 (Widescreen)", ratio: 16/9},
    {value: "4:3", label: "4:3 (Standard)", ratio: 4/3},
    {value: "3:2", label: "3:2 (Photo)", ratio: 3/2},
    {value: "21:9", label: "21:9 (Ultra-wide)", ratio: 21/9},
] as const;

export const getLayoutGrids = (layout: LayoutType): GridItemData[] => {
    const grids: GridItemData[] = [];
    switch (layout) {
        case "1+3":
            grids.push({id: 0, type: 'large', className: 'lg:col-span-2 lg:row-span-2'});
            for (let i = 1; i <= 3; i++) {
                grids.push({id: i, type: 'small', className: 'lg:col-span-1 lg:row-span-1'});
            }
            break;
        case "1+5":
            grids.push({id: 0, type: 'large', className: 'lg:col-span-2 lg:row-span-2'});
            for (let i = 1; i <= 5; i++) {
                grids.push({id: i, type: 'small', className: 'lg:col-span-1 lg:row-span-1'});
            }
            break;
        case "1+8":
            grids.push({id: 0, type: 'large', className: 'lg:col-span-2 lg:row-span-2'});
            for (let i = 1; i <= 8; i++) {
                grids.push({id: i, type: 'small', className: 'lg:col-span-1 lg:row-span-1'});
            }
            break;
        case "1+12":
            grids.push({id: 0, type: 'large', className: 'lg:col-span-2 lg:row-span-2'});
            for (let i = 1; i <= 12; i++) {
                grids.push({id: i, type: 'small', className: 'lg:col-span-1 lg:row-span-1'});
            }
            break;
        case "2x2":
            for (let i = 0; i < 4; i++) {
                grids.push({id: i, type: 'equal', className: 'lg:col-span-2 lg:row-span-2'});
            }
            break;
        case "3x3":
            for (let i = 0; i < 9; i++) {
                grids.push({id: i, type: 'equal', className: 'lg:col-span-1 lg:row-span-1'});
            }
            break;
        case "4x4":
            for (let i = 0; i < 16; i++) {
                grids.push({id: i, type: 'equal', className: 'lg:col-span-1 lg:row-span-1'});
            }
            break;
        case "5x5":
            for (let i = 0; i < 25; i++) {
                grids.push({id: i, type: 'equal', className: 'lg:col-span-1 lg:row-span-1'});
            }
            break;
        default:
            break;
    }
    return grids;
};

export const getGridContainerClass = (layout: LayoutType): string => {
    const baseClass = "grid gap-2 w-full";
    switch (layout) {
        case "1+3": case "1+5": case "1+8": case "1+12":
            return `${baseClass} grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 lg:grid-rows-4`;
        case "2x2": return `${baseClass} grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 lg:grid-rows-4`;
        case "3x3": return `${baseClass} grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 lg:grid-rows-3`;
        case "4x4": return `${baseClass} grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 lg:grid-rows-4`;
        case "5x5": return `${baseClass} grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 lg:grid-rows-5`;
        default: return baseClass;
    }
};

export const getGridItemClass = (grid: GridItemData, layout: LayoutType, aspectRatio: AspectRatioType = "1:1"): string => {
    const baseClass = "border-2 border-gray-300 rounded-lg flex items-center justify-center";
    const responsiveClass = "col-span-1 row-span-1";

    return `${baseClass} ${responsiveClass} ${grid.className}`;
};

export const getAspectRatioValue = (aspectRatio: AspectRatioType): number => {
    const ratioOption = aspectRatioOptions.find(option => option.value === aspectRatio);
    return ratioOption ? ratioOption.ratio : 1;
};


export const getAspectRatioStyle = (aspectRatio: AspectRatioType): React.CSSProperties => {
    const ratioOption = aspectRatioOptions.find(option => option.value === aspectRatio);
    const ratioValue = ratioOption ? ratioOption.ratio : 1;

    return {
        aspectRatio: ratioValue.toString()
    };
};
