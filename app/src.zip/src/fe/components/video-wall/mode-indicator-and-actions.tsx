import React from 'react';
import { Button } from '@/components/ui/button';
import { Loader2, Save, Plus, Trash2, Edit, Eye } from 'lucide-react';
import { DtoVideoWallDetail } from '@/lib/api/data-contracts';

interface ModeIndicatorAndActionsProps {
    mode: 'view' | 'create' | 'edit';
    selectedVideoWall?: DtoVideoWallDetail | null;
    isProcessingSelection: boolean;
    hasUnsavedChanges: boolean;
    onSaveChanges: () => void;
    onDeleteVideoWall?: () => void;
    isUpdating: boolean;
    isDeleting?: boolean;
    onModeSwitch?: (mode: 'view' | 'create' | 'edit') => void;
}

export const ModeIndicatorAndActions: React.FC<ModeIndicatorAndActionsProps> = ({
                                                                                    mode,
                                                                                    selectedVideoWall,
                                                                                    isProcessingSelection,
                                                                                    hasUnsavedChanges,
                                                                                    onSaveChanges,
                                                                                    onDeleteVideoWall,
                                                                                    isUpdating,
                                                                                    isDeleting = false,
                                                                                    onModeSwitch,
                                                                                }) => {
    const getMainButtonContent = () => {
        if (mode === 'create') {
            return isUpdating ? (
                <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Creating...
                </>
            ) : (
                <>
                    <Plus className="h-4 w-4" />
                    Create Video Wall
                </>
            );
        } else if (mode === 'edit') {
            return isUpdating ? (
                <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Saving...
                </>
            ) : (
                <>
                    <Save className="h-4 w-4" />
                    Save Changes
                </>
            );
        }
        return null;
    };

    const getModeIndicator = () => {
        const baseClass = "px-3 py-1 rounded text-xs font-medium";

        switch (mode) {
            case 'view':
                return (
                    <div className={`${baseClass} bg-primary text-default-50`}>
                        <div className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            View Mode
                        </div>
                    </div>
                );
            case 'create':
                return (
                    <div className={`${baseClass} bg-green-600 text-default-50`}>
                        <div className="flex items-center gap-1">
                            <Plus className="h-3 w-3" />
                            Create Mode
                        </div>
                    </div>
                );
            case 'edit':
                return (
                    <div className={`${baseClass} bg-orange-600 text-default-50`}>
                        <div className="flex items-center gap-1">
                            <Edit className="h-3 w-3" />
                            Edit Mode
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
                {getModeIndicator()}
                {isProcessingSelection && (
                    <div className="flex items-center gap-2 text-sm text-blue-600">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Loading video wall...
                    </div>
                )}
            </div>

            <div className="flex items-center gap-2">
                {/* Quick mode switch buttons */}
                {mode === 'view' && selectedVideoWall && onModeSwitch && (
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onModeSwitch('edit')}
                        disabled={isUpdating || isDeleting}
                        className="flex items-center gap-2"
                    >
                        <Edit className="h-4 w-4" />
                        Edit
                    </Button>
                )}

                {mode === 'edit' && onModeSwitch && (
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onModeSwitch('view')}
                        disabled={isUpdating || isDeleting}
                        className="flex items-center gap-2"
                    >
                        <Eye className="h-4 w-4" />
                        View
                    </Button>
                )}

                {(mode === 'edit' || mode === 'view') && selectedVideoWall && onDeleteVideoWall && (
                    <Button
                        color="destructive"
                        size="sm"
                        onClick={onDeleteVideoWall}
                        disabled={isUpdating || isDeleting}
                        className="flex items-center gap-2"
                    >
                        {isDeleting ? (
                            <>
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Deleting...
                            </>
                        ) : (
                            <>
                                <Trash2 className="h-4 w-4" />
                                Delete
                            </>
                        )}
                    </Button>
                )}

                {hasUnsavedChanges && (
                    <Button
                        onClick={onSaveChanges}
                        disabled={isUpdating || isDeleting}
                        className="flex items-center gap-2"
                    >
                        {getMainButtonContent()}
                    </Button>
                )}
            </div>
        </div>
    );
};
