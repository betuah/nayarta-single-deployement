import React from 'react';
import {Button} from '@/components/ui/button';
import {Play, Pause, RotateCcw, Volume2, VolumeX, Eye, EyeOff} from 'lucide-react';

interface VideoWallGlobalControlsProps {
    onPlayAll: () => void;
    onPauseAll: () => void;
    onSeekToLatestAll: () => void;
    onMuteAll: () => void;
    onUnmuteAll: () => void;
    onToggleControlsVisibility: () => void;
    totalStreams: number;
    playingStreams: number;
    isViewMode: boolean;
    disabled?: boolean;
    areControlsVisible: boolean;
    mutedStreams: number;
}

export const VideoWallGlobalControls: React.FC<VideoWallGlobalControlsProps> = ({
                                                                                    onPlayAll,
                                                                                    onPauseAll,
                                                                                    onSeekToLatestAll,
                                                                                    onMuteAll,
                                                                                    onUnmuteAll,
                                                                                    onToggleControlsVisibility,
                                                                                    totalStreams,
                                                                                    playingStreams,
                                                                                    isViewMode,
                                                                                    disabled = false,
                                                                                    areControlsVisible,
                                                                                    mutedStreams
                                                                                }) => {
    if (!isViewMode || totalStreams === 0) {
        return null;
    }

    const hasStreams = totalStreams > 0;
    const allPlaying = playingStreams === totalStreams;
    const nonePlaying = playingStreams === 0;
    const allMuted = mutedStreams === totalStreams;

    return (
        <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                    <h4 className="text-default font-medium text-sm">Stream Controls</h4>
                    <div className="bg-primary-600 text-default-50 text-xs px-2 py-1 rounded-full">
                        {playingStreams}/{totalStreams} Playing
                    </div>
                </div>

                <div className="text-xs text-gray-400">
                    {totalStreams} camera{totalStreams !== 1 ? 's' : ''} assigned
                </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={onPlayAll}
                        disabled={disabled || !hasStreams || allPlaying}
                        color="success"
                    >
                        <Play className="h-4 w-4 mr-2"/>
                        {allPlaying ? 'All Playing' : nonePlaying ? 'Play All' : `Play Remaining (${totalStreams - playingStreams})`}
                    </Button>

                    <Button
                        variant="outline"
                        size="sm"
                        onClick={onPauseAll}
                        disabled={disabled || !hasStreams || nonePlaying}
                        color="destructive"
                    >
                        <Pause className="h-4 w-4 mr-2"/>
                        {nonePlaying ? 'All Stopped' : allPlaying ? 'Pause All' : `Pause Playing (${playingStreams})`}
                    </Button>

                    <Button
                        variant="outline"
                        size="sm"
                        onClick={onSeekToLatestAll}
                        disabled={disabled || !hasStreams || nonePlaying}
                    >
                        <RotateCcw className="h-4 w-4 mr-2"/>
                        Go to Live
                    </Button>
                </div>

                <div className="w-px h-6 bg-gray-300 mx-1"/>

                <div className="flex items-center gap-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={allMuted ? onUnmuteAll : onMuteAll}
                        disabled={disabled || !hasStreams}
                    >
                        {allMuted ? (
                            <>
                                <Volume2 className="h-4 w-4 mr-2"/>
                                Unmute All
                            </>
                        ) : (
                            <>
                                <VolumeX className="h-4 w-4 mr-2"/>
                                {mutedStreams === 0 ? 'Mute All' : `Mute Remaining (${totalStreams - mutedStreams})`}
                            </>
                        )}
                    </Button>

                    <Button
                        variant="outline"
                        size="sm"
                        onClick={onToggleControlsVisibility}
                        disabled={disabled || !hasStreams}
                    >
                        {areControlsVisible ? (
                            <>
                                <EyeOff className="h-4 w-4 mr-2"/>
                                Hide Controls
                            </>
                        ) : (
                            <>
                                <Eye className="h-4 w-4 mr-2"/>
                                Show Controls
                            </>
                        )}
                    </Button>
                </div>
            </div>

            <div className="mt-3 flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-default-600">Playing: {playingStreams}</span>
                </div>
                <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
                    <span className="text-default-600">Stopped: {totalStreams - playingStreams}</span>
                </div>
                <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span className="text-default-600">Muted: {mutedStreams}</span>
                </div>
                <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-default-600">Controls: {areControlsVisible ? 'Visible' : 'Hidden'}</span>
                </div>
            </div>
        </div>
    );
};
