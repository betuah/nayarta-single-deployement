import React, { useEffect, useRef, useState, useCallback, forwardRef, useImperativeHandle } from 'react';
import { useStreamAuthModuleStore } from '@/store/stream-auth-module-store';
import { constructRTSPUrl } from "@/lib/utils/stream-utils";
import { HlsPlayer, HlsPlayerRef } from "@/components/hsl-player";
import { Play, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUserStore } from '@/store/user-store';
import {getCctvConnection} from "@/actions/cctv-actions";

interface VideoWallStreamPlayerProps {
    cctvId: string;
    aspectFitMode: 'contain' | 'cover' | 'fill';
    onStreamPlayingChange?: (isPlaying: boolean) => void;
    className?: string;
    snapshotImage?: string;
    showControls?: boolean;
    isMuted?: boolean;
}

export interface VideoWallStreamPlayerRef {
    seekToLatest: () => void;
    playStream: () => void;
    pauseStream: () => void;
    isPlaying: () => boolean;
    muteStream: () => void;
    unmuteStream: () => void;
    isMuted: () => boolean;
}

export const VideoWallStreamPlayer = forwardRef<VideoWallStreamPlayerRef, VideoWallStreamPlayerProps>(({
                                                                                                           cctvId,
                                                                                                           aspectFitMode,
                                                                                                           onStreamPlayingChange,
                                                                                                           className = "",
                                                                                                           snapshotImage,
                                                                                                           showControls = false,
                                                                                                           isMuted = false
                                                                                                       }, ref) => {
    const { selectedGroupMember } = useUserStore();
    const { generateToken } = useStreamAuthModuleStore();

    const [isStreamReady, setIsStreamReady] = useState(false);
    const [isVideoPlaying, setIsVideoPlaying] = useState(false);
    const [streamUrl, setStreamUrl] = useState<string | null>(null);
    const [authToken, setAuthToken] = useState<string | null>(null);
    const [connectionDetail, setConnectionDetail] = useState<any>(null);
    const [error, setError] = useState<string | null>(null);
    const [showPlayButton, setShowPlayButton] = useState(true);
    const [isLoading, setIsLoading] = useState(false);
    const [snapshotError, setSnapshotError] = useState(false);
    const [currentMutedState, setCurrentMutedState] = useState(isMuted);
    const playerRef = useRef<HlsPlayerRef | null>(null);
    const videoElementRef = useRef<HTMLVideoElement | null>(null);

    useEffect(() => {
        setCurrentMutedState(isMuted);
        const videoElement = getVideoElement();
        if (videoElement) {
            videoElement.muted = isMuted;
        }
    }, [isMuted]);

    const notifyStreamPlayingChange = useCallback((playing: boolean) => {
        console.log(`[${cctvId}] Notifying parent of playing status change:`, playing);
        if (onStreamPlayingChange) {
            onStreamPlayingChange(playing);
        }
    }, [onStreamPlayingChange, cctvId]);

    useEffect(() => {
        notifyStreamPlayingChange(isVideoPlaying);
    }, [isVideoPlaying, notifyStreamPlayingChange]);

    const getVideoElement = useCallback(() => {
        if (playerRef.current && playerRef.current.video) {
            return playerRef.current.video;
        }
        if (videoElementRef.current) {
            return videoElementRef.current;
        }

        return null;
    }, []);

    useEffect(() => {
        if (isStreamReady) {
            const setupVideoEventListeners = () => {
                const videoElement = getVideoElement();
                if (videoElement && !videoElementRef.current) {
                    console.log(`[${cctvId}] Setting up video element event listeners`);
                    videoElementRef.current = videoElement;
                    videoElement.muted = currentMutedState;

                    const handlePlay = () => {
                        console.log(`[${cctvId}] Video started playing`);
                        setIsVideoPlaying(true);
                        setShowPlayButton(false);
                    };

                    const handlePause = () => {
                        console.log(`[${cctvId}] Video paused`);
                        setIsVideoPlaying(false);
                    };

                    const handleEnded = () => {
                        console.log(`[${cctvId}] Video ended`);
                        setIsVideoPlaying(false);
                    };

                    const handleError = (e: Event) => {
                        console.error(`[${cctvId}] Video element error:`, e);
                        setIsVideoPlaying(false);
                    };

                    videoElement.addEventListener('play', handlePlay);
                    videoElement.addEventListener('pause', handlePause);
                    videoElement.addEventListener('ended', handleEnded);
                    videoElement.addEventListener('error', handleError);

                    return () => {
                        videoElement.removeEventListener('play', handlePlay);
                        videoElement.removeEventListener('pause', handlePause);
                        videoElement.removeEventListener('ended', handleEnded);
                        videoElement.removeEventListener('error', handleError);
                    };
                }
            };

            const cleanup = setupVideoEventListeners();
            if (!cleanup) {
                const retryTimer = setTimeout(() => {
                    setupVideoEventListeners();
                }, 500);
                return () => clearTimeout(retryTimer);
            }
            return cleanup;
        }
    }, [isStreamReady, cctvId, currentMutedState, getVideoElement]);

    const setupStream = useCallback(async () => {
        try {
            setError(null);
            setIsLoading(true);
            console.log(`[${cctvId}] Starting stream setup...`);
            console.log(`[${cctvId}] Fetching connection details...`);
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const fetchedConnectionDetail = await getCctvConnection({
                group_id: selectedGroupMember.group_id,
                id: cctvId
            });

            console.log(`[${cctvId}] Connection details fetched:`, fetchedConnectionDetail);
            setConnectionDetail(fetchedConnectionDetail);

            console.log(`[${cctvId}] Generating auth token...`);
            const tokenResponse = await generateToken({
                cctv_id: cctvId
            });

            if (!tokenResponse || !tokenResponse.token) {
                throw new Error("Failed to generate authentication token");
            }

            console.log(`[${cctvId}] Auth token generated`);
            setAuthToken(tokenResponse.token);

            console.log(`[${cctvId}] Creating stream URL...`);
            const url = constructRTSPUrl(fetchedConnectionDetail);
            console.log(`[${cctvId}] Stream URL created:`, url);

            setStreamUrl(url);
            setIsStreamReady(true);
            setShowPlayButton(true);
            console.log(`[${cctvId}] Stream setup complete! Ready to play.`);

        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'Unknown error during stream setup';
            console.error(`[${cctvId}] Stream setup error:`, errorMessage);
            setError(errorMessage);
            setIsStreamReady(false);
            setIsVideoPlaying(false);
            setShowPlayButton(true);
        } finally {
            setIsLoading(false);
        }
    }, [cctvId, selectedGroupMember, generateToken]);

    useEffect(() => {
        console.log(`[${cctvId}] VideoWallStreamPlayer mounted/cctvId changed`);
        setConnectionDetail(null);
        setAuthToken(null);
        setStreamUrl(null);
        setIsStreamReady(false);
        setIsVideoPlaying(false);
        setShowPlayButton(true);
        setError(null);
        setIsLoading(false);
        setSnapshotError(false);
        videoElementRef.current = null;
    }, [cctvId]);

    const handlePlayStream = useCallback(async () => {
        console.log(`[${cctvId}] Play button clicked`);
        setShowPlayButton(false);

        if (!isStreamReady) {
            await setupStream();
            setTimeout(() => {
                const videoElement = getVideoElement();
                if (videoElement) {
                    console.log(`[${cctvId}] Playing video after setup`);
                    videoElement.play().catch(console.error);
                }
            }, 1000);
        } else {
            const videoElement = getVideoElement();
            if (videoElement) {
                console.log(`[${cctvId}] Playing already-ready video`);
                try {
                    await videoElement.play();
                } catch (error) {
                    console.error(`[${cctvId}] Error playing video:`, error);
                    setShowPlayButton(true);
                }
            }
        }
    }, [setupStream, cctvId, isStreamReady, getVideoElement]);

    const handleStreamError = useCallback((err: Error) => {
        console.error(`[${cctvId}] Stream error:`, err);
        setError('Stream error');
        setIsStreamReady(false);
        setIsVideoPlaying(false);
        setShowPlayButton(true);
    }, [cctvId]);

    const handleRetry = useCallback(() => {
        console.log(`[${cctvId}] Retrying stream...`);
        setError(null);
        setAuthToken(null);
        setConnectionDetail(null);
        setStreamUrl(null);
        setIsStreamReady(false);
        setIsVideoPlaying(false);
        setIsLoading(false);
        setShowPlayButton(false);
        videoElementRef.current = null;
        setupStream().then();
    }, [setupStream, cctvId]);

    const pauseStream = useCallback(() => {
        console.log(`[${cctvId}] Pausing stream...`);
        const videoElement = getVideoElement();
        if (videoElement) {
            videoElement.pause();
        }
    }, [cctvId, getVideoElement]);

    const playStream = useCallback(async () => {
        console.log(`[${cctvId}] Starting stream via global control...`);

        if (!isStreamReady && !isLoading) {
            console.log(`[${cctvId}] Stream not ready, setting up...`);
            await setupStream();
            setTimeout(async () => {
                const videoElement = getVideoElement();
                if (videoElement) {
                    try {
                        await videoElement.play();
                    } catch (error) {
                        console.error(`[${cctvId}] Error playing after setup:`, error);
                    }
                }
            }, 1000);
        } else if (isStreamReady && !isVideoPlaying) {
            const videoElement = getVideoElement();
            if (videoElement) {
                try {
                    await videoElement.play();
                } catch (error) {
                    console.error(`[${cctvId}] Error playing ready stream:`, error);
                }
            }
        }
    }, [cctvId, isStreamReady, isVideoPlaying, isLoading, setupStream, getVideoElement]);

    const getIsPlaying = useCallback(() => {
        return isVideoPlaying;
    }, [isVideoPlaying]);

    const muteStream = useCallback(() => {
        console.log(`[${cctvId}] Muting stream`);
        const videoElement = getVideoElement();
        if (videoElement) {
            videoElement.muted = true;
            setCurrentMutedState(true);
        }
    }, [cctvId, getVideoElement]);

    const unmuteStream = useCallback(() => {
        console.log(`[${cctvId}] Unmuting stream`);
        const videoElement = getVideoElement();
        if (videoElement) {
            videoElement.muted = false;
            setCurrentMutedState(false);
        }
    }, [cctvId, getVideoElement]);

    const getIsMuted = useCallback(() => {
        const videoElement = getVideoElement();
        if (videoElement) {
            return videoElement.muted;
        }
        return currentMutedState;
    }, [currentMutedState, getVideoElement]);

    const seekToLatest = useCallback(() => {
        console.log(`[${cctvId}] seekToLatest called in VideoWallStreamPlayer`);
        if (playerRef.current && playerRef.current.hls) {
            try {
                const hls = playerRef.current.hls;
                if (hls.media) {
                    console.log(`[${cctvId}] Seeking to latest position in stream via HLS ref`, hls.media.duration);
                    hls.media.currentTime = hls.media.duration;
                    console.log(`[${cctvId}] Reloading stream segments`);
                    hls.startLoad(-1);
                    return true;
                }
            } catch (error) {
                console.error(`[${cctvId}] Error seeking to latest via HLS ref:`, error);
            }
        }

        const videoElement = getVideoElement();
        if (videoElement) {
            try {
                console.log(`[${cctvId}] Seeking to latest position via direct video element`, videoElement.duration);
                videoElement.currentTime = videoElement.duration;
                return true;
            } catch (error) {
                console.error(`[${cctvId}] Error seeking to latest via direct video element:`, error);
            }
        }

        console.warn(`[${cctvId}] Could not seek to latest - no valid video element found`);
        return false;
    }, [cctvId, getVideoElement]);

    useImperativeHandle(ref, () => ({
        seekToLatest,
        playStream,
        pauseStream,
        isPlaying: getIsPlaying,
        muteStream,
        unmuteStream,
        isMuted: getIsMuted
    }), [seekToLatest, playStream, pauseStream, getIsPlaying, muteStream, unmuteStream, getIsMuted]);

    const setHlsPlayerRef = useCallback((player: HlsPlayerRef | null) => {
        console.log(`[${cctvId}] HLS Player ref set:`, player);
        playerRef.current = player;
    }, [cctvId]);

    const getAspectFitClass = () => {
        switch (aspectFitMode) {
            case 'contain':
                return 'object-contain';
            case 'cover':
                return 'object-cover';
            case 'fill':
                return 'object-fill';
            default:
                return 'object-contain';
        }
    };

    const handleSnapshotError = () => {
        setSnapshotError(true);
    };
    if (error) {
        return (
            <div className={`w-full h-full bg-gray-900 flex flex-col items-center justify-center rounded-lg ${className}`}>
                <AlertCircle className="h-6 w-6 text-red-500 mb-1" />
                <p className="text-red-400 text-xs text-center mb-2">Stream Error</p>
                <p className="text-gray-400 text-xs text-center mb-2">CCTV: {cctvId}</p>
                <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRetry}
                    className="text-xs h-6 px-2"
                >
                    Retry
                </Button>
            </div>
        );
    }
    if (isLoading) {
        return (
            <div className={`w-full h-full bg-gray-900 flex flex-col items-center justify-center rounded-lg ${className}`}>
                <Loader2 className="h-6 w-6 text-blue-500 animate-spin mb-1" />
                <p className="text-gray-400 text-xs">Loading...</p>
            </div>
        );
    }
    if (streamUrl && authToken && isStreamReady) {
        console.log(`[${cctvId}] Rendering HLS Player with URL:`, streamUrl);
        return (
            <div className={`w-full h-full bg-black rounded-lg overflow-hidden ${className}`}>
                <HlsPlayer
                    ref={setHlsPlayerRef}
                    className={`w-full h-full ${getAspectFitClass()}`}
                    src={streamUrl}
                    width="100%"
                    height="100%"
                    autoPlay={false}
                    muted={currentMutedState}
                    controls={showControls}
                    onError={handleStreamError}
                    authToken={authToken}
                />
                {!isVideoPlaying && !showControls && (
                    <div className="absolute inset-0 flex items-center justify-center">
                        <Button
                            variant="ghost"
                            size="sm"
                            onClick={handlePlayStream}
                            className="bg-black/50 hover:bg-black/70 text-white rounded-full p-2"
                        >
                            <Play className="h-4 w-4" />
                        </Button>
                    </div>
                )}
            </div>
        );
    }

    return (
        <div className={`w-full h-full bg-gray-900 flex flex-col items-center justify-center rounded-lg relative overflow-hidden ${className}`}>
            {snapshotImage && !snapshotError && (
                <img
                    src={snapshotImage}
                    alt={`CCTV ${cctvId} snapshot`}
                    className={`absolute inset-0 w-full h-full ${getAspectFitClass()}`}
                    onError={handleSnapshotError}
                />
            )}
            {snapshotImage && !snapshotError && (
                <div className="absolute inset-0 bg-black/40" />
            )}
            {showPlayButton && (
                <Button
                    variant="ghost"
                    size="sm"
                    onClick={handlePlayStream}
                    className="bg-black/50 hover:bg-black/70 text-white rounded-full p-2 relative z-10"
                    disabled={isLoading}
                >
                    <Play className="h-4 w-4" />
                </Button>
            )}
        </div>
    );
});

VideoWallStreamPlayer.displayName = 'VideoWallStreamPlayer';
