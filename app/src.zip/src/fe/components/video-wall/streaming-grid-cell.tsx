import React, {useState, useRef} from 'react';
import {Button} from '@/components/ui/button';
import {Plus, Eye, MoreVertical, Maximize2, Square, Monitor, CircleDot, AlertTriangle} from 'lucide-react';
import {Tooltip, TooltipContent, TooltipProvider, TooltipTrigger} from "@/components/ui/tooltip";
import {differenceInMinutes, format, parseISO} from 'date-fns';
import {VideoWallStreamPlayer, VideoWallStreamPlayerRef} from '@/components/video-wall/video-wall-stream-player';
import {DtoVideoWallDetail} from "@/lib/api/data-contracts";
import {VideoWallMode} from './constants';

export interface GridItemData {
    id: number;
    type: string;
    className: string;
}

type AspectFitMode = 'contain' | 'cover' | 'fill';

interface CCTVInfo {
    id: string;
    name: string;
    status?: string;
    last_checked?: string;
    check_interval?: number;
    recording_status?: number;
    snapshot_image?: string;
}

interface StreamingGridCellProps {
    grid: GridItemData;
    computedCellClassName: string;
    mode: 'view' | 'create' | 'edit';
    cctvInfo: CCTVInfo | null;
    onAddCamera: () => void;
    onRemoveCamera: () => void;
    isUpdating: boolean;
    onStreamPlayingChange?: (position: number, isPlaying: boolean) => void;
    onStreamControlRegister?: (position: number, controls: any) => void;
    currentVideoWall?: DtoVideoWallDetail;
    showNativeControls?: boolean;
    isMuted?: boolean;
    videoWallMode?: VideoWallMode;
    playbackComponent?: React.ReactNode;
    aspectRatioStyle?: React.CSSProperties;
}

export const StreamingGridCell: React.FC<StreamingGridCellProps> = ({
                                                                        grid,
                                                                        computedCellClassName,
                                                                        mode,
                                                                        cctvInfo,
                                                                        onAddCamera,
                                                                        onRemoveCamera,
                                                                        isUpdating,
                                                                        onStreamPlayingChange,
                                                                        onStreamControlRegister,
                                                                        showNativeControls = false,
                                                                        isMuted = false,
                                                                        videoWallMode = 'live',
                                                                        playbackComponent,
                                                                        aspectRatioStyle = {}
                                                                    }) => {
    const [aspectFitMode, setAspectFitMode] = useState<AspectFitMode>('contain');
    const [isStreamPlaying, setIsStreamPlaying] = useState(false);
    const [showContextMenu, setShowContextMenu] = useState(false);
    const streamRef = useRef<VideoWallStreamPlayerRef>(null);

    const isViewMode = mode === 'view';
    const isStatusOutdated = () => {
        if (!cctvInfo?.last_checked || !cctvInfo?.check_interval) return false;
        const lastCheckedDate = parseISO(cctvInfo.last_checked);
        const minutesSinceLastCheck = differenceInMinutes(new Date(), lastCheckedDate);
        return minutesSinceLastCheck > cctvInfo.check_interval;
    };

    const formatDate = (dateString: string) => {
        try {
            return format(parseISO(dateString), 'dd MMM yyyy HH:mm');
        } catch {
            return dateString;
        }
    };

    const getStatusBadgeProps = () => {
        if (!cctvInfo) return null;

        const outdated = isStatusOutdated();
        const status = cctvInfo.status;

        return {
            color: outdated ? "warning" : status === "online" ? "success" : status === "alert" ? "destructive" : "warning",
            text: outdated ? "Offline" : status,
            outdated,
            tooltipText: outdated
                ? "Status may be outdated. Last check exceeded the expected interval."
                : `Last checked: ${formatDate(cctvInfo.last_checked || '')}`
        };
    };

    const getRecordingBadgeProps = () => {
        if (!cctvInfo) return null;

        const outdated = isStatusOutdated();
        const isRecording = cctvInfo.recording_status === 1;

        return {
            color: outdated ? "warning" : isRecording ? "success" : "default",
            text: outdated ? "Inactive" : isRecording ? "Recording" : "Inactive",
            isRecording,
            outdated,
            tooltipText: outdated
                ? "Recording status may be outdated. Last check exceeded the expected interval."
                : `Last checked: ${formatDate(cctvInfo.last_checked || '')}`
        };
    };

    const handleSeekToLatest = () => {
        console.log(`[${cctvInfo?.id}] Individual stream seek to latest called`);
        if (streamRef.current) {
            const success = streamRef.current.seekToLatest();
            console.log(`[${cctvInfo?.id}] Seek to latest result:`, success);
        } else {
            console.warn(`[${cctvInfo?.id}] No stream ref available for seek to latest`);
        }
        setShowContextMenu(false);
    };

    const handleAspectModeChange = (mode: AspectFitMode) => {
        setAspectFitMode(mode);
        setShowContextMenu(false);
    };

    const handleStreamPlayingChange = React.useCallback((isPlaying: boolean) => {
        setIsStreamPlaying(isPlaying);
        if (onStreamPlayingChange) {
            onStreamPlayingChange(grid.id, isPlaying);
        }
    }, [grid.id, onStreamPlayingChange]);

    const handleStreamRefChange = React.useCallback((streamPlayer: VideoWallStreamPlayerRef | null) => {
        if (onStreamControlRegister && streamPlayer && isViewMode && cctvInfo) {
            console.log(`[${cctvInfo.id}] Registering stream controls for position ${grid.id}`);
            onStreamControlRegister(grid.id, streamPlayer);
        }
    }, [onStreamControlRegister, grid.id, isViewMode, cctvInfo]);

    const setStreamRef = React.useCallback((streamPlayer: VideoWallStreamPlayerRef | null) => {
        (streamRef as React.MutableRefObject<VideoWallStreamPlayerRef | null>).current = streamPlayer;
        handleStreamRefChange(streamPlayer);
    }, [handleStreamRefChange]);

    React.useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            setShowContextMenu(false);
        };

        if (showContextMenu) {
            document.addEventListener('click', handleClickOutside);
            return () => document.removeEventListener('click', handleClickOutside);
        }
    }, [showContextMenu]);

    const StatusIndicator = () => {
        const statusProps = getStatusBadgeProps();
        if (!statusProps) return null;

        return (
            (!statusProps.outdated && statusProps.text === 'online') ? <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>

                        <div className="text-white">Live</div>
                    </TooltipTrigger>
                    <TooltipContent>
                        {statusProps.tooltipText}
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider> : <div/>
        );
    };

    const RecordingIndicator = () => {
        const recordingProps = getRecordingBadgeProps();
        if (!recordingProps) return null;

        return (
            (recordingProps.isRecording && !recordingProps.outdated) ? <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <div className="">
                            <div className="bg-black bg-opacity-50 rounded-full px-2 py-1 flex items-center gap-1">
                                <CircleDot className="h-4 w-4 text-red-500"/>
                                <span className="text-white text-xs">REC</span>
                            </div>
                        </div>
                    </TooltipTrigger>
                    <TooltipContent>Currently recording</TooltipContent>
                </Tooltip>
            </TooltipProvider> : <div/>
        );
    };

    return (
        <div className={computedCellClassName} style={aspectRatioStyle}>
            {!cctvInfo ? (
                <>
                    {!isViewMode ? (
                        <Button
                            variant="outline"
                            className="w-full h-full flex flex-col items-center justify-center gap-2 min-h-[80px] border-dashed border-2 hover:border-blue-400 hover:bg-blue-50"
                            onClick={onAddCamera}
                            disabled={isUpdating}
                        >
                            <Plus className="h-5 w-5 text-gray-400"/>
                            <span className="text-sm font-medium text-gray-600">Add Camera</span>
                            {mode === 'create' && (
                                <span className="text-xs text-gray-400">Position {grid.id + 1}</span>
                            )}
                        </Button>
                    ) : (
                        <div
                            className="w-full h-full flex flex-col items-center justify-center gap-2 min-h-[80px] border-dashed border-2 border-gray-200 bg-gray-50 rounded-lg">
                            <div className="text-sm font-medium text-gray-400">No Camera</div>
                            <div className="text-xs text-gray-400">Position {grid.id + 1}</div>
                            <div className="text-xs text-gray-400">
                                {grid.type === 'large' ? 'Main View' :
                                    grid.type === 'small' ? 'Small View' : 'Equal View'}
                            </div>
                        </div>
                    )}
                </>
            ) : (
                <div className={`relative w-full h-full flex flex-col justify-center ${
                    isViewMode ? 'bg-black' : 'bg-blue-50 border-2 border-blue-200'
                } rounded-lg overflow-hidden`}>

                    {isViewMode && videoWallMode === 'live' && (
                        <div className="absolute top-2 right-2 z-30">
                            <div className="relative">
                                {showContextMenu && (
                                    <div
                                        className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-20">
                                        <div
                                            className="px-3 py-2 text-sm font-medium text-gray-700 border-b border-gray-100">
                                            Aspect Ratio
                                        </div>

                                        <div className="py-1">
                                            <button
                                                onClick={() => handleAspectModeChange('contain')}
                                                className={`w-full px-3 py-2 text-left text-sm hover:bg-gray-50 flex items-center ${
                                                    aspectFitMode === 'contain' ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                                                }`}
                                            >
                                                <Square className="mr-2 h-4 w-4"/>
                                                Fit to Container
                                                {aspectFitMode === 'contain' && (
                                                    <span className="ml-auto text-blue-600">✓</span>
                                                )}
                                            </button>

                                            <button
                                                onClick={() => handleAspectModeChange('cover')}
                                                className={`w-full px-3 py-2 text-left text-sm hover:bg-gray-50 flex items-center ${
                                                    aspectFitMode === 'cover' ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                                                }`}
                                            >
                                                <Maximize2 className="mr-2 h-4 w-4"/>
                                                Fill Container
                                                {aspectFitMode === 'cover' && (
                                                    <span className="ml-auto text-blue-600">✓</span>
                                                )}
                                            </button>

                                            <button
                                                onClick={() => handleAspectModeChange('fill')}
                                                className={`w-full px-3 py-2 text-left text-sm hover:bg-gray-50 flex items-center ${
                                                    aspectFitMode === 'fill' ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                                                }`}
                                            >
                                                <Monitor className="mr-2 h-4 w-4"/>
                                                Stretch to Fill
                                                {aspectFitMode === 'fill' && (
                                                    <span className="ml-auto text-blue-600">✓</span>
                                                )}
                                            </button>
                                        </div>

                                        <div className="border-t border-gray-100">
                                            <button
                                                onClick={handleSeekToLatest}
                                                disabled={!isStreamPlaying}
                                                className={`w-full px-3 py-2 text-left text-sm hover:bg-gray-50 flex items-center ${
                                                    !isStreamPlaying ? 'text-gray-400 cursor-not-allowed' : 'text-gray-700'
                                                }`}
                                            >
                                                <Eye className="mr-2 h-4 w-4"/>
                                                Go to Live
                                            </button>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {!isViewMode && (
                        <Button
                            variant="ghost"
                            size="sm"
                            className="absolute top-1 right-1 h-6 w-6 p-0 text-red-500 hover:text-red-700 hover:bg-red-50 z-10"
                            onClick={onRemoveCamera}
                            disabled={isUpdating}
                            title="Remove camera"
                        >
                            ×
                        </Button>
                    )}

                    {!isViewMode && (
                        <div className="absolute bottom-2 left-2 z-10">
                            <div className="bg-blue-100 border border-blue-200 rounded px-2 py-1">
                                <div className="text-xs text-blue-800 font-medium">
                                    Position {grid.id + 1}
                                </div>
                                <div className="text-xs text-blue-600">
                                    {grid.type === 'large' ? 'Main' :
                                        grid.type === 'small' ? 'Small' : 'Equal'}
                                </div>
                            </div>
                        </div>
                    )}
                    {isViewMode ? (
                        <div className="w-full h-full relative">
                            <div className="absolute bottom-2 left-2 z-10">
                                <div className="bg-black/50 rounded px-2 py-1">
                                    <div className="text-xs text-white font-medium">
                                        {grid.id + 1}
                                    </div>
                                </div>
                            </div>

                            {videoWallMode === 'live' ? (
                                <>
                                    <div className="absolute z-20 flex flex-col gap-1 w-full">
                                        <div className="bg-black/80 px-2 py-1">
                                            <div className="flex flex-row justify-between items-center gap-1">
                                                <div className="text-xs text-white font-medium truncate">
                                                    {cctvInfo.name}
                                                </div>
                                                <div className="flex flex-row items-center">
                                                    <StatusIndicator/>
                                                    <RecordingIndicator/>
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        className="h-8 w-8 p-0 bg-black/50 hover:bg-black/70 text-white"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            setShowContextMenu(!showContextMenu);
                                                        }}
                                                    >
                                                        <MoreVertical className="h-4 w-4"/>
                                                    </Button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <VideoWallStreamPlayer
                                        ref={setStreamRef}
                                        cctvId={cctvInfo.id}
                                        aspectFitMode={aspectFitMode}
                                        onStreamPlayingChange={handleStreamPlayingChange}
                                        className="w-full h-full"
                                        snapshotImage={cctvInfo.snapshot_image}
                                        showControls={showNativeControls}
                                        isMuted={isMuted}
                                    />
                                </>
                            ) : (
                                <>
                                    <div className="absolute z-20 flex flex-col gap-1 w-full">
                                        <div className="bg-black/80 px-2 py-1">
                                            <div className="flex flex-row justify-between items-center gap-1">
                                                <div className="text-xs text-white font-medium truncate">
                                                    {cctvInfo.name}
                                                </div>
                                                <div className="text-xs text-blue-300">
                                                    Playback Mode
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {playbackComponent || (
                                        <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                                            <div className="text-gray-400 text-center">
                                                <p className="text-sm">Playback not available</p>
                                                <p className="text-xs mt-1">for this camera</p>
                                            </div>
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    ) : (
                        <div className="text-center p-2 w-full h-full flex flex-col justify-center">
                            <div
                                className={`text-sm font-medium ${isViewMode ? 'text-blue-800' : 'text-gray-800'} mb-1`}>
                                {cctvInfo.name}
                            </div>

                            <div className={`text-xs ${isViewMode ? 'text-blue-600' : 'text-gray-500'} mb-1`}>
                                ID: {cctvInfo.id}
                            </div>

                            <div className={`text-xs mt-1 ${isViewMode ? 'text-blue-600' : 'text-gray-400'}`}>
                                Position {grid.id + 1}
                            </div>
                            <div className={`text-xs ${isViewMode ? 'text-blue-600' : 'text-gray-400'}`}>
                                {grid.type === 'large' ? 'Main View' :
                                    grid.type === 'small' ? 'Small View' : 'Equal View'}
                            </div>

                            <div className={`mt-1 w-2 h-2 rounded-full mx-auto ${
                                isViewMode ? 'bg-blue-500' : 'bg-green-500'
                            }`} title={isViewMode ? "Camera viewing" : "Camera assigned"}></div>

                            {mode === 'create' && (
                                <div className="text-xs text-blue-600 mt-1 font-medium">
                                    Ready
                                </div>
                            )}

                            {mode === 'edit' && (
                                <div className="text-xs text-orange-600 mt-1 font-medium">
                                    Editing
                                </div>
                            )}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};
