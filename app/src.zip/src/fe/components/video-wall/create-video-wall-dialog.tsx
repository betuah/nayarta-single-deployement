import React, { useState } from 'react';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

interface CreateVideoWallDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (name: string) => void;
    isLoading?: boolean;
}

export const CreateVideoWallDialog: React.FC<CreateVideoWallDialogProps> = ({
                                                                                isOpen,
                                                                                onClose,
                                                                                onSave,
                                                                                isLoading = false
                                                                            }) => {
    const [name, setName] = useState('');
    const [error, setError] = useState('');

    const validateName = (value: string): string => {
        if (!value.trim()) {
            return 'Video wall name is required';
        }
        if (value.trim().length < 3) {
            return 'Video wall name must be at least 3 characters long';
        }
        if (value.trim().length > 50) {
            return 'Video wall name must be less than 50 characters';
        }
        return '';
    };

    const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setName(value);

        if (error) {
            setError('');
        }
    };

    const handleSave = () => {
        const trimmedName = name.trim();
        const validationError = validateName(trimmedName);

        if (validationError) {
            setError(validationError);
            return;
        }

        onSave(trimmedName);
    };

    const handleClose = () => {
        if (!isLoading) {
            setName('');
            setError('');
            onClose();
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !isLoading) {
            handleSave();
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={handleClose}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Create Video Wall</DialogTitle>
                    <DialogDescription>
                        Enter a name for your new video wall. You can assign cameras to the layout once created.
                    </DialogDescription>
                </DialogHeader>

                <div className="py-4">
                    <div className="space-y-2">
                        <Label htmlFor="video-wall-name">Video Wall Name</Label>
                        <Input
                            id="video-wall-name"
                            type="text"
                            placeholder="Enter video wall name..."
                            value={name}
                            onChange={handleNameChange}
                            onKeyPress={handleKeyPress}
                            disabled={isLoading}
                            className={error ? 'border-red-500 focus:border-red-500' : ''}
                            autoFocus
                        />
                        {error && (
                            <p className="text-sm text-red-600 flex items-center gap-1">
                                {error}
                            </p>
                        )}
                    </div>

                    <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm text-blue-800">
                            <span className="font-medium">Note:</span> After creating the video wall,
                            you'll be able to assign cameras to each position in the grid layout.
                        </p>
                    </div>
                </div>

                <DialogFooter>
                    <Button
                        variant="outline"
                        onClick={handleClose}
                        disabled={isLoading}
                    >
                        Cancel
                    </Button>
                    <Button
                        onClick={handleSave}
                        disabled={isLoading || !name.trim()}
                        className="min-w-[120px]"
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Creating...
                            </>
                        ) : (
                            'Create Video Wall'
                        )}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};
