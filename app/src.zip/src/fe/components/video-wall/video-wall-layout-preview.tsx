import React, {useCallback, useState} from 'react';
import {Loader2, Eye, Edit, Plus} from 'lucide-react';
import {StreamingGridCell, GridItemData} from './streaming-grid-cell';
import {AspectRatioType, getAspectRatioStyle, layoutOptions, VideoWallMode} from "@/components/video-wall/constants";
import {VideoWallGlobalControls} from './video-wall-global-controls';
import {DtoVideoWallDetail} from "@/lib/api/data-contracts";

interface CCTVInfo {
    id: string;
    name: string;
}

interface VideoWallLayoutPreviewProps {
    selectedLayout: string;
    isProcessingSelection: boolean;
    gridContainerClass: string;
    grids: GridItemData[];
    getGridItemComputedClass: (grid: GridItemData) => string;
    mode: 'view' | 'create' | 'edit';
    getCCTVAtPosition: (position: number) => CCTVInfo | null;
    onAddCamera: (position: number) => void;
    onRemoveCamera: (position: number) => void;
    isUpdating: boolean;
    gridScale?: number;
    videoWallName?: string;
    currentVideoWall?: DtoVideoWallDetail;
    videoWallMode?: VideoWallMode;
    playbackComponents?: { [position: number]: React.ReactNode };
    globalAspectRatio?: AspectRatioType;
}

export const VideoWallLayoutPreview: React.FC<VideoWallLayoutPreviewProps> = ({
                                                                                  selectedLayout,
                                                                                  isProcessingSelection,
                                                                                  gridContainerClass,
                                                                                  grids,
                                                                                  getGridItemComputedClass,
                                                                                  mode,
                                                                                  getCCTVAtPosition,
                                                                                  onAddCamera,
                                                                                  onRemoveCamera,
                                                                                  isUpdating,
                                                                                  gridScale = 100,
                                                                                  videoWallName,
                                                                                  currentVideoWall,
                                                                                  videoWallMode = 'live',
                                                                                  playbackComponents = {},
                                                                                  globalAspectRatio = "1:1"
                                                                              }) => {
    const layoutLabel = layoutOptions.find(opt => opt.value === selectedLayout)?.label || "Selected Layout";
    const scaleTransform = gridScale / 100;
    const [streamPlayingStatus, setStreamPlayingStatus] = useState<{ [position: number]: boolean }>({});
    const [streamMuteStatus, setStreamMuteStatus] = useState<{ [position: number]: boolean }>({});
    const [showNativeControls, setShowNativeControls] = useState<boolean>(false);
    const [streamControls, setStreamControls] = useState<{ [position: number]: any }>({});

    const getModeIcon = () => {
        switch (mode) {
            case 'view':
                return <Eye className="h-4 w-4 text-blue-600"/>;
            case 'edit':
                return <Edit className="h-4 w-4 text-orange-600"/>;
            case 'create':
                return <Plus className="h-4 w-4 text-green-600"/>;
            default:
                return null;
        }
    };

    const handleStreamPlayingChange = useCallback((position: number, isPlaying: boolean) => {
        if (videoWallMode === 'live') {
            console.log(`[Position ${position}] Playing status changed to:`, isPlaying);
            setStreamPlayingStatus(prev => ({
                ...prev,
                [position]: isPlaying
            }));
        }
    }, [videoWallMode]);

    const handleStreamControlRegister = useCallback((position: number, controls: any) => {
        if (videoWallMode === 'live') {
            console.log(`[Position ${position}] Stream controls registered:`, !!controls);
            setStreamControls(prev => ({
                ...prev,
                [position]: controls
            }));
        }
    }, [videoWallMode]);

    const handlePlayAll = useCallback(async () => {
        if (videoWallMode !== 'live') return;

        console.log('Playing all streams...', Object.keys(streamControls));

        const playPromises = Object.entries(streamControls).map(async ([position, controls]) => {
            const cctvInfo = getCCTVAtPosition(parseInt(position));
            if (cctvInfo && controls && typeof controls.playStream === 'function') {
                console.log(`Playing stream for position ${position}, cctvId: ${cctvInfo.id}`);
                try {
                    if (!controls.isPlaying()) {
                        await controls.playStream();
                        await new Promise(resolve => setTimeout(resolve, 100));
                    }
                } catch (error) {
                    console.error(`Error playing stream for position ${position}:`, error);
                }
            }
        });

        await Promise.all(playPromises);
    }, [streamControls, getCCTVAtPosition, videoWallMode]);

    const handlePauseAll = useCallback(() => {
        if (videoWallMode !== 'live') return;
        console.log('Pausing all streams...', Object.keys(streamControls));
        Object.entries(streamControls).forEach(([position, controls]) => {
            const cctvInfo = getCCTVAtPosition(parseInt(position));
            if (cctvInfo && controls && typeof controls.pauseStream === 'function') {
                console.log(`Pausing stream for position ${position}, cctvId: ${cctvInfo.id}`);
                try {
                    if (controls.isPlaying()) {
                        controls.pauseStream();
                    }
                } catch (error) {
                    console.error(`Error pausing stream for position ${position}:`, error);
                }
            }
        });
    }, [streamControls, getCCTVAtPosition, videoWallMode]);

    const handleSeekToLatestAll = useCallback(() => {
        if (videoWallMode !== 'live') return;
        console.log('Seeking all streams to latest...', Object.keys(streamControls));
        Object.entries(streamControls).forEach(([position, controls]) => {
            const cctvInfo = getCCTVAtPosition(parseInt(position));
            if (cctvInfo && controls && typeof controls.seekToLatest === 'function') {
                console.log(`Seeking stream for position ${position}, cctvId: ${cctvInfo.id}`);
                try {
                    if (controls.isPlaying()) {
                        controls.seekToLatest();
                    }
                } catch (error) {
                    console.error(`Error seeking stream for position ${position}:`, error);
                }
            }
        });
    }, [streamControls, getCCTVAtPosition, videoWallMode]);

    const handleMuteAll = useCallback(() => {
        if (videoWallMode !== 'live') return;
        console.log('Muting all streams...');
        Object.entries(streamControls).forEach(([position, controls]) => {
            const cctvInfo = getCCTVAtPosition(parseInt(position));
            if (cctvInfo && controls && typeof controls.muteStream === 'function') {
                console.log(`Muting stream for position ${position}, cctvId: ${cctvInfo.id}`);
                try {
                    controls.muteStream();
                    setStreamMuteStatus(prev => ({
                        ...prev,
                        [parseInt(position)]: true
                    }));
                } catch (error) {
                    console.error(`Error muting stream for position ${position}:`, error);
                }
            }
        });
    }, [streamControls, getCCTVAtPosition, videoWallMode]);

    const handleUnmuteAll = useCallback(() => {
        if (videoWallMode !== 'live') return;
        console.log('Unmuting all streams...');
        Object.entries(streamControls).forEach(([position, controls]) => {
            const cctvInfo = getCCTVAtPosition(parseInt(position));
            if (cctvInfo && controls && typeof controls.unmuteStream === 'function') {
                console.log(`Unmuting stream for position ${position}, cctvId: ${cctvInfo.id}`);
                try {
                    controls.unmuteStream();
                    setStreamMuteStatus(prev => ({
                        ...prev,
                        [parseInt(position)]: false
                    }));
                } catch (error) {
                    console.error(`Error unmuting stream for position ${position}:`, error);
                }
            }
        });
    }, [streamControls, getCCTVAtPosition, videoWallMode]);

    const handleToggleControlsVisibility = useCallback(() => {
        if (videoWallMode !== 'live') return;
        console.log('Toggling native HTML5 controls visibility...', !showNativeControls);
        setShowNativeControls(prev => !prev);
    }, [showNativeControls, videoWallMode]);

    const totalStreamsWithCameras = grids.filter(grid => getCCTVAtPosition(grid.id)).length;
    const playingStreams = videoWallMode === 'live' ? Object.values(streamPlayingStatus).filter(Boolean).length : 0;
    const mutedStreams = videoWallMode === 'live' ? Object.values(streamMuteStatus).filter(Boolean).length : 0;

    return (
        <div className="space-y-4">
            {mode === 'view' && videoWallMode === 'live' && totalStreamsWithCameras > 0 && (
                <VideoWallGlobalControls
                    onPlayAll={handlePlayAll}
                    onPauseAll={handlePauseAll}
                    onSeekToLatestAll={handleSeekToLatestAll}
                    onMuteAll={handleMuteAll}
                    onUnmuteAll={handleUnmuteAll}
                    onToggleControlsVisibility={handleToggleControlsVisibility}
                    totalStreams={totalStreamsWithCameras}
                    playingStreams={playingStreams}
                    mutedStreams={mutedStreams}
                    areControlsVisible={showNativeControls}
                    isViewMode={mode === 'view'}
                    disabled={isUpdating || isProcessingSelection}
                />
            )}

            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <h3 className="text-lg font-semibold text-default-800">
                        {videoWallName ? `${videoWallName}` : `Preview: ${layoutLabel}`}
                    </h3>
                    <div className="flex items-center gap-2">
                        {getModeIcon()}
                        <span className="text-sm text-default-600">
                            {videoWallName ? layoutLabel : ''}
                        </span>
                        {globalAspectRatio && globalAspectRatio !== "1:1" && (
                            <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">
                                {globalAspectRatio}
                            </span>
                        )}
                        {/* Show mode indicator */}
                        {videoWallMode === 'playback' && (
                            <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                                Playback Mode
                            </span>
                        )}
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    {gridScale !== 100 && (
                        <div className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded">
                            Scale: {gridScale}%
                        </div>
                    )}
                </div>
            </div>

            <div className={`relative border rounded-lg p-4 overflow-auto`}>
                {isProcessingSelection && (
                    <div
                        className="absolute inset-0 bg-white/70 backdrop-blur-sm z-10 flex items-center justify-center rounded-lg">
                        <div className="flex items-center gap-2 text-blue-600">
                            <Loader2 className="h-6 w-6 animate-spin"/>
                            <span className="text-sm font-medium">Loading layout...</span>
                        </div>
                    </div>
                )}

                <div
                    style={{
                        transform: `scale(${scaleTransform})`,
                        transformOrigin: 'center top',
                        transition: 'transform 0.2s ease-in-out'
                    }}
                >
                    <div className={gridContainerClass}>
                        {grids.map((grid) => {
                            const cctvInfo = getCCTVAtPosition(grid.id);
                            const isStreamMuted = videoWallMode === 'live' ? (streamMuteStatus[grid.id] || false) : false;
                            const playbackComponent = playbackComponents[grid.id];
                            const aspectRatioStyle = getAspectRatioStyle(globalAspectRatio as any);

                            return (
                                <StreamingGridCell
                                    key={grid.id}
                                    grid={grid}
                                    currentVideoWall={currentVideoWall}
                                    computedCellClassName={getGridItemComputedClass(grid)}
                                    mode={mode}
                                    cctvInfo={cctvInfo}
                                    onAddCamera={() => onAddCamera(grid.id)}
                                    onRemoveCamera={() => onRemoveCamera(grid.id)}
                                    isUpdating={isUpdating}
                                    onStreamPlayingChange={videoWallMode === 'live' ? handleStreamPlayingChange : undefined}
                                    onStreamControlRegister={videoWallMode === 'live' ? handleStreamControlRegister : undefined}
                                    showNativeControls={videoWallMode === 'live' ? showNativeControls : false}
                                    isMuted={isStreamMuted}
                                    videoWallMode={videoWallMode}
                                    playbackComponent={playbackComponent}
                                    aspectRatioStyle={aspectRatioStyle} // NEW: Pass aspect ratio style
                                />
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
};
