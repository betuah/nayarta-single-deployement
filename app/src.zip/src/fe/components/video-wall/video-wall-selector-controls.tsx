import React from 'react';
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from '@/components/ui/select';
import {Button} from '@/components/ui/button';
import {Eye, Edit, Plus, AlertTriangle} from 'lucide-react';
import {DtoVideoWallDetail} from '@/lib/api/data-contracts';
import {layoutOptions, LayoutType} from './constants';

interface VideoWallSelectorControlsProps {
    videoWalls: DtoVideoWallDetail[] | undefined;
    selectedVideoWallId: string;
    onVideoWallSelect: (videoWallId: string) => void;
    selectedLayout: LayoutType;
    onLayoutSelectChange: (layout: LayoutType) => void;
    isLoaderActive: boolean;
    isLoadingVideoWalls: boolean;
    mode: 'view' | 'create' | 'edit';
    onModeSwitch: (mode: 'view' | 'create' | 'edit') => void;
    hasUnsavedChanges: boolean;
}

export const VideoWallSelectorControls: React.FC<VideoWallSelectorControlsProps> = ({
                                                                                        videoWalls,
                                                                                        selectedVideoWallId,
                                                                                        onVideoWallSelect,
                                                                                        selectedLayout,
                                                                                        onLayoutSelectChange,
                                                                                        isLoaderActive,
                                                                                        isLoadingVideoWalls,
                                                                                        mode,
                                                                                        onModeSwitch,
                                                                                        hasUnsavedChanges,
                                                                                    }) => {
    const handleModeSwitch = (newMode: 'view' | 'create' | 'edit') => {
        if (hasUnsavedChanges && newMode !== mode) {
            const confirmSwitch = window.confirm(
                'You have unsaved changes. Are you sure you want to switch modes? Your changes will be lost.'
            );
            if (!confirmSwitch) return;
        }
        onModeSwitch(newMode);
    };

    const canSwitchToEdit = selectedVideoWallId && selectedVideoWallId !== 'new';
    const canSwitchToView = videoWalls && videoWalls.length > 0;

    return (
        <div className="space-y-4">
            <div className='flex flex-row items-end justify-between'>
                <div className="flex gap-4 flex-wrap">
                    {(mode === 'view' || mode === 'edit') && (
                        <div className="flex-1 min-w-[200px] max-w-xs">
                            <label htmlFor="videowall-select"
                                   className="block text-sm font-medium text-default-700 mb-2">
                                {mode === 'view' ? 'Video Wall' : 'Edit Video Wall'}
                            </label>
                            <Select
                                value={selectedVideoWallId}
                                onValueChange={onVideoWallSelect}
                                disabled={isLoaderActive}
                            >
                                <SelectTrigger className="w-full truncate overflow-hidden whitespace-nowrap text-ellipsis">
                                    <SelectValue
                                        placeholder={isLoadingVideoWalls ? "Loading..." : "Select video wall"}/>
                                </SelectTrigger>
                                <SelectContent>
                                    {videoWalls?.map((videoWall) => (
                                        <SelectItem
                                            key={videoWall.id}
                                            value={videoWall.id!}
                                            className="w-full overflow-hidden whitespace-nowrap text-ellipsis truncate"
                                        >
                                            <span className="block w-full truncate">{videoWall.name}</span>
                                        </SelectItem>
                                    ))}
                                    {(!videoWalls || videoWalls.length === 0) && (
                                        <SelectItem value="no-walls" disabled>
                                            No video walls available
                                        </SelectItem>
                                    )}
                                </SelectContent>

                            </Select>
                        </div>
                    )}
                    {(mode === 'create' || mode === 'edit') && (
                        <div className="flex-1 min-w-[200px] max-w-xs">
                            <label htmlFor="layout-select" className="block text-sm font-medium text-default-700 mb-2">
                                {mode === 'create' ? 'Select Layout' : 'Change Layout'}
                            </label>
                            <Select
                                value={selectedLayout}
                                onValueChange={mode === 'create' ? onLayoutSelectChange : onLayoutSelectChange}
                                disabled={isLoaderActive}
                            >
                                <SelectTrigger className="w-full">
                                    <SelectValue placeholder="Choose a layout"/>
                                </SelectTrigger>
                                <SelectContent>
                                    {layoutOptions.map((option) => (
                                        <SelectItem key={option.value} value={option.value}>
                                            {option.label}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                    {mode === 'view' && (
                        <div className="flex-1 min-w-[200px] max-w-xs">
                            <label className="block text-sm font-medium text-default-700 mb-2">
                                Current Layout
                            </label>
                            <div
                                className="w-full px-3 py-2 text-sm bg-default-50 border border-default-200 rounded-md">
                                {layoutOptions.find(opt => opt.value === selectedLayout)?.label || selectedLayout}
                            </div>
                        </div>
                    )}
                </div>
                <div className="flex items-center justify-end gap-2 flex-wrap">
                    <Button
                        onClick={() => handleModeSwitch('view')}
                        disabled={isLoaderActive || !canSwitchToView || mode === 'view'}
                        variant="soft"
                        size="sm"
                        title={!canSwitchToView ? "No video walls available to view" : "View mode"}
                    >
                        <Eye className="h-4 w-4"/>
                    </Button>
                    {canSwitchToEdit &&
                        <Button
                            size="sm"
                            variant="soft"
                            onClick={() => handleModeSwitch('edit')}
                            disabled={isLoaderActive || !canSwitchToEdit || mode === 'edit'}
                            title={!canSwitchToEdit ? "Select a video wall to edit" : "Edit mode"}
                        >
                            <Edit className="h-4 w-4"/>
                        </Button>
                    }

                    <Button
                        size="sm"
                        variant="soft"
                        onClick={() => handleModeSwitch('create')}
                        disabled={isLoaderActive || mode === 'create'}
                        title="Create new video wall"
                    >
                        <Plus className="h-4 w-4"/>
                    </Button>

                    {hasUnsavedChanges && (
                        <div className="flex items-center gap-1 text-orange-600 text-sm">
                            <AlertTriangle className="h-4 w-4"/>
                            <span>Unsaved changes</span>
                        </div>
                    )}
                </div>

            </div>

            <div className="text-sm text-default-600">
                {mode === 'edit' && (
                    <p className="flex flex-row items-center"><Edit className="h-4 w-4 mr-1"/><strong>Edit
                        Mode:</strong> Modify camera assignments and layout. Changes must be saved.</p>
                )}
                {mode === 'create' && (
                    <p className="flex flex-row items-center"><Plus className="h-4 w-4 mr-1"/><strong>Create
                        Mode:</strong> Design a new video wall layout and assign cameras.</p>
                )}
            </div>
        </div>
    );
};
