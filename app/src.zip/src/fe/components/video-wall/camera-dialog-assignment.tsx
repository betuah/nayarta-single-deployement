import React, { useState, useEffect } from 'react';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ResourceFilter } from '@/components/resource-filter';
import { Loader2 } from 'lucide-react';

interface CameraAssignmentDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onAssign: (filter: {
        locationId?: string;
        locationName?: string;
        floorPlanId?: string;
        floorPlanName?: string;
        cameraId?: string;
        cameraName?: string
    }) => void;
    position: number;
    isLoading?: boolean;
}

export const CameraAssignmentDialog: React.FC<CameraAssignmentDialogProps> = ({
                                                                                  isOpen,
                                                                                  onClose,
                                                                                  onAssign,
                                                                                  position,
                                                                                  isLoading = false
                                                                              }) => {
    const [selectedCameraInfo, setSelectedCameraInfo] = useState<{
        cameraId?: string;
        cameraName?: string;
        locationId?: string;
        locationName?: string;
        floorPlanId?: string;
        floorPlanName?: string;
    }>({});

    useEffect(() => {
        if (!isOpen) {
            setSelectedCameraInfo({});
        }
    }, [isOpen]);

    const handleFilterChange = (filter: {
        locationId?: string;
        floorPlanId?: string;
        cameraId?: string;
        locationName?: string;
        floorPlanName?: string;
        cameraName?: string
    }) => {
        setSelectedCameraInfo(filter);
    };

    const handleAssign = () => {
        if (selectedCameraInfo.cameraId && selectedCameraInfo.cameraName) {
            onAssign(selectedCameraInfo);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle>Assign Camera to Position {position + 1}</DialogTitle>
                    <DialogDescription>
                        Select a camera to assign to this grid position. Use the filters below to narrow down your selection.
                    </DialogDescription>
                </DialogHeader>

                <div className="py-4">
                    <ResourceFilter onFilterChange={handleFilterChange} />
                </div>

                {selectedCameraInfo.cameraId && selectedCameraInfo.cameraName && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                        <div className="text-sm text-blue-800">
                            <div className="font-medium mb-1">Selected Camera:</div>
                            <div className="font-semibold">{selectedCameraInfo.cameraName}</div>
                            <div className="text-xs text-blue-600 mt-1">ID: {selectedCameraInfo.cameraId}</div>
                            {selectedCameraInfo.locationName && (
                                <div className="text-xs text-blue-600">Location: {selectedCameraInfo.locationName}</div>
                            )}
                            {selectedCameraInfo.floorPlanName && (
                                <div className="text-xs text-blue-600">Floor: {selectedCameraInfo.floorPlanName}</div>
                            )}
                        </div>
                    </div>
                )}

                <DialogFooter>
                    <Button
                        variant="outline"
                        onClick={onClose}
                        disabled={isLoading}
                    >
                        Cancel
                    </Button>
                    <Button
                        onClick={handleAssign}
                        disabled={!selectedCameraInfo.cameraId || !selectedCameraInfo.cameraName || isLoading}
                        className="min-w-[100px]"
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Assigning...
                            </>
                        ) : (
                            'Assign Camera'
                        )}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};
