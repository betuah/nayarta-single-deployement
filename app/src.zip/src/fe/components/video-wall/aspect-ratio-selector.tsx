import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { ScreenShare, RotateCcw } from 'lucide-react';
import { AspectRatioType, aspectRatioOptions } from './constants';

interface AspectRatioSelectorProps {
    aspectRatio: AspectRatioType;
    onAspectRatioChange: (aspectRatio: AspectRatioType) => void;
    disabled?: boolean;
}

export const AspectRatioSelector: React.FC<AspectRatioSelectorProps> = ({
                                                                            aspectRatio,
                                                                            onAspectRatioChange,
                                                                            disabled = false
                                                                        }) => {
    const currentOption = aspectRatioOptions.find(option => option.value === aspectRatio);

    const handleReset = () => {
        onAspectRatioChange("1:1");
    };

    const handlePresetRatio = (ratio: AspectRatioType) => {
        onAspectRatioChange(ratio);
    };

    return (
        <div className="bg-default border rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                    <ScreenShare className="h-4 w-4 text-default-600" />
                    <label className="text-sm font-medium text-default-700">
                        Grid Aspect Ratio
                    </label>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-blue-600">
                        {currentOption?.label || aspectRatio}
                    </span>
                    <span className="text-sm text-default-500 bg-default-100 px-2 py-1 rounded">
                        {currentOption?.ratio.toFixed(2) || "1.00"}
                    </span>
                </div>
            </div>

            <div className="flex items-center gap-3 mb-3">
                <div className="flex-1">
                    <Select
                        value={aspectRatio}
                        onValueChange={onAspectRatioChange}
                        disabled={disabled}
                    >
                        <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select aspect ratio" />
                        </SelectTrigger>
                        <SelectContent>
                            {aspectRatioOptions.map((option) => (
                                <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>

                <Button
                    variant="outline"
                    size="sm"
                    onClick={handleReset}
                    disabled={disabled || aspectRatio === "1:1"}
                    title="Reset to square (1:1)"
                >
                    <RotateCcw className="h-4 w-4" />
                </Button>
            </div>

            {/* Quick preset buttons */}
            <div className="flex justify-between items-center">
                <div className="flex gap-1 flex-wrap">
                    {aspectRatioOptions.slice(0, 4).map((option) => (
                        <Button
                            key={option.value}
                            variant={aspectRatio === option.value ? undefined : "outline"}
                            size="sm"
                            onClick={() => handlePresetRatio(option.value)}
                            disabled={disabled}
                            className="h-6 text-xs px-2"
                        >
                            {option.value}
                        </Button>
                    ))}
                </div>

                <div className="text-xs text-gray-400">
                    Grid Shape
                </div>
            </div>

            <div className="mt-3 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-700">
                <strong>Tip:</strong> Change the shape of all grid containers. Each camera can still use its own fit mode (contain/cover/fill).
            </div>
        </div>
    );
};
