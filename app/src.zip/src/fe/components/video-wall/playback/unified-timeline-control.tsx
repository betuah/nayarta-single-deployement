import React, { useState, useRef, useEffect, useCallback } from 'react';
import { DtoRecordingSegment } from '@/lib/api/data-contracts';
import { ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CoverageInfo {
    totalCameras: number;
    camerasWithSegments: number;
    coveragePercentage: number;
}

interface UnifiedTimelineControlProps {
    allSegments: DtoRecordingSegment[];
    currentTime: number;
    onSeek: (time: number) => void;
    onDragStart?: () => void;
    onDragEnd?: (time: number) => void;
    getCameraCoverageAtTime: (timeInSeconds: number) => CoverageInfo;
    totalCameras: number;
}

const SECONDS_IN_DAY = 86400;
const MAX_ZOOM_LEVEL = 24;

interface UnifiedSegment {
    startTime: number;
    endTime: number;
    coveragePercentage: number;
    camerasWithSegments: number;
    totalCameras: number;
}

export const UnifiedTimelineControl: React.FC<UnifiedTimelineControlProps> = ({
                                                                                  allSegments,
                                                                                  currentTime,
                                                                                  onSeek,
                                                                                  onDragStart,
                                                                                  onDragEnd,
                                                                                  getCameraCoverageAtTime,
                                                                                  totalCameras
                                                                              }) => {
    const scrollContainerRef = useRef<HTMLDivElement>(null);
    const timelineRef = useRef<HTMLDivElement>(null);
    const markerRef = useRef<HTMLDivElement>(null);

    const [isDragging, setIsDragging] = useState(false);
    const [draggedTime, setDraggedTime] = useState<number | null>(null);
    const [zoomLevel, setZoomLevel] = useState(1);
    const [visibleRange, setVisibleRange] = useState({ start: 0, end: SECONDS_IN_DAY });

    const positionToSeconds = useCallback((clientX: number): number => {
        if (!timelineRef.current) return 0;
        const rect = timelineRef.current.getBoundingClientRect();
        const positionX = clientX - rect.left;
        const clampedPositionX = Math.max(0, Math.min(rect.width, positionX));
        const positionPercentage = rect.width > 0 ? clampedPositionX / rect.width : 0;
        const seconds = positionPercentage * SECONDS_IN_DAY;
        return Math.max(0, Math.min(SECONDS_IN_DAY, seconds));
    }, []);

    const formatTime = useCallback((secondsInput: number): string => {
        const totalSeconds = Math.max(0, Math.min(secondsInput, SECONDS_IN_DAY));
        if (totalSeconds === SECONDS_IN_DAY) return "24:00:00";

        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const secs = Math.floor(totalSeconds % 60);
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }, []);

    const generateUnifiedSegments = useCallback((): UnifiedSegment[] => {
        if (allSegments.length === 0) return [];
        const timePoints = new Set<number>();
        allSegments.forEach(segment => {
            if (!segment.start_time || typeof segment.duration !== 'number') return;
            try {
                const date = new Date(segment.start_time);
                const hours = date.getUTCHours();
                const minutes = date.getUTCMinutes();
                const seconds = date.getUTCSeconds();
                const startSecondOfDay = hours * 3600 + minutes * 60 + seconds;
                const endSecondOfDay = startSecondOfDay + segment.duration;

                timePoints.add(startSecondOfDay);
                timePoints.add(Math.min(endSecondOfDay, SECONDS_IN_DAY));
            } catch (e) {
                console.error('Error parsing segment time:', e);
            }
        });
        for (let time = 0; time < SECONDS_IN_DAY; time += 300) {
            timePoints.add(time);
        }
        timePoints.add(SECONDS_IN_DAY);
        const sortedTimePoints = Array.from(timePoints).sort((a, b) => a - b);
        const intervals: UnifiedSegment[] = [];
        for (let i = 0; i < sortedTimePoints.length - 1; i++) {
            const startTime = sortedTimePoints[i];
            const endTime = sortedTimePoints[i + 1];
            if (endTime - startTime < 1) continue;
            const midTime = startTime + (endTime - startTime) / 2;
            const coverage = getCameraCoverageAtTime(midTime);

            if (coverage.camerasWithSegments > 0) {
                const lastInterval = intervals[intervals.length - 1];
                if (lastInterval &&
                    Math.abs(lastInterval.endTime - startTime) < 1 &&
                    Math.abs(lastInterval.coveragePercentage - coverage.coveragePercentage) < 0.01 &&
                    lastInterval.camerasWithSegments === coverage.camerasWithSegments) {
                    lastInterval.endTime = endTime;
                } else {
                    intervals.push({
                        startTime,
                        endTime,
                        coveragePercentage: coverage.coveragePercentage,
                        camerasWithSegments: coverage.camerasWithSegments,
                        totalCameras: coverage.totalCameras
                    });
                }
            }
        }

        return intervals;
    }, [allSegments, getCameraCoverageAtTime]);

    const generateTimeLabels = useCallback(() => {
        const labels = [];
        let stepMinutes = 60;

        if (zoomLevel >= 16) stepMinutes = 5;
        else if (zoomLevel >= 8) stepMinutes = 10;
        else if (zoomLevel >= 4) stepMinutes = 15;
        else if (zoomLevel >= 2) stepMinutes = 30;

        const stepSeconds = stepMinutes * 60;
        const bufferSeconds = stepSeconds;
        const rangeStart = Math.max(0, visibleRange.start - bufferSeconds);
        const rangeEnd = Math.min(SECONDS_IN_DAY, visibleRange.end + bufferSeconds);

        let currentTimeLabel = Math.ceil(rangeStart / stepSeconds) * stepSeconds;

        while (currentTimeLabel <= rangeEnd && currentTimeLabel < SECONDS_IN_DAY) {
            const hours = Math.floor(currentTimeLabel / 3600);
            const minutes = Math.floor((currentTimeLabel % 3600) / 60);
            const isHourMark = minutes === 0;

            labels.push({
                time: currentTimeLabel,
                label: isHourMark
                    ? `${hours.toString().padStart(2, '0')}:00`
                    : `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`,
                isHour: isHourMark
            });
            currentTimeLabel += stepSeconds;
        }
        return labels;
    }, [zoomLevel, visibleRange]);

    const handleScroll = useCallback(() => {
        if (!scrollContainerRef.current || !timelineRef.current) return;

        const scrollLeft = scrollContainerRef.current.scrollLeft;
        const visibleWidth = scrollContainerRef.current.clientWidth;
        const totalWidth = timelineRef.current.offsetWidth;

        if (totalWidth <= 0) return;

        const startPercentage = scrollLeft / totalWidth;
        const endPercentage = (scrollLeft + visibleWidth) / totalWidth;
        const newStart = startPercentage * SECONDS_IN_DAY;
        const newEnd = endPercentage * SECONDS_IN_DAY;

        setVisibleRange({
            start: Math.max(0, newStart),
            end: Math.min(SECONDS_IN_DAY, newEnd)
        });
    }, []);

    useEffect(() => {
        if (!isDragging && scrollContainerRef.current && timelineRef.current) {
            const timelineTotalWidth = timelineRef.current.offsetWidth;
            const visibleWidth = scrollContainerRef.current.clientWidth;
            const targetPixelPosition = (currentTime / SECONDS_IN_DAY) * timelineTotalWidth;
            let newScrollLeft = targetPixelPosition - (visibleWidth / 2);
            newScrollLeft = Math.max(0, Math.min(newScrollLeft, timelineTotalWidth - visibleWidth));

            const currentScrollLeft = scrollContainerRef.current.scrollLeft;
            const markerLeftEdge = targetPixelPosition - 2;
            const markerRightEdge = targetPixelPosition + 2;

            if (markerRightEdge < currentScrollLeft || markerLeftEdge > currentScrollLeft + visibleWidth || zoomLevel === 1 || Math.abs(currentScrollLeft - newScrollLeft) > 10) {
                scrollContainerRef.current.scrollTo({ left: newScrollLeft, behavior: 'smooth' });
            }
            handleScroll();
        }
    }, [currentTime, isDragging, zoomLevel, handleScroll]);

    const handleTimelineClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (isDragging) return;

        if (markerRef.current && markerRef.current.contains(e.target as Node)) {
            const handleElement = markerRef.current.querySelector('[data-drag-handle="true"]');
            if (handleElement && handleElement.contains(e.target as Node)) {
                return;
            }
        }

        const timeInSeconds = positionToSeconds(e.clientX);
        console.log(`UnifiedTimeline: Click detected at ${timeInSeconds}s`);
        onSeek(timeInSeconds);
    }, [isDragging, positionToSeconds, onSeek]);

    const handleMarkerMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();

        setIsDragging(true);
        const initialTime = positionToSeconds(e.clientX);
        setDraggedTime(initialTime);

        console.log("UnifiedTimeline: Drag Start");
        onDragStart?.();

        const handleMouseMove = (moveEvent: MouseEvent) => {
            const timeInSeconds = positionToSeconds(moveEvent.clientX);
            setDraggedTime(timeInSeconds);

            if (scrollContainerRef.current) {
                const containerRect = scrollContainerRef.current.getBoundingClientRect();
                const relativeX = moveEvent.clientX - containerRect.left;
                const edgeThreshold = 50;
                const scrollAmount = 15;

                if (relativeX < edgeThreshold && scrollContainerRef.current.scrollLeft > 0) {
                    scrollContainerRef.current.scrollLeft -= scrollAmount;
                    handleScroll();
                } else if (relativeX > containerRect.width - edgeThreshold && scrollContainerRef.current.scrollLeft < scrollContainerRef.current.scrollWidth - containerRect.width) {
                    scrollContainerRef.current.scrollLeft += scrollAmount;
                    handleScroll();
                }
            }
        };

        const handleMouseUp = (upEvent: MouseEvent) => {
            upEvent.stopPropagation();

            const finalTime = draggedTime ?? positionToSeconds(upEvent.clientX);
            console.log(`UnifiedTimeline: Drag End at ${finalTime}s`);
            onDragEnd?.(finalTime);

            setIsDragging(false);
            setDraggedTime(null);

            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };

        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    }, [positionToSeconds, handleScroll, draggedTime, onDragStart, onDragEnd]);

    const handleZoom = useCallback((newZoomLevel: number) => {
        if (newZoomLevel < 1 || newZoomLevel > MAX_ZOOM_LEVEL) return;
        setZoomLevel(newZoomLevel);

        setTimeout(() => {
            if (scrollContainerRef.current && timelineRef.current) {
                const timelineTotalWidth = timelineRef.current.offsetWidth;
                const visibleWidth = scrollContainerRef.current.clientWidth;
                const centerTime = isDragging && draggedTime !== null ? draggedTime : currentTime;
                const centerTimePercentage = centerTime / SECONDS_IN_DAY;

                let newScrollLeft;
                if (newZoomLevel === 1) {
                    newScrollLeft = 0;
                } else {
                    const targetPixelPosition = centerTimePercentage * timelineTotalWidth;
                    newScrollLeft = targetPixelPosition - (visibleWidth / 2);
                }
                newScrollLeft = Math.max(0, Math.min(newScrollLeft, timelineTotalWidth - visibleWidth));
                scrollContainerRef.current.scrollLeft = newScrollLeft;
                handleScroll();
            }
        }, 0);
    }, [currentTime, draggedTime, isDragging, handleScroll]);

    const handleZoomIn = useCallback(() => {
        handleZoom(Math.min(MAX_ZOOM_LEVEL, zoomLevel * 2));
    }, [zoomLevel, handleZoom]);

    const handleZoomOut = useCallback(() => {
        handleZoom(Math.max(1, zoomLevel / 2));
    }, [zoomLevel, handleZoom]);

    const handleResetZoom = useCallback(() => {
        handleZoom(1);
    }, [handleZoom]);

    const timeLabels = generateTimeLabels();
    const unifiedSegments = generateUnifiedSegments();
    const displayTime = isDragging && draggedTime !== null ? draggedTime : currentTime;
    const markerPositionPercent = (displayTime / SECONDS_IN_DAY) * 100;
    const visibleDurationMinutes = Math.round((visibleRange.end - visibleRange.start) / 60);

    const currentCoverage = getCameraCoverageAtTime(displayTime);

    return (
        <div className="mt-6 mb-6 select-none">
            <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-medium text-default-700">
                    Multi-Camera Timeline {zoomLevel > 1 ? `(${formatTime(visibleRange.start)} - ${formatTime(visibleRange.end)})` : '(24 Hours)'}
                </h3>
                <div className="flex space-x-1">
                    <Button variant="outline" size="sm" onClick={handleZoomIn} disabled={zoomLevel >= MAX_ZOOM_LEVEL} className="h-7 px-2">
                        <ZoomIn className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleZoomOut} disabled={zoomLevel <= 1} className="h-7 px-2">
                        <ZoomOut className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleResetZoom} disabled={zoomLevel === 1} className="h-7 px-2">
                        <Maximize2 className="h-4 w-4" />
                    </Button>
                </div>
            </div>
            <div
                ref={scrollContainerRef}
                className="overflow-x-auto overflow-y-hidden border border-default-300 rounded bg-default py-3 px-1 relative cursor-pointer"
                onScroll={handleScroll}
                onClick={handleTimelineClick}
                style={{ height: '90px' }}
            >
                <div
                    ref={timelineRef}
                    className="relative h-8 bg-default-200 mt-7 rounded ml-4"
                    style={{
                        width: `${zoomLevel * 100}%`,
                        minWidth: '100%',
                        height: '20px',
                    }}
                >
                    {timeLabels.map(({ time, label, isHour }) => {
                        const positionPercent = (time / SECONDS_IN_DAY) * 100;
                        return (
                            <div key={`label-${time}`} className="absolute top-0 h-full pointer-events-none" style={{ left: `${positionPercent}%` }}>
                                <div className={`absolute -top-4 w-px ${isHour ? 'h-3 bg-default-400' : 'h-3 bg-default-400'}`}></div>
                                <div className={`absolute -top-8 text-xs whitespace-nowrap ${isHour ? 'font-semibold text-gray-400 -ml-4' : 'text-gray-400 -ml-4'}`}>
                                    {label}
                                </div>
                            </div>
                        );
                    })}
                    <div className="absolute top-0 h-full pointer-events-none" style={{ left: '100%' }}>
                        <div className="absolute -top-4 w-px h-3 bg-gray-500"></div>
                        <div className="absolute -top-8 text-xs font-medium text-gray-700 whitespace-nowrap -ml-4">24:00</div>
                    </div>
                    {unifiedSegments.map((segment, index) => {
                        const startPercent = (segment.startTime / SECONDS_IN_DAY) * 100;
                        const endPercent = Math.min(100, (segment.endTime / SECONDS_IN_DAY) * 100);
                        const widthPercent = Math.max(0, endPercent - startPercent);

                        if (widthPercent <= 0 || startPercent >= 100) return null;

                        const getCoverageStyle = () => {
                            if (segment.coveragePercentage >= 1.0) {
                                return 'bg-green-500 opacity-75';
                            } else if (segment.coveragePercentage >= 0.5) {
                                return 'bg-green-400 opacity-60';
                            } else {
                                return 'bg-green-300 opacity-45';
                            }
                        };

                        return (
                            <div
                                key={`unified-segment-${index}`}
                                className={`absolute top-0 h-full rounded-sm pointer-events-none ${getCoverageStyle()}`}
                                style={{ left: `${startPercent}%`, width: `${widthPercent}%` }}
                                title={`Coverage: ${segment.camerasWithSegments}/${segment.totalCameras} cameras (${Math.round(segment.coveragePercentage * 100)}%)`}
                            />
                        );
                    })}
                    <div
                        ref={markerRef}
                        className="absolute top-0 h-[calc(100%+16px)] -mt-2 w-0.5 bg-red-600 z-10 group"
                        style={{ left: `${markerPositionPercent}%`, pointerEvents: 'none' }}
                    >
                        <div
                            data-drag-handle="true"
                            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-red-600 rounded-full border-2 border-white shadow cursor-ew-resize group-hover:scale-110 transition-transform"
                            style={{ pointerEvents: 'auto' }}
                            onMouseDown={handleMarkerMouseDown}
                        />
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-1.5 py-0.5 bg-black bg-opacity-70 text-white text-xs rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                            {formatTime(displayTime)}
                        </div>
                    </div>
                </div>
            </div>
            <div className="flex justify-between items-center mt-2 text-xs text-gray-600">
                <div className="flex items-center space-x-4">
                    <span className="font-semibold text-sm text-default-800 tabular-nums">
                        {formatTime(currentTime)}
                    </span>
                    <span className="text-default-400">/ 24:00:00</span>
                    <div className="flex items-center gap-2">
                        <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs">
                            Coverage: {currentCoverage.camerasWithSegments}/{currentCoverage.totalCameras} cameras
                        </span>
                        {currentCoverage.coveragePercentage > 0 && (
                            <span className="text-blue-600 text-xs">
                                ({Math.round(currentCoverage.coveragePercentage * 100)}%)
                            </span>
                        )}
                    </div>
                </div>
                {zoomLevel > 1 && (
                    <span className="text-default-500 flex-shrink-0 ml-2">
                        {zoomLevel}x zoom ({visibleDurationMinutes} min view)
                    </span>
                )}
            </div>
            <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                <div className="flex items-center gap-1">
                    <div className="w-3 h-2 bg-green-500 opacity-75 rounded"></div>
                    <span>All cameras</span>
                </div>
                <div className="flex items-center gap-1">
                    <div className="w-3 h-2 bg-green-400 opacity-60 rounded"></div>
                    <span>Most cameras</span>
                </div>
                <div className="flex items-center gap-1">
                    <div className="w-3 h-2 bg-green-300 opacity-45 rounded"></div>
                    <span>Few cameras</span>
                </div>
                <div className="flex items-center gap-1">
                    <div className="w-3 h-2 bg-gray-200 rounded"></div>
                    <span>No recordings</span>
                </div>
            </div>
        </div>
    );
};
