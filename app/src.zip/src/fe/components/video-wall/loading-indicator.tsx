import React from 'react';
import { Loader2 } from 'lucide-react';

interface GlobalLoadingIndicatorProps {
    isLoading: boolean;
    message?: string;
}

export const GlobalLoadingIndicator: React.FC<GlobalLoadingIndicatorProps> = ({
                                                                                  isLoading,
                                                                                  message = "Loading video walls..."
                                                                              }) => {
    if (!isLoading) {
        return null;
    }

    return (
        <div className="flex items-center justify-center py-8">
            <div className="flex items-center gap-2 text-blue-600">
                <Loader2 className="h-8 w-8 animate-spin" />
                <span className="text-gray-600">{message}</span>
            </div>
        </div>
    );
};
