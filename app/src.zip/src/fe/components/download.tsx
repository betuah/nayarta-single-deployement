import React, { useState } from "react";
import { useFileDownload } from "@/hooks/use-file-download";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Monitor, HardDrive, Loader2 } from "lucide-react";
import { toast } from "react-toastify";

interface DownloadItem {
    id: string;
    title: string;
    description: string;
    fileUrl: string;
    fileName: string;
    icon: React.ReactNode;
    version?: string;
    size?: string;
}

export default function DownloadPageComponent() {
    const { downloadFile, isDownloading } = useFileDownload();
    const [downloadingItem, setDownloadingItem] = useState<string | null>(null);

    const downloadItems: DownloadItem[] = [
        {
            id: "nvr-app",
            title: "NVR Application",
            description: "Network Video Recorder application for managing and monitoring your security camera system. Features include live viewing, and recording management",
            fileUrl: "https://beesar-obj.sgp1.digitaloceanspaces.com/beesar-obj/download/NVR-INSTALL.zip",
            fileName: "NVR-INSTALL.zip",
            icon: <HardDrive className="w-8 h-8" />,
            version: "Latest",
            size: "~836MB"
        },
        {
            id: "vms-client",
            title: "VMS Desktop Client",
            description: "Video Management System desktop client for Windows. Provides video surveillance management capabilities with advanced monitoring tools.",
            fileUrl: "https://beesar-obj.sgp1.digitaloceanspaces.com/beesar-obj/download/VMS-INSTALL.zip",
            fileName: "VMS-INSTALL.zip",
            icon: <Monitor className="w-8 h-8" />,
            version: "Latest",
            size: "~75MB"
        }
    ];

    const handleDownload = async (item: DownloadItem) => {
        try {
            setDownloadingItem(item.id);

            // Using 'object_storage' as provider since these are DigitalOcean Spaces files
            await downloadFile(item.fileUrl, item.fileName, "object_storage");

            toast.success(`${item.title} download started successfully!`);
        } catch (error) {
            console.error("Download failed:", error);
            toast.error(`Failed to download ${item.title}. Please try again.`);
        } finally {
            setDownloadingItem(null);
        }
    };

    return (
        <div className="container mx-auto px-4 py-8 max-w-4xl">
            {/* Header */}
            <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-default-900 mb-4">
                    Download Center
                </h1>
                <p className="text-lg text-default-600 max-w-2xl mx-auto">
                    Download supporting applications for Windows.
                    Both applications are designed to provide comprehensive security monitoring solutions.
                </p>
            </div>

            {/* System Requirements */}
            <Card className="mb-8 bg-card border-default-200 border">
                <CardHeader>
                    <CardTitle className="text-blue-800 flex items-center gap-2">
                        <Monitor className="w-5 h-5" />
                        System Requirements
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                        <div>
                            <p className="font-medium text-blue-700 mb-1">Operating System:</p>
                            <p className="text-blue-600">Windows 11 (64-bit)</p>
                        </div>
                        <div>
                            <p className="font-medium text-blue-700 mb-1">Network:</p>
                            <p className="text-blue-600">Internet connection required</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Download Cards */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
                {downloadItems.map((item) => (
                    <Card key={item.id} className="h-full transition-shadow hover:shadow-lg">
                        <CardHeader>
                            <div className="flex items-start justify-between">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 bg-primary/10 rounded-lg text-primary">
                                        {item.icon}
                                    </div>
                                    <div>
                                        <CardTitle className="text-xl">{item.title}</CardTitle>
                                        <div className="flex gap-2 mt-2">
                                            <Badge variant="soft">{item.version}</Badge>
                                            <Badge variant="outline">Windows</Badge>
                                            {item.size && <Badge variant="outline">{item.size}</Badge>}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent className="flex-1 flex flex-col">
                            <CardDescription className="text-sm leading-relaxed mb-6 flex-1">
                                {item.description}
                            </CardDescription>

                            <Button
                                onClick={() => handleDownload(item)}
                                disabled={isDownloading || downloadingItem === item.id}
                                className="w-full"
                                size="lg"
                            >
                                {downloadingItem === item.id ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Preparing Download...
                                    </>
                                ) : (
                                    <>
                                        <Download className="w-4 h-4 mr-2" />
                                        Download {item.title}
                                    </>
                                )}
                            </Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
