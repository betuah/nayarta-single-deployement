import React from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Icon } from '@iconify/react';
import { useCCTVModuleStore } from '@/store/cctv-module-store';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'react-toastify';

interface CameraDetailsRefreshControlsProps {
    cameraId: string;
}

const CameraDetailsRefreshControls: React.FC<CameraDetailsRefreshControlsProps> = ({ cameraId }) => {
    const {
        isAutoRefreshEnabled,
        refreshInterval,
        lastRefreshTime,
        isAutoRefreshing,
        isLoading,
        setAutoRefreshEnabled,
        setRefreshInterval,
        refreshCameraDetails
    } = useCCTVModuleStore();

    const handleManualRefresh = async () => {
        try {
            await refreshCameraDetails(cameraId);
            toast.success('Camera details refreshed successfully');
        } catch (error) {
            toast.error('Failed to refresh camera details');
        }
    };

    const handleIntervalChange = (value: string) => {
        const intervalMs = parseInt(value);
        setRefreshInterval(intervalMs);
        toast.success(`Auto-refresh interval set to ${intervalMs / 60000} minute(s)`);
    };

    const getIntervalLabel = (ms: number) => {
        const minutes = ms / 60000;
        return minutes === 1 ? '1 minute' : `${minutes} minutes`;
    };

    const getLastRefreshText = () => {
        if (!lastRefreshTime) return 'Never';
        try {
            return formatDistanceToNow(lastRefreshTime, { addSuffix: true });
        } catch {
            return 'Recently';
        }
    };

    return (
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4 p-4 bg-card border-b border-border">
            {/* Manual Refresh Button */}
            <Button
                variant="outline"
                size="sm"
                onClick={handleManualRefresh}
                disabled={isLoading || isAutoRefreshing}
                className="flex items-center gap-2"
            >
                <Icon
                    icon="heroicons:arrow-path"
                    className={`h-4 w-4 ${(isLoading || isAutoRefreshing) ? 'animate-spin' : ''}`}
                />
                Refresh
            </Button>

            {/* Auto-refresh Toggle */}
            <div className="flex items-center gap-2">
                <Switch
                    checked={isAutoRefreshEnabled}
                    onCheckedChange={setAutoRefreshEnabled}
                    id="auto-refresh-details"
                />
                <label
                    htmlFor="auto-refresh-details"
                    className="text-sm font-medium cursor-pointer"
                >
                    Auto-refresh
                </label>
            </div>

            {/* Refresh Interval Selector */}
            {isAutoRefreshEnabled && (
                <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">Every:</span>
                    <Select
                        value={refreshInterval.toString()}
                        onValueChange={handleIntervalChange}
                    >
                        <SelectTrigger className="w-32">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="60000">1 minute</SelectItem>
                            <SelectItem value="180000">3 minutes</SelectItem>
                            <SelectItem value="300000">5 minutes</SelectItem>
                            <SelectItem value="600000">10 minutes</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            )}

            {/* Status Indicator */}
            <div className="flex items-center gap-2 ml-auto">
                {isAutoRefreshing && (
                    <div className="flex items-center gap-2 text-sm text-blue-600">
                        <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>
                        Refreshing...
                    </div>
                )}

                {!isAutoRefreshing && (
                    <div className="text-sm text-muted-foreground">
                        Last updated: {getLastRefreshText()}
                    </div>
                )}

                {isAutoRefreshEnabled && !isAutoRefreshing && (
                    <div className="flex items-center gap-1 text-sm text-green-600">
                        <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                        <span>Auto: {getIntervalLabel(refreshInterval)}</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CameraDetailsRefreshControls;
