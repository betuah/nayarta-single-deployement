import React, { useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useCCTVModuleStore } from '@/store/cctv-module-store';
import CameraListCardView from "@/components/camera/list/camera-list-card-view";
import CameraListTableView from "@/components/camera/list/camera-list-table-view";
import CameraListSearchFilter from "@/components/camera/list/camera-list-search-filter";
import {useAutoRefresh} from "@/hooks/use-auto-refresh";
import RefreshControls from "@/components/camera/refresh-control";

const CameraList: React.FC = () => {
    const {
        isLoading,
        isAutoRefreshing,
        activeTab,
        fetchCCTVs,
        setActiveTab
    } = useCCTVModuleStore();

    // Initialize auto-refresh functionality
    const { setUserInteracting, resetTimer } = useAutoRefresh();

    useEffect(() => {
        fetchCCTVs();
    }, []);

    // Handle user interaction events to pause auto-refresh temporarily
    const handleSearchFocus = () => setUserInteracting(true);
    const handleSearchBlur = () => setUserInteracting(false);
    const handleTabChange = (value: string) => {
        setActiveTab(value as 'table' | 'card');
        // Reset timer when user changes tabs (manual interaction)
        resetTimer();
    };

    return (
        <>
            {/* Main loading indicator */}
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs" />}

            {/* Auto-refresh loading indicator */}
            {isAutoRefreshing && !isLoading && (
                <Progress value={30} color="primary" isInfinite size="xs" />
            )}

            {/* Refresh Controls */}
            <RefreshControls />

            <div className="bg-card mt-2 rounded-md p-6">
                {/* Search Filter with interaction handlers */}
                <div
                    onFocus={handleSearchFocus}
                    onBlur={handleSearchBlur}
                >
                    <CameraListSearchFilter />
                </div>

                <Tabs
                    value={activeTab}
                    onValueChange={handleTabChange}
                    className="p-0 px-1"
                >
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="table">
                            Table View
                        </TabsTrigger>
                        <TabsTrigger value="card">
                            List View
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="card" className="py-4">
                        <div className="py-4">
                            <CameraListCardView />
                        </div>
                    </TabsContent>

                    <TabsContent value="table" className="py-4">
                        <CameraListTableView />
                    </TabsContent>
                </Tabs>
            </div>
        </>
    );
};

export default CameraList;
