import React, {useState, useEffect} from 'react';
import {Tabs, TabsContent, TabsList, TabsTrigger} from '@/components/ui/tabs';
import {Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle} from '@/components/ui/card';
import {useForm, Controller} from 'react-hook-form';
import {zodResolver} from '@hookform/resolvers/zod';
import * as z from 'zod';
import {DtoCreateCCTVDTO, DtoUpdateCCTVDTO} from '@/lib/api/data-contracts';
import {useCCTVModuleStore} from "@/store/cctv-module-store";
import {useNVRModuleStore} from "@/store/nvr-module-store";
import {useMounted} from "@/hooks/use-mounted";
import {useRouter} from "next/navigation";
import CameraFormBasicInfo from "@/components/camera/form/camera-form-basic-info";
import CameraFormConnectionDetails from "@/components/camera/form/camera-form-connection-details";
import CameraFormAdvancedSettings from "@/components/camera/form/camera-form-advanced-settings";
import CameraFormStepNavigation from "@/components/camera/form/camera-form-step-navigation";
import {Progress} from "@/components/ui/progress";


const schema = z.object({
    protocol: z.string().min(2, 'Protocol is required'),
    brand: z.string().min(5, 'Brand is required'),
    description: z.string().optional(),
    hostname: z.string().min(5, 'Hostname is required'),
    name: z.string().min(5, 'Camera name is required'),
    nvr_id: z.string().uuid('NVR selection is required'),
    check_interval: z.number().positive("Check interval is required"),
    password: z.string().optional(),
    port: z.number().int().positive('Port must be a positive number'),
    type: z.string().min(5, 'Camera type is required'),
    username: z.string().optional(),
    path: z.string().optional(),
});

export interface CameraFormProps {
    cameraId?: string;
}

const CameraForm: React.FC<CameraFormProps> = ({cameraId}) => {
    const [activeTab, setActiveTab] = useState<'manual'>('manual');
    const [step, setStep] = useState(1);
    const {
        addCamera,
        editCamera,
        fetchCameraDetails,
        currentCameraDetails,
        isLoading,
        reset: resetStore
    } = useCCTVModuleStore();
    const {fetchNVRs} = useNVRModuleStore();
    const mounted = useMounted()
    const router = useRouter()

    const {
        control,
        handleSubmit,
        formState: {errors, isValid},
        trigger,
        setValue,
        reset,
        watch
    } = useForm<DtoCreateCCTVDTO & DtoUpdateCCTVDTO>({
        resolver: zodResolver(schema),
        mode: 'onChange',
        defaultValues: {
            password: '',
            username: '',
            path: '',
            check_interval: 15
        },
    });

    const watchAllFields = watch();

    const validateStep = async (nextStep: number) => {
        let fieldsToValidate: (keyof (DtoCreateCCTVDTO & DtoUpdateCCTVDTO))[] = [];

        switch (step) {
            case 1:
                fieldsToValidate = ['protocol', 'brand', 'type', 'name'];
                break;
            case 2:
                fieldsToValidate = ['hostname', 'port', 'nvr_id', 'check_interval'];
                break;
            case 3:
                fieldsToValidate = ['username', 'password', 'path', 'description'];
                break;
        }

        const isStepValid = await trigger(fieldsToValidate);
        if (isStepValid) {
            setStep(nextStep);
        }
    };

    if (!mounted) {
        resetStore()
        reset()
    }

    useEffect(() => {
        fetchNVRs();
        if (cameraId) {
            fetchCameraDetails(cameraId);
        }
    }, [cameraId]);

    useEffect(() => {
        if (currentCameraDetails) {
            Object.entries(currentCameraDetails).forEach(([key, value]) => {
                setValue(key as keyof (DtoCreateCCTVDTO & DtoUpdateCCTVDTO), value);
            });
        }
    }, [currentCameraDetails, setValue]);

    const onSubmit = async (data: DtoCreateCCTVDTO & DtoUpdateCCTVDTO) => {
        if (cameraId) {
            const updateData: DtoUpdateCCTVDTO = {
                brand: data.brand,
                description: data.description,
                hostname: data.hostname,
                name: data.name,
                password: data.password,
                port: data.port,
                protocol: data.protocol,
                type: data.type,
                username: data.username,
                path: data.path,
                check_interval: data.check_interval,
                nvr_id: data.nvr_id,
            };
            await editCamera(cameraId, updateData);
            router.push(`/camera/${cameraId}`)
        } else {
            await addCamera(data as DtoCreateCCTVDTO);
            router.push(`/camera`)
        }
    };

    return (
        <>
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}
            <div className=" mx-auto bg-card rounded-md p-6 mt-2">
                <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'manual')}>
                    <TabsList className="grid w-full grid-cols-1">
                        <TabsTrigger value="manual">Manual Setup</TabsTrigger>
                    </TabsList>

                    <TabsContent value="manual">
                        <Card className="p-4 rounded-md group w-full border border-default-200 mt-5">
                            <CardHeader>
                                <CardTitle>{cameraId ? 'Edit Camera' : 'Add New Camera'} - Step {step} of 3</CardTitle>
                                <CardDescription>Enter the details for your camera</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleSubmit(onSubmit)}>
                                    {step === 1 && <CameraFormBasicInfo control={control} errors={errors}/>}
                                    {step === 2 && <CameraFormConnectionDetails control={control} errors={errors}/>}
                                    {step === 3 && <CameraFormAdvancedSettings control={control} errors={errors}/>}
                                </form>
                            </CardContent>
                            <CameraFormStepNavigation
                                step={step}
                                validateStep={validateStep}
                                handleSubmit={handleSubmit}
                                onSubmit={onSubmit}
                                isValid={isValid}
                                watchAllFields={watchAllFields}
                            />
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </>
    );
}

export default CameraForm;
