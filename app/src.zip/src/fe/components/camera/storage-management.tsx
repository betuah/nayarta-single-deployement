import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import DatePickerWithRange from "@/components/date-picker-with-range";


const StorageManagement: React.FC = () => {
    const [storageAllocation, setStorageAllocation] = useState(1000); // in GB
    const [retentionPeriod, setRetentionPeriod] = useState(30); // in days
    const [editDateRange, setEditDateRange] = useState({ from: new Date(), to: new Date() });

    return (
        <Card className="bg-card border border-default-200 rounded-lg shadow w-full">
            <CardHeader>
                <CardTitle>Storage Management</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <Label className='mb-4'>Storage Allocation (GB)</Label>
                    <Input
                        type="number"
                        value={storageAllocation}
                        onChange={(e) => setStorageAllocation(Number(e.target.value))}
                    />
                </div>
                <div>
                    <Label className='mb-4'>Retention Period (days)</Label>
                    <Slider
                        value={[retentionPeriod]}
                        onValueChange={([value]) => setRetentionPeriod(value)}
                        max={365}
                        step={1}
                    />
                    <div className='pt-3'>{retentionPeriod} days</div>
                </div>
                <Button>Apply Storage Settings</Button>
            </CardContent>
        </Card>
    );
};

export default StorageManagement



