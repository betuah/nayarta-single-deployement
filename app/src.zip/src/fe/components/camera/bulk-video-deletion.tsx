import React, { useState } from 'react';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2 } from 'lucide-react';

interface VideoPreview {
    id: string;
    timestamp: Date;
    thumbnail: string;
}

const BulkVideoDeletion: React.FC = () => {
    const [dateRange, setDateRange] = useState<{
        from: Date | undefined;
        to: Date | undefined;
    }>({
        from: undefined,
        to: undefined,
    });
    const [videosToDelete, setVideosToDelete] = useState<VideoPreview[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);

    const handleDateSelect = (range: { from: Date | undefined; to: Date | undefined }) => {
        setDateRange(range);
        // In a real application, you would fetch the video previews here based on the date range
        // For this example, we'll use mock data
        if (range.from && range.to) {
            setIsLoading(true);
            setError(null);
            // Simulating API call
            setTimeout(() => {
                setVideosToDelete([
                    { id: '1', timestamp: new Date(2023, 6, 1, 10, 30), thumbnail: 'https://picsum.photos/400/300' },
                    { id: '2', timestamp: new Date(2023, 6, 2, 15, 45), thumbnail: 'https://picsum.photos/400/300' },
                    { id: '3', timestamp: new Date(2023, 6, 3, 9, 0), thumbnail: 'https://picsum.photos/400/300' },
                ]);
                setIsLoading(false);
            }, 1000);
        }
    };

    const handleDelete = async () => {
        setIsLoading(true);
        setError(null);
        try {
            // Simulating API call for deletion
            await new Promise(resolve => setTimeout(resolve, 2000));
            // If successful, clear the videos to delete
            setVideosToDelete([]);
            setIsConfirmDialogOpen(false);
        } catch (err) {
            setError('An error occurred while deleting videos. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };


    return (
        <Card className="w-full max-w-3xl mx-auto">
            <CardHeader>
                <CardTitle>Delete Videos</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="mb-6">
                    <Calendar
                        mode="range"
                        selected={dateRange}
                        // @ts-ignore
                        onSelect={handleDateSelect}
                        numberOfMonths={2}
                        className="rounded-md border"
                    />
                </div>
                {isLoading && (
                    <div className="flex justify-center items-center h-32">
                        <Loader2 className="h-8 w-8 animate-spin" />
                    </div>
                )}
                {error && (
                    <Alert variant="soft">
                        <AlertTitle>Error</AlertTitle>
                        <AlertDescription>{error}</AlertDescription>
                    </Alert>
                )}
                {videosToDelete.length > 0 && (
                    <ScrollArea className="h-64 border rounded-md p-4">
                        <div className="grid grid-cols-3 gap-4">
                            {videosToDelete.map(video => (
                                <div key={video.id} className="text-center">
                                    <img src={video.thumbnail} alt={`Video thumbnail ${video.id}`} className="w-full h-auto rounded-md" />
                                    <p className="mt-2 text-sm">{format(video.timestamp, 'MMM d, yyyy HH:mm')}</p>
                                </div>
                            ))}
                        </div>
                    </ScrollArea>
                )}
            </CardContent>
            <CardFooter className="flex justify-between">
                <p>{videosToDelete.length} videos selected</p>
                <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
                    <DialogTrigger asChild>
                        <Button variant="soft" color='destructive' disabled={videosToDelete.length === 0 || isLoading}>
                            Delete Selected Videos
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Confirm Deletion</DialogTitle>
                            <DialogDescription>
                                Are you sure you want to delete {videosToDelete.length} videos? This action cannot be undone.
                            </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>Cancel</Button>
                            <Button variant="soft" onClick={handleDelete} disabled={isLoading} color='destructive'>
                                {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                                Confirm Delete
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </CardFooter>
        </Card>
    );
};

export default BulkVideoDeletion;
