import React from 'react';
import { Camera, Activity, AlertCircle, Disc, Plus, List, Settings } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import Link from "next/link";

interface CameraStatus {
    id: string;
    name: string;
    status: 'online' | 'offline' | 'warning';
    lastActivity: string;
}

interface PerformanceData {
    date: string;
    uptime: number;
    incidents: number;
}

const dummyCameras: CameraStatus[] = [
    { id: '1', name: 'SHIP-CAM BC-01', status: 'online', lastActivity: '2 min ago' },
    { id: '2', name: 'SHIP-CAM TX-RD-2', status: 'offline', lastActivity: '1 hour ago' },
    { id: '3', name: 'SHIP-CAM TX-A5', status: 'warning', lastActivity: '5 min ago' },
    { id: '4', name: 'SHIP-CAM 7YT-01', status: 'online', lastActivity: '1 min ago' },
    { id: '5', name: 'Back Entrance', status: 'online', lastActivity: '3 min ago' },
];

const performanceData: PerformanceData[] = [
    { date: 'Mon', uptime: 98, incidents: 2 },
    { date: 'Tue', uptime: 99, incidents: 1 },
    { date: 'Wed', uptime: 97, incidents: 3 },
    { date: 'Thu', uptime: 99, incidents: 1 },
    { date: 'Fri', uptime: 98, incidents: 2 },
    { date: 'Sat', uptime: 100, incidents: 0 },
    { date: 'Sun', uptime: 99, incidents: 1 },
];

const CameraDashboard: React.FC = () => {
    const totalCameras = dummyCameras.length;
    const onlineCameras = dummyCameras.filter(camera => camera.status === 'online').length;
    const storageUsage = 75; // Example percentage

    return (
        <div className="container mx-auto p-4">
      

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <Card className='border border-default-200'>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Cameras</CardTitle>
                        <Camera className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{totalCameras}</div>
                        <p className="text-xs text-muted-foreground">
                            {onlineCameras} online, {totalCameras - onlineCameras} offline
                        </p>
                    </CardContent>
                </Card>
                <Card className='border border-default-200'>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">System Uptime</CardTitle>
                        <Activity className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">99.9%</div>
                        <p className="text-xs text-muted-foreground">+0.1% from last week</p>
                    </CardContent>
                </Card>
                <Card className='border border-default-200'>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
                        <AlertCircle className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">3</div>
                        <p className="text-xs text-muted-foreground">-2 from yesterday</p>
                    </CardContent>
                </Card>
                <Card className='border border-default-200'>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Storage Usage</CardTitle>
                        <Disc className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{storageUsage}%</div>
                        <Progress value={storageUsage} className="h-2" />
                    </CardContent>
                </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <Card className='border border-default-200'>
                    <CardHeader>
                        <CardTitle>Camera Status Overview</CardTitle>
                        <CardDescription>Real-time status of all cameras</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {dummyCameras.map(camera => (
                                <div key={camera.id} className="flex items-center justify-between">
                                    <span className="font-medium">{camera.name}</span>
                                    <div className="flex items-center space-x-2">
                    <span className={`inline-block w-2 h-2 rounded-full ${
                        camera.status === 'online' ? 'bg-green-500' :
                            camera.status === 'offline' ? 'bg-red-500' : 'bg-yellow-500'
                    }`}></span>
                                        <span className="text-sm text-gray-500">{camera.status}</span>
                                        <span className="text-xs text-gray-400">{camera.lastActivity}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card className='border border-default-200'>
                    <CardHeader>
                        <CardTitle>System Performance</CardTitle>
                        <CardDescription>Weekly uptime and incident report</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={performanceData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="date" />
                                <YAxis yAxisId="left" />
                                <YAxis yAxisId="right" orientation="right" />
                                <Tooltip />
                                <Line yAxisId="left" type="monotone" dataKey="uptime" stroke="#8884d8" />
                                <Line yAxisId="right" type="monotone" dataKey="incidents" stroke="#82ca9d" />
                            </LineChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button className="flex items-center justify-center" asChild>
                    <Link href='/camera/add'><Plus className="mr-2 h-4 w-4" /> Add New Camera</Link>
                </Button>
                <Button variant="outline" className="flex items-center justify-center" asChild>
                    <Link href='/camera'><List className="mr-2 h-4 w-4" /> View All Cameras</Link>
                </Button>
                <Button variant="outline" className="flex items-center justify-center">
                    <Settings className="mr-2 h-4 w-4" /> System Settings
                </Button>
            </div>
        </div>
    );
};

export default CameraDashboard;
