import React, {useState, useEffect, useCallback} from 'react';
import {format} from 'date-fns';
import {Calendar} from '@/components/ui/calendar';
import {Card, CardContent, CardHeader, CardTitle} from '@/components/ui/card';
import {Dialog, DialogContent, DialogHeader, DialogTitle} from '@/components/ui/dialog';
import {Badge} from '@/components/ui/badge';
import {CircularProgress} from '@/components/ui/progress';
import {FilesListParams, FilesListData, DtoFileListItem, DtoFileDetail} from '@/lib/api/data-contracts';
import {Button} from "@/components/ui/button";
import {Icon} from "@iconify/react";
import {useFileModuleStore} from "@/store/file-module-store";
import dynamic from "next/dynamic";
import DeleteConfirmationDialog from "@/components/delete-confirmation-dialog";
import {formatDate} from "@/lib/utils";
import {Play} from "lucide-react";
import Link from "next/link";

export interface CameraPlaybackProps {
    cctvId: string;
    snapshotUrl: string | undefined
}

const CameraPlayback: React.FC<CameraPlaybackProps> = (props) => {
    const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
    const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
    const {
        files,
        isLoading,
        error,
        hasMore,
        fetchFiles,
        clearFiles,
        deleteFile,
        isUrlLoading,
        generateDownloadUrlFile,
        currentFileUrl
    } = useFileModuleStore();

    const [isDialogOpen, setDialogOpen] = useState(false);
    const [isDeleteDialogOpen, setDialogDeleteOpen] = useState(false);
    const [selectedId, setSelectedId] = useState<string | undefined>(undefined);

    const loadVideos = useCallback((date: Date, append: boolean = false) => {
        fetchFiles({
            cctv_id: props.cctvId,
            start_date: format(date, 'yyyy-MM-dd'),
            end_date: format(date, 'yyyy-MM-dd'),
            file_type: 'recording'
        }, append);
    }, [props.cctvId, fetchFiles]);

    useEffect(() => {
        if (selectedDate) {
            clearFiles();
            loadVideos(selectedDate);
        }
    }, [selectedDate, clearFiles, loadVideos]);

    // Reset video state when dialog closes
    useEffect(() => {
        if (!isDialogOpen) {
            setActiveVideoId(null);
        }
    }, [isDialogOpen]);

    const handleDateChange = (date: Date | undefined) => {
        if (date) {
            clearFiles();
            setSelectedDate(date);
        }
    };

    const handleSelectFile = async (selectedFileId: string) => {
        try {
            setActiveVideoId(selectedFileId);
            const selectedFile = files.find(item => item.id === selectedFileId);
            if (selectedFile) {
                await generateDownloadUrlFile(selectedFile?.file_url!, selectedFile.provider!);
            }
        } catch (error) {
            console.error('Error selecting file:', error);
        }
    };

    const handleDelete = async () => {
        if (selectedId) {
            await deleteFile(selectedId);
            await fetchFiles({}, false);
            setDialogDeleteOpen(false);
        }
    };

    const renderVideoDialog = (file: any) => (
        <Dialog
            open={isDialogOpen}
            onOpenChange={(open) => {
                setDialogOpen(open);
                if (!open) {
                    setActiveVideoId(null);
                }
            }}
        >
            <DialogContent size="2xl">
                <DialogHeader>
                    <DialogTitle>Video Playback</DialogTitle>
                </DialogHeader>
                <div className="aspect-video bg-black relative">
                    {isUrlLoading ? (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <CircularProgress value={50} color="primary" loading/>
                        </div>
                    ) : currentFileUrl ? (
                        <div className="relative w-full h-full">
                            <video
                                src={currentFileUrl}
                                controls
                                crossOrigin="anonymous"
                                className="w-full h-full"
                                autoPlay={false}
                            >
                                Your browser does not support the video tag.
                            </video>
                        </div>
                    ) : (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <p className="text-white">Video not available</p>
                        </div>
                    )}
                </div>

                <p>Timestamp: {formatDate(file.created_at!)}</p>

                <div className="flex flex-row justify-between items-center">
                    <div className="flex flex-wrap gap-1 mt-1">
                        {file.analytics.map((analytic: any) => (
                            <Badge key={analytic.name} variant="outline">
                                {analytic.name}
                            </Badge>
                        ))}
                    </div>
                    <div className="flex flex-row gap-x-2">
                        {currentFileUrl && (
                            <div>
                                <a href={currentFileUrl!} target="_blank">
                                    <Button
                                        size="icon"
                                        variant="soft"
                                        rel="noopener noreferrer"
                                        disabled={isUrlLoading}
                                    >
                                        <Icon icon="material-symbols:download-sharp" className="h-6 w-6"/>
                                    </Button>
                                </a>
                            </div>
                        )}
                        <Button
                            size="icon"
                            variant="soft"
                            color="destructive"
                            disabled={file.analytics.length > 0}
                            onClick={() => {
                                setDialogOpen(false);
                                setDialogDeleteOpen(true);
                            }}
                        >
                            <Icon icon="ic:baseline-delete" className="h-6 w-6"/>
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );

    return (
        <div className="my-4">
            <h1 className="text-2xl font-bold mb-4">Camera Playback</h1>

            <div className="grid grid-cols-1 md:grid-cols-1 gap-4 mb-6 w-full">
                <Card className="bg-card border border-default-200 p-4 rounded-lg shadow w-full">
                    <CardHeader>
                        <CardTitle>Select Date</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Calendar
                            mode="single"
                            selected={selectedDate}
                            onSelect={handleDateChange}
                            className="rounded-md border"
                        />
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-card border border-default-200 p-4 rounded-lg shadow">
                <CardHeader>
                    <CardTitle>
                        Videos for {selectedDate ? format(selectedDate, 'MMMM d, yyyy') : 'Selected Date'}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {
                        files.length === 0 && isLoading &&
                        <div className="flex flex-row items-center justify-center">
                            <CircularProgress value={50} color="primary" loading/>
                        </div>

                    }
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        {files.map((file: DtoFileListItem) => (
                            <div key={file.id} className="cursor-pointer">
                                <div className="relative">
                                    <div className="aspect-video w-full overflow-hidden rounded-md">
                                        <img
                                            src={file.snapshot_image || props.snapshotUrl || '/images/no-image.png'}
                                            alt={`Video at ${format(new Date(file.created_at || ''), 'HH:mm')}`}
                                            onClick={() => {
                                                setSelectedId(file.id);
                                                handleSelectFile(file.id!).then();
                                                setDialogOpen(true);
                                            }}
                                            className="w-full h-full object-cover"
                                        />
                                    </div>
                                    <Button
                                        className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-opacity-75 hover:bg-opacity-100 transition-opacity"
                                        onClick={() => {
                                            setSelectedId(file.id);
                                            handleSelectFile(file.id!).then();
                                            setDialogOpen(true);
                                        }}
                                    >
                                        <Play className="w-8 h-8"/>
                                    </Button>
                                </div>

                                {activeVideoId === file.id && renderVideoDialog(file)}

                                <div className="flex flex-row justify-between items-start my-3">
                                    <div>
                                        <p className="mt-2">{formatDate(file.created_at!)}</p>
                                        <div className="flex flex-wrap gap-1 mt-1">
                                            {file?.analytics?.map(analytic => (
                                                <Badge key={analytic.name} variant="outline">
                                                    {analytic.name}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                    <div className="flex flex-row gap-x-2">
                                        <Button
                                            size="icon"
                                            disabled={(file?.analytics?.length || 0) > 0 || file.provider === "local"}
                                            variant="soft"
                                            color="destructive"
                                            onClick={() => {
                                                setSelectedId(file.id);
                                                setDialogDeleteOpen(true);
                                            }}
                                        >
                                            <Icon icon="ic:baseline-delete" className="h-6 w-6"/>
                                        </Button>
                                        <Link href={`/file-storage/video/${file.id}`}>
                                            <Button
                                                size="icon"
                                                variant="soft"
                                            >
                                                <Icon icon="solar:eye-broken" className="h-6 w-6"/>
                                            </Button>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        ))}
                        {files.length === 0 && (
                            <div>No video available on {selectedDate?.toLocaleDateString()}</div>
                        )}
                    </div>

                    {error && <p className="text-red-500 mt-4">Error: {error}</p>}

                    {hasMore && !isLoading && (
                        <div className="flex flex-row mt-8 justify-center items-center">
                            <Button onClick={() => selectedDate && loadVideos(selectedDate, true)}
                                    isLoading={isLoading}>
                                <Icon icon="ic:outline-expand-more" className="w-6 h-6 mr-2"/>
                                Load More
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>

            <DeleteConfirmationDialog
                open={isDeleteDialogOpen}
                onClose={() => setDialogDeleteOpen(false)}
                onConfirm={handleDelete}
                defaultToast={false}
                message="This action cannot be undone. This will permanently delete your file and remove your data from our servers. The file maybe can not be deleted because it is used by another constrains."
            />
        </div>
    );
};

export default CameraPlayback;
