import React, { useEffect, useRef, useState } from 'react';
import {Button} from '@/components/ui/button';
import {Progress} from "@/components/ui/progress";
import Link from "next/link";
import {Edit} from 'lucide-react';
import {useCCTVModuleStore} from '@/store/cctv-module-store';
import {useCCTVAnalyticsModuleStore} from "@/store/cctv-analytics-module-store";

import CameraInfoStream, {CameraInfoStreamRef} from "@/components/camera/details/camera-info-stream";
import CameraInfoTabs from "@/components/camera/details/camera-info-tabs";
import CameraInfoPTZControls from "@/components/camera/details/camera-info-ptz-controls";
import {useMounted} from "@/hooks/use-mounted";
import StreamUrlsDialog from "@/components/camera/details/stream-urls-dialog";
import CameraPlayback from "@/components/camera/playback/camera-playback";
import {useCameraDetailsAutoRefresh} from "@/hooks/use-camera-details-auto-refresh ";
import CameraDetailsRefreshControls from "@/components/camera/camera-detail-refresh-control";

export interface CameraDetailsProps {
    id: string;
}

const CameraDetails: React.FC<CameraDetailsProps> = ({id}) => {
    const {
        currentCameraDetails,
        isLoading,
        isAutoRefreshing,
        error,
        fetchCameraDetails,
        reset
    } = useCCTVModuleStore();
    const {isUpdating, isSyncing} = useCCTVAnalyticsModuleStore();
    const mounted = useMounted();

    // Initialize auto-refresh functionality for camera details
    const { setUserInteracting, resetTimer } = useCameraDetailsAutoRefresh(id);

    // Track if stream is playing for PTZ controls
    const [isStreamPlaying, setIsStreamPlaying] = useState(false);

    // Reference to stream component for seeking
    const streamRef = useRef<CameraInfoStreamRef>(null);

    if (!mounted) {
        reset();
    }

    useEffect(() => {
        fetchCameraDetails(id);
    }, [id, fetchCameraDetails]);

    // Handle PTZ command completion with forced debug logging
    const handlePtzCommandSent = () => {
        console.log("PTZ command completed callback triggered");

        // Seek the stream to latest
        if (streamRef.current) {
            console.log("Calling seekToLatest on streamRef");
            streamRef.current.seekToLatest();
        } else {
            console.error("streamRef.current is null - cannot seek");
        }

        // Reset timer when user performs PTZ command (manual interaction)
        resetTimer();
    };

    // Debug useEffect to verify ref is properly set
    useEffect(() => {
        console.log("Stream ref available:", streamRef.current !== null);
    }, [streamRef.current]);

    // Handle user interaction events to pause auto-refresh temporarily
    const handleTabChange = () => {
        setUserInteracting(true);
        setTimeout(() => setUserInteracting(false), 1000);
        resetTimer();
    };

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <>
            {/* Main loading indicator */}
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}

            {/* Auto-refresh loading indicator */}
            {isAutoRefreshing && !isLoading && (
                <Progress value={30} color="primary" isInfinite size="xs" />
            )}

            {(isUpdating || isSyncing) && !isLoading && !isAutoRefreshing && (
                <Progress value={50} color="warning" isInfinite size="xs"/>
            )}

            {/* Refresh Controls */}
            <CameraDetailsRefreshControls cameraId={id} />

            <div className="bg-card rounded-md p-6 mt-2">
                {!currentCameraDetails ? <div>No camera details available</div> : <>
                    <div className="flex justify-between items-center mb-4">
                        <h1 className="text-2xl font-bold">{currentCameraDetails.name}</h1>
                        <Button variant="outline" asChild>
                            <Link href={`/camera/${currentCameraDetails.id}/edit`}>
                                <Edit className="mr-2 h-4 w-4"/> Edit Camera
                            </Link>
                        </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="md:col-span-2">
                            <div className="flex items-center justify-between mb-2">
                                <h2 className="text-lg font-semibold">Camera Stream</h2>
                                <div className="flex gap-2">
                                    <StreamUrlsDialog cctvId={id}/>
                                </div>
                            </div>
                            <CameraInfoStream
                                ref={streamRef}
                                id={id}
                                onStreamPlayingChange={setIsStreamPlaying}
                            />
                            <CameraInfoPTZControls
                                isStreamPlaying={isStreamPlaying}
                                onCommandSent={handlePtzCommandSent}
                            />
                        </div>

                        <div className="mb-4">
                            <div onClick={handleTabChange}>
                                <CameraInfoTabs id={id}/>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h2 className="text-lg mt-4 mb-3 font-semibold">Camera Playback & Recordings</h2>
                        <CameraPlayback
                            cctvId={id}
                            date={new Date().toISOString().split('T')[0]}
                        />
                    </div>
                </>}
            </div>
        </>
    );
}

export default CameraDetails;
