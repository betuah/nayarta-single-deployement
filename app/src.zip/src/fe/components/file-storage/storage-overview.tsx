"use client";

import React, {useEffect, useState} from "react";
import {useCCTVAnalyticsModuleStore} from "@/store/dashboard-module-store";
import {Card, CardContent, CardHeader, CardTitle} from "@/components/ui/card";
import {Button} from "@/components/ui/button";
import {BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer} from "recharts";
import {Calendar} from "@/components/ui/calendar";
import {format} from "date-fns";
import {CalendarIcon} from "lucide-react";
import {Popover, PopoverContent, PopoverTrigger} from "@/components/ui/popover";
import {DateRange} from "react-day-picker";
import {Badge} from "@/components/ui/badge";

type RangeType = "last_3_days" | "last_week" | "last_4_months" | "custom";

const StorageOverview: React.FC = () => {
    const [activeFilter, setActiveFilter] = useState<RangeType>("last_3_days");
    const [dateRange, setDateRange] = useState<DateRange | undefined>();
    const [isCalendarOpen, setIsCalendarOpen] = useState(false);

    const {
        getStorageOverviewData,
        isLoadingStorageOverview,
        storageDetailOverview,
    } = useCCTVAnalyticsModuleStore();

    useEffect(() => {
        if (activeFilter === "custom" && dateRange?.from && dateRange?.to) {
            const startDate = format(dateRange.from, "yyyy-MM-dd");
            const endDate = format(dateRange.to, "yyyy-MM-dd");
            getStorageOverviewData(activeFilter, startDate, endDate);
        } else if (activeFilter !== "custom") {
            getStorageOverviewData(activeFilter, undefined, undefined);
        }
    }, [activeFilter, dateRange, getStorageOverviewData]);

    const handleFilterClick = (filter: RangeType) => {
        setActiveFilter(filter);
        if (filter === "custom") {
            setIsCalendarOpen(true);
        }
    };

    const formatBytes = (bytes: number | undefined) => {
        if (bytes === undefined) return "0 MB";

        if (bytes < 1024) {
            return bytes.toFixed(2) + " MB";
        } else {
            return (bytes / 1024).toFixed(2) + " GB";
        }
    };

    return (
        <div className="w-full p-4 space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                <div className="lg:col-span-3 space-y-6">
                    {/* Filter buttons */}
                    <div className="flex flex-wrap w-full mb-4">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 w-full">
                            <Button
                                variant={activeFilter === "last_3_days" ? undefined : "outline"}
                                onClick={() => handleFilterClick("last_3_days")}
                                className="w-full"
                            >
                                Last 3 Days
                            </Button>
                            <Button
                                variant={activeFilter === "last_week" ? undefined : "outline"}
                                onClick={() => handleFilterClick("last_week")}
                                className="w-full"
                            >
                                Last 1 Week
                            </Button>
                            <Button
                                variant={activeFilter === "last_4_months" ? undefined : "outline"}
                                onClick={() => handleFilterClick("last_4_months")}
                                className="w-full"
                            >
                                Last 4 Months
                            </Button>
                            <Popover open={isCalendarOpen && activeFilter === "custom"} onOpenChange={setIsCalendarOpen}>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant={activeFilter === "custom" ? undefined : "outline"}
                                        onClick={() => handleFilterClick("custom")}
                                        className="w-full flex items-center justify-center gap-2 text-xs"
                                    >
                                        {dateRange?.from ? (
                                            dateRange.to ? (
                                                <>
                                                    {format(dateRange.from, "LLL dd, y")} -{" "}
                                                    {format(dateRange.to, "LLL dd, y")}
                                                </>
                                            ) : (
                                                format(dateRange.from, "LLL dd, y")
                                            )
                                        ) : (
                                            "Custom Date"
                                        )}
                                        <CalendarIcon className="h-4 w-4" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                        initialFocus
                                        mode="range"
                                        defaultMonth={dateRange?.from}
                                        selected={dateRange}
                                        onSelect={(range) => {
                                            setDateRange(range);
                                            if (range?.from && range?.to) {
                                                setIsCalendarOpen(false);
                                            }
                                        }}
                                        numberOfMonths={2}
                                    />
                                </PopoverContent>
                            </Popover>
                        </div>
                    </div>

                    {/* Chart */}
                    <Card className="w-full border" style={{height: "400px"}}>
                        <CardContent className="p-6 h-full">
                            {isLoadingStorageOverview ? (
                                <div className="flex h-full w-full items-center justify-center">
                                    <p>Loading chart data...</p>
                                </div>
                            ) : storageDetailOverview?.chart_data && storageDetailOverview.chart_data.length > 0 ? (
                                <div style={{width: '100%', height: '100%'}}>
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart
                                            data={storageDetailOverview.chart_data}
                                            margin={{
                                                top: 5,
                                                right: 30,
                                                left: 20,
                                                bottom: 5,
                                            }}
                                        >
                                            <CartesianGrid strokeDasharray="3 3"/>
                                            <XAxis
                                                dataKey="time_label"
                                                label={{
                                                    value: 'Date',
                                                    position: 'insideBottom',
                                                    offset: -5
                                                }}
                                            />
                                            <YAxis
                                                label={{
                                                    value: 'Usage (MB)',
                                                    angle: -90,
                                                    position: 'insideLeft',
                                                    style: {textAnchor: 'middle'}
                                                }}
                                            />
                                            <Tooltip
                                                formatter={(value) => [`${value} MB`, 'Storage Usage']}
                                                labelFormatter={(label) => `Date: ${label}`}
                                            />


                                            <Legend
                                                verticalAlign="bottom"
                                                height={36}
                                                wrapperStyle={{
                                                    marginTop: '10px',
                                                    paddingTop: '10px'
                                                }}
                                            />


                                            <Bar
                                                name="Storage Usage"
                                                dataKey="usage"
                                                fill="#2563eb"
                                                radius={[4, 4, 0, 0]}
                                                barSize={60}
                                            />

                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            ) : (
                                <div className="flex h-full w-full items-center justify-center">
                                    <p>No chart data available</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>

                {/* Storage Stats */}
                <div className="space-y-4">
                    <Card className="border">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-lg">Main Storage Total</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-2">
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Storage Used :</span>
                                    <span className="font-medium">
                                        {formatBytes(storageDetailOverview?.total_storage)}
                                    </span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Storage Status :</span>
                                    <Badge variant="outline" className="bg-green-50 text-green-600 hover:bg-green-50">
                                        Normal
                                    </Badge>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="border">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-lg">Storage Breakdown</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-2">
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Recordings :</span>
                                    <span className="font-medium">
                                        {formatBytes(storageDetailOverview?.storage_breakdown?.recording)}
                                    </span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Video :</span>
                                    <span className="font-medium">
                                        {formatBytes(storageDetailOverview?.storage_breakdown?.video)}
                                    </span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Images :</span>
                                    <span className="font-medium">
                                        {formatBytes(storageDetailOverview?.storage_breakdown?.image)}
                                    </span>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default StorageOverview;
