import React, {useEffect, useState} from 'react';
import {useFileModuleStore} from '@/store/file-module-store';
import VideoPlayer from '@/components/video-player';
import VideoAnnotationPlayer from '@/components/file-storage/video-annotation/video-annotation-player';
import {Card, CardContent, CardDescription, CardHeader, CardTitle} from '@/components/ui/card';
import {Badge} from '@/components/ui/badge';
import {Alert, AlertDescription, AlertTitle} from '@/components/ui/alert';
import {Button} from '@/components/ui/button';
import {Separator} from '@/components/ui/separator';
import {
    AlertCircle,
    AlertTriangle,
    Camera,
    Download,
    FileVideo,
    Film,
    HardDrive,
    MapPin,
    Radar,
    Info,
    PlayCircle,
    Sparkles,
    ExternalLink,
} from 'lucide-react';
import {formatDate} from '@/lib/utils';
import type {AnnotationData} from '@/types/annotations';
import AnnotationProcessSelector from "@/components/file-storage/recording-details/annotation-process-selector";
import MediaMetadataRenderer from "@/components/file-storage/recording-details/media-metadata-renderer";
import AnalyticProcessesSection from "@/components/file-storage/recording-details/analytic-processes-section";
import LoadingRecordingDetailState from "@/components/file-storage/recording-details/loading-recording-details";
import AnnotationLoadingState from "@/components/file-storage/recording-details/annotation-loading";
import FileSummaryModal from "@/components/file-storage/summary/file-summary-modal";
import Link from "next/link";
import {useFetchWithProgress} from '@/hooks/use-fetch-with-progress';
import {useAnnotationParser} from '@/hooks/use-annotation-parser';
import { useSearchParams, useRouter, usePathname } from 'next/navigation';

interface RecordingDetailsProps {
    fileId: string;
}

const RecordingDetails: React.FC<RecordingDetailsProps> = ({fileId}) => {
    const {
        fileDetailWithAnalytic,
        isLoadingDetailAndAnalytic,
        error,
        fetchFileDetailAndAnalytic,
        generateDownloadUrlFile
    } = useFileModuleStore();

    const [annotationData, setAnnotationData] = useState<AnnotationData | null>(null);
    const [annotationError, setAnnotationError] = useState<string | null>(null);
    const [hasEnhancedFeatures, setHasEnhancedFeatures] = useState(false);
    const [availableAnnotationProcesses, setAvailableAnnotationProcesses] = useState<any[]>([]);
    const [selectedProcessId, setSelectedProcessId] = useState<string | null>(null);
    const [showSummaryModal, setShowSummaryModal] = useState(false);

    const searchParams = useSearchParams();
    const router = useRouter();
    const pathname = usePathname();

    const getPlayerModeFromParams = () => {
        const playerParam = searchParams.get('player');
        return playerParam === 'events';
    };

    const getAnalyticIdFromParams = () => {
        return searchParams.get('analytic');
    };

    const [useEnhancedPlayer, setUseEnhancedPlayer] = useState(getPlayerModeFromParams);


    const updatePlayerMode = (enhanced: boolean) => {
        setUseEnhancedPlayer(enhanced);

        const params = new URLSearchParams(searchParams);
        if (!enhanced) {
            params.delete('player');
        } else {
            params.set('player', 'events');
        }

        const newUrl = `${pathname}?${params.toString()}`;
        router.replace(newUrl);
    };

    const updateSelectedAnalytic = (analyticId: string) => {
        setSelectedProcessId(analyticId);

        const params = new URLSearchParams(searchParams);
        params.set('analytic', analyticId);

        router.replace(`${pathname}?${params.toString()}`);
    };


    useEffect(() => {
        setUseEnhancedPlayer(getPlayerModeFromParams());

        const analyticParam = getAnalyticIdFromParams();
        if (analyticParam && availableAnnotationProcesses.some(p => p.id === analyticParam)) {
            setSelectedProcessId(analyticParam);
        }
    }, [searchParams, availableAnnotationProcesses]);

    const {
        fetchWithProgress,
        progress: downloadProgress,
        isLoading: isDownloading,
        error: downloadError
    } = useFetchWithProgress();

    const {
        parseAnnotations,
        isParsingAnnotations,
        parsingProgress,
        parsingError
    } = useAnnotationParser();

    const getLoadingStage = () => {
        if (isDownloading) return 'downloading';
        if (isParsingAnnotations) return 'parsing';
        return 'complete';
    };

    const isLoadingAnnotations = isDownloading || isParsingAnnotations;

    useEffect(() => {
        if (fileId) {
            fetchFileDetailAndAnalytic(fileId);
        }
    }, [fileId, fetchFileDetailAndAnalytic]);

    useEffect(() => {
        if (!fileDetailWithAnalytic?.analytic_processes) {
            setHasEnhancedFeatures(false);
            setAvailableAnnotationProcesses([]);
            setSelectedProcessId(null);
            setAnnotationData(null);
            return;
        }

        const processesWithAnnotations = fileDetailWithAnalytic.analytic_processes.filter(process => {
            const metadata = process.metadata as any;
            return metadata && metadata.jsonl && metadata.bin;
        });

        setAvailableAnnotationProcesses(processesWithAnnotations);

        if (processesWithAnnotations.length > 0) {
            setHasEnhancedFeatures(true);

            const analyticParam = getAnalyticIdFromParams();

            if (analyticParam && processesWithAnnotations.some(p => p.id === analyticParam)) {
                setSelectedProcessId(analyticParam);
            } else if (!selectedProcessId) {
                const firstProcessId = processesWithAnnotations[0].id!;
                setSelectedProcessId(firstProcessId);

                const params = new URLSearchParams(searchParams);
                params.set('analytic', firstProcessId);
                router.replace(`${pathname}?${params.toString()}`);
            }
        } else {
            setHasEnhancedFeatures(false);
            setAvailableAnnotationProcesses([]);
            setSelectedProcessId(null);
            setAnnotationData(null);
        }
    }, [fileDetailWithAnalytic]);

    useEffect(() => {
        const loadAnnotationData = async () => {
            if (!useEnhancedPlayer) {
                setAnnotationData(null);
                setAnnotationError(null);
                return;
            }

            if (!selectedProcessId || !hasEnhancedFeatures) return;

            const selectedProcess = availableAnnotationProcesses.find(p => p.id === selectedProcessId);
            if (!selectedProcess) return;

            const metadata = selectedProcess.metadata as any;
            if (!metadata?.jsonl || !metadata?.bin) return;

            // Reset states
            setAnnotationError(null);
            setAnnotationData(null);

            try {
                console.log('🚀 Starting annotation loading process...');
                const jsonlUrl = await generateDownloadUrlFile(metadata.jsonl, 'object_storage');
                if (!jsonlUrl) {
                    throw new Error('Failed to generate download URL for annotation file');
                }
                console.log('📥 Starting download...');
                const jsonlText = await fetchWithProgress(jsonlUrl);
                // Parse with Web Worker
                const parsedData = await parseAnnotations(jsonlText);

                console.log('✅ Annotation loading complete!', {
                    metadata: parsedData.metadata,
                    framesCount: parsedData.frames.size
                });

                setAnnotationData(parsedData);

            } catch (error) {
                console.error('❌ Annotation loading failed:', error);
                const errorMessage = error instanceof Error ? error.message : 'Failed to load annotations';
                setAnnotationError(errorMessage);
            }
        };

        loadAnnotationData();
    }, [selectedProcessId, availableAnnotationProcesses, hasEnhancedFeatures, useEnhancedPlayer, generateDownloadUrlFile, fetchWithProgress, parseAnnotations]);

    useEffect(() => {
        if (downloadError || parsingError) {
            setAnnotationError(downloadError || parsingError);
        }
    }, [downloadError, parsingError]);

    if (isLoadingDetailAndAnalytic) {
        return <LoadingRecordingDetailState/>;
    }

    if (error) {
        return (
            <Alert color="destructive" className="mb-6">
                <AlertCircle className="h-4 w-4"/>
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>
                    Failed to load video details. Please try again.
                    <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={() => fetchFileDetailAndAnalytic(fileId)}
                    >
                        Retry
                    </Button>
                </AlertDescription>
            </Alert>
        );
    }

    if (!fileDetailWithAnalytic) {
        return (
            <Alert className="mb-6">
                <AlertTriangle className="h-4 w-4"/>
                <AlertTitle>No Data</AlertTitle>
                <AlertDescription>No video details found for this ID.</AlertDescription>
            </Alert>
        );
    }

    const formatFileSize = (bytes: number) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const handleRetryAnnotations = () => {
        setAnnotationError(null);
        const currentId = selectedProcessId;
        setSelectedProcessId(null);
        setTimeout(() => setSelectedProcessId(currentId), 100);
    };

    return (
        <div className="space-y-6">
            { useEnhancedPlayer &&
                <AnnotationProcessSelector
                    availableProcesses={availableAnnotationProcesses}
                    selectedProcessId={selectedProcessId}
                    onProcessSelect={updateSelectedAnalytic}
                />
            }

            {annotationError && !isLoadingAnnotations && (
                <Alert color="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4"/>
                    <AlertTitle>Annotation Features Unavailable</AlertTitle>
                    <AlertDescription>
                        {annotationError}
                        <div className="mt-2 flex gap-2">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                    setAnnotationError(null);
                                    setHasEnhancedFeatures(false);
                                }}
                            >
                                Use Standard Player
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={handleRetryAnnotations}
                            >
                                Retry Annotation Features
                            </Button>
                        </div>
                    </AlertDescription>
                </Alert>
            )}

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                <div className="xl:col-span-2 space-y-6">
                    <div className="rounded-lg overflow-hidden shadow-md bg-background border">
                        {fileDetailWithAnalytic.download_url && (
                            <>
                                {hasEnhancedFeatures && isLoadingAnnotations && !annotationData ? (
                                    <AnnotationLoadingState
                                        isDownloading={isDownloading}
                                        downloadProgress={downloadProgress}
                                        isParsing={isParsingAnnotations}
                                        parseProgress={parsingProgress}
                                        fileName={fileDetailWithAnalytic.file_name}
                                        stage={getLoadingStage()}
                                    />
                                ) : (
                                    <>
                                        {hasEnhancedFeatures && useEnhancedPlayer && annotationData && !annotationError ? (
                                            <VideoAnnotationPlayer
                                                videoUrl={fileDetailWithAnalytic.download_url}
                                                annotationData={annotationData}
                                                downloadUrl={fileDetailWithAnalytic.download_url}
                                            />
                                        ) : (
                                            <VideoPlayer src={fileDetailWithAnalytic.download_url}/>
                                        )}
                                    </>
                                )}
                            </>
                        )}
                        <div className="p-4 flex flex-col items-end">
                            <Button
                                className={`bg-gradient-to-r from-blue-500 to-purple-800 hover:from-purple-800 hover:to-blue-700 px-4 py-2 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 flex items-center gap-2`}
                                size="xs"
                                onClick={() => setShowSummaryModal(true)}
                            >
                                <Sparkles className="h-4 w-4"/>
                                Generate AI Summary
                            </Button>
                        </div>
                    </div>

                    {fileDetailWithAnalytic.metadata && Object.keys(fileDetailWithAnalytic.metadata).length > 0 && (
                        <Card className="border">
                            <CardHeader className="border-b">
                                <CardTitle className="flex items-center">
                                    <Film className="mr-2 h-5 w-5"/>
                                    Technical Metadata
                                </CardTitle>
                                <CardDescription>
                                    Detailed technical information about this video file
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="p-4">
                                <div className="flex flex-col items-center">
                                    <MediaMetadataRenderer metadata={fileDetailWithAnalytic.metadata}/>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    <Card className="border">
                        <CardHeader className="pb-3">
                            <CardTitle className="flex items-center">
                                <Radar className="mr-2 h-5 w-5"/>
                                Analytics Summary
                            </CardTitle>
                            <CardDescription>
                                Analytics that have been applied and found on this video
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            {fileDetailWithAnalytic.file_analytics && fileDetailWithAnalytic.file_analytics.length > 0 ? (
                                <div className="flex flex-wrap gap-2">
                                    {fileDetailWithAnalytic.file_analytics.map((analytic) => (
                                        <Badge key={analytic.id} color="secondary" className="text-sm py-1 px-3">
                                            {analytic.analytic_type?.name || 'Unknown Analytic'}
                                        </Badge>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-muted-foreground">No analytics were found on this video.</p>
                            )}
                        </CardContent>
                    </Card>

                    <AnalyticProcessesSection
                        processes={fileDetailWithAnalytic.analytic_processes as any || []}
                        availableAnnotationProcesses={availableAnnotationProcesses}
                        selectedProcessId={selectedProcessId}
                        onProcessSelect={updateSelectedAnalytic}
                    />
                </div>

                <div className="xl:col-span-1">
                    <div className="space-y-6">
                        {availableAnnotationProcesses.length > 0 && (
                            <div className="flex items-center justify-between mb-4 p-3 bg-muted/50 rounded-lg border">
                                <div className="flex items-center gap-2">
                                    <Sparkles className="w-4 h-4 text-blue-500"/>
                                    <span className="text-sm font-medium">Player Mode</span>
                                </div>

                                <div className="flex items-center gap-2">
                                    <Button
                                        onClick={() => updatePlayerMode(false)}
                                        variant="soft"
                                        size="sm"
                                        disabled={!useEnhancedPlayer}
                                    >
                                        Standard
                                    </Button>
                                    <Button
                                        onClick={() => updatePlayerMode(true)}
                                        variant="soft"
                                        disabled={useEnhancedPlayer}
                                        size="sm"
                                    >
                                        Events
                                    </Button>
                                </div>
                            </div>
                        )}

                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                    <PlayCircle className="h-5 w-5 text-primary"/>
                                    <h2 className="text-lg font-semibold text-foreground">Video Details</h2>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <div className="bg-muted/50 rounded-lg p-3 border">
                                    <div className="flex items-center space-x-2">
                                        <HardDrive className="h-4 w-4 text-blue-500"/>
                                        <span className="text-xs text-muted-foreground">Size</span>
                                    </div>
                                    <p className="text-sm font-medium mt-1">
                                        {fileDetailWithAnalytic.size ? formatFileSize(fileDetailWithAnalytic.size) : 'N/A'}
                                    </p>
                                </div>
                                <div className="bg-muted/50 rounded-lg p-3 border">
                                    <div className="flex items-center space-x-2">
                                        <FileVideo className="h-4 w-4 text-green-500"/>
                                        <span className="text-xs text-muted-foreground">Type</span>
                                    </div>
                                    <p className="text-sm font-medium mt-1 capitalize">
                                        {fileDetailWithAnalytic.file_type || 'Unknown'}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <Card className="border">
                            <CardHeader className="pb-3">
                                <CardTitle className="flex items-center text-base">
                                    <Info className="mr-2 h-4 w-4"/>
                                    File Information
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="space-y-2">
                                    <div className="flex items-center justify-between py-1">
                                        <span className="text-xs text-muted-foreground">Name</span>
                                        <span className="text-xs font-medium text-right max-w-[60%] truncate"
                                              title={fileDetailWithAnalytic.file_name}>
                                            {fileDetailWithAnalytic.file_name}
                                        </span>
                                    </div>
                                    <Separator/>
                                    <div className="flex items-center justify-between py-1">
                                        <span className="text-xs text-muted-foreground">Created</span>
                                        <span className="text-xs font-medium">
                                            {formatDate(fileDetailWithAnalytic.created_at!)}
                                        </span>
                                    </div>
                                    <Separator/>
                                    <div className="flex items-center justify-between py-1">
                                        <span className="text-xs text-muted-foreground">Updated</span>
                                        <span className="text-xs font-medium">
                                            {formatDate(fileDetailWithAnalytic.updated_at!)}
                                        </span>
                                    </div>
                                </div>

                                <Button
                                    variant="outline"
                                    size="sm"
                                    className="w-full mt-3"
                                    onClick={() => window.open(fileDetailWithAnalytic.download_url || '#', '_blank')}
                                >
                                    <Download className="mr-2 h-3 w-3"/>
                                    Download Video
                                </Button>
                            </CardContent>
                        </Card>

                        <Card className="border">
                            <CardHeader className="pb-3">
                                <CardTitle className="flex items-center text-base">
                                    <Camera className="mr-2 h-4 w-4"/>
                                    Camera Details
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="space-y-2">
                                    <div className="flex items-center justify-between py-1">
                                        <span className="text-xs text-muted-foreground">Camera</span>
                                        <span className="text-xs font-medium">
                                            {
                                                fileDetailWithAnalytic.cctv?.name ?
                                                    <Link href={`/camera/${fileDetailWithAnalytic.cctv_id}`}
                                                          target="_blank">
                                                        <div className="text-primary text-xs flex flex-row">
                                                            {fileDetailWithAnalytic.cctv?.name} <ExternalLink
                                                            className="ml-2 h-3 w-3"/>
                                                        </div>
                                                    </Link> : "Unknown"
                                            }
                                        </span>
                                    </div>
                                    <Separator/>
                                    <div className="flex items-center justify-between py-1">
                                        <span className="text-xs text-muted-foreground">Brand</span>
                                        <span className="text-xs font-medium">
                                            {fileDetailWithAnalytic.cctv?.brand || 'Unknown'}
                                        </span>
                                    </div>
                                    <Separator/>
                                    <div className="flex items-center justify-between py-1">
                                        <span className="text-xs text-muted-foreground">NVR</span>
                                        <span className="text-xs font-medium">
                                            {
                                                fileDetailWithAnalytic.cctv?.nvr_name ?
                                                    <Link href={`/nvr/${fileDetailWithAnalytic.cctv_id}`}
                                                          target="_blank">
                                                        <div className="text-primary text-xs flex flex-row">
                                                            {fileDetailWithAnalytic.cctv?.nvr_name} <ExternalLink
                                                            className="ml-2 h-3 w-3"/>
                                                        </div>
                                                    </Link> : "Unknown"
                                            }
                                        </span>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="border">
                            <CardHeader className="pb-3">
                                <CardTitle className="flex items-center text-base">
                                    <MapPin className="mr-2 h-4 w-4"/>
                                    Location Details
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="space-y-2">
                                    <div className="flex items-center justify-between py-1">
                                        <span className="text-xs text-muted-foreground">Location</span>
                                        <span className="text-xs font-medium">
                                            {
                                                fileDetailWithAnalytic.location?.name ?
                                                    <Link href={`/nvr/locations/${fileDetailWithAnalytic.location.id}`}
                                                          target="_blank">
                                                        <div className="text-primary text-xs flex flex-row">
                                                            {fileDetailWithAnalytic.location?.name} <ExternalLink
                                                            className="ml-2 h-3 w-3"/>
                                                        </div>
                                                    </Link> : "Unknown"
                                            }
                                        </span>
                                    </div>
                                    <Separator/>
                                    <div className="flex items-center justify-between py-1">
                                        <span className="text-xs text-muted-foreground">Floor Plan</span>
                                        <span className="text-xs font-medium">
                                            {
                                                fileDetailWithAnalytic.floor_plan?.name ?
                                                    <Link href={`/floor-plans/${fileDetailWithAnalytic.floor_plan.id}`}
                                                          target="_blank">
                                                        <div className="text-primary text-xs flex flex-row">
                                                            {fileDetailWithAnalytic.floor_plan?.name} <ExternalLink
                                                            className="ml-2 h-3 w-3"/>
                                                        </div>
                                                    </Link> : "Unknown"
                                            }
                                        </span>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
            <FileSummaryModal
                open={showSummaryModal}
                onOpenChange={setShowSummaryModal}
                fileId={fileDetailWithAnalytic.id!}
                fileName={fileDetailWithAnalytic.file_name!}
            />
        </div>
    );
};

export default RecordingDetails;
