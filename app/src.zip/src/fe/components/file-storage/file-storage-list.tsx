import React, {useEffect, useState, useMemo} from "react";
import {useFileModuleStore} from "@/store/file-module-store";
import {useLocationModuleStore} from "@/store/location-module-store";
import {useFloorPlanModuleStore} from "@/store/floor-plan-module-store";
import {useUserStore} from "@/store/user-store";
import {WithLocationListParams} from "@/lib/api/data-contracts";
import {Button} from "@/components/ui/button";
import {Input} from "@/components/ui/input";
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from "@/components/ui/select";
import {Skeleton} from "@/components/ui/skeleton";
import {CalendarIcon, Download, Eye, Trash2, Loader2} from "lucide-react";
import {cn, formatDate,} from "@/lib/utils";
import {format} from "date-fns";
import {Calendar} from "@/components/ui/calendar";
import {Popover, PopoverContent, PopoverTrigger} from "@/components/ui/popover";
import {debounce} from "lodash";
import {useRouter} from "next/navigation";
import {toast} from "react-toastify";
import DeleteConfirmationDialog from "@/components/delete-confirmation-dialog";
import {useFileDownload} from "@/hooks/use-file-download";
import ImageViewer from "@/components/image-viewer";

const FileStorageList: React.FC = () => {
    // Get stores
    const fileStore = useFileModuleStore();
    const locationStore = useLocationModuleStore();
    const floorPlanStore = useFloorPlanModuleStore();
    const userStore = useUserStore();
    const { downloadFile, isDownloading } = useFileDownload();

    const router = useRouter();

    // Local state
    const [selectedLocationId, setSelectedLocationId] = useState<string | null>(null);
    const [selectedFloorPlanId, setSelectedFloorPlanId] = useState<string | null>(null);
    const [fileTypeFilter, setFileTypeFilter] = useState<WithLocationListParams['file_type']>("recording");
    const [searchValue, setSearchValue] = useState("");
    const [fromDate, setFromDate] = useState<Date | null>(null);
    const [toDate, setToDate] = useState<Date | null>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [downloadingFileId, setDownloadingFileId] = useState<string | null>(null);

    // Delete confirmation dialog state
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [fileToDelete, setFileToDelete] = useState<{id: string, name: string} | null>(null);

    // Image viewer state
    const [imageViewerOpen, setImageViewerOpen] = useState(false);
    const [selectedFile, setSelectedFile] = useState<{
        id: string;
        file_name: string;
        file_url: string;
        size: number;
        provider: string;
    } | null>(null);

    // Derived state
    const organizationName = userStore.selectedGroupMember?.group_name || "";

    // Fetch initial data
    useEffect(() => {
        locationStore.fetchLocations();
        fetchFiles();

        // Cleanup
        return () => {
            fileStore.reset();
            locationStore.reset();
            floorPlanStore.resetFilters();
        };
    }, []);

    // Fetch floor plans when location changes
    useEffect(() => {
        if (selectedLocationId) {
            floorPlanStore.setLocationId(selectedLocationId);
            floorPlanStore.fetchFloorPlans();
        } else {
            floorPlanStore.resetFilters();
            setSelectedFloorPlanId(null);
        }
    }, [selectedLocationId]);

    // Reset downloading state when isDownloading changes to false
    useEffect(() => {
        if (!isDownloading && downloadingFileId) {
            setDownloadingFileId(null);
        }
    }, [isDownloading]);

    // Debounced search function
    const debouncedSearch = useMemo(
        () => debounce((searchTerm: string) => {
            fileStore.setSearchTerm(searchTerm);
            setCurrentPage(1);
        }, 500),
        []
    );

    // Update search term
    useEffect(() => {
        debouncedSearch(searchValue);
        return () => {
            debouncedSearch.cancel();
        };
    }, [searchValue, debouncedSearch]);

    // Update filters and trigger fetch
    useEffect(() => {
        fetchFiles(currentPage);
    }, [selectedLocationId, selectedFloorPlanId, fileTypeFilter, fromDate, toDate, fileStore.sortBy, fileStore.sortOrder, currentPage]);

    // Fetch files with filters
    const fetchFiles = (page = 1) => {
        const params: Partial<WithLocationListParams> = {
            page,
            size: 10,
            search: fileStore.searchTerm,
            location_id: selectedLocationId || undefined,
            floor_plan_id: selectedFloorPlanId || undefined,
            file_type: fileTypeFilter,
            start_date: fromDate ? format(fromDate, 'yyyy-MM-dd') : undefined,
            end_date: toDate ? format(toDate, 'yyyy-MM-dd') : undefined,
            sort_by: fileStore.sortBy,
            sort_order: fileStore.sortOrder
        };

        console.log("Fetching with params:", params);
        fileStore.fetchFilesWithLocation(params);
    };

    // Handle pagination
    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    // Handle location change
    const handleLocationChange = (value: string) => {
        setSelectedLocationId(value === "all" ? null : value);
        setSelectedFloorPlanId(null);
        setCurrentPage(1);
    };

    // Handle floor plan change
    const handleFloorPlanChange = (value: string) => {
        setSelectedFloorPlanId(value === "all" ? null : value);
        setCurrentPage(1);
    };

    // Handle file type change
    const handleFileTypeChange = (value: string) => {
        setFileTypeFilter(value as WithLocationListParams['file_type']);
        setCurrentPage(1);
    };

    // Handle date range change
    const handleDateChange = (type: 'from' | 'to', date: Date | null) => {
        if (type === 'from') {
            setFromDate(date);
        } else {
            setToDate(date);
        }
        setCurrentPage(1);
    };

    // Handle sorting
    const handleSort = (sortBy: WithLocationListParams['sort_by']) => {
        if (fileStore.sortBy === sortBy) {
            fileStore.handleSort(sortBy); // This toggles sort order
        } else {
            fileStore.handleSort(sortBy); // This sets new sort field
        }
        setCurrentPage(1);
    };

    // Handle view file action
    const handleViewFile = (file: any) => {
        if (file.file_type === "recording" || file.file_type === "video") {
            router.push(`/file-storage/video/${file.id!}`);
        } else if (file.file_type === "image") {
            setSelectedFile({
                id: file.id!,
                file_name: file.file_name,
                file_url: file.file_url,
                size: file.size,
                provider: file.provider || "object_storage" // Default to object_storage if provider is not specified
            });
            setImageViewerOpen(true);
        }
    };

    // Handle download file action
    const handleDownloadFile = async (file: any) => {
        if (!file.file_url) {
            toast.error("File URL is missing. Cannot download the file.");
            return;
        }

        setDownloadingFileId(file.id);

        // Use the download hook to handle the download
        await downloadFile(
            file.file_url,
            file.file_name,
            file.provider || "object_storage"
        );
    };

    // Handle delete confirmation
    const handleDeleteConfirm = async (file: any) => {
        setFileToDelete({
            id: file.id!,
            name: file.file_name
        });
        setDeleteDialogOpen(true);
    };

    // Perform the actual delete
    const performDelete = async () => {
        if (!fileToDelete) return;

        try {
            await fileStore.deleteFile(fileToDelete.id);
            // Refresh the file list after successful deletion
            fetchFiles(currentPage);
        } catch (error) {
            // Error handling is done in the store
            console.error("Error deleting file:", error);
        }
    };

    // Render the file storage list
    return (
        <div className="w-full">
            {/* Filters Section */}
            <div className="flex flex-col space-y-4 mb-6">
                <div className="flex flex-wrap gap-4 justify-end">
                    {/* Location Filter */}
                    <div className="w-64">
                        <Select
                            value={selectedLocationId || "all"}
                            onValueChange={handleLocationChange}
                        >
                            <SelectTrigger className="h-10 border-primary border-2 text-primary font-semibold">
                                <SelectValue placeholder="All Locations"/>
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Locations</SelectItem>
                                {locationStore.locations.map((location) => (
                                    <SelectItem key={location.id} value={location.id || ""}>
                                        {location.location_name}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Floor Plan Filter */}
                    <div className="w-64">
                        <Select
                            value={selectedFloorPlanId || "all"}
                            onValueChange={handleFloorPlanChange}
                            disabled={!selectedLocationId}
                        >
                            <SelectTrigger className="h-10 border-primary border-2 text-primary font-semibold">
                                <SelectValue placeholder="All Floors"/>
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Floors</SelectItem>
                                {floorPlanStore.floorPlans?.items?.map((floorPlan) => (
                                    <SelectItem key={floorPlan.id} value={floorPlan.id || ""}>
                                        {floorPlan.name}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {/* File Type Filter */}
                    <div className="w-64">
                        <Select
                            value={fileTypeFilter || "recording"}
                            onValueChange={handleFileTypeChange}
                        >
                            <SelectTrigger className="h-10 border-primary border-2 text-primary font-semibold">
                                <SelectValue placeholder="File Type"/>
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="recording">Recording</SelectItem>
                                <SelectItem value="image">Image</SelectItem>
                                <SelectItem value="video">Video</SelectItem>
                                <SelectItem value="sound">Sound</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

            </div>

            <div className="rounded-lg bg-card px-8 py-6">

                <div className="flex flex-wrap gap-4 mb-8">
                    {/* Search */}
                    <div className="flex-1 min-w-[200px] gap-x-2">
                        <div className="flex flex-row">
                            <Input
                                placeholder="Search by file name"
                                value={searchValue}
                                onChange={(e) => setSearchValue(e.target.value)}
                                className="h-10 pr-10"
                            />
                            <button
                                className="px-3 flex items-center justify-center bg-primary rounded ml-2"
                                onClick={() => fetchFiles()}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                     fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                                     strokeLinejoin="round" className="lucide lucide-search text-white">
                                    <circle cx="11" cy="11" r="8"/>
                                    <path d="m21 21-4.3-4.3"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    {/* Date Range From */}
                    <div className="w-64">
                        <Popover>
                            <PopoverTrigger asChild className="border-primary border-2 text-primary font-semibold">
                                <Button
                                    variant={"outline"}
                                    className={cn(
                                        "w-full justify-start text-left font-normal h-10",
                                        !fromDate && "text-muted-foreground"
                                    )}
                                >
                                    <CalendarIcon className="mr-2 h-4 w-4"/>
                                    {fromDate ? format(fromDate, "PPP") : <span className="text-primary">Start Date</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                                <Calendar
                                    mode="single"
                                    selected={fromDate as Date}
                                    onSelect={(date) => handleDateChange('from', date || null)}
                                    initialFocus
                                />
                            </PopoverContent>
                        </Popover>
                    </div>

                    {/* Date Range To */}
                    <div className="w-64">
                        <Popover>
                            <PopoverTrigger asChild className="border-primary border-2 text-primary font-semibold">
                                <Button
                                    variant={"outline"}
                                    className={cn(
                                        "w-full justify-start text-left font-normal h-10",
                                        !toDate && "text-muted-foreground"
                                    )}
                                >
                                    <CalendarIcon className="mr-2 h-4 w-4 text-primary"/>
                                    {toDate ? format(toDate, "PPP") : <span className="text-primary">End Date</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                                <Calendar
                                    mode="single"
                                    selected={toDate as Date}
                                    onSelect={(date) => handleDateChange('to', date || null)}
                                    initialFocus
                                />
                            </PopoverContent>
                        </Popover>
                    </div>

                </div>

                {/* Table */}
                <div className="rounded-md border">
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                            <tr className="border-b bg-muted/50">
                                <th
                                    className="px-4 py-3 text-left font-medium cursor-pointer"
                                    onClick={() => handleSort('file_name')}
                                >
                                    <div className="flex items-center text-primary">
                                        File Name
                                        {fileStore.sortBy === 'file_name' && (
                                            <span className="ml-1">
                                                {fileStore.sortOrder === 'asc' ? '↑' : '↓'}
                                            </span>
                                        )}
                                    </div>
                                </th>
                                <th
                                    className="px-4 py-3 text-left font-medium cursor-pointer"
                                    onClick={() => handleSort('created_at')}
                                >
                                    <div className="flex items-center text-primary">
                                        Date Time
                                        {fileStore.sortBy === 'created_at' && (
                                            <span className="ml-1">
                                                {fileStore.sortOrder === 'asc' ? '↑' : '↓'}
                                            </span>
                                        )}
                                    </div>
                                </th>
                                <th className="px-4 py-3 text-left font-medium">Camera</th>
                                <th className="px-4 py-3 text-left font-medium">Floor</th>
                                <th className="px-4 py-3 text-left font-medium">Location</th>
                                <th className="px-4 py-3 text-left font-medium">Organization</th>
                                <th className="px-4 py-3 text-right font-medium">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            {fileStore.isLoading ? (
                                // Loading state
                                Array(7).fill(0).map((_, index) => (
                                    <tr key={`loading-${index}`} className="border-b">
                                        <td className="px-4 py-3"><Skeleton className="h-4 w-[150px]"/></td>
                                        <td className="px-4 py-3"><Skeleton className="h-4 w-[100px]"/></td>
                                        <td className="px-4 py-3"><Skeleton className="h-4 w-[100px]"/></td>
                                        <td className="px-4 py-3"><Skeleton className="h-4 w-[100px]"/></td>
                                        <td className="px-4 py-3"><Skeleton className="h-4 w-[120px]"/></td>
                                        <td className="px-4 py-3"><Skeleton className="h-4 w-[120px]"/></td>
                                        <td className="px-4 py-3 text-right">
                                            <div className="flex justify-end space-x-2">
                                                <Skeleton className="h-8 w-8 rounded-md"/>
                                                <Skeleton className="h-8 w-8 rounded-md"/>
                                                <Skeleton className="h-8 w-8 rounded-md"/>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            ) : fileStore.filesWithLocation.length === 0 ? (
                                // Empty state
                                <tr>
                                    <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">
                                        No files found
                                    </td>
                                </tr>
                            ) : (
                                // Data rows
                                fileStore.filesWithLocation.map((file) => (
                                    <tr key={file.id} className="border-b">
                                        <td className="px-4 py-3 text-xs">{file.file_name}</td>
                                        <td className="px-4 py-3 text-xs">
                                            {file.created_at ? formatDate(file.created_at): ''}
                                        </td>
                                        <td className="px-4 py-3 text-xs">{file.cctv_name || ''}</td>
                                        <td className="px-4 py-3 text-xs">{file.floor_plan_name || ''}</td>
                                        <td className="px-4 py-3 text-xs">{file.location_name || ''}</td>
                                        <td className="px-4 py-3 text-xs">{organizationName}</td>
                                        <td className="px-4 py-3 text-right">
                                            <div className="flex justify-end space-x-2">
                                                <Button
                                                    size="icon"
                                                    variant="outline"
                                                    onClick={() => handleDownloadFile(file)}
                                                    disabled={downloadingFileId === file.id}
                                                >
                                                    {downloadingFileId === file.id ? (
                                                        <Loader2 size={16} className="animate-spin" />
                                                    ) : (
                                                        <Download size={16} />
                                                    )}
                                                </Button>
                                                <Button
                                                    size="icon"
                                                    variant="outline"
                                                    onClick={() => handleViewFile(file)}
                                                >
                                                    <Eye size={16}/>
                                                </Button>
                                                <Button
                                                    size="icon"
                                                    color='destructive'
                                                    variant="outline"
                                                    onClick={() => handleDeleteConfirm(file)}
                                                >
                                                    <Trash2 size={16}/>
                                                </Button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Pagination */}
                {!fileStore.isLoading && fileStore.filesWithLocation.length > 0 && (
                    <div className="flex items-center justify-between py-4">
                        <div className="text-sm text-muted-foreground">
                            Page {currentPage} of {fileStore.totalPages}
                        </div>
                        <div className="flex space-x-2">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handlePageChange(currentPage - 1)}
                                disabled={currentPage === 1}
                            >
                                Previous
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handlePageChange(currentPage + 1)}
                                disabled={currentPage >= fileStore.totalPages}
                            >
                                Next
                            </Button>
                        </div>
                    </div>
                )}
            </div>

            {/* Image Viewer */}
            {selectedFile && (
                <ImageViewer
                    isOpen={imageViewerOpen}
                    onClose={() => {
                        setImageViewerOpen(false);
                        setSelectedFile(null);
                        // Reset currentFileUrl in store when closing
                        fileStore.reset();
                    }}
                    fileId={selectedFile.id}
                    fileName={selectedFile.file_name}
                    fileUrl={selectedFile.file_url}
                    fileSize={selectedFile.size}
                    provider={selectedFile.provider}
                />
            )}

            {/* Delete Confirmation Dialog */}
            {fileToDelete && (
                <DeleteConfirmationDialog
                    open={deleteDialogOpen}
                    onClose={() => {
                        setDeleteDialogOpen(false);
                        setFileToDelete(null);
                    }}
                    onConfirm={performDelete}
                    defaultToast={false} // We're using the store's toast
                    message={`This will permanently delete the file "${fileToDelete.name}". 
                    Please note that if this file is being used by other resources in the system (like analytics or alerts), 
                    it may not be possible to delete it due to data integrity requirements.`}
                />
            )}
        </div>
    );
};

export default FileStorageList;
