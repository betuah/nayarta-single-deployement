"use client";

import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import StorageOverview from "./storage-overview";
import FileStorageList from "./file-storage-list";

const FileStorage: React.FC = () => {
    const [activeTab, setActiveTab] = useState("files");

    return (
        <div className="flex w-full p-4 bg-card border">
            <Tabs
                defaultValue="overview"
                value={activeTab}
                onValueChange={setActiveTab}
                className="w-full"
            >
                <TabsList className="grid w-full grid-cols-2 mb-6">
                    <TabsTrigger value="files">Storage List</TabsTrigger>
                    <TabsTrigger value="overview">Usage Chart</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-0">
                    <StorageOverview />
                </TabsContent>

                <TabsContent value="files" className="mt-0">
                    <FileStorageList />
                </TabsContent>
            </Tabs>
        </div>
    );
};

export default FileStorage;
