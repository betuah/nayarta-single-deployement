import React from 'react';
import { useRouter } from 'next/navigation';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Loader2 } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useUserStore } from "@/store/user-store";
import {toast} from "react-toastify";

interface ChangeOrgDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
}

export function ChangeOrgDialog({
                                    open,
                                    onOpenChange,
                                }: ChangeOrgDialogProps) {
    const router = useRouter();
    const { members, selectedGroupMember, switchMemberByIndex } = useUserStore();
    const [isSwitching, setIsSwitching] = React.useState<string | null>(null);

    const handleSwitchOrg = async (memberIndex: number) => {
        // If already switching or clicking the current org, do nothing
        if (isSwitching || isActive(members[memberIndex].member_id)) return;

        setIsSwitching(members[memberIndex].member_id);

        try {
            // Switch organization in store by index
            switchMemberByIndex(memberIndex);

            // Close dialog first
            onOpenChange(false);

            // Refresh the page
            router.refresh();

            // Hard reload if needed
            window.location.reload();
        } catch (error) {
            console.error('Error switching organization:', error);
            toast.error("Failed switching organization. Please try again later.");
        } finally {
            setIsSwitching(null);
        }
    };

    const isActive = (memberId: string) => {
        return selectedGroupMember?.member_id === memberId;
    };

    const getRoleBadgeVariant = (role: string) => {
        switch (role.toLowerCase()) {
            case 'admin':
                return 'success';
            case 'member':
                return 'info';
            default:
                return 'default';
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Switch Organization</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                    {members.map((member, index) => {
                        const active = isActive(member.member_id);
                        const switching = isSwitching === member.member_id;
                        return (
                            <Button
                                key={member.member_id}
                                variant="outline"
                                className={cn(
                                    "w-full justify-start p-3 h-auto",
                                    active && "bg-primary/10 ",
                                    switching && "opacity-80 cursor-not-allowed"
                                )}
                                onClick={() => handleSwitchOrg(index)}
                                disabled={switching || isSwitching !== null}
                            >
                                <div className="flex flex-col w-full space-y-1">
                                    <div className="flex items-center justify-between w-full">
                                        <div className="flex items-center gap-2">
                                            {active ? (
                                                <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                                            ) : switching ? (
                                                <Loader2 className="h-4 w-4 animate-spin shrink-0" />
                                            ) : null}
                                            <span className="font-medium">
                                                {member.group_name}
                                            </span>
                                        </div>
                                        <Badge
                                            variant="soft"
                                            color={getRoleBadgeVariant(member.role)}
                                            className="capitalize shrink-0"
                                        >
                                            {member.role}
                                        </Badge>
                                    </div>
                                    <span className="text-sm font-light">
                                        Member ID: {member.member_id}
                                    </span>
                                </div>
                            </Button>
                        );
                    })}
                </div>
            </DialogContent>
        </Dialog>
    );
}
