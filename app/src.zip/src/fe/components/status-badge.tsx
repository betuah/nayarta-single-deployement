import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { differenceInMinutes, format, parseISO } from 'date-fns';

interface StatusBadgeProps {
    last_checked: string
    check_interval: number
    status: string
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ last_checked, check_interval, status,  }) => {
    const isStatusOutdated = () => {
        if (!last_checked || !check_interval) return false;
        const lastCheckedDate = parseISO(last_checked);
        const minutesSinceLastCheck = differenceInMinutes(new Date(), lastCheckedDate);
        return minutesSinceLastCheck > check_interval;
    };

    const formatDate = (dateString: string) => {
        try {
            return format(parseISO(dateString), 'dd MMM yyyy HH:mm');
        } catch {
            return dateString;
        }
    };

    const outdated = isStatusOutdated();

    return (
        <TooltipProvider>
            <Tooltip>
                <TooltipTrigger asChild>
                    <div className="flex items-center">
                        <Badge
                            // color={status === "online" ? "success" : status === "alert" ? "destructive" : "warning"}
                            color={outdated ? "warning" : status === "online" ? "success" : status === "alert" ? "destructive" : "warning"}
                            className="capitalize"
                        >
                            {outdated ? "Offline" : status}
                        </Badge>
                        {outdated && (
                            <AlertTriangle className="h-4 w-4 ml-2 text-yellow-500" />
                        )}
                    </div>
                </TooltipTrigger>
                <TooltipContent>
                    {outdated
                        ? "Status may be outdated. Last check exceeded the expected interval."
                        : `Last checked: ${formatDate(last_checked || '')}`}
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>
    );
};
