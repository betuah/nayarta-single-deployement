import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useAlertsModuleStore } from "@/store/alerts-module-store";
import { useFileModuleStore } from "@/store/file-module-store";
import NotificationListFilters from "@/components/notification/list/notification-list-filters";
import NotificationListTabs from "@/components/notification/list/notification-list-tabs";
import NotificationListLoadMore from "@/components/notification/list/notification-list-load-more";
import NotificationListVideoDialog from "@/components/notification/list/notification-list-video-dialog";
import {useRouter} from "next/navigation";

const NotificationList: React.FC = () => {
    const [isDialogOpen, setDialogOpen] = useState(false);
    const { isLoading, fetchAlerts, fetchAnalyticsTypes } = useAlertsModuleStore();
    const { isLoading: isFetchingFile, fetchCurrentFile } = useFileModuleStore();
    const router = useRouter()

    useEffect(() => {
        fetchAlerts();
        fetchAnalyticsTypes();
    }, []);

    const handleFetchCurrentFile = async (id: string, typeId: string) => {
        router.push(`file-storage/video/${id}?analytic=${typeId}&player=events`)
    };

    return (
        <>
            {(isLoading || isFetchingFile) && <Progress value={70} color="primary" isInfinite size="xs" />}
            <Card className="w-full border border-default-200 mt-2">
                <CardHeader>
                    <CardTitle>Notification and Alert History</CardTitle>
                    <CardDescription>View and manage past notifications and alerts</CardDescription>
                </CardHeader>
                <CardContent>
                    <NotificationListFilters />
                    <NotificationListTabs handleFetchCurrentFile={handleFetchCurrentFile} />
                    <NotificationListLoadMore />
                </CardContent>
            </Card>
            <NotificationListVideoDialog isOpen={isDialogOpen} onOpenChange={setDialogOpen} />
        </>
    );
};

export default NotificationList;
