'use client';

import React, { useRef, useState, useEffect } from 'react';
import {
    Play,
    Pause,
    Volume2,
    VolumeX,
    SkipBack,
    SkipForward,
    Settings,
    Maximize,
    Loader2
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { cn } from '@/lib/utils';

interface VideoPlayerProps {
    src: string;
    poster?: string;
    className?: string;
    autoPlay?: boolean
}

export default function VideoPlayer({ src, poster, className, autoPlay = true }: VideoPlayerProps) {
    const videoRef = useRef<HTMLVideoElement>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [volume, setVolume] = useState(1);
    const [isMuted, setIsMuted] = useState(false);
    const [showSpeedOptions, setShowSpeedOptions] = useState(false);
    const [playbackSpeed, setPlaybackSpeed] = useState(1);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [showControls, setShowControls] = useState(true);
    const [controlsTimer, setControlsTimer] = useState<NodeJS.Timeout | null>(null);
    const [isBuffering, setIsBuffering] = useState(false);

    // Set up video event listeners
    useEffect(() => {
        const video = videoRef.current;
        if (!video) return;

        const onTimeUpdate = () => {
            setCurrentTime(video.currentTime);
        };

        const onLoadedMetadata = () => {
            setDuration(video.duration);
        };

        const onEnded = () => {
            setIsPlaying(false);
            setShowControls(true);
        };

        const onPlay = () => {
            setIsPlaying(true);
        };

        const onPause = () => {
            setIsPlaying(false);
            setShowControls(true);
        };

        // Buffering event handlers
        const onWaiting = () => {
            setIsBuffering(true);
        };

        const onCanPlay = () => {
            setIsBuffering(false);
        };

        const onPlaying = () => {
            setIsBuffering(false);
        };

        video.addEventListener('timeupdate', onTimeUpdate);
        video.addEventListener('loadedmetadata', onLoadedMetadata);
        video.addEventListener('ended', onEnded);
        video.addEventListener('play', onPlay);
        video.addEventListener('pause', onPause);
        video.addEventListener('waiting', onWaiting);
        video.addEventListener('canplay', onCanPlay);
        video.addEventListener('playing', onPlaying);

        return () => {
            video.removeEventListener('timeupdate', onTimeUpdate);
            video.removeEventListener('loadedmetadata', onLoadedMetadata);
            video.removeEventListener('ended', onEnded);
            video.removeEventListener('play', onPlay);
            video.removeEventListener('pause', onPause);
            video.removeEventListener('waiting', onWaiting);
            video.removeEventListener('canplay', onCanPlay);
            video.removeEventListener('playing', onPlaying);
        };
    }, []);

    // Handle fullscreen changes
    useEffect(() => {
        const handleFullscreenChange = () => {
            setIsFullscreen(!!document.fullscreenElement);
        };

        document.addEventListener('fullscreenchange', handleFullscreenChange);
        return () => {
            document.removeEventListener('fullscreenchange', handleFullscreenChange);
        };
    }, []);

    // Clean up timer on unmount
    useEffect(() => {
        return () => {
            if (controlsTimer) {
                clearTimeout(controlsTimer);
            }
        };
    }, [controlsTimer]);

    // Handle controls based on play state
    useEffect(() => {
        if (isPlaying) {
            const timer = setTimeout(() => {
                setShowControls(false);
            }, 3000);
            setControlsTimer(timer);
        } else {
            setShowControls(true);
        }

        return () => {
            if (controlsTimer) {
                clearTimeout(controlsTimer);
            }
        };
    }, [isPlaying]);

    // Handle mouse movement to show controls
    const handleMouseMove = () => {
        if (!showControls) {
            setShowControls(true);
        }

        if (controlsTimer) {
            clearTimeout(controlsTimer);
            setControlsTimer(null);
        }

        if (isPlaying) {
            const timer = setTimeout(() => {
                setShowControls(false);
            }, 3000);
            setControlsTimer(timer);
        }
    };

    // Play/Pause toggle
    const togglePlay = () => {
        const video = videoRef.current;
        if (!video) return;

        if (isPlaying) {
            video.pause();
        } else {
            video.play();
        }
        // We don't need to set isPlaying directly here
        // as it will be handled by the play/pause event listeners
    };

    // Format time as MM:SS
    const formatTime = (timeInSeconds: number) => {
        const minutes = Math.floor(timeInSeconds / 60);
        const seconds = Math.floor(timeInSeconds % 60);
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };

    // Handle seeking in video
    const handleSeek = (newValue: number[]) => {
        const video = videoRef.current;
        if (!video) return;

        video.currentTime = newValue[0];
        setCurrentTime(newValue[0]);
    };

    // Handle volume change
    const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const video = videoRef.current;
        if (!video) return;

        const newValue = parseFloat(e.target.value);
        setVolume(newValue);
        video.volume = newValue;

        if (newValue === 0) {
            setIsMuted(true);
        } else {
            setIsMuted(false);
        }
    };

    // Toggle mute
    const toggleMute = () => {
        const video = videoRef.current;
        if (!video) return;

        const newMuteState = !isMuted;
        setIsMuted(newMuteState);
        video.muted = newMuteState;
    };

    // Skip backward 10 seconds
    const skipBackward = () => {
        const video = videoRef.current;
        if (!video) return;

        video.currentTime = Math.max(0, video.currentTime - 10);
    };

    // Skip forward 10 seconds
    const skipForward = () => {
        const video = videoRef.current;
        if (!video) return;

        video.currentTime = Math.min(duration, video.currentTime + 10);
    };

    // Change playback speed
    const changePlaybackSpeed = (speed: number) => {
        const video = videoRef.current;
        if (!video) return;

        video.playbackRate = speed;
        setPlaybackSpeed(speed);
        setShowSpeedOptions(false);
    };

    // Toggle fullscreen
    const toggleFullscreen = () => {
        const videoContainer = document.querySelector('.video-container');
        if (!videoContainer) return;

        if (!document.fullscreenElement) {
            videoContainer.requestFullscreen().catch(err => {
                console.error(`Error attempting to enable fullscreen: ${err.message}`);
            });
        } else {
            document.exitFullscreen();
        }
    };

    const speedOptions = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

    return (
        <div
            className={cn("video-container relative w-full rounded-lg overflow-hidden bg-black", className)}
            onMouseMove={handleMouseMove}
        >
            {/* Video element */}
            <video
                ref={videoRef}
                src={src}
                autoPlay={autoPlay}
                poster={poster}
                onClick={togglePlay}
                className="w-full h-full object-contain cursor-pointer"
            />

            {/* Buffering indicator */}
            {isBuffering && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/30 z-10">
                    <div className="flex flex-col items-center gap-2">
                        <Loader2 className="w-12 h-12 text-white animate-spin" />
                        <span className="text-white text-sm font-medium">Loading...</span>
                    </div>
                </div>
            )}

            {/* Controls overlay */}
            <div
                className={cn(
                    "absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent",
                    "transition-opacity duration-300",
                    showControls ? "opacity-100" : "opacity-0 pointer-events-none"
                )}
            >
                {/* Progress bar */}
                <Slider
                    value={[currentTime]}
                    min={0}
                    max={duration || 100}
                    step={0.1}
                    onValueChange={handleSeek}
                    className="mb-4"
                />

                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        {/* Play/Pause button */}
                        <button onClick={togglePlay} className="text-white p-1 hover:bg-white/10 rounded-full">
                            {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                        </button>

                        {/* Volume control */}
                        <div className="flex items-center gap-2">
                            <button
                                onClick={toggleMute}
                                className="text-white p-1 hover:bg-white/10 rounded-full"
                            >
                                {isMuted || volume === 0 ? <VolumeX size={20} /> : <Volume2 size={20} />}
                            </button>

                            {/* volume slider */}
                            <input
                                type="range"
                                min="0"
                                max="1"
                                step="0.01"
                                value={isMuted ? 0 : volume}
                                onChange={handleVolumeChange}
                                className="w-16 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-primary"
                            />
                        </div>

                        {/* Skip backward 10s */}
                        <button onClick={skipBackward} className="text-white p-1 hover:bg-white/10 rounded-full">
                            <SkipBack size={20} />
                        </button>

                        {/* Skip forward 10s */}
                        <button onClick={skipForward} className="text-white p-1 hover:bg-white/10 rounded-full">
                            <SkipForward size={20} />
                        </button>

                        {/* Time display */}
                        <div className="text-white text-sm">
                            {formatTime(currentTime)} / {formatTime(duration)}
                        </div>
                    </div>

                    <div className="flex items-center gap-2">
                        {/* Playback speed */}
                        <div className="relative">
                            <button
                                onClick={() => setShowSpeedOptions(!showSpeedOptions)}
                                className="text-white p-1 hover:bg-white/10 rounded-full flex items-center"
                            >
                                <Settings size={20} />
                                <span className="ml-1 text-xs">{playbackSpeed}x</span>
                            </button>

                            {/* Speed options */}
                            {showSpeedOptions && (
                                <div
                                    className="absolute bottom-full right-0 mb-2 p-2 bg-gray-900/90 rounded-md w-32 z-10"
                                    onMouseLeave={() => setShowSpeedOptions(false)}
                                >
                                    <div className="flex flex-col space-y-1">
                                        {speedOptions.map(speed => (
                                            <button
                                                key={speed}
                                                onClick={() => changePlaybackSpeed(speed)}
                                                className={cn(
                                                    "text-white text-sm py-1 px-2 rounded hover:bg-white/10 text-left",
                                                    playbackSpeed === speed && "bg-white/20"
                                                )}
                                            >
                                                {speed}x
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Fullscreen toggle */}
                        <button onClick={toggleFullscreen} className="text-white p-1 hover:bg-white/10 rounded-full">
                            <Maximize size={20} />
                        </button>
                    </div>
                </div>
            </div>
            {src && videoRef.current?.readyState! < videoRef.current?.HAVE_FUTURE_DATA! && !isBuffering && (
                <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 z-10">
                    <div className="h-96 flex flex-col items-center justify-center text-gray-500">
                        <Loader2 className="h-12 w-12 animate-spin mb-4 text-primary"/>
                        <p>Loading media...</p>
                    </div>
                </div>
            )}
        </div>
    );
}
