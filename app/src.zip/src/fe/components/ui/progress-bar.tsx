import React from 'react';
import { cn } from '@/lib/utils';

interface ProgressBarProps {
    progress: number;
    className?: string;
    showPercentage?: boolean;
    size?: 'sm' | 'md' | 'lg';
    variant?: 'default' | 'success' | 'warning' | 'error';
}

const ProgressBar: React.FC<ProgressBarProps> = ({
                                                     progress,
                                                     className,
                                                     showPercentage = true,
                                                     size = 'md',
                                                     variant = 'default'
                                                 }) => {
    const sizeClasses = {
        sm: 'h-1',
        md: 'h-2',
        lg: 'h-3'
    };

    const variantClasses = {
        default: 'bg-primary',
        success: 'bg-green-500',
        warning: 'bg-yellow-500',
        error: 'bg-red-500'
    };

    const clampedProgress = Math.max(0, Math.min(100, progress));

    return (
        <div className={cn('w-full', className)}>
            <div className={cn(
                'w-full bg-muted rounded-full overflow-hidden',
                sizeClasses[size]
            )}>
                <div
                    className={cn(
                        'h-full transition-all duration-300 ease-out rounded-full',
                        variantClasses[variant]
                    )}
                    style={{ width: `${clampedProgress}%` }}
                />
            </div>
            {showPercentage && (
                <div className="flex justify-between items-center mt-1 text-xs text-muted-foreground">
                    <span>Loading annotations...</span>
                    <span className="font-mono">{clampedProgress}%</span>
                </div>
            )}
        </div>
    );
};

export default ProgressBar;
