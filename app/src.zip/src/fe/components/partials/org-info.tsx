import {useUserStore} from "@/store/user-store";
import {Icon} from "@iconify/react";
import React from "react";
import {useMemberModuleStore} from "@/store/member-module-store";
import {ChangeOrgDialog} from "@/components/org/change-org-dialog";


const OrgInfo: React.FC<{ hide?: boolean }> = ({hide = false}) => {

    const {selectedGroupMember} = useUserStore()
    const {
        showChangeOrgDialog,
        setShowChangeOrgDialog,
    } = useMemberModuleStore();

    return (<>
        {selectedGroupMember && !hide &&
            <div className='flex flex-col m-4 justify-center px-1 py-2 rounded'>
                <div className="flex flex-row items-center space-x-4 justify-between">
                    <div className="bg-primary p-2 rounded-md">
                        <Icon icon="mdi:account-group" className="w-6 h-6 text-white dark:text-black"/>
                    </div>
                    <div className='flex flex-col'>
                        <div className='text-sm font-semibold'>{selectedGroupMember.group_name}</div>
                        <div className='text-[12px]'>Organization</div>
                    </div>
                    <Icon
                        icon="fluent:chevron-up-down-24-filled"
                        className="w-6 h-6 cursor-pointer hover:text-primary"
                        onClick={() => setShowChangeOrgDialog(true)}
                    />
                </div>
            </div>
        }
        <ChangeOrgDialog
            open={showChangeOrgDialog}
            onOpenChange={setShowChangeOrgDialog}
        />
    </>)
}

export default OrgInfo
