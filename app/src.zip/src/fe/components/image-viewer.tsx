"use client"

import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useFileModuleStore } from "@/store/file-module-store";
import { Skeleton } from "@/components/ui/skeleton";
import {formatBytes} from "@/lib/utils/format-utils";

interface ImageViewerProps {
    isOpen: boolean;
    onClose: () => void;
    fileId: string;
    fileName: string;
    fileUrl: string;
    fileSize: number;
    provider: string;
}

const ImageViewer: React.FC<ImageViewerProps> = ({
                                                     isOpen,
                                                     onClose,
                                                     fileId,
                                                     fileName,
                                                     fileUrl,
                                                     fileSize,
                                                     provider
                                                 }) => {
    const { generateDownloadUrlFile, currentFileUrl, isUrlLoading } = useFileModuleStore();
    const [imageUrl, setImageUrl] = useState<string | null>(null);

    // Determine if the file is public or needs a presigned URL
    useEffect(() => {
        if (isOpen) {
            if (fileUrl.includes('/public/')) {
                // Public file - can be displayed directly
                setImageUrl(fileUrl);
            } else {
                // Private file - needs presigned URL
                generateDownloadUrlFile(fileUrl, provider);
            }
        } else {
            // Reset state when closing
            setImageUrl(null);
        }
    }, [isOpen, fileUrl, provider, generateDownloadUrlFile]);

    // Update image URL when presigned URL is ready
    useEffect(() => {
        if (currentFileUrl) {
            setImageUrl(currentFileUrl);
        }
    }, [currentFileUrl]);

    return (
        <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
            <DialogContent className="max-w-4xl w-full">
                <div className="flex justify-between items-center">
                    <DialogTitle className="text-lg font-medium">{fileName}</DialogTitle>
                </div>
                <div className="flex flex-col items-center justify-center">
                    {isUrlLoading ? (
                        <div className="w-full h-[400px] flex items-center justify-center">
                            <Skeleton className="w-full h-full rounded-md" />
                        </div>
                    ) : imageUrl ? (
                        <img
                            src={imageUrl}
                            alt={fileName}
                            className="max-h-[500px] max-w-full object-contain rounded-md"
                        />
                    ) : (
                        <div className="w-full h-[400px] flex items-center justify-center text-muted-foreground">
                            Unable to load image
                        </div>
                    )}
                    <div className="mt-2 text-sm text-muted-foreground w-full">
                        {fileName} • {formatBytes(fileSize)}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default ImageViewer;
