import React, { useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNVRModuleStore } from "@/store/nvr-module-store";
import { useLocationModuleStore } from "@/store/location-module-store";
import { Progress } from "@/components/ui/progress";
import SearchAndFilterBar from "@/components/nvr/list/search-and-filter-bar";
import CardView from "@/components/nvr/list/card-view";
import TableView from "@/components/nvr/list/table-view";
import Pagination from "@/components/nvr/list/pagination";

const NvrList: React.FC = () => {
    const {
        isLoading,
        error,
        activeTab,
        fetchNVRs,
        setActiveTab,
    } = useNVRModuleStore();

    const { fetchLocations } = useLocationModuleStore();

    useEffect(() => {
        fetchNVRs();
        fetchLocations();
    }, []);

    return (
        <>
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}
            <div className="bg-card mt-2 rounded-md p-6">
                <SearchAndFilterBar />

                <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'table' | 'card')} className="p-0 px-1">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="table">
                            Table View
                        </TabsTrigger>
                        <TabsTrigger value="card">
                            List View
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="card" className="py-4">
                        <div className="py-4">
                            <CardView />
                        </div>
                    </TabsContent>

                    <TabsContent value="table" className="py-4">
                        <TableView />
                        <Pagination />
                    </TabsContent>
                </Tabs>

                {error && <div>Error: {error}</div>}
            </div>
        </>
    );
};

export default NvrList;
