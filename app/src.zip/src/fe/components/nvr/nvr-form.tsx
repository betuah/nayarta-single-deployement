import React, {useEffect, useState, useCallback} from 'react';
import {useForm, Controller} from 'react-hook-form';
import {zodResolver} from '@hookform/resolvers/zod';
import * as z from 'zod';
import {ArrowLeft, Save, CheckCircle, XCircle, Loader2, AlertTriangle, Monitor} from 'lucide-react';
import {Label} from "@/components/ui/label";
import {Input} from "@/components/ui/input";
import {Button} from "@/components/ui/button";
import {Card, CardContent} from "@/components/ui/card";
import {Alert, AlertDescription} from "@/components/ui/alert";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {useNVRModuleStore} from '@/store/nvr-module-store';
import {useGroupModuleStore} from '@/store/group-module-store';
import {useLocationModuleStore} from "@/store/location-module-store";
import {Progress} from "@/components/ui/progress";
import {useRouter} from "next/navigation";

const nvrFormSchema = z.object({
    name: z.string().min(1, {message: "Name is required"}),
    hostname: z.string().min(1, {message: "Hostname is required"}),
    port: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
        message: "Port must be a positive number"
    }),
    user_name: z.string().min(1, {message: "Username is required"}),
    password: z.string().min(1, {message: "Password is required"}),
    location_id: z.string().min(1, {message: "Location is required"}),
    check_interval: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
        message: "Check interval must be a positive number"
    }),
    description: z.string().min(1, {message: "Descriptions is required"}),
});

type NvrFormData = z.infer<typeof nvrFormSchema>;

export interface NvrFormProps {
    nvrId?: string;
}

const NvrForm: React.FC<NvrFormProps> = ({nvrId}) => {
    const {
        addNVR,
        updateNVR,
        fetchNVRDetail,
        isLoading,
        formData,
        resetForm,
        nvrDetail,
        isUsernameExist,
        isLoadingCheckUserName
    } = useNVRModuleStore();

    const {
        quotaNvrs,
        isLoadingQuotaNvrs,
        quotaNvrsError,
        fetchQuotaNvrs
    } = useGroupModuleStore();

    const {fetchLocations, locations} = useLocationModuleStore();
    const router = useRouter();

    const [usernameStatus, setUsernameStatus] = useState<'idle' | 'checking' | 'valid' | 'invalid'>('idle');
    const [originalUsername, setOriginalUsername] = useState<string>('');
    const [usernameError, setUsernameError] = useState<string>('');

    const {control, handleSubmit, reset, watch, formState: {errors}} = useForm<NvrFormData>({
        resolver: zodResolver(nvrFormSchema),
        defaultValues: {
            ...formData,
            port: formData.port.toString(),
            check_interval: formData.check_interval.toString(),
        },
    });

    const watchedUsername = watch('user_name');

    // Debounced username validation
    const checkUsername = useCallback(
        async (username: string) => {
            if (!username.trim()) {
                setUsernameStatus('idle');
                setUsernameError('');
                return;
            }

            // If editing and username hasn't changed, it's valid
            if (nvrId && username === originalUsername) {
                setUsernameStatus('valid');
                setUsernameError('');
                return;
            }

            setUsernameStatus('checking');
            setUsernameError('');

            try {
                const exists = await isUsernameExist(username);

                if (exists) {
                    setUsernameStatus('invalid');
                    setUsernameError('Username already exists');
                } else {
                    setUsernameStatus('valid');
                    setUsernameError('');
                }
            } catch (error) {
                setUsernameStatus('invalid');
                setUsernameError('Error checking username');
            }
        },
        [isUsernameExist, nvrId, originalUsername]
    );

    // Debounce username checking
    useEffect(() => {
        const timeoutId = setTimeout(() => {
            if (watchedUsername && watchedUsername.trim()) {
                checkUsername(watchedUsername);
            } else {
                setUsernameStatus('idle');
                setUsernameError('');
            }
        }, 500); // 500ms delay

        return () => clearTimeout(timeoutId);
    }, [watchedUsername, checkUsername]);

    useEffect(() => {
        resetForm();
        // Only fetch quota for add mode
        if (!nvrId) {
            fetchQuotaNvrs();
        }
    }, [nvrId]);

    useEffect(() => {
        fetchLocations();
        if (nvrId) {
            fetchNVRDetail(nvrId);
        } else {
            resetForm();
            setOriginalUsername('');
        }
    }, [nvrId, fetchNVRDetail, resetForm, fetchLocations]);

    useEffect(() => {
        if (nvrDetail) {
            const formValues = {
                name: nvrDetail.name || '',
                hostname: nvrDetail.hostname || '',
                port: nvrDetail.port?.toString() || '',
                user_name: nvrDetail.user_name || '',
                password: '', // Don't populate password for security reasons
                location_id: nvrDetail.location_id || '',
                check_interval: nvrDetail.check_interval?.toString() || '',
                description: nvrDetail.description || '',
            };

            reset(formValues);
            setOriginalUsername(nvrDetail.user_name || '');
            // Reset username status when loading existing data
            setUsernameStatus('idle');
            setUsernameError('');
        }
    }, [nvrDetail, reset]);

    const onSubmit = async (data: NvrFormData) => {
        // Prevent submission if username is invalid
        if (usernameStatus === 'invalid') {
            setUsernameError('Please resolve username issues before submitting');
            return;
        }

        // If username is still being checked, wait for validation
        if (usernameStatus === 'checking') {
            setUsernameError('Please wait for username validation to complete');
            return;
        }

        try {
            const parsedData = {
                ...data,
                port: Number(data.port),
                check_interval: Number(data.check_interval),
            };
            if (nvrId) {
                await updateNVR(nvrId, parsedData);
            } else {
                await addNVR(parsedData);
                // Refresh quota after successful creation
                await fetchQuotaNvrs();
            }
            router.push('/nvr');

        } catch (error) {
            console.error('Error submitting NVR form:', error);
        }
    };

    const getUsernameIcon = () => {
        switch (usernameStatus) {
            case 'checking':
                return <Loader2 className="h-4 w-4 animate-spin text-blue-600" />;
            case 'valid':
                return <CheckCircle className="h-4 w-4 text-green-600" />;
            case 'invalid':
                return <XCircle className="h-4 w-4 text-red-600" />;
            default:
                return null;
        }
    };

    // Check if quota is exceeded (only for add mode)
    const isQuotaExceeded = !nvrId && quotaNvrs && quotaNvrs.remaining !== undefined && quotaNvrs.remaining <= 0;
    const hasQuotaData = quotaNvrs && quotaNvrs.used !== undefined;
    const shouldShowQuota = !nvrId && hasQuotaData;

    const isSubmitDisabled = isLoading || usernameStatus === 'checking' || usernameStatus === 'invalid';

    // Loading state for quota (only for add mode)
    if (!nvrId && isLoadingQuotaNvrs) {
        return (
            <div>
                <Card className="p-6">
                    <CardContent>
                        <div className="flex items-center justify-center py-8">
                            <div className="animate-spin rounded-full h-8 w-8 border-2 border-default-300 border-t-gray-900"></div>
                            <span className="ml-2">Loading quota information...</span>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    // Error state for quota (only for add mode)
    if (!nvrId && quotaNvrsError) {
        return (
            <div>
                <Card className="p-6">
                    <CardContent>
                        <Alert>
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>
                                Failed to load quota information: {quotaNvrsError}
                            </AlertDescription>
                        </Alert>
                        <Button
                            onClick={() => fetchQuotaNvrs()}
                            className="mt-4"
                            variant="outline"
                        >
                            Retry
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <>
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}
            <div className="bg-card border-b border-default-200 mt-2 rounded-none rounded-t-md p-6">
                {/* Quota Information - Only show for add mode */}
                {shouldShowQuota && (
                    <div className="mb-6 p-4 bg-default-50 border border-default-200 rounded-lg">
                        <div className="flex items-center gap-2 text-sm font-medium text-default-700 mb-2">
                            <Monitor className="h-4 w-4" />
                            NVR Quota Status
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                                <span className="text-default-600">Used:</span>
                                <span className="ml-1 font-medium">{quotaNvrs.used || 0}</span>
                            </div>
                            <div>
                                <span className="text-default-600">Max:</span>
                                <span className="ml-1 font-medium">{quotaNvrs.max || 0}</span>
                            </div>
                            <div>
                                <span className="text-default-600">Remaining:</span>
                                <span className={`ml-1 font-medium ${isQuotaExceeded ? 'text-red-600' : 'text-green-600'}`}>
                                    {quotaNvrs.remaining || 0}
                                </span>
                            </div>
                            <div>
                                <span className="text-default-600">Usage:</span>
                                <span className="ml-1 font-medium">{quotaNvrs.percentage || 0}%</span>
                            </div>
                        </div>
                    </div>
                )}

                {/* Quota Exceeded Alert - Only show for add mode */}
                {isQuotaExceeded && (
                    <Alert className="mb-6 border-red-200 bg-red-50">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <AlertDescription className="text-red-800">
                            <strong>NVR quota exceeded!</strong> You have reached the maximum number of NVRs
                            ({quotaNvrs.max}) for your organization. Please contact your administrator to
                            increase the quota or remove some NVRs before adding new ones.
                        </AlertDescription>
                    </Alert>
                )}

                {/* Form Content - Hide if quota is exceeded for add mode */}
                {!(!nvrId && isQuotaExceeded) && (
                    <form onSubmit={handleSubmit(onSubmit)} className="">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="mb-4">
                                <Label htmlFor="name" className="mb-2">Name <span className="text-warning">*</span></Label>
                                <Controller
                                    name="name"
                                    control={control}
                                    disabled={isLoading}
                                    render={({field}) => (
                                        <Input
                                            {...field}
                                            id="name"
                                            type="text"
                                            size='lg'
                                            placeholder="NVR name"
                                        />
                                    )}
                                />
                                {errors.name && <p className="text-red-500">{errors.name.message}</p>}
                            </div>
                            <div className="mb-4">
                                <Label htmlFor="hostname" className="mb-2">Hostname <span className="text-warning">*</span></Label>
                                <Controller
                                    name="hostname"
                                    control={control}
                                    disabled={isLoading}
                                    render={({field}) => (
                                        <Input
                                            {...field}
                                            id="hostname"
                                            type="text"
                                            size='lg'
                                            placeholder="Example: 192.168.1.100"
                                        />
                                    )}
                                />
                                {errors.hostname && <p className="text-red-500">{errors.hostname.message}</p>}
                            </div>
                            <div className="mb-4">
                                <Label htmlFor="port" className="mb-2">Port <span className="text-warning">*</span></Label>
                                <Controller
                                    name="port"
                                    control={control}
                                    disabled={isLoading}
                                    render={({field}) => (
                                        <Input
                                            {...field}
                                            id="port"
                                            type="number"
                                            size='lg'
                                            placeholder="Example: 8000"
                                        />
                                    )}
                                />
                                {errors.port && <p className="text-red-500">{errors.port.message}</p>}
                            </div>
                            <div className="mb-4">
                                <Label htmlFor="user_name" className="mb-2">Username <span className="text-warning">*</span></Label>
                                <div className="relative">
                                    <Controller
                                        name="user_name"
                                        control={control}
                                        disabled={isLoading}
                                        render={({field}) => (
                                            <Input
                                                {...field}
                                                id="user_name"
                                                type="text"
                                                size='lg'
                                                placeholder="Username for NVR access"
                                                className={`pr-10 ${
                                                    usernameStatus === 'invalid' ? 'border-red-500' :
                                                        usernameStatus === 'valid' ? 'border-green-500' : ''
                                                }`}
                                            />
                                        )}
                                    />
                                    <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                                        {getUsernameIcon()}
                                    </div>
                                </div>
                                {errors.user_name && <p className="text-red-500">{errors.user_name.message}</p>}
                                {usernameError && <p className="text-red-500">{usernameError}</p>}
                                {usernameStatus === 'valid' && !usernameError && (
                                    <p className="text-green-600 text-sm">Username is available</p>
                                )}
                            </div>
                            <div className="mb-4">
                                <Label htmlFor="password" className="mb-2">Password <span className="text-warning">*</span></Label>
                                <Controller
                                    name="password"
                                    control={control}
                                    disabled={isLoading}
                                    render={({field}) => (
                                        <Input
                                            {...field}
                                            id="password"
                                            type="password"
                                            size='lg'
                                            placeholder="Password for NVR access"
                                        />
                                    )}
                                />
                                {errors.password && <p className="text-red-500">{errors.password.message}</p>}
                            </div>
                            <div className="mb-4">
                                <Label htmlFor="location_id" className="mb-2">Location <span
                                    className="text-warning">*</span></Label>
                                <Controller
                                    name="location_id"
                                    control={control}
                                    disabled={isLoading}
                                    render={({field}) => (
                                        <Select onValueChange={field.onChange} value={field.value}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Location"/>
                                            </SelectTrigger>
                                            <SelectContent>
                                                {locations.map((location) => (
                                                    <SelectItem key={location.id} value={location.id || ''}>
                                                        {location.location_name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    )}
                                />
                                {errors.location_id && <p className="text-red-500">{errors.location_id.message}</p>}
                            </div>
                            <div className="mb-4 hidden">
                                <Label htmlFor="check_interval" className="mb-2">Check Interval (minutes) <span
                                    className="text-warning">*</span></Label>
                                <Controller
                                    name="check_interval"
                                    control={control}
                                    disabled={isLoading}
                                    render={({field}) => (
                                        <Input
                                            {...field}
                                            id="check_interval"
                                            type="number"
                                            size='lg'
                                            placeholder="Example: 300"
                                        />
                                    )}
                                />
                                {errors.check_interval && <p className="text-red-500">{errors.check_interval.message}</p>}
                            </div>
                            <div className="mb-4">
                                <Label htmlFor="description" className="mb-2">Description <span
                                    className="text-warning">*</span></Label>

                                <Controller
                                    name="description"
                                    control={control}
                                    disabled={isLoading}
                                    render={({field}) => (
                                        <Input
                                            {...field}
                                            id="description"
                                            type="text"
                                            size='lg'
                                            placeholder="NVR Description"
                                        />
                                    )}
                                />
                                {errors.description && <p className="text-red-500">{errors.description.message}</p>}
                            </div>
                        </div>
                        <div className="flex items-center justify-end mt-6">
                            <Button
                                type="submit"
                                disabled={isSubmitDisabled}
                                isLoading={isLoading}
                            >
                                <Save className="mr-2" size={18}/>
                                {nvrId ? 'Update NVR' : 'Add NVR'}
                            </Button>
                        </div>
                    </form>
                )}
            </div>
        </>
    );
}

export default NvrForm;
