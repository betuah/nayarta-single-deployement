import React, {useEffect} from "react";
import NvrCameraList from "@/components/nvr/list/nvr-camera-list";
import {useNVRModuleStore} from "@/store/nvr-module-store";
import {Progress} from "@/components/ui/progress";
import NvrInfoList from "@/components/nvr/details/nvr-info-list";
import NvrInfoHeader from "@/components/nvr/details/nvr-info-header";
import NvrInfoActions from "@/components/nvr/details/nvr-info-actions";

export interface NvrDetailsProps {
    nvrId: string;
}


const NvrDetails: React.FC<NvrDetailsProps> = ({nvrId}) => {
    const {nvrDetail, isLoading, error, fetchNVRDetail, reset: resetNvr} = useNVRModuleStore();

    useEffect(() => {
        resetNvr()
    }, [])

    useEffect(() => {
        fetchNVRDetail(nvrId);
    }, [nvrId, fetchNVRDetail]);

    if (error) return <div>Error: {error}</div>;


    return (
        <>
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}
            {!nvrDetail ? <div className="bg-card mt-2 rounded-md p-6">No NVR details found</div> :
                <div className="bg-card mt-2 rounded-md p-6">
                    <NvrInfoHeader/>
                    <NvrInfoList/>
                    <NvrInfoActions/>
                    {nvrDetail.cctvs && <NvrCameraList cameras={nvrDetail.cctvs}/>}
                </div>
            }
        </>
    );
}
export default NvrDetails;
