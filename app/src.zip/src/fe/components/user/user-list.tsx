"use client"
import React from "react";
import {Card} from "@/components/ui/card";
import Pagination from "./list/pagination";
import SearchBar from "@/components/user/list/search-bar";
import FilterOptions from "@/components/user/list/filter-options";
import UserTable from "@/components/user/list/user-table";
import {useUserModuleStore} from "@/store/user-module-store";
import {Progress} from "@/components/ui/progress";

const UserList: React.FC = () => {
    const {fetchMembers, totalMembers, currentPage, pageSize, isLoading} = useUserModuleStore();

    React.useEffect(() => {
        fetchMembers();
    }, [fetchMembers]);

    return (
        <>
            {isLoading &&
                <Progress value={70} color="primary" isInfinite size="xs"/>
            }
            <Card className="mt-2">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-6 gap-y-4 px-4 py-4">
                    <SearchBar/>
                    <FilterOptions/>
                </div>
                <UserTable/>
                <Pagination
                    currentPage={currentPage}
                    totalItems={totalMembers}
                    pageSize={pageSize}
                />
            </Card>
        </>
    );
};

export default UserList;
