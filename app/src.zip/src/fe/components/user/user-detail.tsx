import React, {useEffect} from 'react';
import {Tabs, TabsContent, TabsList, TabsTrigger} from '@/components/ui/tabs';
import {Progress} from "@/components/ui/progress";
import {useProfileModuleStore} from "@/store/profile-module-store";
import {useFileUploadStore} from "@/store/file-upload-store";
import {UserDetailProfile} from "@/components/user/detail/user-detail-profile";
import {UserDetailPassword} from "@/components/user/detail/user-detail-password";
import MembershipList from "@/components/membership-list";

export function UserDetail() {
    const {isLoading, fetchUserDetails} = useProfileModuleStore();
    const {isUploading} = useFileUploadStore();


    useEffect(() => {
        fetchUserDetails();
    }, []);

    return (
        <>
            {(isLoading || isUploading) && <Progress value={70} color="primary" isInfinite size="xs"/>}
            <div className="bg-card rounded-md p-6 mt-2 space-y-4">
                <Tabs defaultValue="profile">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="profile">Profile</TabsTrigger>
                        <TabsTrigger value="password">Change Password</TabsTrigger>
                    </TabsList>
                    <TabsContent value="profile">
                        <UserDetailProfile/>
                    </TabsContent>
                    <TabsContent value="password">
                        <UserDetailPassword/>
                    </TabsContent>
                </Tabs>
                <MembershipList/>
            </div>
        </>
    );
}

export default UserDetail;
