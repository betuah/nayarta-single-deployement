import React, {useState, useEffect} from "react";
import {useUserModuleStore} from "@/store/user-module-store";
import {useGroupModuleStore} from "@/store/group-module-store";
import {useForm, Controller} from "react-hook-form";
import {zodResolver} from "@hookform/resolvers/zod";
import * as z from "zod";
import {DtoCreateMemberDTO, DtoRegisterRequest} from "@/lib/api/data-contracts";
import {Button} from "@/components/ui/button";
import {Card, CardContent, CardHeader, CardTitle} from "@/components/ui/card";
import {Input} from "@/components/ui/input";
import {Label} from "@/components/ui/label";
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from "@/components/ui/select";
import {RadioGroup, RadioGroupItem} from "@/components/ui/radio-group";
import {useRouter} from "next/navigation";
import {useUserStore} from "@/store/user-store";
import {Eye, UserPlus, AlertTriangle, Users} from "lucide-react";
import {Alert, AlertDescription} from "@/components/ui/alert";

const existingUserSchema = z.object({
    email: z.string().email("Invalid email address"),
    role: z.enum(["admin", "member"], {
        required_error: "Please select a role",
    }),
});

const newUserSchema = z.object({
    full_name: z.string().min(1, "Full name is required"),
    email: z.string().email("Invalid email address"),
    role: z.enum(["admin", "member"], {
        required_error: "Please select a role",
    }),
    password: z.string().min(6, "Password must be at least 6 characters long"),
});

type ExistingUserFormData = z.infer<typeof existingUserSchema>;
type NewUserFormData = z.infer<typeof newUserSchema>;

const UserAdd: React.FC = () => {
    const {handleCreateUser, isLoading} = useUserModuleStore();
    const {
        quotaMembers,
        isLoadingQuotaMembers,
        quotaMembersError,
        fetchQuotaMembers
    } = useGroupModuleStore();

    const [userType, setUserType] = useState<'existing' | 'new'>('existing');
    const router = useRouter();

    const {
        control: controlExisting,
        register: registerExisting,
        handleSubmit: handleSubmitExisting,
        reset: resetExisting,
        formState: {errors: errorsExisting}
    } = useForm<ExistingUserFormData>({
        resolver: zodResolver(existingUserSchema),
    });

    const {
        control: controlNew,
        register: registerNew,
        handleSubmit: handleSubmitNew,
        reset: resetNew,
        formState: {errors: errorsNew}
    } = useForm<NewUserFormData>({
        resolver: zodResolver(newUserSchema),
    });

    // Fetch quota on component mount
    useEffect(() => {
        fetchQuotaMembers();
    }, [fetchQuotaMembers]);

    const handleUserTypeChange = (value: 'existing' | 'new') => {
        // Clear both forms when switching
        resetExisting();
        resetNew();
        setUserType(value);
    };

    const {user} = useUserStore.getState();

    const onSubmitExisting = async (data: ExistingUserFormData) => {
        try {
            // @ts-ignore
            const isCreated = await handleCreateUser(data as DtoCreateMemberDTO);
            if (isCreated) {
                // Refresh quota after successful creation
                await fetchQuotaMembers();
                router.push("/users");
            }
        } catch (e) {
            // Handle error
        }
    };

    const onSubmitNew = async (data: NewUserFormData) => {
        try {
            const isCreated = await handleCreateUser(data as DtoCreateMemberDTO & DtoRegisterRequest);
            if (isCreated) {
                // Refresh quota after successful creation
                await fetchQuotaMembers();
                router.push("/users");
            }
        } catch (e) {
            // Handle error
        }
    };

    // Check if quota is exceeded
    const isQuotaExceeded = quotaMembers && quotaMembers.remaining !== undefined && quotaMembers.remaining <= 0;
    const hasQuotaData = quotaMembers && quotaMembers.used !== undefined;

    if (isLoadingQuotaMembers) {
        return (
            <div>
                <Card className="p-6">
                    <CardContent>
                        <div className="flex items-center justify-center py-8">
                            <div
                                className="animate-spin rounded-full h-8 w-8 border-2 border-default-300 border-t-gray-900"></div>
                            <span className="ml-2">Loading quota information...</span>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    if (quotaMembersError) {
        return (
            <div>
                <Card className="p-6">
                    <CardContent>
                        <Alert>
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>
                                Failed to load quota information: {quotaMembersError}
                            </AlertDescription>
                        </Alert>
                        <Button
                            onClick={() => fetchQuotaMembers()}
                            className="mt-4"
                            variant="outline"
                        >
                            Retry
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div>
            <Card className="p-6">
                <CardHeader className="px-0 pt-0">
                    <CardTitle className="flex items-center gap-2">
                        <UserPlus className="h-5 w-5" />
                        Add User
                    </CardTitle>
                </CardHeader>
                <CardContent className="px-0">
                    {/* Quota Information */}
                    {hasQuotaData && (
                        <div className="mb-6 p-4 bg-default-50 border border-default-200 rounded-lg">
                            <div className="flex items-center gap-2 text-sm font-medium text-default-700 mb-2">
                                <Users className="h-4 w-4" />
                                Member Quota Status
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                                <div>
                                    <span className="text-default-600">Used:</span>
                                    <span className="ml-1 font-medium">{quotaMembers.used || 0}</span>
                                </div>
                                <div>
                                    <span className="text-default-600">Max:</span>
                                    <span className="ml-1 font-medium">{quotaMembers.max || 0}</span>
                                </div>
                                <div>
                                    <span className="text-default-600">Remaining:</span>
                                    <span className={`ml-1 font-medium ${isQuotaExceeded ? 'text-red-600' : 'text-green-600'}`}>
                                        {quotaMembers.remaining || 0}
                                    </span>
                                </div>
                                <div>
                                    <span className="text-default-600">Usage:</span>
                                    <span className="ml-1 font-medium">{quotaMembers.percentage?.toFixed(2) || 0}%</span>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Quota Exceeded Alert */}
                    {isQuotaExceeded && (
                        <Alert className="mb-6 border-red-200 bg-red-50">
                            <AlertTriangle className="h-4 w-4 text-red-600" />
                            <AlertDescription className="text-red-800">
                                <strong>Member quota exceeded!</strong> You have reached the maximum number of members
                                ({quotaMembers.max}) for your organization. Please contact your administrator to
                                increase the quota or remove some members before adding new ones.
                            </AlertDescription>
                        </Alert>
                    )}

                    {/* Form Content - Only show if quota allows */}
                    {!isQuotaExceeded && (
                        <>
                            <div className="mb-6">
                                <Label className="mb-2">User Type</Label>
                                <RadioGroup value={userType} onValueChange={handleUserTypeChange}
                                            className="flex space-x-4">
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="existing" id="existing"/>
                                        <Label htmlFor="existing">Existing User</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="new" id="new"/>
                                        <Label htmlFor="new">New User</Label>
                                    </div>
                                </RadioGroup>
                            </div>

                            {userType === 'existing' && (
                                <div>
                                    <div className="mb-4 p-3 bg-blue-100 border border-blue-200 rounded-lg">
                                        <div className="flex items-center gap-2 text-sm text-blue-800">
                                            <UserPlus className="h-4 w-4"/>
                                            <span className="font-medium">Adding Existing User</span>
                                        </div>
                                        <p className="text-xs text-blue-600 mt-1">
                                            <div>- Make sure the user already exists with the target email</div>
                                            <div>- Make sure the user with the target email has not joined this organization</div>
                                            - Make sure you are not adding/inviting yourself
                                        </p>
                                    </div>
                                    <form onSubmit={handleSubmitExisting(onSubmitExisting)}>
                                        <div className="space-y-4">
                                            <div>
                                                <Label htmlFor="existing-email">Email</Label>
                                                <Input id="existing-email" autoComplete="off" {...registerExisting("email")} />
                                                {errorsExisting.email &&
                                                    <p className="text-red-500">{errorsExisting.email.message}</p>}
                                            </div>
                                            <div>
                                                <Label htmlFor="existing-role">Role</Label>
                                                <Controller
                                                    name="role"
                                                    control={controlExisting}
                                                    render={({field}) => (
                                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                            <SelectTrigger>
                                                                <SelectValue placeholder="Select a role"/>
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="admin">Admin</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    )}
                                                />
                                                {errorsExisting.role &&
                                                    <p className="text-red-500">{errorsExisting.role.message}</p>}
                                            </div>
                                            <Button type="submit" disabled={isLoading} isLoading={isLoading}>
                                                Add Existing User
                                            </Button>
                                        </div>
                                    </form>
                                </div>
                            )}

                            {userType === 'new' && (
                                <div>
                                    <div className="mb-4 p-3 bg-blue-100 border border-blue-200 rounded-lg">
                                        <div className="flex items-center gap-2 text-sm text-blue-800">
                                            <UserPlus className="h-4 w-4"/>
                                            <span className="font-medium">Adding New User</span>
                                        </div>
                                        <p className="text-xs text-blue-600 mt-1">
                                            <div>- Make sure the user not exists with the target email</div>
                                            - Make sure you are not adding your current user email
                                        </p>
                                    </div>
                                    <form onSubmit={handleSubmitNew(onSubmitNew)}>
                                        <div className="space-y-4">
                                            <div>
                                                <Label htmlFor="new-full-name">Full Name</Label>
                                                <Input id="new-full-name" autoComplete="off" {...registerNew("full_name")} />
                                                {errorsNew.full_name &&
                                                    <p className="text-red-500">{errorsNew.full_name.message}</p>}
                                            </div>
                                            <div>
                                                <Label htmlFor="new-email">Email</Label>
                                                <Input id="new-email" autoComplete="off" {...registerNew("email")} />
                                                {errorsNew.email && <p className="text-red-500">{errorsNew.email.message}</p>}
                                            </div>
                                            <div>
                                                <Label htmlFor="new-role">Role</Label>
                                                <Controller
                                                    name="role"
                                                    control={controlNew}
                                                    render={({field}) => (
                                                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                            <SelectTrigger>
                                                                <SelectValue placeholder="Select a role"/>
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="admin">Admin</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    )}
                                                />
                                                {errorsNew.role && <p className="text-red-500">{errorsNew.role.message}</p>}
                                            </div>
                                            <div>
                                                <Label htmlFor="new-password">Password</Label>
                                                <Input id="new-password" type="password" {...registerNew("password")} />
                                                {errorsNew.password &&
                                                    <p className="text-red-500">{errorsNew.password.message}</p>}
                                            </div>
                                            <Button type="submit" disabled={isLoading} isLoading={isLoading}>
                                                Create New User
                                            </Button>
                                        </div>
                                    </form>
                                </div>
                            )}
                        </>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default UserAdd;
