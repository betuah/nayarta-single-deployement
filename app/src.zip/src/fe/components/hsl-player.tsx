import React, { useEffect, useRef, forwardRef, useImperativeHandle, useState, memo } from 'react';
import Hls from 'hls.js';
import { Loader2 } from 'lucide-react';
import { CircularProgress } from "@/components/ui/progress";

interface HlsPlayerProps {
    src: string;
    autoPlay?: boolean;
    controls?: boolean;
    width?: string | number;
    height?: string | number;
    className?: string;
    onError?: (error: Error) => void;
    authToken?: string;
    host?: string
    muted?: boolean
}

export interface HlsPlayerRef {
    video: HTMLVideoElement | null;
    hls: Hls | null;
}

const HlsPlayerCore = forwardRef<HlsPlayerRef, HlsPlayerProps>(
    ({ src, autoPlay = false, controls = true, width = '100%', height = 'auto', className = '', onError, authToken, host, muted = false }, ref) => {
        const videoRef = useRef<HTMLVideoElement>(null);
        const hlsRef = useRef<Hls | null>(null);
        const [isLoading, setIsLoading] = useState(true);
        const loadTimeoutRef = useRef<NodeJS.Timeout>();

        // Store the initial source to prevent unnecessary reloads
        const initialSourceRef = useRef(src);
        const authTokenRef = useRef(authToken);

        useImperativeHandle(ref, () => ({
            video: videoRef.current,
            hls: hlsRef.current,
        }), []);

        useEffect(() => {
            const video = videoRef.current;
            if (!video) return;

            // Only initialize if source has changed or auth token has changed
            if (initialSourceRef.current !== src || authTokenRef.current !== authToken) {
                initialSourceRef.current = src;
                authTokenRef.current = authToken;
            } else if (hlsRef.current) {
                // If HLS instance exists and source/token haven't changed, don't reinitialize
                return;
            }

            setIsLoading(true);

            const setupHls = () => {
                if (hlsRef.current) {
                    hlsRef.current.destroy();
                }

                const hls = new Hls({
                    enableWorker: true,
                    lowLatencyMode: true,
                    manifestLoadingTimeOut: 10000,
                    manifestLoadingMaxRetry: 3,
                    levelLoadingTimeOut: 10000,
                    fragLoadingTimeOut: 20000,
                    //@ts-ignore
                    xhrSetup: (xhr, url) => {
                        // Parse the URL to get its components
                        try {
                            const parsedUrl = new URL(url);

                            // Get existing query parameters
                            const params = new URLSearchParams(parsedUrl.search);

                            // Add the JWT token if it's not already there
                            if (!params.has('jwt') && authToken) {
                                params.set('jwt', authToken);
                            }

                            // Replace the URL's search part with our updated params
                            parsedUrl.search = params.toString();

                            // Use the modified URL for the request
                            xhr.open('GET', parsedUrl.toString(), true);
                        } catch (e) {
                            console.error('Error setting up XHR with JWT token:', e);
                        }

                        return xhr;
                    }
                });

                hlsRef.current = hls;

                loadTimeoutRef.current = setTimeout(() => {
                    if (isLoading) {
                        onError?.(new Error('Stream loading timeout: Source might be unavailable'));
                        setIsLoading(false);
                    }
                }, 15000);

                hls.on(Hls.Events.MANIFEST_LOADING, () => {
                    setIsLoading(true);
                });

                hls.on(Hls.Events.MANIFEST_LOADED, () => {
                    setIsLoading(false);
                    if (loadTimeoutRef.current) {
                        clearTimeout(loadTimeoutRef.current);
                    }
                });

                hls.on(Hls.Events.ERROR, (_, data) => {
                    if (loadTimeoutRef.current) {
                        clearTimeout(loadTimeoutRef.current);
                    }

                    if (data.fatal) {
                        setIsLoading(false);
                        switch (data.type) {
                            case Hls.ErrorTypes.NETWORK_ERROR:
                                // Check for authentication errors (401/403)
                                if (data.response && (data.response.code === 401 || data.response.code === 403)) {
                                    onError?.(new Error('Authentication error: Invalid or expired token'));
                                } else if (data.details === Hls.ErrorDetails.MANIFEST_LOAD_ERROR ||
                                    data.details === Hls.ErrorDetails.MANIFEST_LOAD_TIMEOUT) {
                                    onError?.(new Error('Failed to load stream: Source might be unavailable'));
                                } else {
                                    hls.startLoad();
                                    onError?.(new Error('Network error: Attempting to recover'));
                                }
                                break;
                            case Hls.ErrorTypes.MEDIA_ERROR:
                                hls.recoverMediaError();
                                onError?.(new Error('Media error: Attempting to recover'));
                                break;
                            default:
                                hls.destroy();
                                onError?.(new Error(`Fatal error: ${data.details}`));
                                break;
                        }
                    }
                });

                try {
                    hls.loadSource(src);
                    hls.attachMedia(video);
                    hls.on(Hls.Events.MANIFEST_PARSED, () => {
                        setIsLoading(false);
                        if (loadTimeoutRef.current) {
                            clearTimeout(loadTimeoutRef.current);
                        }
                        if (autoPlay) {
                            video.play().catch((error) => {
                                onError?.(new Error(`Autoplay failed: ${error.message}`));
                            });
                        }
                    });
                } catch (error) {
                    setIsLoading(false);
                    onError?.(new Error('Failed to initialize stream'));
                }
            };

            if (Hls.isSupported()) {
                setupHls();
            } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
                try {
                    // For Safari, which has native HLS support
                    // Note: Safari doesn't support custom headers via HTML5 video API
                    // For proper auth, you might need a proxy or adaptable backend
                    video.src = src;
                    video.addEventListener('loadstart', () => setIsLoading(true));
                    video.addEventListener('loadeddata', () => setIsLoading(false));
                    video.addEventListener('error', (e) => {
                        setIsLoading(false);
                        onError?.(new Error(`Video error: ${video.error?.message || 'Unknown error'}`));
                    });
                } catch (error) {
                    setIsLoading(false);
                    onError?.(new Error('Failed to load video in Safari'));
                }
            } else {
                setIsLoading(false);
                onError?.(new Error('HLS is not supported in this browser'));
            }

            return () => {
                if (loadTimeoutRef.current) {
                    clearTimeout(loadTimeoutRef.current);
                }
            };
        }, [src, autoPlay, onError, authToken]);

        // Cleanup on unmount
        useEffect(() => {
            return () => {
                if (hlsRef.current) {
                    hlsRef.current.destroy();
                    hlsRef.current = null;
                }
                if (loadTimeoutRef.current) {
                    clearTimeout(loadTimeoutRef.current);
                }
            };
        }, []);

        return (
            <div className="relative w-full h-full">
                <video
                    ref={videoRef}
                    className={`${className} ${isLoading ? 'opacity-0' : 'opacity-100'} transition-opacity duration-300`}
                    controls={controls}
                    style={{ width, height }}
                    playsInline
                    muted={muted}
                />
                {isLoading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black rounded-md bg-opacity-50">
                        <CircularProgress value={50} color="primary" loading />
                    </div>
                )}
            </div>
        );
    }
);

HlsPlayerCore.displayName = 'HlsPlayerCore';

export const HlsPlayer = memo(HlsPlayerCore);

export default HlsPlayer;
