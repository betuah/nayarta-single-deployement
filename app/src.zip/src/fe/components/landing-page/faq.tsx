import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from "@/components/ui/accordion";
import Link from "next/link";

const Faq = () => {

    return (
        <section className="py-16 2xl:py-[120px] bg-default-100">
            <div className="container">

                <div className="max-w-[670px] mx-auto mb-14">
                    <h2 className="text-center text-xl xl:text-3xl xl:leading-[46px] font-semibold text-default-900 mb-3">
                        <span className="text-primary">FAQs</span>
                    </h2>
                    <p className="text-base xl:leading-7 text-center text-default-700 ">
                        <strong> Lorem Ipsum?</strong> Cras vel volutpat urna, hendrerit porttitor odio. Integer et
                        posuere sapien. Orci varius natoque penatibus et magnis dis parturient montes, nascetur
                        ridiculus mus. Mauris lacinia id ligula sit amet gravida. Mauris sed faucibus odio.
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-12 gap-y-6">
                    <div>
                        <Accordion type="single" collapsible className="space-y-6">
                            {
                                [1, 2, 3, 4, 5].map(n => {
                                    return (
                                        <AccordionItem
                                            key={n}
                                            value={`item-${n}`}
                                            className="dark:bg-secondary"
                                        >
                                            <AccordionTrigger
                                                className="text-base xl:text-lg text-left font-medium text-default-900">
                                                Lorem Ipsum {n} ?
                                            </AccordionTrigger>
                                            <AccordionContent
                                                className="text-sm xl:text-base text-default-700 dark:text-white">
                                                A <Link href="#"
                                                        target="_blank" className="text-primary">Lorem Ipsum</Link> is
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non urna
                                                augue. Maecenas justo urna, tempus at ultrices at, rutrum sed tellus.
                                                Morbi in luctus sapien. Nunc a metus in tellus aliquam dapibus.
                                            </AccordionContent>
                                        </AccordionItem>
                                    )
                                })
                            }

                        </Accordion>
                    </div>
                    <div>
                        <Accordion type="single" collapsible className="space-y-6">
                            {
                                [1, 2, 3, 4,].map(n => {
                                    return (
                                        <AccordionItem
                                            key={n}
                                            value={`item-${n}`}
                                            className="dark:bg-secondary"
                                        >
                                            <AccordionTrigger
                                                className="text-base xl:text-lg text-left font-medium text-default-900">
                                                Lorem Ipsum {n+5} ?
                                            </AccordionTrigger>
                                            <AccordionContent
                                                className="text-sm xl:text-base text-default-700 dark:text-white">
                                                A <Link href="#"
                                                        target="_blank" className="text-primary">Lorem Ipsum</Link> is
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non urna
                                                augue. Maecenas justo urna, tempus at ultrices at, rutrum sed tellus.
                                                Morbi in luctus sapien. Nunc a metus in tellus aliquam dapibus.
                                            </AccordionContent>
                                        </AccordionItem>
                                    )
                                })
                            }

                        </Accordion>
                    </div>
                </div>

            </div>
        </section>
    );
};

export default Faq;
