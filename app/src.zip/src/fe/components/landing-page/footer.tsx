"use client"
import Image from "next/image";
import Link from "next/link";
import {SiteLogo} from "@/components/svg";
import {Button} from "@/components/ui/button";
import footerImage from "@/public/images/landing-page/footer.png"
import facebook from "@/public/images/social/facebook-1.png"
import dribble from "@/public/images/social/dribble-1.png"
import linkedin from "@/public/images/social/linkedin-1.png"
import github from "@/public/images/social/github-1.png"
import behance from "@/public/images/social/behance-1.png"
import twitter from "@/public/images/social/twitter-1.png"
import youtube from "@/public/images/social/youtube.png"

const Footer = () => {

    return (
        <footer
            className=" bg-cover bg-center bg-no-repeat relative before:absolute before:top-0 before:left-0 before:w-full before:h-full before:bg-default-900/90 dark:before:bg-default-100"
        >
            <div className="py-16 2xl:py-[120px]">
                <div className="max-w-[700px] mx-auto flex flex-col items-center relative">
                    <Link
                        href="/"
                        className="inline-flex items-center gap-4 text-primary-foreground"
                    >
                        <SiteLogo className="w-[50px] h-[52px]"/>
                        <span className="text-3xl font-semibold">VMS Web</span>
                    </Link>
                    <p className="text-base leading-7 text-default-200 dark:text-default-600 text-center mt-3">
                        Duis dapibus vehicula interdum. Nunc sed sollicitudin mi. Nunc mattis nec tortor ut mollis.
                        Suspendisse consequat lacinia magna, at pharetra est accumsan sit amet.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
