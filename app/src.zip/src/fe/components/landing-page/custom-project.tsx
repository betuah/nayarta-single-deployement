"use client"
import Image from "next/image"
import Link from "next/link"
import {Swiper, SwiperSlide} from 'swiper/react';
import {Autoplay} from 'swiper/modules';
import 'swiper/css';
import {Button} from "@/components/ui/button";

const CustomProject = () => {
    return (
        <section
            className="py-16 2xl:py-[120px] bg-gradient-to-r from-[#E8EAF3] via-[#E1EDF4] to-pink-[#EFE8F0] dark:from-transparent dark:via-transparent dark:to-transparent dark:bg-card overflow-hidden"
            id="custom"
        >
            <div className="max-w-[670px] mx-auto">
                <h2
                    className="text-center text-xl xl:text-3xl xl:leading-[46px] font-semibold text-default-900 mb-3">
                    Lorem Ipsum <span className="text-primary">Dolor </span>

                </h2>
                <p className="text-sm xl:text-base leading-7 text-center text-default-700 ">
                    Maecenas justo urna, tempus at ultrices at, rutrum sed tellus. Morbi in luctus sapien. Nunc a metus
                    in tellus aliquam dapibus.
                </p>

                <div className="flex justify-center gap-8 mb-10 xl:mb-[22px] mt-7 xl:mt-9">
                    <Button variant="outline" asChild>
                        <Link href="#" target="_blank"> Request Demo</Link>
                    </Button>
                    <Button asChild>
                        <Link href="#">Contact Us</Link>
                    </Button>
                </div>
            </div>
        </section>
    );
};

export default CustomProject;
