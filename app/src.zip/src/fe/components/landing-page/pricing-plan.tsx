"use client";
import {Icon} from "@iconify/react";
import {Button} from "@/components/ui/button";
import Link from "next/link";
import CardImage from "@/public/images/landing-page/avatar.jpg";
import Image from "next/image";
import {SiteLogo} from "@/components/svg";
import React from "react";
import ResizableSiteLogo from "@/components/resizable-site-logo";

const PricingPlan = () => {
    return (
        <section className="py-16 2xl:py-[120px]" id="pricing">
            <div className="container">

                <div className="max-w-[670px] mx-auto ">
                    <h2 className="text-center text-xl xl:text-3xl xl:leading-[46px] font-semibold text-default-900 mb-3">
                        Subscription <span className="text-primary">Plan</span>
                    </h2>
                    <p className="text-base xl:leading-7 text-center text-default-700 ">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non urna augue. Maecenas justo
                        urna, tempus at ultrices at, rutrum sed tellus. Morbi in luctus sapien.
                    </p>
                </div>

                <div className="mt-14">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-y-8 lg:gap-x-12">
                        {/* card one */}
                        <div className="bg-default-100 rounded-xl py-10 px-7 flex flex-col">
                            <div className="flex-none">
                                <div className="flex mb-3">
                                    <h4 className="flex-1 text-xl xl:text-2xl  font-semibold text-default-900">
                                        Regular
                                    </h4>
                                    <span className="flex-none text-xl xl:text-2xl  font-semibold text-primary">
                    $<span className="underline">9</span>
                  </span>
                                </div>
                                <p className="text-sm xl:text-base  text-default-600">
                                    Cras vel volutpat urna, hendrerit porttitor odio. Integer et posuere sapien.{" "}
                                    <span className="font-medium text-primary">
                    Orci varius.
                  </span>
                                </p>
                            </div>
                            <div className="flex-1">
                                <div className="text-base xl:text-xl font-semibold text-default-900 mt-5 mb-3 xl:mb-5 ">
                                    What’s Included
                                </div>
                                <ul className="space-y-3">
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Lorem ipsum
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Dolor sit amet.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Consectetur adipiscing elit.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:x-mark-16-solid"
                                            className="w-4 h-4 text-destructive"
                                        />
                                        <span className="text-sm xl:text-base text-default-900">
                      Sed non urna.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:x-mark-16-solid"
                                            className="w-4 h-4 text-destructive"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Maecenas justo urna, tempus at ultrices at.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:x-mark-16-solid"
                                            className="w-4 h-4 text-destructive"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Rutrum sed tellus.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:x-mark-16-solid"
                                            className="w-4 h-4 text-destructive"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Morbi in luctus sapien.
                    </span>
                                    </li>
                                </ul>
                            </div>
                            <ul className="space-y-3">
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Nunc a metus.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Nullam id justo laoreet.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Vulputate mi et,.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:x-mark-16-solid"
                                        className="w-4 h-4 text-destructive"
                                    />
                                    <span className="text-sm xl:text-base text-default-900">
                    Sed pellentesque pharetra arcu.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:x-mark-16-solid"
                                        className="w-4 h-4 text-destructive"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Ornare dui laoreet quis.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:x-mark-16-solid"
                                        className="w-4 h-4 text-destructive"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Integer blandit accumsan urna.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:x-mark-16-solid"
                                        className="w-4 h-4 text-destructive"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Sed volutpat mi varius bibendum.
                  </span>
                                </li>
                            </ul>
                            <Button asChild>
                                <Link href="#" target="__blank"
                                      className="mt-8 xl:mt-12 w-full">
                                    Subscribe Now
                                </Link>
                            </Button>
                        </div>

                        {/* card two */}

                        <div
                            className="bg-default-100 rounded-xl py-8 px-6 border border-primary relative flex flex-col">
              <span
                  className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary font-medium text-primary-foreground py-1 px-3 rounded text-base ">
                Featured
              </span>
                            <div className="flex-none">
                                <div className="flex mb-3">
                                    <h4 className="flex-1 text-xl xl:text-2xl  font-semibold text-default-900">
                                        Extend
                                    </h4>
                                    <span className="flex-none text-xl xl:text-2xl  font-semibold text-primary">
                    $<span className="underline">300</span>
                  </span>
                                </div>
                                <p className="text-sm xl:text-base  text-default-600">
                                    Cras vel volutpat urna, hendrerit porttitor odio. Integer et posuere sapien.{" "}
                                    <span className="font-medium text-primary">
                    Orci varius.
                  </span>
                                </p>
                            </div>
                            <div className="flex-1">

                                <div className="text-base  font-semibold text-default-900 mt-5 mb-3 xl:mb-5">
                                    What’s Included
                                </div>
                                <ul className="space-y-3">
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Lorem ipsum.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Dolor sit amet.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Consectetur adipiscing elit.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Sed non urna.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Maecenas justo urna, tempus at ultrices at.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base  text-default-900">
                      Rutrum sed tellus.
                    </span>
                                    </li>
                                    <li className="flex items-center gap-3">
                                        <Icon
                                            icon="heroicons:check-16-solid"
                                            className="w-4 h-4 text-success"
                                        />
                                        <span className="text-sm xl:text-base text-default-900">
                      Morbi in luctus sapien.
                    </span>
                                    </li>
                                </ul>
                            </div>
                            <ul className="space-y-3">
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Nunc a metus.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Nullam id justo laoreet.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Vulputate mi et.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Sed pellentesque pharetra arcu.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Ornare dui laoreet quis.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base  text-default-900">
                    Integer blandit accumsan urna.
                  </span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <Icon
                                        icon="heroicons:check-16-solid"
                                        className="w-4 h-4 text-success"
                                    />
                                    <span className="text-sm xl:text-base text-default-900">
                    Sed volutpat mi varius bibendum.
                  </span>
                                </li>
                            </ul>
                            <Button asChild>
                                <Link href="#" target="__blank"
                                      className="mt-8 xl:mt-12 w-full">
                                    Subscribe Now
                                </Link>
                            </Button>
                        </div>

                        {/* card three */}

                        <div className="bg-default-100 rounded-xl py-8 px-6 flex flex-col">
                            <div className="flex-none">
                                <h4 className="text-xl xl:text-2xl font-semibold text-primary mb-3">
                                    Custom
                                </h4>
                                <p className="text-sm xl:text-base  text-default-600">
                                    Cras vel volutpat urna, hendrerit porttitor odio. Integer et posuere sapien.{" "}
                                    <span className="font-medium text-primary">
                    Orci varius.
                  </span>
                                </p>
                            </div>
                            <div className="flex-1 flex flex-col justify-center items-center mt-8 lg:mt-0">
                                <ResizableSiteLogo  height={140} width={145}/>
                            </div>
                            <Button asChild>
                                <Link href="#" target="__blank"
                                      className="mt-8 xl:mt-12 w-full">
                                    Contact us
                                </Link>
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default PricingPlan;
