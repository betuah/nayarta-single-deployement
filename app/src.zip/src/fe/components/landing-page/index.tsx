"use client";
import {useEffect} from "react";
import {useRouter} from "next/navigation";
import LayoutLoader from "@/components/layout-loader";
import {useSession} from "next-auth/react";

const LandingPageView = () => {
    const {data: session, status} = useSession();
    const router = useRouter();

    useEffect(() => {
        if (status === "authenticated" && session) {
            router.push("/dashboard");
        } else if (status === "unauthenticated") {
            router.push("/auth/login");
        }
    }, [session, status, router]);

    return (
        <LayoutLoader/>
    );
};

export default LandingPageView;
