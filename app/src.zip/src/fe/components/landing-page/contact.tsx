import {Button} from "@/components/ui/button";
import Link from "next/link";
import {Card, CardContent} from "../ui/card";

const Contact = () => {
    return (
        <section className="py-16 2xl:py-[120px]">
            <div className="container">
                <div className="flex flex-col lg:grid grid-cols-1 lg:grid-cols-2  items-center gap-10">
                    <div>
                        <Card className="max-w-[600px]">
                            <CardContent className="p-5 xl:p-8">
                                <h2 className="text-xl xl:text-2xl  font-semibold text-default-900 mb-3">Lorem
                                    Ipsum</h2>
                                <p className="text-sm xl:text-base  text-default-700">
                                    Pellentesque euismod convallis neque in gravida. Mauris velit libero, viverra vitae
                                    egestas ac, egestas sit amet leo. Etiam a condimentum diam. Sed tempor enim sit amet
                                    nisl molestie pretium. Nullam odio lacus, feugiat imperdiet bibendum sit amet,
                                    rutrum sed diam.
                                </p>
                                <Button asChild className="mt-5">
                                    <Link href="#" target="_blank">Get
                                        Support </Link>
                                </Button>
                            </CardContent>
                        </Card>
                    </div>
                    <div>
                        <Card className="max-w-[600px]">
                            <CardContent className="p-5 xl:p-8">
                                <div>
                                    <h2 className="text-xl xl:text-2xl font-semibold text-default-900 mb-3">Consectetur
                                        Adipiscing</h2>
                                    <p className=" text-sm xl:text-base text-default-700">
                                        Cras vel volutpat urna, hendrerit porttitor odio. Integer et posuere sapien.
                                        Orci varius natoque penatibus et magnis dis parturient montes, nascetur
                                        ridiculus mus. Mauris lacinia id ligula sit amet gravida. Mauris sed faucibus
                                        odio.
                                    </p>
                                    <Button asChild className="mt-5">
                                        <Link href="/"> Request Demo </Link>
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </section>

    );
};

export default Contact;
