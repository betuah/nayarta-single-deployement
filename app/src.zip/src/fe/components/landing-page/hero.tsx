import Link from "next/link";
import Image from "next/image";
import {motion} from "framer-motion";
import {Button} from "@/components/ui/button";


const Hero = () => {
    return (
        <section
            className="bg-cover bg-no-repeat relative mb-24"
            id="home"
        >
            <div className="bg-gradient-to-b from-primary/30 to-[#fff] dark:from-primary/20 dark:to-[#0F172A]">
                <div className="container">
                    <div className=" relative z-10">
                        <div className="pt-32 md:pt-48">
                            <h1 className="max-w-[600px] mx-auto text-xl md:text-2xl xl:text-4xl xl:leading-[52px] font-semibold text-default-900 text-center">
                                <span className="text-primary">VMS Web</span> - Lorem ipsum dolor sit amet, consectetur
                                adipiscing elit.
                            </h1>
                            <p className="text-base leading-7 md:text-lg md:leading-8 text-default-700 text-center mt-5 max-w-[800px] mx-auto">
                                Sed non urna augue. Maecenas justo urna, tempus at ultrices at, rutrum sed tellus. Morbi
                                in luctus sapien. Nunc a metus in tellus aliquam dapibus. Nullam id justo laoreet,
                                vulputate mi et, congue nunc.
                            </p>
                            <div className="flex mt-9 justify-center gap-4 lg:gap-8">
                                <Button asChild size="xl">
                                    <Link href="#"> Request Demo </Link>
                                </Button>
                                <Button asChild variant="outline" size="xl">
                                    <Link href="#" target="_blank">
                                        Talk to sales
                                    </Link>
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Hero;
