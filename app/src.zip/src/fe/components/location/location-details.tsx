import React from 'react';
import {Card, CardContent} from "@/components/ui/card";
import {Progress} from "@/components/ui/progress";
import {useLocationModuleStore} from "@/store/location-module-store";
import LocationDetailHeader from "@/components/location/location-detail-header";
import LocationDetailStats from "@/components/location/location-detail-stats";
import LocationDetailActions from "@/components/location/location-detail-actions";
import LocationDetailMap from "@/components/location/loocation-detail-map";
import LocationFloorPlans from "@/components/location/location-floor-plans";

export interface LocationDetailsProps {
    locationId: string;
}

const LocationDetails: React.FC<LocationDetailsProps> = ({locationId}) => {
    const {currentLocationDetails, fetchLocationDetails, isLoading, reset} = useLocationModuleStore();

    React.useEffect(() => {
        reset()
        fetchLocationDetails(locationId);
    }, [locationId, fetchLocationDetails]);

    if (isLoading && !currentLocationDetails) {
        return <Progress value={70} color="primary" isInfinite size="xs"/>;
    }

    if (!currentLocationDetails) {
        return <div>No location details found</div>;
    }

    return (
        <>
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}
            <Card className="mt-2">
                <CardContent className="p-0">
                    <LocationDetailHeader/>
                    <LocationDetailStats/>
                    <LocationDetailActions/>
                    <LocationDetailMap/>
                    <div className="p-6">
                        <LocationFloorPlans selectedLocation={currentLocationDetails}/>
                    </div>
                </CardContent>
            </Card>
        </>
    );
}

export default LocationDetails;
