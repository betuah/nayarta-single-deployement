import React, { useRef } from 'react';
import { MapContainer, Marker, TileLayer } from "react-leaflet";
import Leaflet from "leaflet";
import 'leaflet/dist/leaflet.css';
import { useLocationModuleStore } from "@/store/location-module-store";

// Set default icon paths
Leaflet.Icon.Default.imagePath = "../node_modules/leaflet";
Leaflet.Icon.Default.mergeOptions({
    iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png').default,
    iconUrl: require('leaflet/dist/images/marker-icon.png').default,
    shadowUrl: require('leaflet/dist/images/marker-shadow.png').default
})

const customIcon = Leaflet.icon({iconUrl: "/images/marker-icon.png"});

const LocationDetailMap = () => {
    const mapRef = useRef<Leaflet.Map | null>(null);
    const { currentLocationDetails } = useLocationModuleStore();

    if (!currentLocationDetails) return null;

    const position: [number, number] = [
        currentLocationDetails.latitude || 51.505,
        currentLocationDetails.longitude || -0.09
    ];

    return (
        <div className="h-[450px] w-full p-6">
            <MapContainer
                center={position}
                zoom={13}
                style={{
                    height: '100%',
                    width: '100%',
                    borderRadius: '10px',
                    overflow: 'hidden'
                }}
                ref={mapRef}
            >
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
                <Marker
                    position={position}
                    icon={customIcon}
                    draggable={false}
                />
            </MapContainer>
        </div>
    );
};

export default LocationDetailMap;
