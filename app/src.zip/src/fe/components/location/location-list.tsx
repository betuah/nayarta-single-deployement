import React, { useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useLocationModuleStore } from "@/store/location-module-store";
import SearchAndSort from "@/components/location/search-and-sort";
import LocationListView from "@/components/location/location-listview";
import LocationMap from "@/components/location/location-map";
import Pagination from "@/components/location/pagination";

const LocationList: React.FC = () => {
    const { isLoading, fetchLocations } = useLocationModuleStore();

    useEffect(() => {
        fetchLocations();
    }, [fetchLocations]);

    return (
        <>
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}
            <div className="bg-card mt-2 rounded-md p-6">
                <SearchAndSort />

                <Tabs defaultValue="list" className="p-0 px-1">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="list">List View</TabsTrigger>
                        <TabsTrigger value="map">Map View</TabsTrigger>
                    </TabsList>

                    <TabsContent value="list" className="py-4">
                        <LocationListView />
                    </TabsContent>

                    <TabsContent value="map" className="py-4">
                        <LocationMap />
                    </TabsContent>
                </Tabs>

                <Pagination />
            </div>
        </>
    );
}

export default LocationList;
