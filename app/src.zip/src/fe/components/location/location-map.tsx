import React, { useMemo, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import Leaflet from 'leaflet';
import "leaflet/dist/leaflet.css";
import { useLocationModuleStore } from '@/store/location-module-store';
import LocationCard from "@/components/location/location-card";
import LocationFloorPlans from "@/components/location/location-floor-plans";
import { DtoLocationListItem } from '@/lib/api/data-contracts';

// Set default icon paths
Leaflet.Icon.Default.imagePath = "../node_modules/leaflet";
Leaflet.Icon.Default.mergeOptions({
    iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png').default,
    iconUrl: require('leaflet/dist/images/marker-icon.png').default,
    shadowUrl: require('leaflet/dist/images/marker-shadow.png').default
});

// Component to fit bounds
const ChangeView = ({ bounds }: { bounds: Leaflet.LatLngBounds }) => {
    const map = useMap();
    map.fitBounds(bounds);
    return null;
};

const LocationMap: React.FC = () => {
    const { locations } = useLocationModuleStore();
    const [selectedLocation, setSelectedLocation] = useState<DtoLocationListItem | null>(null);
    const customIcon = Leaflet.icon({ iconUrl: "/images/marker-icon.png" });

    const { mapCenter, mapBounds } = useMemo(() => {
        const validLocations = locations.filter(
            loc => typeof loc.latitude === 'number' && typeof loc.longitude === 'number'
        );

        if (validLocations.length === 0) {
            return { mapCenter: [0, 0] as [number, number], mapBounds: undefined };
        }

        const latLngs = validLocations.map(loc => Leaflet.latLng(loc.latitude!, loc.longitude!));
        const bounds = Leaflet.latLngBounds(latLngs);
        const center = bounds.getCenter();

        return {
            mapCenter: [center.lat, center.lng] as [number, number],
            mapBounds: bounds
        };
    }, [locations]);

    if (!mapBounds) {
        return <div className="w-full flex flex-row items-center justify-center">No Location Found</div>;
    }

    return (
        <>
            <MapContainer
                center={mapCenter}
                zoom={3} // Default zoom, will be adjusted by ChangeView
                style={{
                    height: '750px',
                    borderRadius: '10px',
                    overflow: 'hidden'
                }}
            >
                <ChangeView bounds={mapBounds} />
                <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                {locations.map(location => (
                    location.latitude && location.longitude ? (
                        <Marker
                            key={location.id}
                            position={[location.latitude, location.longitude]}
                            icon={customIcon}
                            eventHandlers={{
                                click: () => {
                                    setSelectedLocation(location);
                                }
                            }}
                        >
                            <Popup>
                                <LocationCard {...location} />
                            </Popup>
                        </Marker>
                    ) : null
                ))}
            </MapContainer>

            {/* Floor Plans Section */}
            <LocationFloorPlans selectedLocation={selectedLocation} />
        </>
    );
}

export default LocationMap;
