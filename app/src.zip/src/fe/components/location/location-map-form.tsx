import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, useMap } from 'react-leaflet';
import {Controller, Control, FieldErrors, UseFormWatch, UseFormSetValue} from 'react-hook-form';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLocationModuleStore } from '@/store/location-module-store';
import Leaflet from "leaflet";
import 'leaflet/dist/leaflet.css';

// Set default icon paths
Leaflet.Icon.Default.imagePath = "../node_modules/leaflet";
Leaflet.Icon.Default.mergeOptions({
    iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png').default,
    iconUrl: require('leaflet/dist/images/marker-icon.png').default,
    shadowUrl: require('leaflet/dist/images/marker-shadow.png').default
});

const customIcon = Leaflet.icon({iconUrl: "/images/marker-icon.png"});

interface LocationMapFormProps {
    control: Control<any>;
    errors: FieldErrors<any>;
    watch: UseFormWatch<any>;
    setValue: UseFormSetValue<any>;
}

const MapEvents: React.FC<{ lat: number; lng: number }> = ({ lat, lng }) => {
    const map = useMap();
    useEffect(() => {
        // Check if coordinates are valid numbers before trying to fly to them
        if (!isNaN(lat) && !isNaN(lng) && isFinite(lat) && isFinite(lng)) {
            map.flyTo([lat, lng], map.getZoom());
        }
    }, [map, lat, lng]);
    return null;
};

const LocationMapForm: React.FC<LocationMapFormProps> = ({ control, errors, watch, setValue }) => {
    const {
        isAutomatic,
        handleMarkerDrag,
        updateLocationName,
    } = useLocationModuleStore();

    const watchLatitude = watch('latitude');
    const watchLongitude = watch('longitude');

    // Ensure we have valid coordinates for the map, fallback to defaults
    const validLat = !isNaN(watchLatitude) && isFinite(watchLatitude) ? watchLatitude : 0;
    const validLng = !isNaN(watchLongitude) && isFinite(watchLongitude) ? watchLongitude : 0;

    const onMarkerDragEnd = async (lat: number, lng: number) => {
        handleMarkerDrag(lat, lng);
        setValue('latitude', lat);
        setValue('longitude', lng);
        if (isAutomatic) {
            const address = await updateLocationName(lat, lng);
            setValue('locationName', address);
        }
    };

    return (
        <>
            <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2 lg:col-span-1">
                    <Label htmlFor="latitude" className="mb-2">
                        Latitude <span className="text-warning">*</span>
                    </Label>
                    <Controller
                        name="latitude"
                        control={control}
                        render={({ field }) => (
                            <Input
                                {...field}
                                type="number"
                                id="latitude"
                                placeholder="Latitude"
                                disabled={isAutomatic}
                                onChange={(e) => {
                                    const value = e.target.value;
                                    // Handle empty string case
                                    if (value === '') {
                                        field.onChange('');
                                        return;
                                    }

                                    const lat = parseFloat(value);
                                    if (!isNaN(lat) && isFinite(lat)) {
                                        field.onChange(lat);
                                        if (!isAutomatic && !isNaN(watchLongitude) && isFinite(watchLongitude)) {
                                            handleMarkerDrag(lat, watchLongitude);
                                        }
                                    }
                                }}
                            />
                        )}
                    />
                    {/*@ts-ignore*/}
                    {errors.latitude && <p className="text-red-500 text-sm mt-1">{errors.latitude.message}</p>}
                </div>
                <div className="col-span-2 lg:col-span-1">
                    <Label htmlFor="longitude" className="mb-2">
                        Longitude <span className="text-warning">*</span>
                    </Label>
                    <Controller
                        name="longitude"
                        control={control}
                        render={({ field }) => (
                            <Input
                                {...field}
                                type="number"
                                id="longitude"
                                placeholder="Longitude"
                                disabled={isAutomatic}
                                onChange={(e) => {
                                    const value = e.target.value;
                                    // Handle empty string case
                                    if (value === '') {
                                        field.onChange('');
                                        return;
                                    }

                                    const lon = parseFloat(value);
                                    if (!isNaN(lon) && isFinite(lon)) {
                                        field.onChange(lon);
                                        if (!isAutomatic && !isNaN(watchLatitude) && isFinite(watchLatitude)) {
                                            handleMarkerDrag(watchLatitude, lon);
                                        }
                                    }
                                }}
                            />
                        )}
                    />
                    {/*@ts-ignore*/}
                    {errors.longitude && <p className="text-red-500 text-sm mt-1">{errors.longitude.message}</p>}
                </div>
            </div>

            <div className="h-[750px] w-full mt-6">
                <MapContainer
                    center={[validLat, validLng]}
                    zoom={13}
                    style={{
                        height: '100%',
                        width: '100%',
                        borderRadius: '10px',
                        overflow: 'hidden'
                    }}
                >
                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
                    <Marker
                        position={[validLat, validLng]}
                        icon={customIcon}
                        draggable={true}
                        eventHandlers={{
                            dragend: (e) => {
                                const { lat, lng } = e.target.getLatLng();
                                onMarkerDragEnd(lat, lng);
                            },
                        }}
                    />
                    <MapEvents lat={validLat} lng={validLng}/>
                </MapContainer>
            </div>
        </>
    );
};

export default LocationMapForm;
