import React from 'react';
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { Upload } from 'lucide-react';
import { Icon } from '@iconify/react';
import { useFileUploadStore } from '@/store/file-upload-store';
import { toast } from 'react-toastify';

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

const LocationHeaderForm: React.FC = () => {
    const { files, fileUrl, handleFileDrop, clearFiles } = useFileUploadStore();

    const {getRootProps, getInputProps} = useDropzone({
        multiple: false,
        accept: {
            "image/*": [".png", ".jpg", ".jpeg", ".gif"],
        },
        maxSize: MAX_FILE_SIZE,
        onDrop: handleFileDrop,
        onDropRejected: (fileRejections) => {
            fileRejections.forEach((file) => {
                file.errors.forEach((err) => {
                    if (err.code === "file-too-large") {
                        toast.error(`File is too large. Max size is 5MB.`);
                    }
                });
            });
        },
    });

    return (
        <div className={files.length ? "h-[400px] w-full" : ""}>
            {files.length || fileUrl !== "" ? (
                <div className="w-full h-full relative">
                    <Button
                        type="button"
                        className="absolute top-4 right-4 h-12 w-12 rounded-full bg-default-900 hover:bg-background hover:text-default-900 z-20"
                        onClick={clearFiles}
                    >
                        <span className="text-xl"><Icon icon="fa6-solid:xmark"/></span>
                    </Button>
                    {files.map((file) => (
                        <img
                            key={file.name}
                            alt={file.name}
                            className="w-full h-full object-cover rounded-md"
                            src={URL.createObjectURL(file)}
                        />
                    ))}
                    {fileUrl !== "" && (
                        <img
                            alt='cover image'
                            className="w-full h-full object-cover rounded-md"
                            src={fileUrl}
                        />
                    )}
                </div>
            ) : (
                <div {...getRootProps({className: "dropzone"})}>
                    <input {...getInputProps()} />
                    <div className="w-full text-center border-dashed border rounded-md py-[52px] flex items-center flex-col">
                        <div className="h-12 w-12 inline-flex rounded-md bg-muted items-center justify-center mb-3">
                            <Upload className="text-default-500"/>
                        </div>
                        <h4 className="text-2xl font-medium mb-1 text-card-foreground/80">
                            Add cover image.
                        </h4>
                        <div className="text-xs text-muted-foreground">
                            Drop file here or click to upload to select image (max 5MB)
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default LocationHeaderForm;
