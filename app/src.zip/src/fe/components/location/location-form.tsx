import React, {useEffect} from 'react';
import {useRouter} from "next/navigation";
import {useForm} from 'react-hook-form';
import {zodResolver} from '@hookform/resolvers/zod';
import * as z from 'zod';
import {toast} from 'react-toastify';
import {useLocationModuleStore} from '@/store/location-module-store';
import {useGroupModuleStore} from '@/store/group-module-store';
import {useFileUploadStore} from '@/store/file-upload-store';
import {useUserStore} from "@/store/user-store";
import {Button} from "@/components/ui/button";
import {Card, CardContent} from "@/components/ui/card";
import {Loader2, AlertTriangle, MapPin} from 'lucide-react';
import {Alert, AlertDescription} from "@/components/ui/alert";
import LocationHeaderForm from "@/components/location/location-header-form";
import LocationDetailsForm from "@/components/location/location-details-form";
import LocationMapForm from "@/components/location/location-map-form";
import {Progress} from "@/components/ui/progress";

const locationSchema = z.object({
    name: z.string().min(1, "Name is required"),
    locationName: z.string().min(1, "Address is required"),
    latitude: z.number().min(-90).max(90),
    longitude: z.number().min(-180).max(180),
});

type LocationFormData = z.infer<typeof locationSchema>;

interface LocationFormProps {
    mode: 'add' | 'edit';
    locationId?: string;
}

const LocationForm: React.FC<LocationFormProps> = ({mode, locationId}) => {
    const {selectedGroupMember} = useUserStore();
    const {
        createLocation,
        updateLocation,
        fetchLocationDetails,
        currentLocationDetails,
        isLoading,
        reset: resetLocation,
    } = useLocationModuleStore();

    const {
        quotaLocations,
        isLoadingQuotaLocations,
        quotaLocationsError,
        fetchQuotaLocations
    } = useGroupModuleStore();

    const {
        files,
        fileUrl,
        createPresignedUrl,
        uploadFile,
        isUploading,
        setFileUrl,
        reset: resetUpload,
    } = useFileUploadStore();

    const router = useRouter();

    const {control, handleSubmit, setValue, watch, formState: {errors}} = useForm<LocationFormData>({
        resolver: zodResolver(locationSchema),
        defaultValues: {
            name: "",
            locationName: "",
            latitude: 0,
            longitude: 0,
        },
    });

    useEffect(() => {
        resetLocation();
        resetUpload();
        // Only fetch quota for add mode
        if (mode === 'add') {
            fetchQuotaLocations();
        }
    }, [mode]);

    useEffect(() => {
        if (mode === 'edit' && locationId) {
            fetchLocationDetails(locationId);
        }
    }, [mode, locationId, fetchLocationDetails]);

    useEffect(() => {
        if (mode === 'edit' && currentLocationDetails) {
            setValue("name", currentLocationDetails.location_name || "");
            setValue("locationName", currentLocationDetails.address || "");
            setValue("latitude", currentLocationDetails.latitude || 0);
            setValue("longitude", currentLocationDetails.longitude || 0);
            setFileUrl(currentLocationDetails.image_url);
        }
    }, [mode, currentLocationDetails, setValue]);

    const onSubmit = async (data: LocationFormData) => {
        if (!selectedGroupMember) {
            toast.error("No group selected");
            return;
        }

        let imageUrl = fileUrl;

        if (files.length > 0) {
            const file = files[0];
            const presignedUrlResponse = await createPresignedUrl(selectedGroupMember.group_id, {
                content_length: file.size,
                file_name: file.name
            });

            if (presignedUrlResponse) {
                const uploadSuccess = await uploadFile(presignedUrlResponse, file);
                if (uploadSuccess) {
                    imageUrl = presignedUrlResponse.file_url || '';
                } else {
                    toast.error("Failed to upload image. Please try again.");
                    return;
                }
            }
        }

        const locationData = {
            location_name: data.name,
            address: data.locationName,
            latitude: data.latitude,
            longitude: data.longitude,
            image_url: imageUrl,
        };

        try {
            if (mode === 'add') {
                await createLocation(locationData);
                // Refresh quota after successful creation
                await fetchQuotaLocations();
            } else if (mode === 'edit' && locationId) {
                await updateLocation(locationId, locationData);
            }

            router.push("/nvr/locations");
        } catch (error) {
            toast.error("Failed to save location. Please try again.");
        }
    };

    // Check if quota is exceeded (only for add mode)
    const isQuotaExceeded = mode === 'add' && quotaLocations && quotaLocations.remaining !== undefined && quotaLocations.remaining <= 0;
    const hasQuotaData = quotaLocations && quotaLocations.used !== undefined;
    const shouldShowQuota = mode === 'add' && hasQuotaData;

    // Loading state for quota (only for add mode)
    if (mode === 'add' && isLoadingQuotaLocations) {
        return (
            <div>
                <Card className="p-6">
                    <CardContent>
                        <div className="flex items-center justify-center py-8">
                            <div className="animate-spin rounded-full h-8 w-8 border-2 border-default-300 border-t-gray-900"></div>
                            <span className="ml-2">Loading quota information...</span>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    // Error state for quota (only for add mode)
    if (mode === 'add' && quotaLocationsError) {
        return (
            <div>
                <Card className="p-6">
                    <CardContent>
                        <Alert>
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>
                                Failed to load quota information: {quotaLocationsError}
                            </AlertDescription>
                        </Alert>
                        <Button
                            onClick={() => fetchQuotaLocations()}
                            className="mt-4"
                            variant="outline"
                        >
                            Retry
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <>
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}
            <div className='bg-card border-b border-default-200 mt-2 rounded-none rounded-t-md p-6'>
                {/* Quota Information - Only show for add mode */}
                {shouldShowQuota && (
                    <div className="mb-6 p-4 bg-default-50 border border-default-200 rounded-lg">
                        <div className="flex items-center gap-2 text-sm font-medium text-default-700 mb-2">
                            <MapPin className="h-4 w-4" />
                            Location Quota Status
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                                <span className="text-default-600">Used:</span>
                                <span className="ml-1 font-medium">{quotaLocations.used || 0}</span>
                            </div>
                            <div>
                                <span className="text-default-600">Max:</span>
                                <span className="ml-1 font-medium">{quotaLocations.max || 0}</span>
                            </div>
                            <div>
                                <span className="text-default-600">Remaining:</span>
                                <span className={`ml-1 font-medium ${isQuotaExceeded ? 'text-red-600' : 'text-green-600'}`}>
                                    {quotaLocations.remaining || 0}
                                </span>
                            </div>
                            <div>
                                <span className="text-default-600">Usage:</span>
                                <span className="ml-1 font-medium">{quotaLocations.percentage?.toFixed(2) || 0}%</span>
                            </div>
                        </div>
                    </div>
                )}

                {/* Quota Exceeded Alert - Only show for add mode */}
                {isQuotaExceeded && (
                    <Alert className="mb-6 border-red-200 bg-red-50">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <AlertDescription className="text-red-800">
                            <strong>Location quota exceeded!</strong> You have reached the maximum number of locations
                            ({quotaLocations.max}) for your organization. Please contact your administrator to
                            increase the quota or remove some locations before adding new ones.
                        </AlertDescription>
                    </Alert>
                )}

                {/* Form Content - Hide if quota is exceeded for add mode */}
                {!(mode === 'add' && isQuotaExceeded) && (
                    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 mt-2">
                        <LocationHeaderForm/>
                        <LocationDetailsForm control={control} errors={errors} setValue={setValue}/>
                        <LocationMapForm control={control} errors={errors} watch={watch} setValue={setValue}/>
                        <div className='flex flex-col items-end'>
                            <Button type="submit" disabled={isLoading || isUploading}>
                                {(isLoading || isUploading) && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                                {mode === 'add' ? 'Create Location' : 'Update Location'}
                            </Button>
                        </div>
                    </form>
                )}
            </div>
        </>
    );
}

export default LocationForm;
