'use client';

import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useFloorPlanModuleStore } from "@/store/floor-plan-module-store";
import { Progress } from "@/components/ui/progress";
import { DtoLocationListItem } from "@/lib/api/data-contracts";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import {Loader, Loader2} from "lucide-react";


interface LocationFloorPlansProps {
    selectedLocation: DtoLocationListItem | null;
}

const LocationFloorPlans: React.FC<LocationFloorPlansProps> = ({ selectedLocation }) => {
    const {
        floorPlans,
        isLoading,
        fetchFloorPlans,
        setLocationId,
        setLimit,
        clearFloorPlans
    } = useFloorPlanModuleStore();

    useEffect(() => {
        if (selectedLocation) {
            setLimit(100);
            setLocationId(selectedLocation.id || null);
            fetchFloorPlans().then();
        } else {
            // Clear floor plans when no location is selected
            clearFloorPlans();
        }
    }, [selectedLocation, setLocationId, setLimit, fetchFloorPlans, clearFloorPlans]);

    if (!selectedLocation) {
        return null;
    }

    return (
        <div className="mt-6">
            <div className="flex flex-row justify-between items-center">
                <h2 className="text-2xl font-medium text-default-900">
                    Floor/Site Plans for {selectedLocation.location_name}
                </h2>
            </div>

            {isLoading && <div className="flex items-center justify-center h-screen">
                <Loader2 className="animate-spin w-12 h-12 text-primary"/>
            </div>}

            {!isLoading && floorPlans?.items?.length === 0 && (
                <div className="bg-card mt-4 rounded-md p-6 text-center">
                    <p className="text-lg text-default-600">No floor plans found for this location.</p>

                </div>
            )}

            {!isLoading && floorPlans?.items && floorPlans.items.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-4">
                    {floorPlans.items.map((floorPlan) => (
                        <Card key={floorPlan.id} className="w-full border">
                            <CardHeader>
                                <CardTitle className="text-lg">{floorPlan.name}</CardTitle>
                                <div className="text-xs text-default-600">Location: {selectedLocation.location_name}</div>
                            </CardHeader>
                            <CardContent>
                                <Link href={`/floor-plans/${floorPlan.id}`}>
                                    <div className="aspect-video relative mb-4 rounded-lg overflow-hidden">
                                        {floorPlan.image_url ? (
                                            <img
                                                src={floorPlan.image_url}
                                                alt={floorPlan.name || 'Floor plan'}
                                                className="object-cover w-full h-full"
                                            />
                                        ) : (
                                            <div className="w-full h-full bg-muted flex items-center justify-center">
                                                No image
                                            </div>
                                        )}
                                    </div>
                                </Link>
                                <div className="flex justify-between items-center">
                                    <div className="text-sm bg-default-200 rounded text-default-600 p-2 font-semibold">
                                        Total Objects: {floorPlan.object_count || 0}
                                    </div>
                                    <div className="space-x-2">
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            asChild
                                        >
                                            <Link href={`/nvr/locations/floor-plans/edit?id=${floorPlan.id}`}>Edit</Link>
                                        </Button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
};

export default LocationFloorPlans;
