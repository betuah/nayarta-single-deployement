import React from 'react';
import { format, parseISO } from 'date-fns';
import Link from 'next/link';
import { Icon } from '@iconify/react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DtoLocationListItem } from '@/lib/api/data-contracts';

interface LocationCardProps extends DtoLocationListItem {}

const LocationCard: React.FC<LocationCardProps> = ({ image_url, location_name, address, id, created_at }) => {
    const formattedDate = created_at ? format(parseISO(created_at), 'dd-MM-yyyy hh:mm') : 'Unknown date';

    return (
        <Card className="p-4 rounded-md group w-full border border-default-200">
            <Link href={`/nvr/locations/${id}`}>
                <div className="relative h-[210px] flex flex-col justify-center items-center mb-3 rounded-md">
                    <div className="w-full overflow-hidden rounded-md relative z-10 bg-default-100 dark:bg-default-200 h-full">
                        <img
                            alt={location_name}
                            className="h-full w-full transition-all object-cover duration-300 group-hover:scale-105"
                            src={image_url || '/images/no-image.png'}
                        />
                        <Badge color="success" className="absolute top-3 ltr:left-3 rtl:right-3">
                            Active
                        </Badge>
                    </div>
                </div>
            </Link>

            <div>
                <div className="flex justify-between items-center mb-2">
                    <p className="text-xs text-secondary-foreground uppercase font-normal">{formattedDate}</p>
                </div>
                <h6 className="text-secondary-foreground text-base font-medium mb-[6px] truncate">
                    <Link href="#">{location_name}</Link>
                </h6>
                <p className="text-default-500 dark:text-default-500 text-sm font-normal mb-2">
                    {address}
                </p>
                <div className='flex flex-row gap-x-5'>
                    <Button className="w-full" variant="outline" asChild>
                        <Link href={`/nvr/locations/${id}`}>
                            <Icon icon="carbon:map" className="w-4 h-4 ltr:mr-2 rtl:ml-2"/>
                            View Details
                        </Link>
                    </Button>
                    <Button className="w-full" variant="outline" asChild>
                        <Link href={`/nvr/locations/${id}/edit`}>
                            <Icon icon="uil:edit" className="w-4 h-4 ltr:mr-2 rtl:ml-2"/>
                            Edit
                        </Link>
                    </Button>
                </div>
            </div>
        </Card>
    );
}

export default LocationCard;
