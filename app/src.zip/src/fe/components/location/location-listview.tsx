import React from 'react';
import {useLocationModuleStore} from '@/store/location-module-store';
import LocationCard from "@/components/location/location-card";

const LocationListView: React.FC = () => {
    const {locations, isLoading} = useLocationModuleStore();

    if (isLoading) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {locations.map(location => (
                    <LocationCard key={location.id} {...location} />
                ))}
            </div>
            {
                locations.length === 0 &&
                <div className="w-full flex flex-row items-center justify-center">
                    No Location Found
                </div>
            }
        </div>
    );
}

export default LocationListView;
