import React from 'react';
import {Controller, Control, FieldErrors, UseFormSetValue} from 'react-hook-form';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from 'lucide-react';
import { useLocationModuleStore } from '@/store/location-module-store';

interface LocationDetailsFormProps {
    control: Control<any>;
    errors: FieldErrors<any>;
    setValue: UseFormSetValue<any>;
}

const LocationDetailsForm: React.FC<LocationDetailsFormProps> = ({ control, errors, setValue  }) => {
    const {
        isLoading,
        suggestions,
        isAutomatic,
        handleLocationNameChange,
        handleSuggestionSelect,
        setAutomatic,
    } = useLocationModuleStore();

    const onSuggestionSelect = (suggestion: any) => {
        handleSuggestionSelect(suggestion);
        setValue('locationName', suggestion.display_name);
        setValue('latitude', parseFloat(suggestion.lat));
        setValue('longitude', parseFloat(suggestion.lon));
    };

    return (
        <>
            <div>
                <Label htmlFor="name" className="mb-2">
                    Name <span className="text-warning">*</span>
                </Label>
                <Controller
                    name="name"
                    control={control}
                    render={({ field }) => (
                        <Input
                            {...field}
                            placeholder="input location name"
                            type="text"
                            size="lg"
                            id="name"
                        />
                    )}
                />
                {/*@ts-ignore*/}
                {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>}
            </div>

            <div className="relative">
                <div className='flex flex-row mb-2 justify-between items-center'>
                    <Label htmlFor="location" className="flex">
                        Location in Map <span className="text-warning">*</span>
                    </Label>
                    <div className="flex items-center space-x-2">
                        <Switch
                            id="auto-status"
                            checked={isAutomatic}
                            onCheckedChange={(checked) => {
                                setAutomatic(checked);
                                if (!checked) {
                                    handleLocationNameChange("");
                                }
                            }}
                        />
                        <Label htmlFor="active-status">
                            {isAutomatic ? 'Autofill' : 'Manual'}
                        </Label>
                    </div>
                </div>
                <div className="relative">
                    <Controller
                        name="locationName"
                        control={control}
                        render={({ field }) => (
                            <Input
                                {...field}
                                placeholder="search location"
                                type="text"
                                size="lg"
                                id="location"
                                onChange={(e) => {
                                    field.onChange(e);
                                    if (isAutomatic) {
                                        handleLocationNameChange(e.target.value);
                                    }
                                }}
                            />
                        )}
                    />
                    {isLoading && (
                        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                            <Loader2 className="h-5 w-5 text-gray-400 animate-spin"/>
                        </div>
                    )}
                </div>
                {/*@ts-ignore*/}
                {errors.locationName && <p className="text-red-500 text-sm mt-1">{errors.locationName.message}</p>}
                {isAutomatic && suggestions.length > 0 && (
                    <div className="absolute z-10 w-full bg-card border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto">
                        {suggestions.map((suggestion) => (
                            <div
                                key={suggestion.place_id}
                                onClick={() => onSuggestionSelect(suggestion)}
                                className="px-4 py-2 text-card-foreground cursor-pointer hover:bg-gray-100"
                            >
                                {suggestion.display_name}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </>
    );
};

export default LocationDetailsForm;
