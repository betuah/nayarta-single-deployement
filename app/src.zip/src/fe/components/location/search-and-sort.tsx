import React, {useEffect} from 'react';
import { Icon } from '@iconify/react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { useLocationModuleStore } from '@/store/location-module-store';

const SearchAndSort: React.FC = () => {
    const { searchQuery, sortBy, sortOrder, handleSearch, handleSort, fetchLocations } = useLocationModuleStore();

    // Clear search when component unmounts (user navigates away)
    useEffect(() => {
        return () => {
            handleSearch(""); // Clear search on cleanup
        };
    }, [handleSearch]);

    return (
        <div className="grid grid-cols-2 lg:grid-cols-2 gap-x-6 gap-y-4 py-4">
            <div className="flex gap-4 items-center">
                <Input
                    type="text"
                    placeholder="Search by name"
                    size="lg"
                    value={searchQuery}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleSearch(e.target.value)}
                />
                <Button size="icon" onClick={fetchLocations}>
                    <Icon icon="heroicons:magnifying-glass" className="h-6 w-6"/>
                </Button>
            </div>
            <div className="flex gap-4 items-center justify-end">
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="outline">
                            Sort
                            <Icon icon="heroicons:chevron-down" className="h-5 w-5 ml-2"/>
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="w-[196px]" align="start">
                        <DropdownMenuLabel>Sort Location by:</DropdownMenuLabel>
                        <DropdownMenuSeparator/>
                        <DropdownMenuItem onClick={() => handleSort("created_at")}>
                            {sortBy === "created_at" && (sortOrder === "asc" ? "↑ " : "↓ ")}
                            Date Created
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleSort("location_name")}>
                            {sortBy === "location_name" && (sortOrder === "asc" ? "↑ " : "↓ ")}
                            Location Name
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
        </div>
    );
}

export default SearchAndSort;
