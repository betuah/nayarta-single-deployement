import React from 'react';
import { Icon } from '@iconify/react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useLocationModuleStore } from '@/store/location-module-store';

const Pagination: React.FC = () => {
    const { currentPage, totalLocations, pageSize, handlePageChange } = useLocationModuleStore();
    const totalPages = Math.ceil(totalLocations / pageSize);

    return (
        <div className="flex items-center gap-2 justify-end mx-4 py-8">
            <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
            >
                <Icon icon="heroicons:chevron-left" className="w-5 h-5 rtl:rotate-180"/>
            </Button>

            {Array.from({length: Math.min(5, totalPages)}, (_, i) => {
                const pageNumber = i + Math.max(1, Math.min(currentPage - 2, totalPages - 4));
                return (
                    <Button
                        key={`page-${pageNumber}`}
                        variant={pageNumber === currentPage ? undefined : "outline"}
                        className={cn("w-8 h-8")}
                        onClick={() => handlePageChange(pageNumber)}
                    >
                        {pageNumber}
                    </Button>
                );
            })}

            <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
            >
                <Icon icon="heroicons:chevron-right" className="w-5 h-5 rtl:rotate-180"/>
            </Button>
        </div>
    );
}

export default Pagination;
