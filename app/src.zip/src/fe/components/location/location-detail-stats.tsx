import React from 'react';
import {Icon} from "@iconify/react";
import {Button} from "@/components/ui/button";
import {useLocationModuleStore} from "@/store/location-module-store";
import Link from "next/link";
import {SiBlueprint} from "react-icons/si";

const LocationDetailStats = () => {
    const {currentLocationDetails} = useLocationModuleStore();

    if (!currentLocationDetails) return null;

    return (
        <div className="bg-white rounded-lg ml-5 mr-5">
            <div className="p-4 bg-secondary rounded-lg">
                <dl className="grid max-w-screen-xl grid-cols-3 gap-8 p-4 mx-auto text-gray-900">
                    <div className="flex flex-col items-center justify-start">
                        <SiBlueprint className="w-16 h-16 text-primary"/>
                        <dt className="mb-2 text-3xl font-extrabold text-default-950">
                            {currentLocationDetails.total_floor_plans || 0}
                        </dt>
                        <dd className="text-center text-default-500 mb-4">Floor/Site Plans</dd>
                        <Link href='/floor-plans'>
                            <Button variant="soft">
                                <Icon icon="carbon:view-filled" className="w-4 h-4 ltr:mr-2 rtl:ml-2 "/>
                                View All Floor Plans
                            </Button>
                        </Link>
                    </div>
                    <div className="flex flex-col items-center justify-start">
                        <Icon icon="fluent-mdl2:device-run" className="w-16 h-16 text-primary"/>
                        <dt className="mb-2 text-3xl font-extrabold text-default-950">
                            {currentLocationDetails.total_nvrs || 0}
                        </dt>
                        <dd className="text-center text-default-500 mb-4">Network Video Recorder</dd>
                        <Link href='/nvr'>
                            <Button variant="soft">
                                <Icon icon="carbon:view-filled" className="w-4 h-4 ltr:mr-2 rtl:ml-2 "/>
                                View All NVR
                            </Button>
                        </Link>
                    </div>
                    <div className="flex flex-col items-center justify-start">
                        <Icon icon="lucide:cctv" className="w-16 h-16 text-primary"/>
                        <dt className="mb-2 text-3xl font-extrabold text-default-950">
                            {currentLocationDetails.total_cctvs || 0}
                        </dt>
                        <dd className="text-center text-default-500 mb-5">Camera</dd>
                        <Link href='/camera'>
                            <Button variant="soft">
                                <Icon icon="carbon:view-filled" className="w-4 h-4 ltr:mr-2 rtl:ml-2 "/>
                                View All Cameras
                            </Button>
                        </Link>
                    </div>
                </dl>
            </div>
        </div>
    );
};

export default LocationDetailStats;
