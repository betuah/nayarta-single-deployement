import React from 'react';
import { Icon } from "@iconify/react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useLocationModuleStore } from "@/store/location-module-store";

const LocationDetailHeader = () => {
    const { currentLocationDetails } = useLocationModuleStore();

    if (!currentLocationDetails) return null;

    return (
        <>
            <div className="w-full h-[320px] bg-muted-foreground overflow-hidden rounded-t-md">
                <img
                    className="w-full h-full object-cover"
                    src={currentLocationDetails.image_url || '/images/header_plain.png'}
                    alt="location image"
                />
            </div>
            <div className="p-4 flex flex-col items-center">
                <div className="w-24 h-24 rounded-full flex flex-col justify-center items-center p-[2px] bg-background overflow-hidden -mt-12 relative z-20 mb-2 border-2 border-primary">
                    <Icon icon="basil:location-solid" className="w-16 h-16 text-primary"/>
                </div>
                <p className="mb-1 text-lg text-default-700 font-medium">{currentLocationDetails.location_name}</p>
                <p className="mb-2 text-sm text-muted-foreground">{currentLocationDetails.address}</p>
                {currentLocationDetails.created_by_user && (
                    <div className="mt-4 mb-4 flex items-center space-x-4 bg-secondary p-4 rounded-lg w-full max-w-md">
                        <Avatar className="h-12 w-12">
                            <AvatarImage
                                src={currentLocationDetails.created_by_user.profile_picture_url || '/images/default-avatar.jpg'}
                                alt={currentLocationDetails.created_by_user.full_name}/>
                            <AvatarFallback>{currentLocationDetails.created_by_user.full_name?.substring(0, 2).toUpperCase() || 'U'}</AvatarFallback>
                        </Avatar>
                        <div>
                            <p className="text-sm font-medium">Created by</p>
                            <p className="text-xs text-muted-foreground">{currentLocationDetails.created_by_user.full_name}</p>
                            <p className="text-xs text-muted-foreground">{currentLocationDetails.created_by_user.email}</p>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
};

export default LocationDetailHeader;
