import React, { useState } from 'react';
import { Icon } from "@iconify/react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useLocationModuleStore } from "@/store/location-module-store";
import {
    Dialog,
    DialogClose,
    DialogContent,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger
} from "@/components/ui/dialog";

const LocationDetailActions = () => {
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const router = useRouter();
    const { currentLocationDetails, deleteLocation } = useLocationModuleStore();

    if (!currentLocationDetails) return null;

    const canDelete = (currentLocationDetails.total_cctvs === 0 && currentLocationDetails.total_nvrs === 0);

    const handleDelete = async () => {
        const success = await deleteLocation(currentLocationDetails!.id!);
        if (success) {
            router.push('/nvr/locations');
        }
        setIsDeleteDialogOpen(false);
    };

    return (
        <div className='flex flex-row gap-x-5 p-5 justify-end'>
            <Button asChild>
                <Link href={`/nvr/locations/${currentLocationDetails.id}/edit`}>
                    <Icon icon="uil:edit" className="w-4 h-4 mr-2 "/>
                    Edit
                </Link>
            </Button>

            <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <DialogTrigger asChild>
                    <Button variant="outline" color="destructive">
                        <Icon icon="ant-design:delete-filled" className="w-4 h-4 mr-2"/>
                        Delete
                    </Button>
                </DialogTrigger>
                <DialogContent size="md">
                    <DialogHeader>
                        <DialogTitle className="text-base font-medium text-default-700 gap-x-5 flex flex-row items-center">
                            <Icon icon="basil:location-solid" className="w-8 h-8 text-primary"/> Delete {currentLocationDetails.location_name}
                        </DialogTitle>
                    </DialogHeader>
                    <div className="text-sm text-default-500 space-y-4">
                        <div className='flex flex-row gap-2 items-center'>
                            {canDelete ? (
                                <p>
                                    Are you sure you want to delete <span className="text-destructive font-medium">{currentLocationDetails.location_name}</span>?
                                    This action cannot be undone.
                                </p>
                            ) : (
                                <p>
                                    Cannot delete <span className="text-destructive font-medium">{currentLocationDetails.location_name}</span>,
                                    because it is being used by {currentLocationDetails.total_cctvs} CCTVs and {currentLocationDetails.total_nvrs} NVRs.
                                    Remove all associated items before deleting this location.
                                </p>
                            )}
                        </div>
                    </div>
                    <DialogFooter className="mt-8">
                        <DialogClose asChild>
                            <Button type="button" variant="outline">
                                Cancel
                            </Button>
                        </DialogClose>
                        <Button
                            type="button"
                            color="destructive"
                            disabled={!canDelete}
                            onClick={handleDelete}
                        >
                            Delete
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default LocationDetailActions;
