import React from 'react';
import { AlertTriangle, InfoIcon } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {secondsToHoursFormatted} from "@/lib/utils";

interface UptimeBadgeProps {
    seconds: number
}

export const UptimeBadge: React.FC<UptimeBadgeProps> = ({ seconds }) => {


    return (
        <TooltipProvider>
            <Tooltip>
                <TooltipTrigger asChild>
                    <div className="flex items-center">
                        <Badge
                            className="capitalize"
                        >
                            {secondsToHoursFormatted(seconds || 0)}
                        </Badge>

                            <InfoIcon className="h-4 w-4 ml-2 text-primary-500" />
                    </div>
                </TooltipTrigger>
                <TooltipContent>
                    Uptime is calculated from when the camera was last online
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>
    );
};
