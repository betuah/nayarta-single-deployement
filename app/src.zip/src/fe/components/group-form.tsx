import React, {useState, useTransition} from 'react';
import {Button} from "@/components/ui/button";
import {Input} from "@/components/ui/input";
import {Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter} from "@/components/ui/card";
import {Tabs, TabsContent, TabsList, TabsTrigger} from "@/components/ui/tabs";
import {Label} from "@/components/ui/label";
import {Alert, AlertDescription} from "@/components/ui/alert";
import {Loader2} from "lucide-react";

const JoinGroupForm = () => {
    const [newOrgEmail, setNewOrgEmail] = useState('');
    const [newOrgName, setNewOrgName] = useState('');
    const [existingOrgEmail, setExistingOrgEmail] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [isPending, startTransition] = useTransition();

    const validateEmail = (email: string) => {
        const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return re.test(email);
    };

    const handleCreateOrg = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (!validateEmail(newOrgEmail)) {
            setError('Please enter a valid email address.');
            return;
        }

        if (newOrgName.length < 3) {
            setError('Organization name must be at least 3 characters long.');
            return;
        }

        setError("")

        startTransition(async () => {
            try {
                // Simulating API call
                await new Promise(resolve => setTimeout(resolve, 1500));
                // Replace this with actual API call
                // const response = await fetch('/api/create-organization', {
                //   method: 'POST',
                //   headers: { 'Content-Type': 'application/json' },
                //   body: JSON.stringify({ email: newOrgEmail, name: newOrgName }),
                // });
                // if (!response.ok) throw new Error('Failed to create organization');
                setSuccess('This organization was successfully created and was in the process of review by our team. For the time being, you cannot use this organization until the process is complete. Make sure the organizational email you enter is active, our team will immediately contact you. Thank You.');
                setNewOrgEmail('');
                setNewOrgName('');
            } catch (err) {
                setError('Failed to create organization. Please try again.');
            }
        });
    };

    const handleJoinOrg = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (!validateEmail(existingOrgEmail)) {
            setError('Please enter a valid email address.');
            return;
        }

        setError("")

        startTransition(async () => {
            try {
                // Simulating API call
                await new Promise(resolve => setTimeout(resolve, 1500));
                // Replace this with actual API call
                // const response = await fetch('/api/join-organization', {
                //   method: 'POST',
                //   headers: { 'Content-Type': 'application/json' },
                //   body: JSON.stringify({ email: existingOrgEmail }),
                // });
                // if (!response.ok) throw new Error('Failed to join organization');
                setSuccess('The request to join the organization was successfully made, but your membership was postponed until the admin at the organization approved your membership.');
                setExistingOrgEmail('');
            } catch (err) {
                setError('Failed to join organization. Please try again.');
            }
        });
    };

    return (
        <div className="">
            <Card className="w-full">
                <CardHeader>
                    <CardTitle>Join an Organization</CardTitle>
                    <CardDescription>Create a new organization or join an existing one.</CardDescription>
                </CardHeader>
                <CardContent>
                    {error && (
                        <Alert variant="soft" color="destructive" className="mb-4">
                            <AlertDescription>{error}</AlertDescription>
                        </Alert>
                    )}
                    {success && (
                        <Alert variant="soft" color="success" className="mb-4">
                            <AlertDescription>{success}</AlertDescription>
                        </Alert>
                    )}
                    <Tabs defaultValue="create">
                        <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="create">Create New</TabsTrigger>
                            <TabsTrigger value="join">Join Existing</TabsTrigger>
                        </TabsList>
                        <TabsContent value="create">
                            <form onSubmit={handleCreateOrg}>
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="newOrgEmail">Organization Email</Label>
                                        <Input
                                            id="newOrgEmail"
                                            type="email"
                                            placeholder="org@example.com"
                                            value={newOrgEmail}
                                            onChange={(e) => setNewOrgEmail(e.target.value)}
                                            required
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="newOrgName">Organization Name</Label>
                                        <Input
                                            id="newOrgName"
                                            type="text"
                                            placeholder="My Organization"
                                            value={newOrgName}
                                            onChange={(e) => setNewOrgName(e.target.value)}
                                            required
                                        />
                                    </div>
                                </div>
                                <Button type="submit" className="w-full mt-4" disabled={isPending}>
                                    {isPending ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin"/>
                                            Creating...
                                        </>
                                    ) : (
                                        'Create Organization'
                                    )}
                                </Button>
                            </form>
                        </TabsContent>
                        <TabsContent value="join">
                            <form onSubmit={handleJoinOrg}>
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="existingOrgEmail">Organization Email</Label>
                                        <Input
                                            id="existingOrgEmail"
                                            type="email"
                                            placeholder="org@example.com"
                                            value={existingOrgEmail}
                                            onChange={(e) => setExistingOrgEmail(e.target.value)}
                                            required
                                        />
                                    </div>
                                </div>
                                <Button type="submit" className="w-full mt-4" disabled={isPending}>
                                    {isPending ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin"/>
                                            Joining...
                                        </>
                                    ) : (
                                        'Join Organization'
                                    )}
                                </Button>
                            </form>
                        </TabsContent>
                    </Tabs>
                </CardContent>
            </Card>
        </div>
    );
};

export default JoinGroupForm;
