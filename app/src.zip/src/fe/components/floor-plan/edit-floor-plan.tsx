import React from "react";
import FloorPlanForm from "@/components/floor-plan/floor-plan-form";

interface EditFloorPlanProps {
    floorPlanId: string
}

const EditFloorPlan: React.FC<EditFloorPlanProps> = (props) => {
    return (<>
            <div className="bg-card mt-2 rounded-md p-6">
                <FloorPlanForm floorPlanId={props.floorPlanId}/>
            </div>
        </>
    )
}

export default EditFloorPlan
