import React from "react";
import FloorPlanForm from "@/components/floor-plan/floor-plan-form";

const AddFloorPlan: React.FC = () => {
    return (<>
            <div className="bg-card mt-2 rounded-md p-6">
                <FloorPlanForm />
            </div>
        </>
    )
}

export default AddFloorPlan
