'use client';

import React, { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
    Loader2,
    MapPin,
    ImageIcon,
    LayoutDashboard,
    Calendar,
    ArrowLeft,
    Camera,
    Server,
    Maximize2,
    TimerReset,
    Save,
    Grid,
    AlertCircle
} from 'lucide-react';
import { format } from 'date-fns';
import {useFloorPlanObjectModuleStore} from "@/store/floor-plan-object-module-store";

interface FloorPlanObjectPlacementProps {
    objectId: string;
}

const objectColors = {
    nvr: '#4ADE80',
    cctv: '#2563EB',
};

const FloorPlanObjectEdit: React.FC<FloorPlanObjectPlacementProps> = ({ objectId }) => {
    const router = useRouter();
    const {
        currentFloorPlanObject,
        isLoadingDetail,
        isUpdating,
        fetchFloorPlanObjectDetail,
        updateFloorPlanObject,
    } = useFloorPlanObjectModuleStore();

    const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
    const [isDragging, setIsDragging] = useState(false);

    useEffect(() => {
        fetchFloorPlanObjectDetail(objectId);
    }, [objectId, fetchFloorPlanObjectDetail]);

    useEffect(() => {
        if (currentFloorPlanObject?.position_x !== undefined && currentFloorPlanObject?.position_y !== undefined) {
            setPosition({
                x: (currentFloorPlanObject.position_x / (currentFloorPlanObject.floor_plan?.dimension_width || 1)) * 100,
                y: (currentFloorPlanObject.position_y / (currentFloorPlanObject.floor_plan?.dimension_height || 1)) * 100,
            });
        }
    }, [currentFloorPlanObject]);

    const handleImageClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;

        setPosition({
            x: Math.min(100, Math.max(0, x)),
            y: Math.min(100, Math.max(0, y)),
        });
    }, []);

    const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (!isDragging) return;

        const rect = e.currentTarget.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;

        setPosition({
            x: Math.min(100, Math.max(0, x)),
            y: Math.min(100, Math.max(0, y)),
        });
    }, [isDragging]);

    const handleSave = async () => {
        if (!position || !currentFloorPlanObject?.floor_plan) return;

        const pixelX = (position.x / 100) * (currentFloorPlanObject.floor_plan.dimension_width || 0);
        const pixelY = (position.y / 100) * (currentFloorPlanObject.floor_plan.dimension_height || 0);

        await updateFloorPlanObject(objectId, {
            position_x: pixelX,
            position_y: pixelY,
        });
        router.push(`/floor-plans/${currentFloorPlanObject?.floor_plan?.id}`);
    };

    const handleReset = () => {
        if (currentFloorPlanObject?.position_x !== undefined &&
            currentFloorPlanObject?.position_y !== undefined &&
            currentFloorPlanObject.floor_plan) {
            setPosition({
                x: (currentFloorPlanObject.position_x / currentFloorPlanObject.floor_plan.dimension_width!) * 100,
                y: (currentFloorPlanObject.position_y / currentFloorPlanObject.floor_plan.dimension_height!) * 100,
            });
        }
    };

    if (isLoadingDetail || !currentFloorPlanObject) {
        return (
            <div className="flex justify-center items-center min-h-[400px]">
                <Loader2 className="w-8 h-8 animate-spin" />
            </div>
        );
    }

    const getPixelPosition = () => {
        if (!position || !currentFloorPlanObject.floor_plan) return { x: 0, y: 0 };
        return {
            x: Math.round((position.x / 100) * (currentFloorPlanObject.floor_plan.dimension_width || 0)),
            y: Math.round((position.y / 100) * (currentFloorPlanObject.floor_plan.dimension_height || 0)),
        };
    };

    const pixelPosition = getPixelPosition();

    return (
        <div className="container py-8">
            <div className="mb-6 flex items-center justify-between">
                <Button
                    variant="outline"
                    onClick={() => router.push(`/floor-plans/${currentFloorPlanObject.floor_plan?.id}`)}
                >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Floor Plan
                </Button>
                <div className="space-x-2">
                    <Button
                        variant="outline"
                        onClick={handleReset}
                        disabled={isUpdating}
                    >
                        <TimerReset className="w-4 h-4 mr-2" />
                        Reset Position
                    </Button>
                    <Button
                        onClick={handleSave}
                        disabled={isUpdating}
                    >
                        {isUpdating ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Saving...
                            </>
                        ) : (
                            <>
                                <Save className="w-4 h-4 mr-2" />
                                Save Position
                            </>
                        )}
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg flex items-center">
                            <LayoutDashboard className="w-5 h-5 mr-2" />
                            Floor Plan Details
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <div className="text-sm text-muted-foreground flex items-center">
                                <ImageIcon className="w-4 h-4 mr-1" />
                                Name
                            </div>
                            <div className="font-medium">{currentFloorPlanObject.floor_plan?.name}</div>
                        </div>
                        <div>
                            <div className="text-sm text-muted-foreground flex items-center">
                                <Maximize2 className="w-4 h-4 mr-1" />
                                Dimensions
                            </div>
                            <div className="font-medium">
                                {currentFloorPlanObject.floor_plan?.dimension_width} × {currentFloorPlanObject.floor_plan?.dimension_height}px
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg flex items-center">
                            {currentFloorPlanObject.object_type === 'cctv' ? (
                                <Camera className="w-5 h-5 mr-2" />
                            ) : (
                                <Server className="w-5 h-5 mr-2" />
                            )}
                            Object Details
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <div className="text-sm text-muted-foreground flex items-center">
                                <AlertCircle className="w-4 h-4 mr-1" />
                                Type
                            </div>
                            <div className="font-medium flex items-center">
                                <div
                                    className="w-3 h-3 rounded-full mr-2"
                                    style={{ backgroundColor: objectColors[currentFloorPlanObject.object_type as keyof typeof objectColors] }}
                                />
                                {currentFloorPlanObject.object_type?.toUpperCase()}
                            </div>
                        </div>
                        <div>
                            <div className="text-sm text-muted-foreground">Name</div>
                            <div className="font-medium">{currentFloorPlanObject.object?.name}</div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg flex items-center">
                            <Grid className="w-5 h-5 mr-2" />
                            Position Information
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <div className="text-sm text-muted-foreground">Current Position</div>
                            <div className="font-medium">
                                x: {pixelPosition.x}px, y: {pixelPosition.y}px
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                                ({position?.x.toFixed(1)}%, {position?.y.toFixed(1)}%)
                            </div>
                        </div>
                        <div>
                            <div className="text-sm text-muted-foreground flex items-center">
                                <Calendar className="w-4 h-4 mr-1" />
                                Last Updated
                            </div>
                            <div className="font-medium">
                                {currentFloorPlanObject.updated_at &&
                                    format(new Date(currentFloorPlanObject.updated_at), 'PPp')}
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardContent className="p-4">
                    <div
                        className="relative w-full rounded-lg border overflow-hidden cursor-crosshair"
                        onClick={handleImageClick}
                        onMouseMove={handleMouseMove}
                        onMouseDown={() => setIsDragging(true)}
                        onMouseUp={() => setIsDragging(false)}
                        onMouseLeave={() => setIsDragging(false)}
                    >
                        {currentFloorPlanObject.floor_plan?.image_url && (
                            <img
                                src={currentFloorPlanObject.floor_plan.image_url}
                                alt={currentFloorPlanObject.floor_plan.name || 'Floor plan'}
                                className="w-full"
                            />
                        )}
                        {position && (
                            <div
                                className="absolute"
                                style={{
                                    left: `${position.x}%`,
                                    top: `${position.y}%`,
                                }}
                            >
                                <div className="relative -translate-x-1/2 -translate-y-1/2">
                                    <MapPin
                                        className="w-6 h-6"
                                        fill={objectColors[currentFloorPlanObject.object_type as keyof typeof objectColors]}
                                        color={objectColors[currentFloorPlanObject.object_type as keyof typeof objectColors]}
                                    />
                                    <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-white text-default-600 px-2 py-1 rounded-md shadow-sm text-xs whitespace-nowrap">
                                        {currentFloorPlanObject.object?.name}
                                        <br />
                                        <span className="text-muted-foreground">
                      {pixelPosition.x}px, {pixelPosition.y}px
                    </span>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default FloorPlanObjectEdit;
