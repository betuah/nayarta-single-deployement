'use client';

import React, {useEffect, useState} from 'react';
import {usePathname, useRouter} from 'next/navigation';
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    CardDescription,
} from '@/components/ui/card';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {Button} from '@/components/ui/button';
import {MoreVertical, MapPin, Edit, Trash, Loader2, Eye} from 'lucide-react';
import {DtoFloorPlanResponse} from '@/lib/api/data-contracts';
import {useFloorPlanModuleStore} from "@/store/floor-plan-module-store";
import Link from "next/link";
import {useFloorPlanObjectModuleStore} from "@/store/floor-plan-object-module-store";
import DeleteConfirmationDialog from "@/components/delete-confirmation-dialog";

interface FloorPlanDetailProps {
    floorPlanId: string;
}

// Define object type colors
const objectColors: Record<string, string> = {
    nvr: '#4ADE80',  // Green for NVR
    cctv: '#2563EB', // Blue for CCTV
};

interface ObjectPinProps {
    object: NonNullable<DtoFloorPlanResponse['objects']>[number];
    containerWidth: number;
    containerHeight: number;
    floorPlanId: string
}

const ObjectPin: React.FC<ObjectPinProps> = ({object, containerWidth, containerHeight, floorPlanId}) => {
    if (!object.position_x || !object.position_y) return null;
    const router = useRouter();

    return (
        <div
            className="absolute"
            style={{
                left: `${(object.position_x / containerWidth) * 100}%`,
                top: `${(object.position_y / containerHeight) * 100}%`,
            }}
        >
            <div className="relative -translate-x-1/2 -translate-y-1/2 group">
                <MapPin
                    className="w-6 h-6"
                    fill={objectColors[object.object_type as keyof typeof objectColors]}
                    color={objectColors[object.object_type as keyof typeof objectColors]}
                />
                <div
                    className="absolute top-full left-1/2 -translate-x-1/2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div
                        className="bg-background border text-foreground px-4 py-2 rounded-lg shadow-lg text-xs whitespace-nowrap space-y-2">
                        <div className="text-xs">
                            {object.object_info?.name}
                        </div>
                        <div className="border-t border-border pt-2 flex flex-col items-start space-y-2">
                            <Button
                                variant="soft"
                                size="xs"
                                className="w-full h-7 text-xs"
                                onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    router.push(object.object_type === "nvr" ? `/nvr/${object.object_id}` : `/camera/${object.object_id}`)
                                }}
                            >
                                <Eye className="w-3 h-3 mr-1"/>
                                Object Detail
                            </Button>
                            <Button
                                variant="soft"
                                size="xs"
                                className="w-full h-7 text-xs"
                                onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    router.push(`/floor-plans/${floorPlanId}/object/${object.id}/edit`)
                                }}
                            >
                                <Edit className="w-3 h-3 mr-1"/>
                                Edit Placement
                            </Button>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const FloorPlanDetail: React.FC<FloorPlanDetailProps> = ({floorPlanId}) => {
    const router = useRouter();
    const pathname = usePathname();
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);
    const [selectedObjectName, setSelectedObjectName] = useState<string>('');

    const {deleteFloorPlanObject, isDeleting} = useFloorPlanObjectModuleStore();

    const {
        currentFloorPlan,
        isLoadingDetail,
        fetchFloorPlanDetail,
        deleteFloorPlan,
    } = useFloorPlanModuleStore();

    useEffect(() => {
        fetchFloorPlanDetail(floorPlanId);
    }, [floorPlanId, fetchFloorPlanDetail]);

    const handleDelete = async (objectId: string, objectName: string) => {
        setSelectedObjectId(objectId);
        setSelectedObjectName(objectName);
        setDeleteDialogOpen(true);
    };

    const handleConfirmDelete = async () => {
        if (selectedObjectId) {
            await deleteFloorPlanObject(selectedObjectId);
            await fetchFloorPlanDetail(floorPlanId);
        }
    };


    const handleEditPlacement = (objectId: string) => {
        router.push(`/floor-plans/${floorPlanId}/object/${objectId}/edit`)
    };

    if (isLoadingDetail) {
        return (
            <div className="flex justify-center items-center min-h-[400px]">
                <Loader2 className="w-8 h-8 animate-spin"/>
            </div>
        );
    }

    if (!currentFloorPlan) {
        return (
            <div className="text-center py-8">
                <p className="text-muted-foreground">Floor plan not found</p>
            </div>
        );
    }

    return (
        <div className="container py-8">
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle className="text-2xl">{currentFloorPlan.name}</CardTitle>
                            <CardDescription>
                                Location: {currentFloorPlan.location?.name || 'N/A'}
                            </CardDescription>
                        </div>
                        <div className="flex flex-row space-x-2">
                            <Button
                                size="xs"
                                variant="outline"
                                onClick={() => {
                                    const params = new URLSearchParams();
                                    params.set("id", floorPlanId);
                                    router.push(`edit?${params.toString()}`);
                                }}
                            >
                                Edit Floor Plan
                            </Button>
                            <Link href={`/floor-plans/${floorPlanId}/add`}>
                                <Button variant="outline" size="xs">
                                    Add new placement
                                </Button>
                            </Link>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
                        <div>
                            <div className="text-sm text-muted-foreground">Dimensions</div>
                            <div>{currentFloorPlan.dimension_width}px × {currentFloorPlan.dimension_height}px</div>
                        </div>
                        <div>
                            <div className="text-sm text-muted-foreground">Total Objects</div>
                            <div>{currentFloorPlan.objects?.length || 0}</div>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="relative">
                        {currentFloorPlan.image_url && (
                            <img
                                src={currentFloorPlan.image_url}
                                alt={currentFloorPlan.name || 'Floor plan'}
                                className="w-full rounded-lg border"
                            />
                        )}
                        {currentFloorPlan.objects?.map((obj) => (
                            <ObjectPin
                                floorPlanId={floorPlanId}
                                key={obj.id}
                                object={obj}
                                containerWidth={currentFloorPlan.dimension_width || 1}
                                containerHeight={currentFloorPlan.dimension_height || 1}
                            />
                        ))}
                    </div>

                    <Card>
                        <CardHeader>
                            <CardTitle>Objects</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Name</TableHead>
                                        <TableHead>Type</TableHead>
                                        <TableHead>Position</TableHead>
                                        <TableHead>Action</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {currentFloorPlan.objects?.map((obj) => (
                                        <TableRow key={obj.id}>
                                            <TableCell>
                                                <Link
                                                    href={obj.object_type === "nvr" ? `/nvr/${obj.object_id}` : `/camera/${obj.object_id}`}>
                                                    <div className="underline">{obj.object_info?.name}</div>
                                                </Link>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <div
                                                        className="w-3 h-3 rounded-full"
                                                        style={{backgroundColor: objectColors[obj.object_type as keyof typeof objectColors]}}
                                                    />
                                                    {obj.object_type?.toUpperCase()}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                {obj.position_x!.toFixed(2)}, {obj.position_y!.toFixed(2)}
                                            </TableCell>
                                            <TableCell>
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="icon">
                                                            <MoreVertical className="w-4 h-4"/>
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuItem onClick={() => handleEditPlacement(obj.id!)}>
                                                            <Edit className="w-4 h-4 mr-2"/>
                                                            Edit Placement
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem
                                                            className="text-destructive"
                                                            onClick={() => handleDelete(obj.id!, obj.object_info?.name || 'this object')}
                                                        >
                                                            <Trash className="w-4 h-4 mr-2"/>
                                                            Delete Object
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </CardContent>
            </Card>
            <DeleteConfirmationDialog
                open={deleteDialogOpen}
                onClose={() => setDeleteDialogOpen(false)}
                onConfirm={handleConfirmDelete}
                message={`This will permanently delete ${selectedObjectName} from this floor plan and cannot be undone.`}
                toastMessage="Object successfully removed from floor plan"
            />
        </div>
    );
};

export default FloorPlanDetail;
