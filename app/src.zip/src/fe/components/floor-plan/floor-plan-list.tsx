'use client';

import React, {useEffect, useMemo, useState} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from '@/components/ui/card';
import {Skeleton} from '@/components/ui/skeleton';
import {DtoFloorPlanListResponse} from '@/lib/api/data-contracts';
import Image from 'next/image';
import {useFloorPlanModuleStore} from "@/store/floor-plan-module-store";
import {useLocationModuleStore} from "@/store/location-module-store";
import {ChevronLeftIcon, ChevronRightIcon, X} from "lucide-react";
import {Progress} from "@/components/ui/progress";
import {router} from "next/client";
import {useRouter, usePathname} from "next/navigation";
import {toast} from "react-toastify";
import DeleteConfirmationDialog from "@/components/delete-confirmation-dialog";
import Link from "next/link";


interface FloorPlanCardProps {
    floorPlan: NonNullable<DtoFloorPlanListResponse['items']>[number];
    onEdit: (id: string) => void;
    onDelete: (id: string) => void;
    isLoading: boolean,
}

const FloorPlanCard: React.FC<FloorPlanCardProps> = ({
                                                         floorPlan,
                                                         onEdit,
                                                         onDelete,
                                                         isLoading = false,
                                                     }) => (
    <Card className="w-full border">
        <CardHeader>
            <CardTitle className="text-lg">{floorPlan.name}</CardTitle>
            <CardDescription>
                Location: {floorPlan.location?.name || 'N/A'}
            </CardDescription>
        </CardHeader>
        <CardContent>
            <Link href={`/floor-plans/${floorPlan.id}`}>
                <div className="aspect-video relative mb-4 rounded-lg overflow-hidden">
                    {floorPlan.image_url ? (
                        <img
                            src={floorPlan.image_url}
                            alt={floorPlan.name || 'Floor plan'}
                            className="object-cover"
                        />
                    ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                            No image
                        </div>
                    )}
                </div>
            </Link>
            <div className="flex justify-between items-center">
                <div className="text-sm bg-default-200 rounded text-default-600 p-2 font-semibold">
                    Total Objects: {floorPlan.object_count || 0}
                </div>
                <div className="space-x-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onEdit(floorPlan.id!)}
                    >
                        Edit
                    </Button>
                    <Button
                        color="destructive"
                        isLoading={isLoading}
                        size="sm"
                        onClick={() => onDelete(floorPlan.id!)}
                    >
                        Delete
                    </Button>
                </div>
            </div>
        </CardContent>
    </Card>
);

const FloorPlanList: React.FC = () => {
    const {
        floorPlans,
        isLoading,
        search,
        locationId,
        offset,
        limit,
        setSearch,
        setLocationId,
        setOffset,
        fetchFloorPlans,
        deleteFloorPlan,
        isDeleting
    } = useFloorPlanModuleStore();
    const router = useRouter();
    const pathname = usePathname();

    const {locations, fetchLocations} = useLocationModuleStore();
    const [searchInput, setSearchInput] = useState('');

    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [selectedFloorPlan, setSelectedFloorPlan] = useState<NonNullable<DtoFloorPlanListResponse['items']>[number] | null>(null);

    // Clear search when component unmounts (user navigates away)
    useEffect(() => {
        return () => {
            setSearch(""); // Clear search on cleanup
        };
    }, [setSearch]);


    useEffect(() => {
        fetchFloorPlans();
        fetchLocations();
    }, [fetchFloorPlans, fetchLocations, search, locationId, offset, limit]);

    const totalPages = useMemo(() => {
        return Math.ceil((floorPlans?.total || 0) / limit);
    }, [floorPlans?.total, limit]);

    const currentPage = useMemo(() => {
        return Math.floor(offset / limit) + 1;
    }, [offset, limit]);

    const handlePageChange = (page: number) => {
        setOffset((page - 1) * limit);
    };

    const handleDeleteClick = (floorPlan: NonNullable<DtoFloorPlanListResponse['items']>[number]) => {
        setSelectedFloorPlan(floorPlan);
        setDeleteDialogOpen(true);
    };

    const handleDeleteConfirm = async () => {
        if (!selectedFloorPlan) return;

        if (selectedFloorPlan.object_count && selectedFloorPlan.object_count > 0) {
            toast.error("Cannot delete floor plan that has objects. Please remove all objects first.");
            setDeleteDialogOpen(false);
        } else {
            await deleteFloorPlan(selectedFloorPlan.id!);
        }


        setDeleteDialogOpen(false);
    };

    const handleSearchClick = () => {
        setSearch(searchInput);
    };

    const handleClearSearch = () => {
        setSearchInput('');
        setSearch('');
    };

    return (
        <>
            {isLoading && <Progress value={70} color="primary" isInfinite size="xs"/>}
            <div className="bg-card mt-2 rounded-md p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-2">
                    <div className="flex flex-row gap-x-2 items-center">
                        <div className="w-full">
                            <Input
                                type="text"

                                placeholder="Search floor plans..."
                                value={searchInput}
                                onChange={(e) => setSearchInput(e.target.value)}
                                size="lg"
                            />
                        </div>
                        <Button onClick={handleSearchClick}>
                            Search
                        </Button>
                    </div>
                    <div className="flex flex-row justify-end items-end">
                        <Select
                            value={locationId || ''}
                            onValueChange={(value) => setLocationId(value || null)}
                        >
                            <SelectTrigger className="max-w-sm">
                                <SelectValue placeholder="Filter by location"/>
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="">All locations</SelectItem>
                                {locations.map((location) => (
                                    <SelectItem key={location.id} value={location.id!}>
                                        {location.location_name}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                {isLoading ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-4">
                        {[...Array(6)].map((_, idx) => (
                            <Card key={idx} className="w-full">
                                <CardHeader>
                                    <Skeleton className="h-6 w-3/4"/>
                                    <Skeleton className="h-4 w-1/2"/>
                                </CardHeader>
                                <CardContent>
                                    <Skeleton className="aspect-video w-full mb-4"/>
                                    <div className="flex justify-between items-center">
                                        <Skeleton className="h-4 w-24"/>
                                        <div className="space-x-2">
                                            <Skeleton className="h-8 w-16 inline-block"/>
                                            <Skeleton className="h-8 w-16 inline-block"/>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                ) : (
                    <>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-4">
                            {floorPlans?.items?.map((floorPlan) => (
                                <FloorPlanCard
                                    key={floorPlan.id}
                                    floorPlan={floorPlan}
                                    isLoading={isDeleting && selectedFloorPlan?.id! === floorPlan.id}
                                    onEdit={(id) => {
                                        const params = new URLSearchParams();
                                        params.set("id", id);
                                        router.push(`${pathname}/edit?${params.toString()}`);
                                    }}
                                    onDelete={() => {
                                        handleDeleteClick(floorPlan)
                                    }}
                                />
                            ))}
                        </div>

                        {
                            floorPlans?.items?.length === 0 &&
                            <div className="w-full flex flex-row items-center justify-center mt-4">
                                No Floor Plan Found
                            </div>
                        }

                        {(
                            <div className="flex items-center gap-2 justify-end mx-4 py-8">
                                <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => handlePageChange(currentPage - 1)}
                                    disabled={currentPage === 1}
                                >
                                    <ChevronLeftIcon className="w-4 h-4"/>
                                </Button>

                                {[...Array(totalPages)].map((_, idx) => (
                                    <Button
                                        key={`floor-plan-page-${idx + 1}`}
                                        variant={currentPage === idx + 1 ? undefined : 'outline'}
                                        className="w-8 h-8"
                                        onClick={() => handlePageChange(idx + 1)}
                                    >
                                        {idx + 1}
                                    </Button>
                                ))}

                                <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => handlePageChange(currentPage + 1)}
                                    disabled={currentPage === totalPages}
                                >
                                    <ChevronRightIcon className="w-4 h-4"/>
                                </Button>
                            </div>
                        )}
                    </>
                )}
            </div>
            <DeleteConfirmationDialog
                open={deleteDialogOpen}
                onClose={() => setDeleteDialogOpen(false)}
                onConfirm={handleDeleteConfirm}
                message={
                    selectedFloorPlan?.object_count && selectedFloorPlan.object_count > 0
                        ? `This floor plan has ${selectedFloorPlan.object_count} objects. Please remove all objects before deleting.`
                        : "This action cannot be undone. This will permanently delete the floor plan."
                }
                defaultToast={false}
                toastMessage="Floor plan deleted successfully"
            />
        </>
    );
};

export default FloorPlanList;
