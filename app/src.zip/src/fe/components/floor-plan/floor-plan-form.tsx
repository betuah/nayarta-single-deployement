'use client';

import React, {useEffect} from 'react';
import {useForm} from 'react-hook-form';
import {zodResolver} from '@hookform/resolvers/zod';
import {z} from 'zod';
import {v4 as uuidv4} from 'uuid';
import {useFileUploadStore} from '@/store/file-upload-store';
import {useGroupModuleStore} from '@/store/group-module-store';
import {Input} from '@/components/ui/input';
import {Button} from '@/components/ui/button';
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from '@/components/ui/form';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import {Card, CardContent} from '@/components/ui/card';
import {Alert, AlertDescription} from "@/components/ui/alert";
import {useRouter} from 'next/navigation';
import {useLocationModuleStore} from "@/store/location-module-store";
import {useFloorPlanModuleStore} from "@/store/floor-plan-module-store";
import {Progress} from "@/components/ui/progress";
import {AlertTriangle, Layout} from 'lucide-react';

const formSchema = z.object({
    name: z.string().min(1, 'Name is required'),
    location_id: z.string().min(1, 'Location is required'),
    dimension_width: z.number().min(1, 'Width must be greater than 0'),
    dimension_height: z.number().min(1, 'Height must be greater than 0'),
    image_url: z.string().optional()
});

type FormValues = z.infer<typeof formSchema>;

interface FloorPlanFormProps {
    floorPlanId?: string;
}

const FloorPlanForm: React.FC<FloorPlanFormProps> = ({floorPlanId}) => {
    const router = useRouter();
    const {locations, fetchLocations} = useLocationModuleStore();
    const {
        createFloorPlan,
        updateFloorPlan,
        currentFloorPlan,
        fetchFloorPlanDetail,
        isLoadingDetail,
        isCreating,
        isUpdating
    } = useFloorPlanModuleStore();

    const {
        quotaFloorPlans,
        isLoadingQuotaFloorPlans,
        quotaFloorPlansError,
        fetchQuotaFloorPlans
    } = useGroupModuleStore();

    const {
        files,
        fileUrl,
        isUploading,
        handleFileDrop,
        createPresignedUrl,
        uploadFile,
        clearFiles,
    } = useFileUploadStore();

    const form = useForm<FormValues>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: '',
            location_id: '',
            dimension_width: 0,
            dimension_height: 0,
            image_url: '',
        },
    });

    useEffect(() => {
        useLocationModuleStore.setState({pageSize: 300});
        fetchLocations();

        // Only fetch quota for add mode
        if (!floorPlanId) {
            fetchQuotaFloorPlans();
        }

        if (floorPlanId) {
            fetchFloorPlanDetail(floorPlanId).then(r => {

            }).catch(e => {
                router.push("/floor-plans");
            });
        }
    }, [fetchLocations, floorPlanId, fetchFloorPlanDetail]);

    useEffect(() => {
        if (floorPlanId && currentFloorPlan) {
            form.reset({
                name: currentFloorPlan.name || '',
                location_id: currentFloorPlan.location?.id || '',
                dimension_width: currentFloorPlan.dimension_width || 0,
                dimension_height: currentFloorPlan.dimension_height || 0,
                image_url: currentFloorPlan.image_url || '',
            });
        }
    }, [currentFloorPlan, floorPlanId, form]);

    const getImageDimensions = (file: File): Promise<{ width: number; height: number }> => {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                URL.revokeObjectURL(img.src);
                resolve({width: img.width, height: img.height});
            };
            img.src = URL.createObjectURL(file);
        });
    };

    const handleImageChange = async (files: FileList | null) => {
        if (files && files.length > 0) {
            const file = files[0];
            handleFileDrop([file]);

            // Get image dimensions and update form
            const dimensions = await getImageDimensions(file);
            form.setValue('dimension_width', dimensions.width);
            form.setValue('dimension_height', dimensions.height);

            // Set a temporary local URL for validation
            form.setValue('image_url', URL.createObjectURL(file));
        }
    };

    const handleFileUpload = async (file: File) => {
        const uniqueId = uuidv4();
        const fileExtension = file.name.split('.').pop() || 'png';
        const fileName = `floor-plans/${uniqueId}_${file.name}`;

        const presignedData = await createPresignedUrl(fileName, {
            content_length: file.size,
            file_name: fileName,
        });

        if (presignedData) {
            const uploadSuccess = await uploadFile(presignedData, file);
            if (uploadSuccess && presignedData.file_url) {
                form.setValue('image_url', presignedData.file_url);
                return presignedData.file_url;
            }
        }
        return '';
    };

    const onSubmit = async (values: FormValues) => {
        try {
            if (files.length > 0) {
                const uploadedUrl = await handleFileUpload(files[0]);
                if (!uploadedUrl) {
                    throw new Error('Failed to upload image');
                }
                values.image_url = uploadedUrl;
            } else if (!values.image_url) {
                // If no new file and no existing image URL
                form.setError('image_url', {message: 'Image is required'});
                return;
            }

            if (floorPlanId) {
                await updateFloorPlan(floorPlanId, {
                    name: values.name,
                    dimension_width: values.dimension_width,
                    dimension_height: values.dimension_height,
                    image_url: values.image_url,
                });
            } else {
                await createFloorPlan({
                    name: values.name,
                    location_id: values.location_id,
                    dimension_width: values.dimension_width,
                    dimension_height: values.dimension_height,
                    image_url: values.image_url,
                });
                // Refresh quota after successful creation
                await fetchQuotaFloorPlans();
            }

            clearFiles();
            router.push('/floor-plans');
        } catch (error) {
            console.error('Error submitting form:', error);
        }
    };

    // Check if quota is exceeded (only for add mode)
    const isQuotaExceeded = !floorPlanId && quotaFloorPlans && quotaFloorPlans.remaining !== undefined && quotaFloorPlans.remaining <= 0;
    const hasQuotaData = quotaFloorPlans && quotaFloorPlans.used !== undefined;
    const shouldShowQuota = !floorPlanId && hasQuotaData;

    // Loading state for quota (only for add mode)
    if (!floorPlanId && isLoadingQuotaFloorPlans) {
        return (
            <div>
                <Card className="p-6">
                    <CardContent>
                        <div className="flex items-center justify-center py-8">
                            <div className="animate-spin rounded-full h-8 w-8 border-2 border-default-300 border-t-gray-900"></div>
                            <span className="ml-2">Loading quota information...</span>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    // Error state for quota (only for add mode)
    if (!floorPlanId && quotaFloorPlansError) {
        return (
            <div>
                <Card className="p-6">
                    <CardContent>
                        <Alert>
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>
                                Failed to load quota information: {quotaFloorPlansError}
                            </AlertDescription>
                        </Alert>
                        <Button
                            onClick={() => fetchQuotaFloorPlans()}
                            className="mt-4"
                            variant="outline"
                        >
                            Retry
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <>
            {isLoadingDetail && <Progress value={70} color="primary" isInfinite size="xs" />}
            <Card className="border p-5 mx-auto mt-2">
                {/* Quota Information - Only show for add mode */}
                {shouldShowQuota && (
                    <div className="mb-6 p-4 bg-default-50 border border-default-200 rounded-lg">
                        <div className="flex items-center gap-2 text-sm font-medium text-default-700 mb-2">
                            <Layout className="h-4 w-4" />
                            Floor Plan Quota Status
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                                <span className="text-default-600">Used:</span>
                                <span className="ml-1 font-medium">{quotaFloorPlans.used || 0}</span>
                            </div>
                            <div>
                                <span className="text-default-600">Max:</span>
                                <span className="ml-1 font-medium">{quotaFloorPlans.max || 0}</span>
                            </div>
                            <div>
                                <span className="text-default-600">Remaining:</span>
                                <span className={`ml-1 font-medium ${isQuotaExceeded ? 'text-red-600' : 'text-green-600'}`}>
                                    {quotaFloorPlans.remaining || 0}
                                </span>
                            </div>
                            <div>
                                <span className="text-default-600">Usage:</span>
                                <span className="ml-1 font-medium">{quotaFloorPlans.percentage || 0}%</span>
                            </div>
                        </div>
                    </div>
                )}

                {/* Quota Exceeded Alert - Only show for add mode */}
                {isQuotaExceeded && (
                    <Alert className="mb-6 border-red-200 bg-red-50">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <AlertDescription className="text-red-800">
                            <strong>Floor Plan quota exceeded!</strong> You have reached the maximum number of floor plans
                            ({quotaFloorPlans.max}) for your organization. Please contact your administrator to
                            increase the quota or remove some floor plans before adding new ones.
                        </AlertDescription>
                    </Alert>
                )}

                {/* Form Content - Hide if quota is exceeded for add mode */}
                {!(!floorPlanId && isQuotaExceeded) && (
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                            <FormField
                                control={form.control}
                                name="name"
                                render={({field}) => (
                                    <FormItem>
                                        <FormLabel>Name</FormLabel>
                                        <FormControl>
                                            <Input {...field} />
                                        </FormControl>
                                        <FormMessage/>
                                    </FormItem>
                                )}
                            />

                            {!floorPlanId && (
                                <FormField
                                    control={form.control}
                                    name="location_id"
                                    render={({field}) => (
                                        <FormItem>
                                            <FormLabel>Location</FormLabel>
                                            <Select
                                                onValueChange={field.onChange}
                                                defaultValue={field.value}
                                            >
                                                <FormControl>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select a location"/>
                                                    </SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    {locations.map((location) => (
                                                        <SelectItem
                                                            key={location.id}
                                                            value={location.id || ''}
                                                        >
                                                            {location.location_name}
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                            <FormMessage/>
                                        </FormItem>
                                    )}
                                />
                            )}

                            <FormField
                                control={form.control}
                                name="image_url"
                                render={({field}) => (
                                    <FormItem>
                                        <FormLabel>Floor Plan Image</FormLabel>
                                        <FormControl>
                                            <div className="space-y-4">
                                                <Input
                                                    type="file"
                                                    onChange={(e) => handleImageChange(e.target.files)}
                                                    disabled={isUploading}
                                                    accept="image/*"
                                                />
                                                {field.value && (
                                                    <div className="mt-2">
                                                        <img
                                                            src={field.value}
                                                            alt="Floor plan preview"
                                                            className="max-w-sm rounded-lg"
                                                        />
                                                    </div>
                                                )}
                                            </div>
                                        </FormControl>
                                        <FormMessage/>
                                    </FormItem>
                                )}
                            />

                            <div className="grid grid-cols-2 gap-4">
                                <FormField
                                    control={form.control}
                                    name="dimension_width"
                                    render={({field}) => (
                                        <FormItem>
                                            <FormLabel>Width (px)</FormLabel>
                                            <FormControl>
                                                <Input
                                                    type="number"
                                                    {...field}
                                                    disabled
                                                    className="bg-muted"
                                                />
                                            </FormControl>
                                            <FormMessage/>
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="dimension_height"
                                    render={({field}) => (
                                        <FormItem>
                                            <FormLabel>Height (px)</FormLabel>
                                            <FormControl>
                                                <Input
                                                    type="number"
                                                    {...field}
                                                    disabled
                                                    className="bg-muted"
                                                />
                                            </FormControl>
                                            <FormMessage/>
                                        </FormItem>
                                    )}
                                />
                            </div>

                            <div className="flex justify-end space-x-4">
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => router.push('/floor-plans')}
                                >
                                    Cancel
                                </Button>
                                <Button type="submit" isLoading={isUploading || isUpdating || isCreating}>
                                    {isUploading ? 'Uploading...' : floorPlanId ? 'Update' : 'Create'}
                                </Button>
                            </div>
                        </form>
                    </Form>
                )}
            </Card>
        </>
    );
};

export default FloorPlanForm;
