'use client';

import React, {useEffect, useState, useCallback} from 'react';
import {useRouter} from 'next/navigation';
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    CardDescription,
} from '@/components/ui/card';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import {Button} from '@/components/ui/button';
import {
    Loader2,
    MapPin,
    Video,
    Server,
    AlertCircle,
    CheckCircle2,
} from 'lucide-react';
import {useUserStore} from '@/store/user-store';
import {Alert, AlertDescription} from '@/components/ui/alert';
import {Skeleton} from '@/components/ui/skeleton';
import {useFloorPlanModuleStore} from "@/store/floor-plan-module-store";
import {useFloorPlanObjectModuleStore} from "@/store/floor-plan-object-module-store";

interface FloorPlanObjectCreateProps {
    floorPlanId: string;
}

const objectColors = {
    nvr: '#4ADE80',
    cctv: '#2563EB',
};

const objectIcons = {
    nvr: Server,
    cctv: Video,
};

const FloorPlanObjectCreate: React.FC<FloorPlanObjectCreateProps> = ({floorPlanId}) => {
    const router = useRouter();
    const {selectedGroupMember} = useUserStore();
    const {currentFloorPlan, isLoadingDetail, fetchFloorPlanDetail} = useFloorPlanModuleStore();
    const {
        availableCCTVs,
        availableNVRs,
        isLoadingAvailableCCTVs,
        isLoadingAvailableNVRs,
        isCreating,
        fetchAvailableCCTVs,
        fetchAvailableNVRs,
        createFloorPlanObject,
        resetAvailableCCTVs,
        resetAvailableNVRs,
    } = useFloorPlanObjectModuleStore();

    const [objectType, setObjectType] = useState<'nvr' | 'cctv' | null>(null);
    const [selectedObjectId, setSelectedObjectId] = useState<string>('');
    const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [imageElement, setImageElement] = useState<HTMLImageElement | null>(null);

    useEffect(() => {
        fetchFloorPlanDetail(floorPlanId);
    }, [floorPlanId, fetchFloorPlanDetail]);

    useEffect(() => {
        if (!selectedGroupMember?.group_id || !floorPlanId) return;

        if (objectType === 'cctv') {
            fetchAvailableCCTVs(selectedGroupMember.group_id, floorPlanId);
            resetAvailableNVRs();
            setSelectedObjectId('');
        } else if (objectType === 'nvr') {
            fetchAvailableNVRs(selectedGroupMember.group_id, floorPlanId);
            resetAvailableCCTVs();
            setSelectedObjectId('');
        }
    }, [objectType, selectedGroupMember?.group_id, floorPlanId]);

    useEffect(() => {
        if (currentFloorPlan?.image_url) {
            const img = new Image();
            img.src = currentFloorPlan.image_url;
            img.onload = () => setImageElement(img);
        }
    }, [currentFloorPlan?.image_url]);

    const calculatePosition = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (!imageElement || !currentFloorPlan?.dimension_width || !currentFloorPlan?.dimension_height) return null;

        const rect = e.currentTarget.getBoundingClientRect();
        const scaleX = currentFloorPlan.dimension_width / rect.width;
        const scaleY = currentFloorPlan.dimension_height / rect.height;

        const x = (e.clientX - rect.left) * scaleX;
        const y = (e.clientY - rect.top) * scaleY;

        return {
            x: Math.min(currentFloorPlan.dimension_width, Math.max(0, x)),
            y: Math.min(currentFloorPlan.dimension_height, Math.max(0, y)),
        };
    }, [imageElement, currentFloorPlan]);

    const handleImageClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        const newPosition = calculatePosition(e);
        if (newPosition) setPosition(newPosition);
    }, [calculatePosition]);

    const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (!isDragging) return;
        const newPosition = calculatePosition(e);
        if (newPosition) setPosition(newPosition);
    }, [isDragging, calculatePosition]);

    const handleSave = async () => {
        if (!position || !objectType || !selectedObjectId) return;

        await createFloorPlanObject({
            floor_plan_id: floorPlanId,
            object_id: selectedObjectId,
            object_type: objectType,
            position_x: position.x,
            position_y: position.y,
        });
        router.push(`/floor-plans/${floorPlanId}`);
    };

    const ObjectIcon = objectType ? objectIcons[objectType] : null;

    const availableObjects = objectType === 'cctv'
        ? availableCCTVs?.items
        : objectType === 'nvr'
            ? availableNVRs?.items
            : [];

    const isLoading = isLoadingDetail || isLoadingAvailableCCTVs || isLoadingAvailableNVRs;

    if (isLoadingDetail) {
        return (
            <div className="container py-8">
                <Card>
                    <CardHeader>
                        <Skeleton className="h-8 w-64"/>
                        <Skeleton className="h-4 w-48 mt-2"/>
                    </CardHeader>
                    <CardContent>
                        <Skeleton className="h-[400px] w-full"/>
                    </CardContent>
                </Card>
            </div>
        );
    }

    if (!currentFloorPlan) {
        return (
            <div className="text-center py-8">
                <p className="text-muted-foreground">Floor plan not found</p>
            </div>
        );
    }

    return (
        <div className="container py-8">
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle className="text-2xl">Add Object to Floor Plan</CardTitle>
                            <CardDescription>
                                Floor Plan: {currentFloorPlan.name}
                            </CardDescription>
                        </div>
                        <div className="space-x-2 flex flex-row items-center">
                            <Button
                                variant="outline"
                                onClick={() => router.push(`/floor-plans/${floorPlanId}`)}
                            >
                                Cancel
                            </Button>
                            <Button
                                onClick={handleSave}
                                disabled={!position || !objectType || !selectedObjectId || isCreating}
                            >
                                {isCreating ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin"/>
                                        Creating...
                                    </>
                                ) : (
                                    <>
                                        <CheckCircle2 className="w-4 h-4 mr-2"/>
                                        Create Object
                                    </>
                                )}
                            </Button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="text-sm font-medium mb-2 block">Object Type</label>
                            <Select
                                value={objectType || ''}
                                onValueChange={(value: 'nvr' | 'cctv') => {
                                    setObjectType(value);
                                    setSelectedObjectId('');
                                }}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Select object type"/>
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="nvr">
                                        <div className="flex items-center">
                                            <Server className="w-4 h-4 mr-2"/>
                                            NVR
                                        </div>
                                    </SelectItem>
                                    <SelectItem value="cctv">
                                        <div className="flex items-center">
                                            <Video className="w-4 h-4 mr-2"/>
                                            CCTV
                                        </div>
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div>
                            <label className="text-sm font-medium mb-2 block">
                                Select Object
                                {(isLoadingAvailableCCTVs || isLoadingAvailableNVRs) && (
                                    <Loader2 className="w-4 h-4 ml-2 inline animate-spin"/>
                                )}
                            </label>
                            <Select
                                value={selectedObjectId}
                                onValueChange={setSelectedObjectId}
                                disabled={!objectType || isLoadingAvailableCCTVs || isLoadingAvailableNVRs}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder={
                                        isLoadingAvailableCCTVs || isLoadingAvailableNVRs
                                            ? 'Loading available objects...'
                                            : objectType
                                                ? `Select ${objectType.toUpperCase()}`
                                                : 'Select object type first'
                                    }/>
                                </SelectTrigger>
                                <SelectContent>
                                    {availableObjects?.map((obj) => (
                                        <SelectItem key={obj.id} value={obj.id!}>
                                            {obj.name}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            {objectType && selectedObjectId === '' && (
                                (objectType === 'cctv' && !isLoadingAvailableCCTVs && availableCCTVs?.items?.length === 0) ||
                                (objectType === 'nvr' && !isLoadingAvailableNVRs && availableNVRs?.items?.length === 0)
                            ) && (
                                <Alert className="my-4">
                                    <AlertCircle className="h-4 w-4" />
                                    <AlertDescription>
                                        There are no more unassigned {objectType === 'cctv' ? 'cameras' : 'NVRs'} in the same location as the floor plan. Please add them first.
                                    </AlertDescription>
                                </Alert>
                            )}
                        </div>
                    </div>

                    {!position && objectType && selectedObjectId && (
                        <Alert>
                            <AlertCircle className="h-4 w-4"/>
                            <AlertDescription>
                                Click on the floor plan to place the object, or drag to adjust the position
                            </AlertDescription>
                        </Alert>
                    )}

                    <div
                        className="relative w-full rounded-lg border overflow-hidden cursor-crosshair"
                        onClick={handleImageClick}
                        onMouseMove={handleMouseMove}
                        onMouseDown={() => setIsDragging(true)}
                        onMouseUp={() => setIsDragging(false)}
                        onMouseLeave={() => setIsDragging(false)}
                    >
                        {currentFloorPlan.image_url && (
                            <img
                                src={currentFloorPlan.image_url}
                                alt={currentFloorPlan.name || 'Floor plan'}
                                className="w-full"
                            />
                        )}
                        {position && objectType && selectedObjectId && (
                            <div
                                className="absolute"
                                style={{
                                    left: `${(position.x / currentFloorPlan.dimension_width!) * 100}%`,
                                    top: `${(position.y / currentFloorPlan.dimension_height!) * 100}%`,
                                }}
                            >
                                <div className="relative -translate-x-1/2 -translate-y-1/2">
                                    <MapPin
                                        className="w-6 h-6"
                                        fill={objectColors[objectType]}
                                        color={objectColors[objectType]}
                                    />
                                    <div
                                        className="absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-white px-2 py-1 rounded-md shadow-sm text-xs whitespace-nowrap">
                                        {availableObjects?.find(obj => obj.id === selectedObjectId)?.name}
                                        <br/>
                                        <span className="text-muted-foreground">
                      x: {Math.round(position.x)}, y: {Math.round(position.y)}
                    </span>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default FloorPlanObjectCreate;
