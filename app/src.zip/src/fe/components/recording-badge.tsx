import React from 'react';
import {AlertTriangle, CircleDot} from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { differenceInMinutes, format, parseISO } from 'date-fns';

interface RecordingBadgeProps {
    last_checked: string
    check_interval: number
    recording_status?: number
}

export const RecordingBadge: React.FC<RecordingBadgeProps> = ({ last_checked, check_interval, recording_status }) => {
    const isStatusOutdated = () => {
        if (!last_checked || !check_interval) return false;
        const lastCheckedDate = parseISO(last_checked);
        const minutesSinceLastCheck = differenceInMinutes(new Date(), lastCheckedDate);
        return minutesSinceLastCheck > check_interval;
    };

    const formatDate = (dateString: string) => {
        try {
            return format(parseISO(dateString), 'dd MMM yyyy HH:mm');
        } catch {
            return dateString;
        }
    };

    const outdated = isStatusOutdated();
    const isRecording = recording_status === 1;

    return (
        <TooltipProvider>
            <Tooltip>
                <TooltipTrigger asChild>
                    <div className="flex items-center">
                        <Badge
                            color={outdated ? "warning" : isRecording ? "success" : "default"}
                            className="capitalize flex items-center gap-1"
                        >
                            {isRecording && <CircleDot className="h-3 w-3 text-white" />}
                            {outdated ? "Inactive" : isRecording ? "Recording" : "Inactive"}
                        </Badge>
                        {outdated && (
                            <AlertTriangle className="h-4 w-4 ml-2 text-yellow-500" />
                        )}
                    </div>
                </TooltipTrigger>
                <TooltipContent>
                    {outdated
                        ? "Recording status may be outdated. Last check exceeded the expected interval."
                        : `Last checked: ${formatDate(last_checked || '')}`}
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>
    );
};
