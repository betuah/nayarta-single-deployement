'use client';

import React, {useState, useEffect} from 'react';
import {format} from 'date-fns';
import {CalendarIcon, Search, Download, Eye, ChevronDown} from 'lucide-react';
import {DateRange} from 'react-day-picker';

import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Calendar} from '@/components/ui/calendar';
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from '@/components/ui/popover';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table';
import {Badge} from '@/components/ui/badge';
import {Skeleton} from '@/components/ui/skeleton';
import {cn, formatDate} from '@/lib/utils';

import {useAnalyticModuleStore} from '@/store/analytic-module-store';
import {useFileDownload} from '@/hooks/use-file-download';
import {ReportsNotificationsListParams} from '@/lib/api/data-contracts';
import Link from "next/link";

interface AnalyticNotificationsProps {
    analyticType: ReportsNotificationsListParams['analytic_type'];
    title?: string;
}

const AnalyticNotifications: React.FC<AnalyticNotificationsProps> = ({
                                                                         analyticType,
                                                                         title = 'Analytic Notifications'
                                                                     }) => {
    const {
        notificationListData,
        isLoadingNotificationList,
        notificationListError,
        fetchNotificationList
    } = useAnalyticModuleStore();

    const {downloadFile, isDownloading} = useFileDownload();

    // State for filters
    const [searchInput, setSearchInput] = useState<string>('');
    const [searchQuery, setSearchQuery] = useState<string>('');
    const [dateRange, setDateRange] = useState<DateRange | undefined>();
    const [sortBy, setSortBy] = useState<'created_at' | 'camera_name'>('created_at');
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
    const [currentPage, setCurrentPage] = useState<number>(1);
    const pageSize = 10;

    // Fetch data when filters change
    useEffect(() => {
        const params: Omit<ReportsNotificationsListParams, 'group_id'> = {
            analytic_type: analyticType,
            search: searchQuery || undefined,
            start_date: dateRange?.from ? format(dateRange.from, 'yyyy-MM-dd') : undefined,
            end_date: dateRange?.to ? format(dateRange.to, 'yyyy-MM-dd') : undefined,
            sort_by: sortBy,
            sort_order: sortOrder,
            page: currentPage,
            size: pageSize
        };

        fetchNotificationList(params);
    }, [searchQuery, dateRange, sortBy, sortOrder, currentPage, analyticType]);

    // Handle search - only trigger on button click
    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        setSearchQuery(searchInput);
        setCurrentPage(1);
    };

    // Handle download
    const handleDownload = async (notification: any) => {
        if (!notification.download_url) return;

        // Generate filename from analytic name and timestamp
        const timestamp = notification.created_at
            ? format(new Date(notification.created_at), 'yyyyMMdd_HHmmss')
            : 'unknown';
        const fileName = `${notification.analytic_name || 'analytic'}_${timestamp}.jpg`;

        await downloadFile(notification.download_url, fileName, 'object_storage');
    };

    // Handle view
    const handleView = (analyticId?: string) => {
        if (analyticId) {
            console.log('View analytic:', analyticId);
        }
    };

    // Format timestamp
    const formatTimestamp = (timestamp?: string) => {
        if (!timestamp) return '-';
        try {
            return format(new Date(timestamp), 'dd/MM/yyyy HH:mm:ss');
        } catch {
            return timestamp;
        }
    };

    // Reset filters
    const resetFilters = () => {
        setSearchInput('');
        setSearchQuery('');
        setDateRange(undefined);
        setSortBy('created_at');
        setSortOrder('desc');
        setCurrentPage(1);
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">{title} Notifications</h2>
                <Button variant="outline" onClick={resetFilters}>
                    Reset Filters
                </Button>
            </div>

            {/* Filters */}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                {/* Search */}
                <form onSubmit={handleSearch} className="flex gap-2 flex-1 max-w-md">
                    <Input
                        placeholder="Search by camera name, location, or message..."
                        value={searchInput}
                        onChange={(e) => setSearchInput(e.target.value)}
                        className="flex-1"
                    />
                    <Button type="submit" size="icon">
                        <Search className="h-4 w-4"/>
                    </Button>
                </form>

                <div className="flex gap-2">
                    {/* Date Range Picker */}
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button
                                variant="outline"
                                className={cn(
                                    'w-[240px] justify-start text-left font-normal',
                                    !dateRange && 'text-muted-foreground'
                                )}
                            >
                                <CalendarIcon className="mr-2 h-4 w-4"/>
                                {dateRange?.from ? (
                                    dateRange.to ? (
                                        <>
                                            {format(dateRange.from, 'dd/MM/yyyy')} -{' '}
                                            {format(dateRange.to, 'dd/MM/yyyy')}
                                        </>
                                    ) : (
                                        format(dateRange.from, 'dd/MM/yyyy')
                                    )
                                ) : (
                                    'Pick a date range'
                                )}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="end">
                            <Calendar
                                initialFocus
                                mode="range"
                                defaultMonth={dateRange?.from}
                                selected={dateRange}
                                onSelect={setDateRange}
                                numberOfMonths={2}
                            />
                        </PopoverContent>
                    </Popover>

                    {/* Sort Options */}
                    <Select
                        value={`${sortBy}-${sortOrder}`}
                        onValueChange={(value) => {
                            const [field, order] = value.split('-') as [typeof sortBy, typeof sortOrder];
                            setSortBy(field);
                            setSortOrder(order);
                            setCurrentPage(1);
                        }}
                    >
                        <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder="Sort"/>
                            <ChevronDown className="ml-2 h-4 w-4"/>
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="created_at-desc">Newest First</SelectItem>
                            <SelectItem value="created_at-asc">Oldest First</SelectItem>
                            <SelectItem value="camera_name-asc">Camera A-Z</SelectItem>
                            <SelectItem value="camera_name-desc">Camera Z-A</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>

            {/* Error State */}
            {notificationListError && (
                <div className="rounded-md bg-destructive/15 p-3">
                    <p className="text-sm text-destructive">{notificationListError}</p>
                </div>
            )}

            {/* Table */}
            <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Timestamp</TableHead>
                            <TableHead>Camera</TableHead>
                            <TableHead>Location</TableHead>
                            <TableHead>Floor Plan</TableHead>
                            <TableHead>Message</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoadingNotificationList ? (
                            // Loading skeletons
                            Array.from({length: pageSize}).map((_, index) => (
                                <TableRow key={`loading-${index}`}>
                                    <TableCell><Skeleton className="h-4 w-32"/></TableCell>
                                    <TableCell><Skeleton className="h-4 w-24"/></TableCell>
                                    <TableCell><Skeleton className="h-4 w-24"/></TableCell>
                                    <TableCell><Skeleton className="h-4 w-20"/></TableCell>
                                    <TableCell><Skeleton className="h-4 w-40"/></TableCell>
                                    <TableCell className="text-right">
                                        <div className="flex justify-end gap-2">
                                            <Skeleton className="h-8 w-8"/>
                                            <Skeleton className="h-8 w-8"/>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : notificationListData?.analytics?.length ? (
                            // Data rows - Fixed key issue by adding index to ensure uniqueness
                            notificationListData.analytics.map((notification, index) => (
                                <TableRow key={`${notification.analytic_id}-${index}`}>
                                    <TableCell className="font-medium">
                                        {formatDate(notification.created_at!)}
                                    </TableCell>
                                    <TableCell>{notification.camera_name || '-'}</TableCell>
                                    <TableCell>{notification.location_name || '-'}</TableCell>
                                    <TableCell>
                                        {notification.floor_plan_name ? (
                                            <Badge variant="soft">{notification.floor_plan_name}</Badge>
                                        ) : (
                                            '-'
                                        )}
                                    </TableCell>
                                    <TableCell className="max-w-xs truncate" title={notification.message}>
                                        {notification.message || '-'}
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <div className="flex justify-end gap-2">
                                            <Button
                                                variant="outline"
                                                size="icon"
                                                onClick={() => handleDownload(notification)}
                                                disabled={!notification.download_url || isDownloading}
                                                title="Download"
                                            >
                                                <Download className="h-4 w-4"/>
                                            </Button>
                                            <Link href={`/file-storage/video/${notification.file_id}`}>
                                                <Button
                                                    variant="outline"
                                                    size="icon"
                                                    // onClick={() => handleView(notification.analytic_id)}
                                                    title="View"
                                                >
                                                    <Eye className="h-4 w-4"/>
                                                </Button>
                                            </Link>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : (
                            // Empty state
                            <TableRow>
                                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                                    <div className="flex flex-row items-center justify-center w-full">
                                        No notifications found
                                    </div>
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            {/* Pagination */}
            {notificationListData && notificationListData.total! > pageSize && (
                <div className="flex items-center justify-between">
                    <p className="text-sm text-muted-foreground">
                        Showing {((currentPage - 1) * pageSize) + 1} to{' '}
                        {Math.min(currentPage * pageSize, notificationListData.total!)} of{' '}
                        {notificationListData.total} results
                    </p>
                    <div className="flex gap-2">
                        <Button
                            variant="outline"
                            onClick={() => setCurrentPage(currentPage - 1)}
                            disabled={currentPage === 1}
                        >
                            Previous
                        </Button>
                        <Button
                            variant="outline"
                            onClick={() => setCurrentPage(currentPage + 1)}
                            disabled={currentPage * pageSize >= notificationListData.total!}
                        >
                            Next
                        </Button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AnalyticNotifications;
