import React, {useEffect, useState} from 'react';
import {Card, CardContent, CardHeader, CardTitle} from '@/components/ui/card';
import {Button} from '@/components/ui/button';
import {Calendar} from '@/components/ui/calendar';
import {Popover, PopoverContent, PopoverTrigger} from '@/components/ui/popover';
import {Calendar as CalendarIcon, RefreshCw} from 'lucide-react';
import {format} from 'date-fns';
import {ResourceFilter} from '@/components/resource-filter';
import {useAnalyticResultModuleStore} from '@/store/analytic-result-module-store';
import dynamic from 'next/dynamic';
import {cn} from '@/lib/utils';

// Dynamic import for ApexCharts to avoid SSR issues
const Chart = dynamic(() => import('react-apexcharts'), {ssr: false});

type AnalyticType =
    | "different-direction"
    | "fire-smoke"
    | "people-converge"
    | "person-running"
    | "restricted-area"
    | "unattended-object"
    | "health-safety-environment"
    | "illegal-parking";

interface AlertNotificationChartProps {
    analyticType: AnalyticType;
    className?: string;
}

// Configuration for each analytic type
const analyticConfig = {
    "different-direction": {
        title: "Different Direction Alerts",
        description: "Hourly alerts for different direction detection",
        color: "#ef4444",
        fetchMethod: "fetchDifferentDirectionChart",
        dataKey: "differentDirectionChartData",
        loadingKey: "isLoadingDifferentDirectionChart",
        errorKey: "differentDirectionChartError"
    },
    "fire-smoke": {
        title: "Fire & Smoke Alerts",
        description: "Hourly alerts for fire and smoke detection",
        color: "#f97316",
        fetchMethod: "fetchFireSmokeChart",
        dataKey: "fireSmokeChartData",
        loadingKey: "isLoadingFireSmokeChart",
        errorKey: "fireSmokeChartError"
    },
    "people-converge": {
        title: "People Converge Alerts",
        description: "Hourly alerts for people convergence detection",
        color: "#8b5cf6",
        fetchMethod: "fetchPeopleConvergeChart",
        dataKey: "peopleConvergeChartData",
        loadingKey: "isLoadingPeopleConvergeChart",
        errorKey: "peopleConvergeChartError"
    },
    "person-running": {
        title: "Person Running Alerts",
        description: "Hourly alerts for person running detection",
        color: "#06b6d4",
        fetchMethod: "fetchPersonRunningChart",
        dataKey: "personRunningChartData",
        loadingKey: "isLoadingPersonRunningChart",
        errorKey: "personRunningChartError"
    },
    "health-safety-environment": {
        title: "Health Safety Environment Alerts",
        description: "Hourly alerts for Health Safety Environment detection",
        color: "#5ac719",
        fetchMethod: "fetchHealthSafetyEnvironmentChart",
        dataKey: "healthSafetyEnvironmentChartData",
        loadingKey: "isLoadingHealthSafetyEnvironmentChart",
        errorKey: "healthSafetyEnvironmentChartError"
    },
    "restricted-area": {
        title: "Restricted Area Alerts",
        description: "Hourly alerts for restricted area violations",
        color: "#dc2626",
        fetchMethod: "fetchRestrictedAreaChart",
        dataKey: "restrictedAreaChartData",
        loadingKey: "isLoadingRestrictedAreaChart",
        errorKey: "restrictedAreaChartError"
    },
    "illegal-parking": {
        title: "Illegal Parking Alerts",
        description: "Hourly alerts for illegal parking on area",
        color: "#dc2626",
        fetchMethod: "fetchIllegalParkingChart",
        dataKey: "illegalParkingChartData",
        loadingKey: "isLoadingIllegalParkingChart",
        errorKey: "illegalParkingChartError"
    },
    "unattended-object": {
        title: "Unattended Object Alerts",
        description: "Hourly alerts for unattended object detection",
        color: "#16a34a",
        fetchMethod: "fetchUnattendedObjectChart",
        dataKey: "unattendedObjectChartData",
        loadingKey: "isLoadingUnattendedObjectChart",
        errorKey: "unattendedObjectChartError"
    }
};

export const AlertNotificationChart: React.FC<AlertNotificationChartProps> = ({
                                                                                  analyticType,
                                                                                  className
                                                                              }) => {
    const [selectedDate, setSelectedDate] = useState<Date>(new Date());
    const [filters, setFilters] = useState<{
        locationId?: string;
        floorPlanId?: string;
        cameraId?: string;
    }>({});

    const store = useAnalyticResultModuleStore();
    const config = analyticConfig[analyticType];

    // Get data, loading state, and error from store using dynamic keys
    const chartData = store[config.dataKey as keyof typeof store] as any;
    const isLoading = store[config.loadingKey as keyof typeof store] as boolean;
    const error = store[config.errorKey as keyof typeof store] as string | null;

    // Get the fetch method dynamically
    const fetchMethod = store[config.fetchMethod as keyof typeof store] as Function;

    // Fetch data function
    const fetchData = async () => {
        if (!fetchMethod) return;

        const params = {
            date: format(selectedDate, 'yyyy-MM-dd'),
            ...(filters.locationId && {location_id: filters.locationId}),
            ...(filters.floorPlanId && {floor_plan_id: filters.floorPlanId}),
            ...(filters.cameraId && {cctv_id: filters.cameraId}),
        };

        await fetchMethod(params);
    };

    // Fetch data when dependencies change
    useEffect(() => {
        fetchData();
    }, [selectedDate, filters.locationId, filters.floorPlanId, filters.cameraId, analyticType]);

    // Handle filter changes
    const handleFilterChange = (newFilters: {
        locationId?: string;
        floorPlanId?: string;
        cameraId?: string;
    }) => {
        setFilters({
            locationId: newFilters.locationId,
            floorPlanId: newFilters.floorPlanId,
            cameraId: newFilters.cameraId,
        });
    };

    // Chart configuration
    const chartOptions = {
        chart: {
            type: 'area' as const,
            height: 350,
            toolbar: {
                show: false,
            },
            zoom: {
                enabled: false,
            },
        },
        colors: [config.color],
        dataLabels: {
            enabled: false,
        },
        stroke: {
            curve: 'smooth' as const,
            width: 2,
        },
        fill: {
            type: 'gradient',
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.4,
                opacityTo: 0.1,
                stops: [0, 90, 100],
            },
        },
        xaxis: {
            categories: chartData?.labels || [],
            title: {
                text: 'Hours',
            },
        },
        yaxis: {
            title: {
                text: 'Alert Count',
            },
            min: 0,
        },
        grid: {
            borderColor: '#e5e7eb',
            strokeDashArray: 3,
        },
        tooltip: {
            theme: 'light',
            x: {
                format: 'HH:mm',
            },
        },
    };

    const series = [
        {
            name: 'Alerts',
            data: chartData?.data || [],
        },
    ];

    return (
        <Card className={cn("w-full border", className)}>
            <CardHeader className="pb-4">
                <div className="flex flex-col space-y-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <h3 className="text-lg font-semibold">
                                {config.title} Chart
                            </h3>
                            <p className="text-sm text-muted-foreground mt-1">
                                {config.description}
                            </p>
                        </div>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={fetchData}
                            disabled={isLoading}
                            className="ml-auto"
                        >
                            <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")}/>
                        </Button>
                    </div>

                    {/* Filters Row */}
                    <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center">
                        {/* Resource Filter */}
                        <div className="flex-1">
                            <ResourceFilter onFilterChange={handleFilterChange}/>
                        </div>

                        {/* Date Picker */}
                        <div className="flex-shrink-0">
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant="outline"
                                        className={cn(
                                            "w-[200px] justify-start text-left font-normal",
                                            !selectedDate && "text-muted-foreground"
                                        )}
                                    >
                                        <CalendarIcon className="mr-2 h-4 w-4"/>
                                        {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="end">
                                    <Calendar
                                        mode="single"
                                        selected={selectedDate}
                                        onSelect={(date) => date && setSelectedDate(date)}
                                        initialFocus
                                    />
                                </PopoverContent>
                            </Popover>
                        </div>
                    </div>
                </div>
            </CardHeader>

            <CardContent>
                {error ? (
                    <div className="flex items-center justify-center h-[350px] text-red-500">
                        <p>Error loading chart data: {error}</p>
                    </div>
                ) : isLoading ? (
                    <div className="flex items-center justify-center h-[350px]">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    </div>
                ) : chartData ? (
                    <div className="w-full">
                        <Chart
                            options={chartOptions}
                            series={series}
                            type="area"
                            height={350}
                            width="100%"
                        />
                    </div>
                ) : (
                    <div className="flex items-center justify-center h-[350px] text-muted-foreground">
                        <p>No data available</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};
