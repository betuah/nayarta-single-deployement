import React, {useEffect, useState} from 'react';
import {useSearchModuleStore} from '@/store/search-module-store';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import {DtoLocationSearchResult, DtoFloorPlanSearchResult, DtoCameraSearchResult} from '@/lib/api/data-contracts';

interface ResourceFilterProps {
    onFilterChange: (filter: {
        locationId?: string;
        locationName?: string;
        floorPlanId?: string;
        floorPlanName?: string;
        cameraId?: string;
        cameraName?: string
    }) => void;
}

export const ResourceFilter: React.FC<ResourceFilterProps> = ({onFilterChange}) => {
    // States for selected values
    const [selectedLocationId, setSelectedLocationId] = useState<string | undefined>(undefined);
    const [selectedLocationName, setSelectedLocationName] = useState<string | undefined>(undefined);
    const [selectedFloorPlanId, setSelectedFloorPlanId] = useState<string | undefined>(undefined);
    const [selectedFloorPlanName, setSelectedFloorPlanName] = useState<string | undefined>(undefined);
    const [selectedCameraId, setSelectedCameraId] = useState<string | undefined>(undefined);
    const [selectedCameraName, setSelectedCameraName] = useState<string | undefined>(undefined);
    const [selectedCameraStatus, setSelectedCameraStatus] = useState<string | undefined>(undefined);

    // Get data and loading states from the store
    const {
        locations,
        floorPlans,
        cameras,
        isLoadingLocations,
        isLoadingFloorPlans,
        isLoadingCameras,
        fetchLocations,
        fetchFloorPlans,
        fetchCameras,
    } = useSearchModuleStore();

    // Initial load of locations
    useEffect(() => {
        fetchLocations();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); // Only run once on component mount

    // Load floor plans when location changes
    useEffect(() => {
        if (selectedLocationId) {
            fetchFloorPlans(selectedLocationId);
            setSelectedFloorPlanId(undefined); // Reset floor plan selection
            setSelectedCameraId(undefined); // Reset camera selection
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedLocationId]); // Only re-run when locationId changes

    // Load cameras when floor plan changes
    useEffect(() => {
        if (selectedFloorPlanId) {
            fetchCameras(selectedFloorPlanId, undefined);
            setSelectedCameraId(undefined); // Reset camera selection
        } else if(selectedCameraStatus){
            fetchCameras(undefined, selectedCameraStatus);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedFloorPlanId, selectedCameraStatus]); // Only re-run when floorPlanId changes

    // Notify parent component when filters change
    useEffect(() => {
        // Wrap this in a debounce or use a ref to prevent excessive updates
        const timeoutId = setTimeout(() => {
            onFilterChange({
                locationId: selectedLocationId,
                locationName: selectedLocationName,
                floorPlanId: selectedFloorPlanId,
                floorPlanName: selectedFloorPlanName,
                cameraId: selectedCameraId,
                cameraName: selectedCameraName,
            });
        }, 0);

        return () => clearTimeout(timeoutId);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedLocationId, selectedFloorPlanId, selectedCameraId, selectedLocationName, selectedFloorPlanName, selectedCameraName, selectedCameraStatus]);

    return (
        <div className="flex flex-wrap gap-4">
            {/* Location Filter */}
            <div className="w-full sm:w-auto">
                <Select
                    value={selectedLocationId}
                    onValueChange={(value) => {
                        const loc = locations.find(l => l.id === value)
                        setSelectedLocationName(loc?.name)
                        setSelectedLocationId(value || undefined)
                    }}
                    disabled={isLoadingLocations}
                >
                    <SelectTrigger className="w-full sm:w-[200px]">
                        <SelectValue placeholder="All Locations"/>
                    </SelectTrigger>
                    <SelectContent className="z-[99999999] overflow-y-auto max-h-[20rem]">
                        <SelectItem value="">All Locations</SelectItem>
                        {locations.map((location: DtoLocationSearchResult) => (
                            <SelectItem key={location.id} value={location.id || ''}>
                                {location.name}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            {/* Floor Plan Filter */}
            <div className="w-full sm:w-auto">
                <Select
                    value={selectedFloorPlanId}
                    onValueChange={(value) => {
                        console.log(value)
                        const fp = floorPlans.find(l => l.id === value)
                        if (value === "all" || value === "unsigned") {
                            setSelectedCameraStatus(value)
                            setSelectedFloorPlanId(undefined)
                            setSelectedFloorPlanName(value)
                        } else {
                            setSelectedFloorPlanName(fp?.name)
                            setSelectedFloorPlanId(value || undefined)
                        }

                    }}
                    disabled={isLoadingFloorPlans || (!selectedLocationId && floorPlans.length === 0)}
                >
                    <SelectTrigger className="w-full sm:w-[200px]">
                        <SelectValue placeholder="Select Floor Plan"/>
                    </SelectTrigger>
                    <SelectContent className="z-[99999999] overflow-y-auto max-h-[20rem]">
                        <SelectItem value="all">All Floor</SelectItem>
                        <SelectItem value="unsigned">Unsigned</SelectItem>
                        {floorPlans.map((floorPlan: DtoFloorPlanSearchResult) => (
                            <SelectItem key={floorPlan.id} value={floorPlan.id || ''}>
                                {floorPlan.name}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            {/* Camera Filter */}
            <div className="w-full sm:w-auto">
                <Select
                    value={selectedCameraId}
                    onValueChange={(value) => {
                        const cam = cameras.find(l => l.id === value)
                        setSelectedCameraId(value || undefined)
                        setSelectedCameraName(cam?.name)

                    }}
                    disabled={isLoadingCameras || (!selectedFloorPlanId && cameras.length === 0) || !selectedCameraStatus}
                >
                    <SelectTrigger className="w-full sm:w-[200px]">
                        <SelectValue placeholder="All Camera"/>
                    </SelectTrigger>
                    <SelectContent className="z-[99999999] overflow-y-auto max-h-[20rem]">
                        <SelectItem value="">All Camera</SelectItem>
                        {cameras.map((camera: DtoCameraSearchResult) => (
                            <SelectItem key={camera.id} value={camera.id || ''}>
                                {camera.name}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
        </div>
    );
};
