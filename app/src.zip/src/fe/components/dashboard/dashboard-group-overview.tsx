import React from 'react';
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import {
    Building2,
    Users,
    FileText,
    HardDrive,
    Camera,
    AlertCircle,
    Layers,
    Mail,
    Check,
    ChevronRight
} from "lucide-react";
import { useCCTVAnalyticsModuleStore } from "@/store/dashboard-module-store";
import { formatBytes } from "@/lib/utils/format-utils";
import Link from 'next/link';
import {formatDate} from "@/lib/utils";

interface OverviewCardProps {
    title: string;
    value: React.ReactNode;
    unit?: string;
    icon: React.ReactNode;
    description?: string;
    actionLink?: {
        text: string;
        href: string;
    };
}

const OverviewCard: React.FC<OverviewCardProps> = ({
                                                       title,
                                                       value,
                                                       unit,
                                                       icon,
                                                       description,
                                                       actionLink
                                                   }) => (
    <Card className="bg-card border h-full">
        <CardHeader className="border-b h-16 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-medium text-muted-foreground">
                {title}
            </CardTitle>
            {icon}
        </CardHeader>
        <CardContent className="p-6 flex flex-col justify-between h-[calc(100%-4rem)]">
            <div className="text-center">
                <div className="text-3xl font-bold">
                    {value}
                </div>
                {unit && <span className="text-sm font-bold ml-1">{unit}</span>}
                {description && (
                    <p className="text-sm text-muted-foreground mt-2">
                        {description}
                    </p>
                )}
            </div>

            {actionLink && (
                <div className="mt-4 text-center">
                    <Link
                        href={actionLink.href}
                        className="text-blue-600 hover:text-blue-700 flex items-center justify-center text-sm font-bold"
                    >
                        {actionLink.text}
                        <ChevronRight className="h-4 w-4 ml-1" />
                    </Link>
                </div>
            )}
            <div className="mb-2"/>
        </CardContent>
    </Card>
);

const GroupOverviewSkeleton: React.FC = () => (
    <div className="space-y-6">
        <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-96" />
        </div>
        <div className="bg-white p-4 rounded-lg mb-6">
            <div className="grid grid-cols-3 gap-4">
                <Skeleton className="h-20" />
                <Skeleton className="h-20" />
                <Skeleton className="h-20" />
            </div>
        </div>
        <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
            {[1, 2, 3, 4, 5, 6, 7].map((i) => (
                <Card key={i} className="h-full">
                    <CardHeader className="border-b h-16">
                        <Skeleton className="h-4 w-[140px]" />
                    </CardHeader>
                    <CardContent className="p-6">
                        <Skeleton className="h-10 w-[100px] mx-auto" />
                    </CardContent>
                </Card>
            ))}
        </div>
    </div>
);

const DashboardGroupOverview: React.FC = () => {
    const {
        groupOverviewData,
        isLoadingGroupOverview,
        groupOverviewError,
        getGroupOverviewData
    } = useCCTVAnalyticsModuleStore();

    React.useEffect(() => {
        getGroupOverviewData();
    }, [getGroupOverviewData]);

    if (groupOverviewError) {
        return (
            <Alert color="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                    {groupOverviewError}
                </AlertDescription>
            </Alert>
        );
    }

    if (isLoadingGroupOverview) {
        return <GroupOverviewSkeleton />;
    }

    if (!groupOverviewData) {
        return null;
    }

    // Main group information for the top section
    const groupInfo = {
        name: groupOverviewData.group_name || "N/A",
        status: groupOverviewData.group_status?.toLowerCase() || "N/A",
        email: groupOverviewData.email || "N/A",
        activeUntil: groupOverviewData.active_until || "N/A"
    };

    // Cards for the grid layout
    const overviewCards: OverviewCardProps[] = [
        {
            title: "Total Members",
            value: groupOverviewData.total_members || 0,
            unit: "members",
            icon: <Users className="h-4 w-4 text-muted-foreground" />,
            actionLink: {
                text: "See all members",
                href: "/users"
            }
        },
        {
            title: "Total Locations",
            value: groupOverviewData.total_locations || 0,
            unit: "locations",
            icon: <Building2 className="h-4 w-4 text-muted-foreground" />,
            actionLink: {
                text: "See all locations",
                href: "/nvr/locations"
            }
        },
        {
            title: "Floor Plans",
            value: groupOverviewData.total_floor_plans || 0,
            unit: "plans",
            icon: <FileText className="h-4 w-4 text-muted-foreground" />,
            actionLink: {
                text: "See all floor plans",
                href: "/floor-plans"
            }
        },
        {
            title: "Storage Used",
            value: formatBytes(groupOverviewData.total_storage_used || 0, 2, true),
            icon: <HardDrive className="h-4 w-4 text-muted-foreground" />,
            actionLink: {
                text: "File Storage",
                href: "/file-storage"
            }
        },
        {
            title: "Active Recording Cameras",
            value: groupOverviewData.active_recording_cctvs || 0,
            unit: "cameras",
            icon: <Camera className="h-4 w-4 text-muted-foreground" />
        },
        {
            title: "Floor Plan Cameras",
            value: groupOverviewData.cctvs_on_floor_plans || 0,
            icon: <Layers className="h-4 w-4 text-muted-foreground" />,
            description: "Cameras placed on floor plans"
        },
        {
            title: "Floor Plan NVRs",
            value: groupOverviewData.nvrs_on_floor_plans || 0,
            icon: <Layers className="h-4 w-4 text-muted-foreground" />,
            description: "NVRs placed on floor plans"
        }
    ];

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-3xl font-bold tracking-tight">Organization Overview</h2>
                <p className="text-muted-foreground">
                    Summary of your organization's resources and configuration
                </p>
            </div>

            {/* Group main info section at the top */}
            <div className="rounded-lg border bg-card p-6 shadow-sm">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-muted-foreground">Organization Name</span>
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div className="text-xl font-semibold">{groupInfo.name}</div>
                    </div>

                    <div className="space-y-2">
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-muted-foreground">Organization Status</span>
                            <Check className="h-4 w-4 text-green-500" />
                        </div>
                        <div className="flex flex-col">
                            <div className="text-base font-semibold">{groupInfo.status.toUpperCase()}</div>
                            <div className="text-xs"><span className="font-semibold">Until:</span> {formatDate(groupInfo.activeUntil)}</div>
                        </div>

                    </div>

                    <div className="space-y-2">
                    <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-muted-foreground">Admin Email</span>
                            <Mail className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div className="text-lg font-semibold truncate">{groupInfo.email}</div>
                    </div>
                </div>
            </div>

            {/* Grid of stat cards */}
            <div className="grid gap-4 grid-cols-1 md:grid-cols-3 lg:grid-cols-4">
                {overviewCards.map((card, index) => (
                    <OverviewCard key={index} {...card} />
                ))}
            </div>
        </div>
    );
};

export default DashboardGroupOverview;
