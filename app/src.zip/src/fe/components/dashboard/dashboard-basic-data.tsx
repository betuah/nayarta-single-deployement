import React from 'react';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import {
    Camera,
    Server,
    Building2,
    AlertCircle,
    CheckCircle2,
    XCircle,
    ChevronRight
} from "lucide-react";

import Link from 'next/link';
import {useCCTVAnalyticsModuleStore} from "@/store/dashboard-module-store";

interface StatCardProps {
    title: string;
    stats: {
        total: number;
        online?: number;
        offline?: number;
    };
    icon: React.ReactNode;
    linkText?: string;
    linkHref?: string;
}

const StatCard: React.FC<StatCardProps> = ({
                                               title,
                                               stats,
                                               icon,
                                               linkText,
                                               linkHref
                                           }) => (
    <Card className="grid grid-rows-[auto_1fr_auto] h-full">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
                {title}
            </CardTitle>
            {icon}
        </CardHeader>
        <CardContent className="space-y-3">
            <div className="flex items-baseline space-x-2">
                <div className="text-2xl font-bold">
                    {stats.total}
                </div>
                <span className="text-sm text-muted-foreground">total</span>
            </div>

            {(typeof stats.online === 'number' || typeof stats.offline === 'number') && (
                <div className="flex items-center space-x-4 text-sm">
                    {typeof stats.online === 'number' && (
                        <div className="flex items-center space-x-1">
                            <div className="h-2 w-2 rounded-full bg-green-500" />
                            <span className="font-medium">{stats.online}</span>
                            <span className="text-muted-foreground">online</span>
                        </div>
                    )}
                    {typeof stats.offline === 'number' && (
                        <div className="flex items-center space-x-1">
                            <div className="h-2 w-2 rounded-full bg-red-500" />
                            <span className="font-medium">{stats.offline}</span>
                            <span className="text-muted-foreground">offline</span>
                        </div>
                    )}
                </div>
            )}
        </CardContent>
        {linkText && linkHref && (
            <CardFooter className="mt-auto pt-6">
                <Button
                    variant="ghost"
                    className="w-full justify-between text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                    asChild
                >
                    <Link href={linkHref}>
                        {linkText}
                        <ChevronRight className="h-4 w-4" />
                    </Link>
                </Button>
            </CardFooter>
        )}
    </Card>
);

const LoadingSkeleton: React.FC = () => (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="h-full">
                <CardHeader className="pb-2">
                    <Skeleton className="h-4 w-[140px]" />
                </CardHeader>
                <CardContent className="space-y-3">
                    <Skeleton className="h-8 w-[100px]" />
                    <Skeleton className="h-4 w-[160px]" />
                </CardContent>
                <CardFooter>
                    <Skeleton className="h-9 w-full" />
                </CardFooter>
            </Card>
        ))}
    </div>
);

const HealthCard: React.FC<{
    onlineCount: number;
    totalCount: number;
    title: string;
}> = ({ onlineCount, totalCount, title }) => {
    const healthPercentage = Math.round((onlineCount / (totalCount || 1)) * 100);
    const healthStatus = healthPercentage >= 90 ? 'Healthy' :
        healthPercentage >= 70 ? 'Warning' : 'Critical';

    const statusColors = {
        Healthy: 'text-green-500',
        Warning: 'text-yellow-500',
        Critical: 'text-red-500'
    };

    return (
        <Card className="h-full">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                    System Health
                </CardTitle>
                <div className={`flex items-center space-x-1 ${statusColors[healthStatus]}`}>
                    {healthStatus === 'Healthy' ? (
                        <CheckCircle2 className="h-4 w-4" />
                    ) : healthStatus === 'Warning' ? (
                        <AlertCircle className="h-4 w-4" />
                    ) : (
                        <XCircle className="h-4 w-4" />
                    )}
                </div>
            </CardHeader>
            <CardContent className="space-y-3">
                <div className="flex items-baseline space-x-2">
                    <div className="text-2xl font-bold">
                        {healthPercentage}%
                    </div>
                    <span className={`text-sm ${statusColors[healthStatus]}`}>
            {healthStatus}
          </span>
                </div>
                <div className="text-sm text-muted-foreground">
                    {title}
                </div>
            </CardContent>
        </Card>
    );
};

const DashboardBasicData: React.FC = () => {
    const {
        dashboardBasicData,
        isLoading,
        error,
        getDashboardBasicData
    } = useCCTVAnalyticsModuleStore();

    React.useEffect(() => {
        getDashboardBasicData();
    }, [getDashboardBasicData]);

    if (error) {
        return (
            <Alert color="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                    {error}
                </AlertDescription>
            </Alert>
        );
    }

    if (isLoading) {
        return <LoadingSkeleton />;
    }

    if (!dashboardBasicData) {
        return null;
    }

    const stats: StatCardProps[] = [
        {
            title: "Cameras",
            stats: {
                total: dashboardBasicData.total_camera || 0,
                online: dashboardBasicData.camera_online || 0,
                offline: dashboardBasicData.camera_offline || 0
            },
            icon: <Camera className="h-4 w-4 text-muted-foreground" />,
            linkText: "See all cameras",
            linkHref: "/camera"
        },
        {
            title: "NVR Devices",
            stats: {
                total: dashboardBasicData.total_nvr || 0,
                online: dashboardBasicData.nvr_online || 0,
                offline: dashboardBasicData.nvr_offline || 0
            },
            icon: <Server className="h-4 w-4 text-muted-foreground" />,
            linkText: "See all NVRs",
            linkHref: "/nvr"
        },
        {
            title: "Locations",
            stats: {
                total: dashboardBasicData.total_location || 0
            },
            icon: <Building2 className="h-4 w-4 text-muted-foreground" />,
            linkText: "See all locations",
            linkHref: "/nvr/locations"
        }
    ];

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-3xl font-bold tracking-tight">System Health</h2>
                <p className="text-muted-foreground">
                    Overview of your VMS system status and health
                </p>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                {stats.map((stat, index) => (
                    <StatCard key={index} {...stat} />
                ))}
                <HealthCard
                    onlineCount={dashboardBasicData.camera_online || 0}
                    totalCount={dashboardBasicData.total_camera || 0}
                    title="Camera System Health"
                />
            </div>
        </div>
    );
};

export default DashboardBasicData;
