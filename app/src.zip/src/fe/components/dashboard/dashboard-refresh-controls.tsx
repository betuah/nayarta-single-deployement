import React from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Icon } from '@iconify/react';
import { useCCTVAnalyticsModuleStore } from '@/store/dashboard-module-store';
import { useGroupModuleStore } from '@/store/group-module-store';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'react-toastify';

interface DashboardRefreshControlsProps {
    // Optional prop to control which sections to refresh
    enabledSections?: {
        basicData?: boolean;
        groupOverview?: boolean;
        planQuota?: boolean;
        storageOverview?: boolean;
    };
}

const DashboardRefreshControls: React.FC<DashboardRefreshControlsProps> = ({
                                                                               enabledSections = {
                                                                                   basicData: true,
                                                                                   groupOverview: true,
                                                                                   planQuota: true,
                                                                                   storageOverview: false
                                                                               }
                                                                           }) => {
    const {
        isLoading,
        isLoadingGroupOverview,
        isLoadingStorageOverview,
        getDashboardBasicData,
        getGroupOverviewData,
        getStorageOverviewData
    } = useCCTVAnalyticsModuleStore();

    const {
        isLoadingQuotaAll,
        fetchQuotaAll
    } = useGroupModuleStore();

    // Local state for auto-refresh functionality
    const [isAutoRefreshEnabled, setIsAutoRefreshEnabled] = React.useState(true);
    const [refreshInterval, setRefreshInterval] = React.useState(300000); // 5 minutes default
    const [lastRefreshTime, setLastRefreshTime] = React.useState<Date | null>(null);
    const [isAutoRefreshing, setIsAutoRefreshing] = React.useState(false);

    // Auto-refresh timer ref
    const refreshTimerRef = React.useRef<NodeJS.Timeout | null>(null);
    const userInteractingRef = React.useRef(false);

    const isAnyLoading = isLoading || isLoadingGroupOverview || isLoadingStorageOverview || isLoadingQuotaAll;

    const handleManualRefresh = async () => {
        try {
            setIsAutoRefreshing(true);

            const promises: Promise<void>[] = [];

            if (enabledSections.basicData) {
                promises.push(getDashboardBasicData());
            }

            if (enabledSections.groupOverview) {
                promises.push(getGroupOverviewData());
            }

            if (enabledSections.planQuota) {
                promises.push(fetchQuotaAll());
            }

            if (enabledSections.storageOverview) {
                // Use default parameters for storage overview
                promises.push(getStorageOverviewData("last_week", undefined, undefined));
            }

            await Promise.all(promises);

            setLastRefreshTime(new Date());
            toast.success('Dashboard refreshed successfully');
        } catch (error) {
            toast.error('Failed to refresh dashboard');
        } finally {
            setIsAutoRefreshing(false);
        }
    };

    const handleIntervalChange = (value: string) => {
        const intervalMs = parseInt(value);
        setRefreshInterval(intervalMs);
        toast.success(`Auto-refresh interval set to ${intervalMs / 60000} minute(s)`);

        // Restart the timer with new interval
        if (isAutoRefreshEnabled) {
            startAutoRefresh();
        }
    };

    const handleAutoRefreshToggle = (enabled: boolean) => {
        setIsAutoRefreshEnabled(enabled);
        if (enabled) {
            startAutoRefresh();
        } else {
            stopAutoRefresh();
        }
    };

    const startAutoRefresh = React.useCallback(() => {
        stopAutoRefresh(); // Clear any existing timer

        if (!isAutoRefreshEnabled) return;

        refreshTimerRef.current = setInterval(async () => {
            // Don't auto-refresh if user is currently interacting or if already loading
            if (userInteractingRef.current || isAnyLoading) {
                return;
            }

            try {
                setIsAutoRefreshing(true);

                const promises: Promise<void>[] = [];

                if (enabledSections.basicData) {
                    promises.push(getDashboardBasicData());
                }

                if (enabledSections.groupOverview) {
                    promises.push(getGroupOverviewData());
                }

                if (enabledSections.planQuota) {
                    promises.push(fetchQuotaAll());
                }

                if (enabledSections.storageOverview) {
                    promises.push(getStorageOverviewData("last_week", undefined, undefined));
                }

                await Promise.all(promises);
                setLastRefreshTime(new Date());
            } catch (error) {
                console.error('Auto-refresh failed:', error);
                // Don't show toast for auto-refresh errors to avoid spam
            } finally {
                setIsAutoRefreshing(false);
            }
        }, refreshInterval);
    }, [isAutoRefreshEnabled, refreshInterval, enabledSections, isAnyLoading, getDashboardBasicData, getGroupOverviewData, fetchQuotaAll, getStorageOverviewData]);

    const stopAutoRefresh = React.useCallback(() => {
        if (refreshTimerRef.current) {
            clearInterval(refreshTimerRef.current);
            refreshTimerRef.current = null;
        }
    }, []);

    // Start auto-refresh when component mounts or settings change
    React.useEffect(() => {
        if (isAutoRefreshEnabled) {
            startAutoRefresh();
        }

        return () => stopAutoRefresh();
    }, [isAutoRefreshEnabled, startAutoRefresh, stopAutoRefresh]);

    // Set user interaction flag
    const setUserInteracting = (interacting: boolean) => {
        userInteractingRef.current = interacting;
    };

    // Reset timer when user interacts
    const resetTimer = () => {
        if (isAutoRefreshEnabled) {
            startAutoRefresh();
        }
    };

    // Expose methods to parent component
    // @ts-ignore
    React.useImperativeHandle(React.forwardRef(() => null), () => ({
        setUserInteracting,
        resetTimer
    }));

    const getIntervalLabel = (ms: number) => {
        const minutes = ms / 60000;
        return minutes === 1 ? '1 minute' : `${minutes} minutes`;
    };

    const getLastRefreshText = () => {
        if (!lastRefreshTime) return 'Never';
        try {
            return formatDistanceToNow(lastRefreshTime, { addSuffix: true });
        } catch {
            return 'Recently';
        }
    };

    // Count enabled sections for display
    const enabledSectionCount = Object.values(enabledSections).filter(Boolean).length;
    const sectionNames = [];
    if (enabledSections.basicData) sectionNames.push('System Health');
    if (enabledSections.groupOverview) sectionNames.push('Organization Overview');
    if (enabledSections.planQuota) sectionNames.push('Plan & Quotas');
    if (enabledSections.storageOverview) sectionNames.push('Storage Overview');

    return (
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4 p-4 bg-card border-b rounded border-border">
            {/* Manual Refresh Button */}
            <Button
                variant="outline"
                size="sm"
                onClick={handleManualRefresh}
                disabled={isAnyLoading || isAutoRefreshing}
                className="flex items-center gap-2"
            >
                <Icon
                    icon="heroicons:arrow-path"
                    className={`h-4 w-4 ${(isAnyLoading || isAutoRefreshing) ? 'animate-spin' : ''}`}
                />
                Refresh Dashboard
            </Button>

            {/* Auto-refresh Toggle */}
            <div className="flex items-center gap-2">
                <Switch
                    checked={isAutoRefreshEnabled}
                    onCheckedChange={handleAutoRefreshToggle}
                    id="auto-refresh-dashboard"
                />
                <label
                    htmlFor="auto-refresh-dashboard"
                    className="text-sm font-medium cursor-pointer"
                >
                    Auto-refresh
                </label>
            </div>

            {/* Refresh Interval Selector */}
            {isAutoRefreshEnabled && (
                <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">Every:</span>
                    <Select
                        value={refreshInterval.toString()}
                        onValueChange={handleIntervalChange}
                    >
                        <SelectTrigger className="w-32">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="180000">3 minutes</SelectItem>
                            <SelectItem value="300000">5 minutes</SelectItem>
                            <SelectItem value="600000">10 minutes</SelectItem>
                            <SelectItem value="900000">15 minutes</SelectItem>
                            <SelectItem value="1800000">30 minutes</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            )}

            {/* Status Indicator */}
            <div className="flex items-center gap-2 ml-auto">
                {isAutoRefreshing && (
                    <div className="flex items-center gap-2 text-sm text-blue-600">
                        <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>
                        Refreshing {enabledSectionCount} section{enabledSectionCount !== 1 ? 's' : ''}...
                    </div>
                )}

                {!isAutoRefreshing && !isAnyLoading && (
                    <div className="text-sm text-muted-foreground">
                        Last updated: {getLastRefreshText()}
                    </div>
                )}

                {isAutoRefreshEnabled && !isAutoRefreshing && !isAnyLoading && (
                    <div className="flex items-center gap-1 text-sm text-green-600">
                        <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                        <span>Auto: {getIntervalLabel(refreshInterval)}</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default DashboardRefreshControls;
