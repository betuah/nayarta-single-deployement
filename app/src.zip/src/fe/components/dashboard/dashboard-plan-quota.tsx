import React from 'react';
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import {
    Crown,
    Camera,
    Building2,
    Users,
    Server,
    FileText,
    HardDrive,
    AlertCircle,
    CheckCircle2,
    AlertTriangle,
    Sparkles
} from "lucide-react";
import { useGroupModuleStore } from "@/store/group-module-store";
import { formatBytes } from "@/lib/utils/format-utils";

interface QuotaCardProps {
    title: string;
    used: number;
    max: number;
    unit?: string;
    icon: React.ReactNode;
    formatValue?: (value: number) => string;
}

const QuotaCard: React.FC<QuotaCardProps> = ({
                                                 title,
                                                 used,
                                                 max,
                                                 unit = "",
                                                 icon,
                                                 formatValue
                                             }) => {
    const percentage = max > 0 ? Math.round((used / max) * 100) : 0;
    const remaining = Math.max(0, max - used);

    const getStatusColor = (percent: number) => {
        if (percent >= 90) return 'text-red-500';
        if (percent >= 75) return 'text-yellow-500';
        return 'text-green-500';
    };

    const getProgressColor = (percent: number) => {
        if (percent >= 90) return 'bg-red-500';
        if (percent >= 75) return 'bg-yellow-500';
        return 'bg-green-500';
    };

    const formatDisplayValue = (value: number) => {
        if (formatValue) return formatValue(value);
        return `${value}${unit}`;
    };

    return (
        <Card className="h-full">
            <CardHeader className="flex flex-row items-center justify-between pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                    {title}
                </CardTitle>
                {icon}
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="space-y-2">
                    <div className="flex items-baseline justify-between">
                        <div className="text-2xl font-bold">
                            {formatDisplayValue(used)}
                        </div>
                        <div className="text-sm text-muted-foreground">
                            of {formatDisplayValue(max)}
                        </div>
                    </div>

                    <Progress
                        value={percentage}
                        className="h-2"
                    />

                    <div className="flex items-center justify-between text-xs">
                        <span className={`font-medium ${getStatusColor(percentage)}`}>
                            {percentage}% used
                        </span>
                        <span className="text-muted-foreground">
                            {formatDisplayValue(remaining)} remaining
                        </span>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

const PlanCard: React.FC<{
    plan: {
        id?: string;
        name?: string;
        display_name?: string;
    } | null;
    analytics?: string[];
}> = ({ plan, analytics }) => {
    if (!plan) return null;

    return (
        <Card className="w-full">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <div className="space-y-1">
                        <CardTitle className="text-lg font-semibold text-muted-foreground flex items-center gap-2">
                            <Crown className="h-5 w-5 text-muted-foreground" />
                            Current Plan
                        </CardTitle>
                        <div className="text-2xl font-bold text-blue-800">
                            {plan.display_name || plan.name || 'Unknown Plan'}
                        </div>
                        {/*{plan.id && (*/}
                        {/*    <div className="text-sm text-muted-foreground">*/}
                        {/*        Plan ID: {plan.id}*/}
                        {/*    </div>*/}
                        {/*)}*/}
                    </div>
                </div>
            </CardHeader>

            {analytics && analytics.length > 0 && (
                <CardContent>
                    <div className="space-y-3">
                        <div className="text-sm font-medium text-muted-foreground">
                            Analytics Features
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {analytics.map((feature, index) => (
                                <div
                                    key={index}
                                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-100 dark:bg-blue-900 dark:text-blue-100 text-blue-700 rounded-full text-sm font-medium"
                                >
                                    <Sparkles className="h-3 w-3" />
                                    {feature}
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            )}
        </Card>
    );
};

const LoadingSkeleton: React.FC = () => (
    <div className="space-y-6">
        <div>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-96" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="h-full">
                    <CardHeader className="pb-3">
                        <Skeleton className="h-4 w-[140px]" />
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Skeleton className="h-8 w-[100px]" />
                        <Skeleton className="h-2 w-full" />
                        <Skeleton className="h-3 w-[120px]" />
                    </CardContent>
                </Card>
            ))}
        </div>
    </div>
);

const DashboardPlanQuota: React.FC = () => {
    const {
        quotaAll,
        isLoadingQuotaAll,
        quotaAllError,
        fetchQuotaAll
    } = useGroupModuleStore();

    React.useEffect(() => {
        fetchQuotaAll();
    }, [fetchQuotaAll]);

    if (quotaAllError) {
        return (
            <Alert color="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                    {quotaAllError}
                </AlertDescription>
            </Alert>
        );
    }

    if (isLoadingQuotaAll) {
        return <LoadingSkeleton />;
    }

    if (!quotaAll) {
        return null;
    }

    const quotaCards = [
        {
            title: "Cameras",
            used: quotaAll.cameras?.used || 0,
            max: quotaAll.cameras?.max || 0,
            icon: <Camera className="h-4 w-4 text-muted-foreground" />
        },
        {
            title: "Locations",
            used: quotaAll.locations?.used || 0,
            max: quotaAll.locations?.max || 0,
            icon: <Building2 className="h-4 w-4 text-muted-foreground" />
        },
        {
            title: "Members",
            used: quotaAll.members?.used || 0,
            max: quotaAll.members?.max || 0,
            icon: <Users className="h-4 w-4 text-muted-foreground" />
        },
        {
            title: "NVR Devices",
            used: quotaAll.nvrs?.used || 0,
            max: quotaAll.nvrs?.max || 0,
            icon: <Server className="h-4 w-4 text-muted-foreground" />
        },
        {
            title: "Floor Plans",
            used: quotaAll.floor_plans?.used || 0,
            max: quotaAll.floor_plans?.max || 0,
            icon: <FileText className="h-4 w-4 text-muted-foreground" />
        },
        {
            title: "Storage",
            used: quotaAll.storage?.used || 0,
            max: quotaAll.storage?.max || 0,
            icon: <HardDrive className="h-4 w-4 text-muted-foreground" />,
            formatValue: (bytes: number) => formatBytes(bytes, 2, true)
        }
    ].filter(card => card.max > 0); // Only show quotas that have limits

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-3xl font-bold tracking-tight">Plan & Quotas</h2>
                <p className="text-muted-foreground">
                    Your organization's subscription plan and resource usage
                </p>
            </div>

            {/* Plan Information Card - Full Width */}
            <PlanCard
                plan={quotaAll.plan || null}
                analytics={quotaAll.analytics || []}
            />

            {/* Quota Cards Grid */}
            {quotaCards.length > 0 && (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {quotaCards.map((card, index) => (
                        <QuotaCard key={index} {...card} />
                    ))}
                </div>
            )}

            {/* Quota Summary Alert */}
            {quotaCards.length > 0 && (
                <div className="mt-4">
                    {(() => {
                        const criticalQuotas = quotaCards.filter(card => {
                            const percentage = card.max > 0 ? (card.used / card.max) * 100 : 0;
                            return percentage >= 90;
                        });

                        const warningQuotas = quotaCards.filter(card => {
                            const percentage = card.max > 0 ? (card.used / card.max) * 100 : 0;
                            return percentage >= 75 && percentage < 90;
                        });

                        if (criticalQuotas.length > 0) {
                            return (
                                <Alert color="destructive">
                                    <AlertTriangle className="h-4 w-4" />
                                    <AlertDescription>
                                        <strong>Critical:</strong> {criticalQuotas.map(q => q.title).join(', ')} {criticalQuotas.length === 1 ? 'is' : 'are'} at 90%+ capacity. Consider upgrading your plan.
                                    </AlertDescription>
                                </Alert>
                            );
                        }

                        if (warningQuotas.length > 0) {
                            return (
                                <Alert>
                                    <AlertCircle className="h-4 w-4" />
                                    <AlertDescription>
                                        <strong>Warning:</strong> {warningQuotas.map(q => q.title).join(', ')} {warningQuotas.length === 1 ? 'is' : 'are'} at 75%+ capacity.
                                    </AlertDescription>
                                </Alert>
                            );
                        }

                        return (
                            <Alert>
                                <CheckCircle2 className="h-4 w-4" />
                                <AlertDescription>
                                    All quotas are within healthy limits.
                                </AlertDescription>
                            </Alert>
                        );
                    })()}
                </div>
            )}
        </div>
    );
};

export default DashboardPlanQuota;
