export const getCurrentFrame = (currentTime: number, fps: number): number => {
    return Math.floor(currentTime * fps);
};

export const scaleCoordinates = (
    bbox: [number, number, number, number],
    originalSize: { width: number; height: number },
    displaySize: { width: number; height: number }
): [number, number, number, number] => {
    const [x1, y1, x2, y2] = bbox;
    const scaleX = displaySize.width / originalSize.width;
    const scaleY = displaySize.height / originalSize.height;

    const scaledCoords: [number, number, number, number] = [
        Math.round(x1 * scaleX),
        Math.round(y1 * scaleY),
        Math.round(x2 * scaleX),
        Math.round(y2 * scaleY)
    ];

    return scaledCoords;
};

export const scalePoint = (
    point: [number, number],
    originalSize: { width: number; height: number },
    displaySize: { width: number; height: number }
): [number, number] => {
    const [x, y] = point;
    const scaleX = displaySize.width / originalSize.width;
    const scaleY = displaySize.height / originalSize.height;

    return [
        Math.round(x * scaleX),
        Math.round(y * scaleY)
    ];
};

// Fallback colors for class-based coloring (when no status or color scheme)
const DEFAULT_CLASS_COLORS = [
    '#20B2AA', '#4682B4', '#D2691E', '#DC143C', '#00CED1',
    '#9400D3', '#FF1493', '#1E90FF', '#FFD700', '#32CD32',
    '#FF69B4', '#CD5C5C', '#4B0082', '#F0E68C', '#E6E6FA',
    '#87CEEB', '#DDA0DD', '#98FB98', '#F0A460', '#DB7093',
    '#8B4513', '#87CEFA', '#778899', '#B0C4DE', '#FFFFE0',
    '#D3D3D3', '#90EE90', '#FFB6C1', '#FFA07A', '#40E0D0'
];

// Default color scheme fallbacks
const DEFAULT_COLOR_SCHEME = {
    normal: '#008000',      // Green
    pre_event: '#FFA500',   // Orange
    event: '#FF0000',       // Red
    region: '#FFFF00',      // Yellow
    text: '#FFFFFF'         // White
};

export const getColorForClass = (classId: number): string => {
    return DEFAULT_CLASS_COLORS[classId % DEFAULT_CLASS_COLORS.length];
};

export const getColorForStatus = (
    status: string | undefined,
    colorScheme?: { normal?: string; pre_event?: string; event?: string }
): string => {
    // Use color scheme from metadata if available, otherwise fallback to defaults
    switch (status) {
        case 'event':
            return colorScheme?.event || DEFAULT_COLOR_SCHEME.event;
        case 'pre_event':
            return colorScheme?.pre_event || DEFAULT_COLOR_SCHEME.pre_event;
        case 'normal':
        default:
            return colorScheme?.normal || DEFAULT_COLOR_SCHEME.normal;
    }
};

export const getRegionColor = (colorScheme?: { region?: string }): string => {
    return colorScheme?.region || DEFAULT_COLOR_SCHEME.region;
};

export const getTextColor = (colorScheme?: { text?: string }): string => {
    return DEFAULT_COLOR_SCHEME.text || (colorScheme?.text || DEFAULT_COLOR_SCHEME.text);
};

// Smart color selection: use status-based if available, otherwise class-based
export const getDetectionColor = (
    detection: { status?: string; class_id: number },
    colorScheme?: { normal?: string; pre_event?: string; event?: string }
): string => {
    if (detection.status) {
        return getColorForStatus(detection.status, colorScheme);
    } else {
        // Fallback to class-based coloring if no status
        return getColorForClass(detection.class_id);
    }
};
