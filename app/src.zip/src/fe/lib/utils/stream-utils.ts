import {DtoCCTVConnectionDetail} from "@/lib/api/data-contracts";


export function constructRTSPUrl(connectionDetail: DtoCCTVConnectionDetail): string {
    const {protocol, hostname, port, username, password, path} = connectionDetail;

    if (!protocol || !hostname || !port) {
        throw new Error('Invalid connection details');
    }


    let url = `${protocol}://`;

    if (username && username !== '-' && username.trim() !== '') {
        url += encodeURIComponent(username);
        if (password && password !== '-' && password.trim() !== '') {
            url += `:${encodeURIComponent(password)}`;
        }
        url += '@';
    }

    url += `${hostname}:${port}`;

    if (path && path !== '-' && path.trim() !== '') {
        url += `/${path.trim().replace(/^\//, '')}`;
    }

    return url;
}
