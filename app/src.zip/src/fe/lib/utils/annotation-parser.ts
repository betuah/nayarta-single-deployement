import type {AnnotationData, VideoMetadata, FrameData} from '@/types/annotations';

export const parseAnnotationFile = (text: string): AnnotationData => {
    const lines = text.trim().split('\n');

    if (lines.length < 2) {
        throw new Error('Invalid annotation file format');
    }

    // Parse first line for metadata
    const metadataLine = JSON.parse(lines[0]);

    // Support both old format (video_metadata) and new format (video_meatdata - typo in example)
    const metadata: VideoMetadata = metadataLine.video_metadata || metadataLine.video_meatdata;

    if (!metadata || !metadata.width || !metadata.height || !metadata.fps) {
        throw new Error('Invalid metadata format');
    }

    console.log('Parsed metadata:', metadata);

    // Parse frame data
    const frames = new Map<number, any[]>();
    for (let i = 1; i < lines.length; i++) {
        try {
            const frameData: FrameData = JSON.parse(lines[i]);
            if (frameData.frame_id !== undefined && frameData.detections) {
                frames.set(frameData.frame_id, frameData.detections);
            }
        } catch (error) {
            console.warn(`Error parsing line ${i + 1}:`, error);
        }
    }

    return { metadata, frames };
};
