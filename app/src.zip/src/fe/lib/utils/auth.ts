import {getServerSession, NextAuthOptions, User} from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import {jwtDecode} from "jwt-decode";
import type {GetServerSidePropsContext, NextApiRequest, NextApiResponse,} from "next"
import prisma from "@/lib/prisma";
import * as bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken'
import {users} from '@prisma/client'

const JWT_EXPIRATION_TIME = 60 * 30 // 30 minutes

async function createCustomJWT(user: User, isInit: boolean): Promise<string> {
    const privateKeyBase64 = process.env.JWT_PRIVATE_KEY_BASE64
    if (!privateKeyBase64) {
        throw new Error('JWT_PRIVATE_KEY_BASE64 is not set in environment variables')
    }

    const privateKeyPem = Buffer.from(privateKeyBase64, 'base64').toString('ascii');
    const privateKeyFormatted = privateKeyPem.replace(/\\n/g, '\n');

    if(!isInit){
        const currUser= await getUserDetails(user.email)
        if(currUser) {
            user.members = currUser.members.map(member => {
                return {
                    group_id: member.group_id,
                    member_id: member.id,
                    group_name: member.groups.group_name,
                    role: member.role
                }
            })
        }
    }

    return jwt.sign(
        {
            email: user.email,
            members: user.members,
            user_id: user.id
        },
        privateKeyFormatted,
        {
            algorithm: 'RS256',
            expiresIn: `${JWT_EXPIRATION_TIME}s`
        }
    )
}


const getUserDetails = async (email: string) => {
    return prisma.users.findUnique({
        where: {
            email: email,
            user_status: "active"
        },
        select: {
            id: true,
            email: true,
            profile_picture_url: true,
            full_name: true,
            password: true,
            members: {
                where: {
                    status: "active",
                    groups: {
                        group_status: "active"
                    }
                },
                include: {
                    groups: true
                }
            }
        }
    })
}

export const authOptions: NextAuthOptions = {
    providers: [
        CredentialsProvider({
            name: 'Credentials',
            credentials: {
                email: {label: "Email", type: "text"},
                password: {label: "Password", type: "password"}
            },
            //@ts-ignore
            async authorize(credentials, req) {
                if (!credentials?.email || !credentials?.password) {
                    return null
                }
                const currUser= await getUserDetails(credentials.email)

                if (currUser && await bcrypt.compare(credentials?.password, currUser.password)) {
                    return {
                        id: currUser.id,
                        name: currUser.full_name,
                        email: currUser.email,
                        profile_picture: currUser.profile_picture_url,
                        members: currUser.members.map(member => {
                            return {
                                group_id: member.group_id,
                                member_id: member.id,
                                group_name: member.groups.group_name,
                                role: member.role
                            }
                        })
                    }
                }
                return null
            }
        })
    ],
    callbacks: {
        async jwt({token, user}) {
            if (user) {
                // This is the initial sign in
                const newToken = await createCustomJWT(user, true)
                const decoded = jwtDecode<any>(newToken);
                return {
                    accessToken: newToken,
                    refreshToken: "-",
                    accessTokenExpires: Date.now() + JWT_EXPIRATION_TIME * 1000,
                    userId: decoded.user_id,
                    members: user.members,
                    picture: user.profile_picture,
                    email: user.email,
                    name: user.name
                };
            }


            // Check if the token has expired or is about to expire
            //@ts-ignore
            if ((Date.now() < (token.accessTokenExpires ?? 0) - 5 * 60 * 1000)) {
                return token;
            } else {
                token.id = token.userId
                //@ts-ignore
                const newToken = await createCustomJWT(token, false)
                return {
                    ...token,
                    accessToken: newToken,
                    accessTokenExpires: Date.now() + JWT_EXPIRATION_TIME * 1000,
                }
            }


        },
        async session({session, token}) {
            session.user.id = token.userId;
            session.user.accessToken = token.accessToken;
            session.user.refreshToken = token.refreshToken;
            session.user.members = token.members;
            session.user.profilePicture = token.picture!;
            session.user.name = token.name!;
            session.user.email = token.email
            session.error = token.error as string | undefined;
            return session;
        }
    },
    pages: {
        signIn: '/en/auth/login',
        signOut: '/en/auth/login'
    },
    events: {
        async signOut({token}) {

        }
    }
};

export async function auth(
    ...args:
        | [GetServerSidePropsContext["req"], GetServerSidePropsContext["res"]]
        | [NextApiRequest, NextApiResponse]
        | []
) {
    return getServerSession(...args, authOptions)
}
