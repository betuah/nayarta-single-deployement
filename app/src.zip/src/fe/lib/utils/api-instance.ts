import {ApiConfig, HttpClient} from "@/lib/api/http-client";
import {Alerts} from "@/lib/api/modules/Alerts";
import {Analytics} from "@/lib/api/modules/Analytics";
import {AnalyticType} from "@/lib/api/modules/AnalyticType";
import {Auth} from "@/lib/api/modules/Auth";
import {CctvAnalytics} from "@/lib/api/modules/CctvAnalytics";
import {Cctvs} from "@/lib/api/modules/Cctvs";
import {FileObjects} from "@/lib/api/modules/FileObjects";
import {Files} from "@/lib/api/modules/Files"
import {Groups} from "@/lib/api/modules/Groups";
import {Locations} from "@/lib/api/modules/Locations";
import {MemberAlertSettings} from "@/lib/api/modules/MemberAlertSettings";
import {Members} from "@/lib/api/modules/Members";
import {Nvrs} from "@/lib/api/modules/Nvrs";
import {Dashboard} from "@/lib/api/modules/Dashboard";
import {FloorPlans} from "@/lib/api/modules/FloorPlans";
import {FloorPlanObjects} from "@/lib/api/modules/FloorPlanObjects";
import {CctvAnalyticConfig} from "@/lib/api/modules/CctvAnalyticConfig";
import {StreamAuth} from "@/lib/api/modules/StreamAuth";
import {Search} from "@/lib/api/modules/Search";
import {AnalyticResult} from "@/lib/api/modules/AnalyticResult";
import {VideoWall} from "@/lib/api/modules/VideoWall";
import {FileAiSummary} from "@/lib/api/modules/FileAiSummary";


const getApiConfig = (accessToken: string): ApiConfig => {
    return {
        baseURL: process.env.API_BASE_URL,
        secure: true,
        securityWorker: (_) => {
            return {
                headers: {
                    Authorization: `Bearer ${accessToken}`
                }
            };
        }
    }
}

const getApi = (accessToken: string) => {
    const config = getApiConfig(accessToken)
    return {
        alerts: new Alerts(config),
        analytics: new Analytics(config),
        analyticType: new AnalyticType(config),
        auth: new Auth(config),
        cctvAnalytics: new CctvAnalytics(config),
        cctvs: new Cctvs(config),
        fileObjects: new FileObjects(config),
        files: new Files(config),
        groups: new Groups(config),
        locations: new Locations(config),
        memberAlertSettings: new MemberAlertSettings(config),
        members: new Members(config),
        nvrs: new Nvrs(config),
        dashboard: new Dashboard(config),
        floorPlan: new FloorPlans(config),
        floorPlanObject: new FloorPlanObjects(config),
        cctvAnalyticConfigs: new CctvAnalyticConfig(config),
        streamAuth: new StreamAuth(config),
        search: new Search(config),
        analyticResult: new AnalyticResult(config),
        videoWalls: new VideoWall(config),
        fileAiSummary: new FileAiSummary(config)
    }
}

export const ApiInstance = getApi;
