'use server'
import {getServerSession} from "next-auth/next";
import {authOptions} from "@/lib/utils/auth";
import {redirect} from "next/navigation";
import {Session} from "next-auth";

export const checkServerSession = async (): Promise<Session> => {
    const session = await getServerSession(authOptions)
    if (!session) {
        redirect('/en/auth/login?error=Unauthorized')
    }
    return session
}
