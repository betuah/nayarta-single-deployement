/**
 * Format bytes to a human-readable size (KB, MB, GB, etc.)
 * @param bytes Number of bytes
 * @param decimals Number of decimal places to show
 * @param simplify If true, will show simplified formats (e.g., 1.12 GB instead of 1.12 Gigabytes)
 */
export function formatBytes(bytes: number, decimals: number = 2, simplify: boolean = false): string {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const sizes = simplify
        ? ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
        : ['Bytes', 'Kilobytes', 'Megabytes', 'Gigabytes', 'Terabytes', 'Petabytes', 'Exabytes', 'Zettabytes', 'Yottabytes'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals)) + ' ' + sizes[i];
}
