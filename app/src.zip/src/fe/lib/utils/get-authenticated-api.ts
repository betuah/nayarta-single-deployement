import {getServerSession} from "next-auth/next";
import {ApiInstance} from "@/lib/utils/api-instance";
import {authOptions} from "@/lib/utils/auth";
import {JWT, encode} from "next-auth/jwt";
import {jwtDecode} from "jwt-decode";
import {cookies} from 'next/headers';
import { signOut } from "next-auth/react";
import { redirect } from "next/navigation";

const REFRESH_TOKEN_BUFFER = 60 * 30; // 30 mins
const SESSION_COOKIE = "next-auth.session-token";
async function logoutAndRedirect() {
    const cookieStore = cookies();
    cookieStore.delete(SESSION_COOKIE);

    await signOut({ redirect: false });

    redirect("/auth/login");
}

export async function getAuthenticatedApi() {
    const session = await getServerSession(authOptions);
    if (!session || !session.user?.accessToken) {
        await logoutAndRedirect();
        throw new Error("Failed to get access token");
    }

    let currentToken = session.user;
    const api = ApiInstance(currentToken.accessToken as string);
    return {api, session: {...session, user: currentToken}};
}
