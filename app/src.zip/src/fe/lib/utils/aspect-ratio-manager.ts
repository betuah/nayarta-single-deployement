class AspectRatioManager {
    private currentRatio: string = "1:1";

    setAspectRatio(ratio: string) {
        if (this.currentRatio === ratio) return;
        document.body.classList.remove(`playback-aspect-${this.currentRatio.replace(':', '-')}`);
        document.body.classList.add(`playback-aspect-${ratio.replace(':', '-')}`);

        this.currentRatio = ratio;
    }
}

export const aspectRatioManager = new AspectRatioManager();
