import { Point } from "@/types/restricted-area";

// Helper function to generate points for regular polygon
export function generateRegularPolygon(
    center: Point,
    radius: number,
    sides: number,
    rotationOffset: number = 0
): Point[] {
    const points: Point[] = [];

    for (let i = 0; i < sides; i++) {
        const angle = rotationOffset + (i * 2 * Math.PI / sides);
        points.push({
            x: center.x + radius * Math.cos(angle),
            y: center.y + radius * Math.sin(angle)
        });
    }

    return points;
}

// Generate rectangle points
export function generateRectangle(startPoint: Point, width: number, height: number): Point[] {
    return [
        startPoint,
        { x: startPoint.x + width, y: startPoint.y },
        { x: startPoint.x + width, y: startPoint.y + height },
        { x: startPoint.x, y: startPoint.y + height }
    ];
}

// Generate triangle points
export function generateTriangle(startPoint: Point, size: number): Point[] {
    const height = size * Math.sqrt(3) / 2;
    return [
        { x: startPoint.x, y: startPoint.y },
        { x: startPoint.x + size, y: startPoint.y },
        { x: startPoint.x + size/2, y: startPoint.y + height }
    ];
}

// Generate circle points (approximated as a regular polygon)
export function generateCircle(center: Point, radius: number): Point[] {
    // Use 24 points to approximate a circle
    return generateRegularPolygon(center, radius, 24);
}

// Generate pentagon
export function generatePentagon(center: Point, radius: number): Point[] {
    return generateRegularPolygon(center, radius, 5, -Math.PI/2);
}

// Generate hexagon
export function generateHexagon(center: Point, radius: number): Point[] {
    return generateRegularPolygon(center, radius, 6, 0);
}
