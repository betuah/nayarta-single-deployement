/* eslint-disable */
/* tslint:disable */
// @ts-nocheck
/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

export enum ModelsFileType {
  FileTypeImage = "image",
  FileTypeSound = "sound",
  FileTypeVideo = "video",
}

export enum ModelsFileAISummaryStatus {
  FileAISummaryStatusInQueue = "in_queue",
  FileAISummaryStatusInProgress = "in_progress",
  FileAISummaryStatusCompleted = "completed",
  FileAISummaryStatusFailed = "failed",
  FileAISummaryStatusTimedOut = "timed_out",
  FileAISummaryStatusStale = "stale",
}

export interface DtoAlertCreatedResponse {
  alert_ids?: string[];
  message?: string;
}

export interface DtoAlertDetail {
  analytic?: {
    description?: string;
    id?: string;
    name?: string;
  };
  cctv_analytic?: {
    analytic_type?: {
      id?: string;
      name?: string;
    };
    cctv?: {
      description?: string;
      hostname?: string;
      id?: string;
      name?: string;
      port?: number;
    };
    id?: string;
  };
  created_at?: string;
  id?: string;
  message?: string;
}

export interface DtoAlertListItem {
  created_at?: string;
  id?: string;
  message?: string;
}

export interface DtoAlertListItemOnAlert {
  analytic?: {
    file_id?: string;
    id?: string;
    name?: string;
  };
  cctv_analytic?: {
    cctv?: {
      id?: string;
      name?: string;
    };
    id?: string;
    name?: string;
    type_id?: string;
  };
  created_at?: string;
  id?: string;
  message?: string;
}

export interface DtoAllQuotasResponseDTO {
  analytics?: string[];
  cameras?: DtoQuotaResponseDTO;
  floor_plans?: DtoQuotaResponseDTO;
  locations?: DtoQuotaResponseDTO;
  members?: DtoQuotaResponseDTO;
  nvrs?: DtoQuotaResponseDTO;
  plan?: DtoPlanInfoDTO;
  storage?: DtoStorageQuotaResponseDTO;
}

export interface DtoAnalyticDetail {
  alerts?: DtoAlertListItem[];
  cctv_analytic?: DtoCCTVAnalyticDetailOnAnalytic;
  cctv_analytic_id?: string;
  cctv_name?: string;
  created_at?: string;
  file?: DtoFileListItemOnAnalytic;
  file_id?: string;
  id?: string;
  updated_at?: string;
}

export interface DtoAnalyticEdgeDetail {
  cctv_analytic_id?: string;
  cctv_name?: string;
  created_at?: string;
  file_id?: string;
  id?: string;
}

export interface DtoAnalyticListItem {
  analytic_type_name?: string;
  cctv_analytic_id?: string;
  cctv_name?: string;
  created_at?: string;
  file_id?: string;
  id?: string;
}

export interface DtoAnalyticListItemOnCCTV {
  analytic_type_id?: string;
  enable?: boolean;
  id?: string;
  name?: string;
}

export interface DtoAnalyticReportItem {
  analytic_id?: string;
  analytic_name?: string;
  camera_id?: string;
  camera_name?: string;
  created_at?: string;
  download_url?: string;
  file_id?: string;
  floor_plan_id?: string;
  floor_plan_name?: string;
  location_id?: string;
  location_name?: string;
  message?: string;
}

export interface DtoAnalyticTypeDetail {
  description?: string;
  id?: string;
  name?: string;
}

export interface DtoAnalyticTypeList {
  types?: DtoAnalyticTypeListItem[];
}

export interface DtoAnalyticTypeListItem {
  description?: string;
  id?: string;
  name?: string;
}

export interface DtoAvailableCCTVsResponse {
  items?: {
    id?: string;
    name?: string;
    snapshot_image?: string;
    status?: string;
  }[];
}

export interface DtoAvailableNVRsResponse {
  items?: {
    id?: string;
    name?: string;
    status?: string;
  }[];
}

export interface DtoBulkDeleteFilesRequest {
  /** @minItems 1 */
  cctv_ids: string[];
  /** Change to string */
  end_date: string;
  /** Change to string */
  start_date: string;
}

export interface DtoBulkDeleteFilesResponse {
  cctv_results?: DtoCCTVDeletionResult[];
  total_deleted_count?: number;
  /** in bytes */
  total_deleted_size?: number;
  total_failed_storage?: number;
  total_files?: number;
  total_skipped_count?: number;
  /** in bytes */
  total_skipped_size?: number;
}

export interface DtoBulkDeleteSummaryRequest {
  /** @minItems 1 */
  cctv_ids: string[];
  end_date: string;
  start_date: string;
}

export interface DtoBulkDeleteSummaryResponse {
  cctv_summaries?: DtoCCTVDeletionSummary[];
  total_deletable_files?: number;
  /** in bytes */
  total_deletable_size?: number;
  total_files?: number;
  /** in bytes */
  total_size?: number;
  total_skipped_files?: number;
  /** in bytes */
  total_skipped_size?: number;
}

export interface DtoCCTVAnalyticConfigResponse {
  cctv_analytic_id?: string;
  config?: object;
  id?: string;
}

export interface DtoCCTVAnalyticDetail {
  analytic_type?: {
    description?: string;
    id?: string;
    name?: string;
  };
  analytic_type_id?: string;
  cctv_id?: string;
  created_at?: string;
  enable?: boolean;
  id?: string;
  updated_at?: string;
}

export interface DtoCCTVAnalyticDetailOnAnalytic {
  analytic_type?: DtoAnalyticTypeDetail;
  analytic_type_id?: string;
  cctv_id?: string;
  enable?: boolean;
  id?: string;
}

export interface DtoCCTVAnalyticListItem {
  analytic_type?: {
    description?: string;
    id?: string;
    name?: string;
  };
  analytic_type_id?: string;
  cctv_id?: string;
  created_at?: string;
  enable?: boolean;
  id?: string;
  updated_at?: string;
}

export interface DtoCCTVConnectionDetail {
  hostname?: string;
  id?: string;
  password?: string;
  path?: string;
  port?: number;
  protocol?: string;
  username?: string;
}

export interface DtoCCTVDeletionResult {
  cctv_id?: string;
  cctv_name?: string;
  deleted_count?: number;
  /** in bytes */
  deleted_size?: number;
  failed_file_ids?: string[];
  failed_storage_count?: number;
  skipped_count?: number;
  /** in bytes */
  skipped_size?: number;
  total_files?: number;
}

export interface DtoCCTVDeletionSummary {
  cctv_id?: string;
  cctv_name?: string;
  deletable_files?: number;
  /** in bytes */
  deletable_size?: number;
  skipped_files?: number;
  /** in bytes */
  skipped_size?: number;
  total_files?: number;
  /** in bytes */
  total_size?: number;
}

export interface DtoCCTVDetail {
  analytics?: DtoAnalyticListItemOnCCTV[];
  brand?: string;
  check_interval?: number;
  created_at?: string;
  description?: string;
  hostname?: string;
  id?: string;
  is_ptz_supported?: boolean;
  last_checked?: string;
  name?: string;
  nvr?: DtoCCTVNVRListItem;
  nvr_id?: string;
  path?: string;
  port?: number;
  protocol?: string;
  recording_status?: number;
  snapshot_image?: string;
  status?: string;
  type?: string;
  updated_at?: string;
  uptime_seconds?: number;
  username?: string;
}

export interface DtoCCTVListItem {
  brand?: string;
  check_interval?: number;
  created_at?: string;
  description?: string;
  hostname?: string;
  id?: string;
  last_checked?: string;
  name?: string;
  nvr_id?: string;
  nvr_name?: string;
  path?: string;
  port?: number;
  protocol?: string;
  recording_status?: number;
  snapshot_image?: string;
  status?: string;
  type?: string;
  uptime_seconds?: number;
}

export interface DtoCCTVNVRListItem {
  description?: string;
  group_id?: string;
  id?: string;
  last_checked?: string;
  location_id?: string;
  name?: string;
  status?: string;
  version?: string;
}

export interface DtoCCTVRecordingPlayback {
  cctv_id?: string;
  cctv_name?: string;
  segments?: DtoRecordingSegment[];
  timeline?: DtoRecordingTimeline;
  total_segments?: number;
}

export interface DtoCCTVRecordingScheduleInfo {
  cctv_id?: string;
  cctv_name?: string;
  created_at?: string;
  enabled_hours?: number[];
  id?: string;
  retention_days?: number;
  updated_at?: string;
}

export interface DtoCCTVRecordingScheduleResponse {
  cctv_id?: string;
  created_at?: string;
  enabled_hours?: number[];
  id?: string;
  retention_days?: number;
  updated_at?: string;
}

export interface DtoCCTVSnapshotResponse {
  snapshot_url?: string;
}

export interface DtoCCTVStatusResponse {
  check_interval?: number;
  last_checked?: string;
  status?: string;
  uptime_seconds?: number;
}

export interface DtoCCTVStorageBreakdown {
  /** in GB */
  avg_daily_size_gb?: number;
  cctv_id?: string;
  cctv_name?: string;
  days_of_recording?: number;
  latest_recording?: string;
  location_name?: string;
  nvr_name?: string;
  oldest_recording?: string;
  /** in GB for readability */
  storage_size_gb?: number;
  total_recordings?: number;
  /** in bytes */
  total_storage_size?: number;
}

export interface DtoCCTVStreamURLsResponse {
  cctv_id?: string;
  main_stream?: DtoStreamURLDetailResponse;
  name?: string;
  streams?: DtoStreamURLDetailResponse[];
}

export interface DtoCameraSearchResponse {
  cameras?: DtoCameraSearchResult[];
}

export interface DtoCameraSearchResult {
  id?: string;
  name?: string;
}

export interface DtoChangePasswordDTO {
  current_password: string;
  /** @minLength 8 */
  new_password: string;
}

export interface DtoCheckUsernameResponse {
  exists?: boolean;
}

export interface DtoCountingChartResponse {
  /** Y-axis data (people count) */
  data?: number[];
  /** X-axis labels (dates or hours) */
  labels?: string[];
  /** Chart title */
  title?: string;
}

export interface DtoCreateAlertDTO {
  analytic_id: string;
  cctv_analytic_id: string;
  message: string;
}

export interface DtoCreateAllMemberAlertSettingsDTO {
  cctv_id: string;
}

export interface DtoCreateAnalyticDTO {
  cctv_analytic_id: string;
  file_id: string;
}

export interface DtoCreateCCTVAnalyticDTO {
  analytic_type_id: string;
  cctv_id: string;
  enable?: boolean;
}

export interface DtoCreateCCTVDTO {
  Protocol: string;
  brand: string;
  check_interval: number;
  description?: string;
  hostname: string;
  name: string;
  nvr_id: string;
  password?: string;
  path?: string;
  port: number;
  type: string;
  username?: string;
}

export interface DtoCreateEdgeAlertDTO {
  analytic_id: string;
  cctv_analytic_id: string;
  message: string;
}

export interface DtoCreateEdgeAlertWithoutAnalyticDTO {
  cctv_analytic_id: string;
  message: string;
}

export interface DtoCreateFileAISummaryRequest {
  /**
   * @minLength 10
   * @maxLength 1000
   */
  custom_prompt: string;
}

export interface DtoCreateFileAnalyticProcessRequest {
  analytic_type_id: string;
  metadata?: object;
  status?: "processing" | "completed" | "error";
}

export interface DtoCreateFileDTO {
  cctv_id: string;
  created_at?: string;
  file_name: string;
  file_type: ModelsFileType;
  file_url: string;
  metadata?: object;
  size: number;
  snapshot_image?: string;
}

export interface DtoCreateFloorPlanObjectRequest {
  floor_plan_id: string;
  object_id: string;
  object_type: "nvr" | "cctv";
  /**
   * @min 0
   * @max 100
   */
  position_x: number;
  /**
   * @min 0
   * @max 100
   */
  position_y: number;
}

export interface DtoCreateFloorPlanRequest {
  dimension_height: number;
  dimension_width: number;
  image_url: string;
  location_id: string;
  name: string;
}

export interface DtoCreateGroupDTO {
  email: string;
  group_name: string;
}

export interface DtoCreateLocationDTO {
  address: string;
  image_url?: string;
  latitude: number;
  location_name: string;
  longitude: number;
}

export interface DtoCreateMemberAlertSettingDTO {
  cctv_analytic_id: string;
}

export interface DtoCreateMemberDTO {
  email: string;
  role: "admin" | "member";
}

export interface DtoCreateNVRDTO {
  check_interval: number;
  description?: string;
  hostname: string;
  location_id: string;
  name: string;
  password: string;
  port: number;
  user_name: string;
}

export interface DtoCreateStreamURLDTO {
  hostname: string;
  password?: string;
  path: string;
  port: number;
  protocol: string;
  title: string;
  username?: string;
}

export interface DtoCreateVideoWallDTO {
  cctv_list: string[];
  group_id: string;
  layout: "1+3" | "1+5" | "1+8" | "1+12" | "2x2" | "3x3" | "4x4" | "5x5";
  name: string;
}

export interface DtoCustomTime {
  "time.Time"?: string;
}

export interface DtoDashboardStatsResponse {
  camera_offline?: number;
  camera_online?: number;
  nvr_offline?: number;
  nvr_online?: number;
  total_camera?: number;
  total_location?: number;
  total_nvr?: number;
}

export interface DtoDeleteFilesResponse {
  deleted_count?: number;
  failed_file_ids?: string[];
  failed_storage_count?: number;
  skipped_count?: number;
  total_files?: number;
}

export interface DtoDifferentDirectionChartResponse {
  data?: number[];
  labels?: string[];
  title?: string;
}

export interface DtoEdgeCCTVConfig {
  brand?: string;
  check_interval?: number;
  description?: string;
  hostname?: string;
  id?: string;
  is_ptz_supported?: boolean;
  name?: string;
  password?: string;
  path?: string;
  port?: number;
  protocol?: string;
  recording_status?: number;
  status?: string;
  type?: string;
  username?: string;
}

export interface DtoEdgeCCTVCreate {
  brand: string;
  check_interval?: number;
  description: string;
  hostname: string;
  id?: string;
  is_ptz_supported?: boolean;
  name: string;
  password: string;
  path: string;
  port: number;
  protocol: string;
  type: string;
  username: string;
}

export interface DtoEdgeCCTVHeartbeat {
  last_checked: string;
  recording_status?: number;
  status: string;
}

export interface DtoEdgeCCTVSnapshot {
  snapshot_image: string;
}

export interface DtoEdgeFileCreate {
  cctv_id: string;
  created_at?: string;
  file_name: string;
  file_type: ModelsFileType;
  file_url: string;
  metadata?: object;
  size: number;
  snapshot_image?: string;
}

export interface DtoEdgeFileDetail {
  cctv_id?: string;
  file_name?: string;
  file_type?: ModelsFileType;
  file_url?: string;
  id?: string;
  size?: number;
  snapshot_image?: string;
}

export interface DtoEdgeFileUpdate {
  file_name?: string;
  file_url?: string;
  size?: number;
  snapshot_image?: string;
}

export interface DtoFaceDetail {
  cctv_id?: string;
  cctv_name?: string;
  event_timestamp?: DtoCustomTime;
  file_id?: string;
  floor_plan_id?: string;
  floor_plan_name?: string;
  group_name?: string;
  location_id?: string;
  location_name?: string;
  org_id?: string;
  track_id?: string;
  video_time?: string;
}

export interface DtoFaceSearchResponse {
  page_number?: number;
  page_size?: number;
  results?: DtoFaceSearchResult[];
  total_pages?: number;
  total_result?: number;
}

export interface DtoFaceSearchResult {
  face_details?: DtoFaceDetail;
  face_link?: string;
  person_link?: string;
  similarity?: number;
}

export interface DtoFileAISummaryDetail {
  completed_at?: string;
  created_at?: string;
  custom_prompt?: string;
  error_message?: string;
  file?: DtoFileDetailSummary;
  file_id?: string;
  id?: string;
  job_id?: string;
  output_result?: object;
  status?: ModelsFileAISummaryStatus;
  updated_at?: string;
  user_id?: string;
}

export interface DtoFileAISummaryListItem {
  completed_at?: string;
  created_at?: string;
  custom_prompt?: string;
  id?: string;
  status?: ModelsFileAISummaryStatus;
}

export interface DtoFileAISummaryResponse {
  created_at?: string;
  custom_prompt?: string;
  file_id?: string;
  id?: string;
  job_id?: string;
  status?: ModelsFileAISummaryStatus;
  user_id?: string;
}

export interface DtoFileAnalyticProcessResponse {
  analytic_type?: {
    description?: string;
    id?: string;
    name?: string;
  };
  analytic_type_id?: string;
  created_at?: string;
  file_id?: string;
  id?: string;
  metadata?: object;
  processed_at?: string;
  status?: string;
}

export interface DtoFileDetail {
  analytics?: DtoAnalyticListItemOnCCTV[];
  cctv?: DtoCCTVListItem;
  cctv_id?: string;
  created_at?: string;
  file_name?: string;
  file_type?: ModelsFileType;
  file_url?: string;
  id?: string;
  size?: number;
  snapshot_image?: string;
  updated_at?: string;
}

export interface DtoFileDetailAdvanced {
  analytic_process?: boolean;
  analytic_processes?: {
    analytic_type?: {
      description?: string;
      id?: string;
      name?: string;
    };
    created_at?: string;
    id?: string;
    metadata?: object;
    processed_at?: string;
    status?: string;
  }[];
  cctv?: {
    brand?: string;
    id?: string;
    name?: string;
    nvr_id?: string;
    nvr_name?: string;
  };
  cctv_id?: string;
  created_at?: string;
  download_url?: string;
  file_analytics?: {
    analytic_type?: {
      id?: string;
      name?: string;
    };
    cctv_analytic_id?: string;
    created_at?: string;
    id?: string;
  }[];
  file_name?: string;
  file_type?: ModelsFileType;
  file_url?: string;
  floor_plan?: {
    id?: string;
    name?: string;
  };
  id?: string;
  location?: {
    id?: string;
    name?: string;
  };
  metadata?: object;
  provider?: string;
  size?: number;
  snapshot_image?: string;
  updated_at?: string;
}

export interface DtoFileDetailSummary {
  created_at?: string;
  file_name?: string;
  file_type?: ModelsFileType;
  file_url?: string;
  id?: string;
  size?: number;
  updated_at?: string;
}

export interface DtoFileListItem {
  analytic_process?: boolean;
  analytics?: {
    name?: string;
  }[];
  cctv_id?: string;
  cctv_name?: string;
  created_at?: string;
  file_name?: string;
  file_type?: ModelsFileType;
  file_url?: string;
  id?: string;
  provider?: string;
  size?: number;
  snapshot_image?: string;
}

export interface DtoFileListItemOnAnalytic {
  cctv_id?: string;
  created_at?: string;
  file_name?: string;
  file_type?: ModelsFileType;
  file_url?: string;
  id?: string;
  size?: number;
  snapshot_image?: string;
}

export interface DtoFileListItemWithLocation {
  analytic_process?: boolean;
  analytics?: {
    name?: string;
  }[];
  cctv_id?: string;
  cctv_name?: string;
  created_at?: string;
  file_name?: string;
  file_type?: ModelsFileType;
  file_url?: string;
  floor_plan_name?: string;
  id?: string;
  location_name?: string;
  provider?: string;
  size?: number;
  snapshot_image?: string;
}

export interface DtoFileLocationDetail {
  cctv_id?: string;
  cctv_name?: string;
  created_at?: string;
  file_name?: string;
  file_type?: ModelsFileType;
  file_url?: string;
  floor_plan?: {
    id?: string;
    name?: string;
  };
  id?: string;
  location_id?: string;
  location_name?: string;
  nvr_id?: string;
  nvr_name?: string;
}

export interface DtoFireSmokeChartResponse {
  data?: number[];
  labels?: string[];
  title?: string;
}

export interface DtoFloorPlanDetailResponse {
  dimension_height?: number;
  dimension_width?: number;
  id?: string;
  image_url?: string;
  location?: {
    id?: string;
    name?: string;
  };
  name?: string;
  objects?: {
    id?: string;
    object_id?: string;
    object_info?: {
      id?: string;
      name?: string;
      snapshot_image?: string;
      status?: string;
    };
    object_type?: string;
    position_x?: number;
    position_y?: number;
  }[];
}

export interface DtoFloorPlanEdgeListResponse {
  items?: {
    dimension_height?: number;
    dimension_width?: number;
    id?: string;
    image_url?: string;
    name?: string;
    object_count?: number;
  }[];
  location?: {
    id?: string;
    name?: string;
  };
}

export interface DtoFloorPlanListResponse {
  items?: {
    created_at?: string;
    dimension_height?: number;
    dimension_width?: number;
    id?: string;
    image_url?: string;
    location?: {
      id?: string;
      name?: string;
    };
    name?: string;
    object_count?: number;
  }[];
  limit?: number;
  offset?: number;
  total?: number;
}

export interface DtoFloorPlanObjectListResponse {
  items?: {
    created_at?: string;
    floor_plan?: {
      id?: string;
      name?: string;
    };
    id?: string;
    object?: {
      id?: string;
      image_url?: string;
      name?: string;
      status?: string;
    };
    object_id?: string;
    object_type?: string;
    position_x?: number;
    position_y?: number;
  }[];
  limit?: number;
  offset?: number;
  total?: number;
}

export interface DtoFloorPlanObjectResponse {
  created_at?: string;
  floor_plan?: {
    dimension_height?: number;
    dimension_width?: number;
    id?: string;
    image_url?: string;
    name?: string;
  };
  id?: string;
  object?: {
    id?: string;
    image_url?: string;
    name?: string;
    status?: string;
  };
  object_id?: string;
  object_type?: string;
  position_x?: number;
  position_y?: number;
  updated_at?: string;
}

export interface DtoFloorPlanResponse {
  created_at?: string;
  dimension_height?: number;
  dimension_width?: number;
  id?: string;
  image_url?: string;
  location?: {
    id?: string;
    name?: string;
  };
  name?: string;
  objects?: {
    id?: string;
    object_id?: string;
    object_info?: {
      name?: string;
    };
    object_type?: string;
    position_x?: number;
    position_y?: number;
  }[];
  updated_at?: string;
}

export interface DtoFloorPlanSearchResponse {
  floor_plans?: DtoFloorPlanSearchResult[];
}

export interface DtoFloorPlanSearchResult {
  id?: string;
  name?: string;
}

export interface DtoForgotPasswordRequest {
  email: string;
}

export interface DtoForgotPasswordResponse {
  message?: string;
}

export interface DtoGeneratePublishTokenRequest {
  /** base64(username:password) */
  basic_auth: string;
  cctv_id: string;
}

export interface DtoGenerateReadTokenRequest {
  cctv_id: string;
}

export interface DtoGetPresignedURLRequest {
  content_length: number;
  file_name: string;
}

export interface DtoGroupCCTVAnalyticsResponse {
  items?: {
    cctv?: {
      cctv_analytics?: {
        analytic_type_id?: string;
        analytic_type_name?: string;
        id?: string;
        status?: boolean;
      }[];
      cctv_id?: string;
      cctv_name?: string;
      nvr_id?: string;
    }[];
    org_id?: string;
    org_name?: string;
  }[];
}

export interface DtoGroupDTO {
  group_name?: string;
  group_status?: string;
  id?: string;
  storage_size?: number;
  storage_used?: number;
}

export interface DtoGroupDetailDTO {
  created_at?: string;
  created_by?: string;
  created_by_user?: {
    email?: string;
    full_name?: string;
    id?: string;
  };
  email?: string;
  group_name?: string;
  group_status?: string;
  id?: string;
  storage_notification_threshold?: number;
  storage_size?: number;
  storage_used?: number;
  updated_at?: string;
}

export interface DtoGroupOverviewResponse {
  active_recording_cctvs?: number;
  active_until?: string;
  cctvs_on_floor_plans?: number;
  created_at?: string;
  email?: string;
  /** Group Information */
  group_name?: string;
  group_status?: string;
  nvrs_on_floor_plans?: number;
  total_floor_plans?: number;
  /** Statistics */
  total_locations?: number;
  total_members?: number;
  total_storage_used?: number;
}

export interface DtoGroupResourceCount {
  cctv_count?: number;
  group_name?: string;
  nvr_count?: number;
}

export interface DtoHealthSafetyEnvironmentChartResponse {
  data?: number[];
  labels?: string[];
  title?: string;
}

export interface DtoHeatmapAnalyticsResponse {
  /** 2D array [day_of_week][hour] for weekly or [day_of_month][hour] for monthly */
  data?: number[][];
  /** Day labels (Mon-Sun for weekly, 1-31 for monthly) */
  day_labels?: string[];
  /** Hour labels (0-23) */
  hour_labels?: number[];
  /** Maximum value in the heatmap for scaling */
  max_value?: number;
  /** Scale steps for visualization (0 to max_value in 5 steps) */
  scale?: number[];
  /** Description of the selected period */
  selected_period?: string;
}

export interface DtoHourlyBreakdownData {
  comparison_time?: string;
  time?: string;
}

export interface DtoIllegalParkingChartResponse {
  data?: number[];
  labels?: string[];
  title?: string;
}

export interface DtoInOutCountingChartDetail {
  /** Time label */
  label?: string;
  /** People in count */
  people_in?: number;
  /** People out count */
  people_out?: number;
}

export interface DtoInOutCountingChartResponse {
  /** Detailed chart data */
  chart_data?: DtoInOutCountingChartDetail[];
  /** Y-axis data for people in */
  data_in?: number[];
  /** Y-axis data for people out */
  data_out?: number[];
  /** X-axis labels (dates or hours) */
  labels?: string[];
  /** Chart title */
  title?: string;
}

export interface DtoInOutCountingOverviewResponse {
  total_people_in?: DtoPeopleCountData;
  total_people_out?: DtoPeopleCountData;
}

export interface DtoJWK {
  /** Curve (P-256) */
  crv?: string;
  /** Key ID */
  kid?: string;
  /** Key Type (EC) */
  kty?: string;
  /** Public key use (sig) */
  use?: string;
  /** X coordinate */
  x?: string;
  /** Y coordinate */
  y?: string;
}

export interface DtoJWKSResponse {
  keys?: DtoJWK[];
}

export interface DtoJoinGroupMemberDTO {
  email: string;
}

export interface DtoListAlertResponse {
  alerts?: DtoAlertListItemOnAlert[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListAnalyticNotificationsResponse {
  analytics?: DtoAnalyticReportItem[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListAnalyticReportsResponse {
  analytics?: DtoAnalyticReportItem[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListAnalyticsResponse {
  analytics?: DtoAnalyticListItem[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListCCTVAnalyticsResponse {
  cctv_analytics?: DtoCCTVAnalyticListItem[];
  total?: number;
}

export interface DtoListCCTVsResponse {
  cctvs?: DtoCCTVListItem[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListFilesResponse {
  files?: DtoFileListItem[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListFilesWithLocationResponse {
  files?: DtoFileListItemWithLocation[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListLocationsResponse {
  locations?: DtoLocationListItem[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListMemberAlertSettingsResponse {
  member_alert_settings?: DtoMemberAlertSettingListItem[];
}

export interface DtoListMembersResponse {
  members?: DtoMemberListItem[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListNVRsResponse {
  nvrs?: DtoNVRListItem[];
  page?: number;
  size?: number;
  total?: number;
}

export interface DtoListVideoWallsResponse {
  page?: number;
  size?: number;
  total?: number;
  video_walls?: DtoVideoWallListItem[];
}

export interface DtoLocationDTO {
  address?: string;
  id?: string;
  image_url?: string;
  latitude?: number;
  location_name?: string;
  longitude?: number;
}

export interface DtoLocationDetail {
  address?: string;
  created_at?: string;
  created_by?: string;
  created_by_user?: DtoUserDTO;
  group?: DtoGroupDTO;
  group_id?: string;
  id?: string;
  image_url?: string;
  latitude?: number;
  location_name?: string;
  longitude?: number;
  total_cctvs?: number;
  total_floor_plans?: number;
  total_nvrs?: number;
  updated_at?: string;
}

export interface DtoLocationListItem {
  address?: string;
  created_at?: string;
  group_name?: string;
  id?: string;
  image_url?: string;
  latitude?: number;
  location_name?: string;
  longitude?: number;
}

export interface DtoLocationSearchResponse {
  locations?: DtoLocationSearchResult[];
}

export interface DtoLocationSearchResult {
  id?: string;
  name?: string;
}

export interface DtoLoginRequest {
  email: string;
  /** @minLength 6 */
  password: string;
}

export interface DtoLoginResponse {
  access_token?: string;
  email?: string;
  name?: string;
  profile_picture?: string;
  refresh_token?: string;
}

export interface DtoMemberAlertSettingDetail {
  cctv_analytic?: {
    analytic_type?: {
      description?: string;
      id?: string;
      name?: string;
    };
    cctv?: {
      description?: string;
      hostname?: string;
      id?: string;
      name?: string;
      port?: number;
    };
    id?: string;
  };
  cctv_analytic_id?: string;
  enabled?: boolean;
  id?: string;
}

export interface DtoMemberAlertSettingListItem {
  cctv_analytic?: {
    analytic_type?: {
      id?: string;
      name?: string;
    };
    cctv?: {
      id?: string;
      name?: string;
    };
    id?: string;
  };
  cctv_analytic_id?: string;
  enabled?: boolean;
  id?: string;
}

export interface DtoMemberDetail {
  created_at?: string;
  group_id?: string;
  id?: string;
  role?: string;
  status?: string;
  updated_at?: string;
  user?: DtoUserDTO;
  user_id?: string;
}

export interface DtoMemberListItem {
  created_at?: string;
  group_id?: string;
  group_name?: string;
  id?: string;
  profile_picture_url?: string;
  role?: string;
  status?: string;
  user_email?: string;
  user_id?: string;
  user_name?: string;
}

export interface DtoMembershipList {
  memberships?: DtoMembershipListItem[];
}

export interface DtoMembershipListItem {
  group_id?: string;
  group_name?: string;
  group_status?: string;
  id?: string;
  role?: string;
  status?: string;
  user_id?: string;
}

export interface DtoMultiCCTVRecordingPlaybackResponse {
  cctv_playbacks?: DtoCCTVRecordingPlayback[];
  end_time?: string;
  start_time?: string;
  total_cctvs?: number;
  video_wall_id?: string;
  video_wall_name?: string;
}

export interface DtoNVRCCTVListItem {
  check_interval?: number;
  description?: string;
  id?: string;
  last_checked?: string;
  name?: string;
  snapshot_image?: string;
  status?: string;
}

export interface DtoNVRCheckIntervalResponse {
  check_interval?: number;
}

export interface DtoNVRConnectionDetail {
  hostname?: string;
  id?: string;
  password?: string;
  port?: number;
  token?: string;
  username?: string;
}

export interface DtoNVRDetail {
  cctvs?: DtoNVRCCTVListItem[];
  check_interval?: number;
  created_at?: string;
  created_by?: string;
  created_by_user?: DtoUserDTO;
  description?: string;
  group?: DtoGroupDTO;
  group_id?: string;
  hostname?: string;
  id?: string;
  last_checked?: string;
  location?: DtoLocationDTO;
  location_id?: string;
  name?: string;
  port?: number;
  status?: string;
  token?: string;
  updated_at?: string;
  user_name?: string;
  version?: string;
}

export interface DtoNVREdgeCCTVSchedulesResponse {
  nvr_id?: string;
  schedules?: DtoCCTVRecordingScheduleInfo[];
}

export interface DtoNVREdgeConfig {
  active_until?: string;
  check_interval?: number;
  group_id?: string;
  group_name?: string;
  hostname?: string;
  id?: string;
  last_checked?: string;
  location?: string;
  location_id?: string;
  name?: string;
  port?: number;
  status?: string;
  user_name?: string;
  version?: string;
}

export interface DtoNVREdgeOrgDetailDto {
  created_at?: string;
  email?: string;
  group_name?: string;
  group_status?: string;
  id?: string;
}

export interface DtoNVRListItem {
  cctv_count?: number;
  check_interval?: number;
  cover_image?: string;
  created_at?: string;
  description?: string;
  group_id?: string;
  group_name?: string;
  hostname?: string;
  id?: string;
  last_checked?: string;
  location_id?: string;
  location_name?: string;
  name?: string;
  port?: number;
  status?: string;
  version?: string;
}

export interface DtoNVRTokenResponse {
  id?: string;
  token?: string;
}

export interface DtoPTZCommandRequest {
  cctv_id: string;
  direction: "up" | "down" | "left" | "right" | "zoomin" | "zoomout";
}

export interface DtoPTZCommandResponse {
  message?: string;
  success?: boolean;
}

export interface DtoPeopleConvergeChartResponse {
  data?: number[];
  labels?: string[];
  title?: string;
}

export interface DtoPeopleCountData {
  count?: number;
  unit?: string;
}

export interface DtoPeopleCountingOverviewResponse {
  busiest_hour?: DtoHourlyBreakdownData;
  people_average?: DtoPeopleCountData;
  quietest_hour?: DtoHourlyBreakdownData;
  total_people?: DtoPeopleCountData;
}

export interface DtoPersonRunningChartResponse {
  data?: number[];
  labels?: string[];
  title?: string;
}

export interface DtoPlanInfoDTO {
  display_name?: string;
  id?: string;
  name?: string;
}

export interface DtoPresignedRequest {
  file_url?: string;
  header?: Record<string, string>;
  method?: string;
  url?: string;
}

export interface DtoPresignedURLResponse {
  url?: string;
}

export interface DtoQuotaResponseDTO {
  max?: number;
  percentage?: number;
  remaining?: number;
  used?: number;
}

export interface DtoRecordingPlaybackResponse {
  cctv_id?: string;
  end_time?: string;
  segments?: DtoRecordingSegment[];
  start_time?: string;
  timeline?: DtoRecordingTimeline;
  total_segments?: number;
}

export interface DtoRecordingSegment {
  duration?: number;
  file_name?: string;
  file_url?: string;
  id?: string;
  offset_from_start?: number;
  sequence?: number;
  start_time?: string;
}

export interface DtoRecordingStorageBreakdownResponse {
  cctv_breakdowns?: DtoCCTVStorageBreakdown[];
  group_id?: string;
  group_name?: string;
  latest_recording?: string;
  oldest_recording?: string;
  storage_info?: DtoStorageInfo;
  /** Top 5 by storage */
  top_storage_cctvs?: DtoCCTVStorageBreakdown[];
  total_cctvs?: number;
  total_days_of_recording?: number;
  total_recordings?: number;
  /** in bytes */
  total_storage_size?: number;
  /** in GB */
  total_storage_size_gb?: number;
}

export interface DtoRecordingTimeline {
  available_duration?: number;
  gaps?: DtoTimelineGap[];
  total_duration?: number;
}

export interface DtoRegenerateTokenRequest {
  refresh_token: string;
}

export interface DtoRegenerateTokenResponse {
  access_token?: string;
  refresh_token?: string;
}

export interface DtoRegisterRequest {
  email: string;
  full_name: string;
  /** @minLength 6 */
  password: string;
}

export interface DtoRegisterResponse {
  message?: string;
}

export interface DtoResendVerificationRequest {
  email: string;
}

export interface DtoResetNVRTokenResponse {
  token?: string;
}

export interface DtoResetPasswordRequest {
  /** @minLength 8 */
  new_password: string;
  token: string;
}

export interface DtoResetPasswordResponse {
  message?: string;
}

export interface DtoRestrictedAreaChartResponse {
  /** Y-axis data (alert count) */
  data?: number[];
  /** X-axis labels (hours 00:00-23:00) */
  labels?: string[];
  /** Chart title */
  title?: string;
}

export interface DtoSearchFaceRequestBody {
  cctv_id?: string;
  /** YYYY-MM-DD format */
  end_date?: string;
  floor_plan_id?: string;
  location_id?: string;
  org_id: string;
  /** YYYY-MM-DD format */
  start_date?: string;
}

export interface DtoStorageChartPoint {
  /** Could be day, week, or month depending on range */
  time_label?: string;
  /** Storage used in MB */
  usage?: number;
}

export interface DtoStorageDetailsResponse {
  /** Chart data for usage over time */
  chart_data?: DtoStorageChartPoint[];
  /** Storage breakdown by file types */
  storage_breakdown?: {
    /** in MB */
    image?: number;
    /** in MB */
    recording?: number;
    /** in MB */
    video?: number;
  };
  /** in MB */
  total_storage?: number;
}

export interface DtoStorageInfo {
  non_recording_size_gb?: number;
  recording_size_gb?: number;
  storage_available_gb?: number;
  storage_limit_gb?: number;
  storage_used_gb?: number;
  utilization_percentage?: number;
}

export interface DtoStorageQuotaResponseDTO {
  /** in bytes */
  max?: number;
  percentage?: number;
  /** in bytes */
  remaining?: number;
  /** in bytes */
  used?: number;
}

export interface DtoStorageUsageDTO {
  is_threshold_exceeded?: boolean;
  storage_notification_threshold?: number;
  storage_size?: number;
  storage_usage_percentage?: number;
  storage_used?: number;
}

export interface DtoStreamTokenResponse {
  token?: string;
}

export interface DtoStreamURLDetailResponse {
  cctv_id?: string;
  created_at?: string;
  hostname?: string;
  id?: string;
  password?: string;
  path?: string;
  port?: number;
  protocol?: string;
  title?: string;
  updated_at?: string;
  url?: string;
  username?: string;
}

export interface DtoStreamURLResponse {
  cctv_id?: string;
  created_at?: string;
  hostname?: string;
  id?: string;
  path?: string;
  port?: number;
  protocol?: string;
  title?: string;
  updated_at?: string;
  username?: string;
}

export interface DtoSurroundingVesselChartDetail {
  /** Buoy count */
  buoy?: number;
  /** Container count */
  container?: number;
  /** Cruise count */
  cruise?: number;
  /** Fish boat count */
  fish_boat?: number;
  /** Time label */
  label?: string;
  /** Obstacle count */
  obstacle?: number;
  /** Warship count */
  warship?: number;
}

export interface DtoSurroundingVesselChartResponse {
  /** Detailed chart data */
  chart_data?: DtoSurroundingVesselChartDetail[];
  /** Y-axis data for buoy */
  data_buoy?: number[];
  /** Y-axis data for container */
  data_container?: number[];
  /** Y-axis data for cruise */
  data_cruise?: number[];
  /** Y-axis data for fish boat */
  data_fish_boat?: number[];
  /** Y-axis data for obstacle */
  data_obstacle?: number[];
  /** Y-axis data for warship */
  data_warship?: number[];
  /** X-axis labels (dates or hours) */
  labels?: string[];
  /** Chart title */
  title?: string;
}

export interface DtoSurroundingVesselOverviewResponse {
  total_buoy?: DtoVesselCountData;
  total_container?: DtoVesselCountData;
  total_cruise?: DtoVesselCountData;
  total_fish_boat?: DtoVesselCountData;
  total_obstacle?: DtoVesselCountData;
  total_warship?: DtoVesselCountData;
}

export interface DtoTimelineGap {
  duration?: number;
  start?: number;
}

export interface DtoUnattendedObjectChartResponse {
  data?: number[];
  labels?: string[];
  title?: string;
}

export interface DtoUpdateAnalyticDTO {
  cctv_analytic_id?: string;
  file_id?: string;
}

export interface DtoUpdateCCTVAnalyticConfigRequest {
  config: object;
}

export interface DtoUpdateCCTVAnalyticDTO {
  enable?: boolean;
}

export interface DtoUpdateCCTVDTO {
  brand?: string;
  check_interval?: number;
  description?: string;
  hostname?: string;
  is_ptz_supported?: boolean;
  name?: string;
  nvr_id?: string;
  password?: string;
  path?: string;
  port?: number;
  protocol?: string;
  recording_status?: number;
  snapshot_image?: string;
  status?: string;
  type?: string;
  username?: string;
}

export interface DtoUpdateCCTVRecordingScheduleRequest {
  enabled_hours: number[];
  /** @min 1 */
  retention_days?: number;
}

export interface DtoUpdateFileDTO {
  file_name?: string;
  file_url?: string;
  size?: number;
  snapshot_image?: string;
}

export interface DtoUpdateFileProcessingStatusRequest {
  analytic_process: boolean;
}

export interface DtoUpdateFloorPlanObjectRequest {
  /**
   * @min 0
   * @max 100
   */
  position_x: number;
  /**
   * @min 0
   * @max 100
   */
  position_y: number;
}

export interface DtoUpdateFloorPlanRequest {
  dimension_height: number;
  dimension_width: number;
  image_url: string;
  name: string;
}

export interface DtoUpdateLocationDTO {
  /** optional */
  address?: string;
  /** optional */
  image_url?: string;
  /** optional */
  latitude?: number;
  /** optional */
  location_name?: string;
  /** optional */
  longitude?: number;
}

export interface DtoUpdateMemberAlertSettingDTO {
  enabled?: boolean;
}

export interface DtoUpdateMemberDTO {
  /** optional */
  role?: "admin" | "member";
  /** optional */
  status?: "active" | "pending" | "banned" | "disabled";
}

export interface DtoUpdateNVRDTO {
  /** optional */
  check_interval?: number;
  /** optional */
  description?: string;
  /** optional */
  hostname?: string;
  /** optional */
  location_id?: string;
  /** optional */
  name?: string;
  /** optional */
  password?: string;
  /** optional */
  port?: number;
  /** optional */
  status?: string;
  /** optional */
  user_name?: string;
  /** optional */
  version?: string;
}

export interface DtoUpdateNVRStatusDTO {
  last_checked: string;
  status: string;
}

export interface DtoUpdateNVRVersionDTO {
  version: string;
}

export interface DtoUpdateStorageSettingsDTO {
  /**
   * @min 0
   * @max 100
   */
  storage_notification_threshold: number;
}

export interface DtoUpdateUserDTO {
  /** optional */
  name?: string;
  /** optional */
  phone?: string;
  /** optional */
  profile_picture_url?: string;
}

export interface DtoUpdateVideoWallDTO {
  cctv_list?: string[];
  layout?: "1+3" | "1+5" | "1+8" | "1+12" | "2x2" | "3x3" | "4x4" | "5x5";
  name?: string;
}

export interface DtoUserDTO {
  email?: string;
  full_name?: string;
  id?: string;
  phone?: string;
  profile_picture_url?: string;
}

export interface DtoValidateStreamTokenRequest {
  token: string;
}

export interface DtoValidateStreamTokenResponse {
  claims?: Record<string, any>;
  error?: string;
  valid?: boolean;
}

export interface DtoVesselCountData {
  count?: number;
  unit?: string;
}

export interface DtoVideoWallCCTVItem {
  check_interval?: number;
  id?: string;
  last_checked?: string;
  name?: string;
  recording_status?: number;
  snapshot_image?: string;
  status?: string;
  stream_urls?: DtoCCTVStreamURLsResponse;
}

export interface DtoVideoWallDetail {
  cctv_list?: DtoVideoWallCCTVItem[];
  created_at?: string;
  group_id?: string;
  id?: string;
  layout?: string;
  name?: string;
  updated_at?: string;
}

export interface DtoVideoWallListItem {
  id?: string;
  layout?: string;
  name?: string;
}

export interface ErrorsAppError {
  code?: number;
  message?: string;
}

export interface HandlersTelegramUpdate {
  message?: {
    chat?: {
      first_name?: string;
      id?: number;
      last_name?: string;
      type?: string;
      username?: string;
    };
    date?: number;
    from?: {
      first_name?: string;
      id?: number;
      is_bot?: boolean;
      last_name?: string;
      username?: string;
    };
    message_id?: number;
    text?: string;
  };
  update_id?: number;
}

export interface AlertsListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID to filter alerts */
  cctv_id?: string;
  /** CCTV Analytic ID to filter alerts */
  cctv_analytic_id?: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for alert message */
  search?: string;
  /** Filter by analytic type */
  analytic_type?: string;
  /**
   * Filter by start date
   * @format date-time
   */
  start_date?: string;
  /**
   * Filter by end date
   * @format date-time
   */
  end_date?: string;
  /** Sort by field */
  sort_by?: "created_at" | "message";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type AlertsListData = DtoListAlertResponse;

export type AlertsListError = ErrorsAppError;

export interface AlertsCreateParams {
  /** Group ID */
  group_id: string;
}

export type AlertsCreateData = DtoAlertDetail;

export type AlertsCreateError = ErrorsAppError;

export type EdgeCreateData = DtoAlertCreatedResponse;

export type EdgeCreateError = ErrorsAppError;

export type EdgeWithoutAnalyticCreateData = DtoAlertCreatedResponse;

export type EdgeWithoutAnalyticCreateError = ErrorsAppError;

export interface PostApiKeyAlertParams {
  /** Group ID */
  group_id: string;
}

export type PostApiKeyAlertData = DtoAlertCreatedResponse;

export type PostApiKeyAlertError = ErrorsAppError;

export interface KeyWithoutAnalyticCreateParams {
  /** Group ID */
  group_id: string;
}

export type KeyWithoutAnalyticCreateData = DtoAlertCreatedResponse;

export type KeyWithoutAnalyticCreateError = ErrorsAppError;

export interface ReportsListParams {
  /** Group ID */
  group_id: string;
  /** Start date (YYYY-MM-DD) */
  start_date?: string;
  /** End date (YYYY-MM-DD) */
  end_date?: string;
  /** Analytic type name */
  analytic_type?:
    | "Smoke"
    | "Fire"
    | "Person"
    | "In-Out Restricted Area"
    | "Speed Detection"
    | "Person Running"
    | "Unattended Object"
    | "Object Detection"
    | "Wrong Way Detection"
    | "People Converge"
    | "Fire & Smoke Detection"
    | "Surrounding Vessel"
    | "Health Safety Environment"
    | "Illegal Parking";
  /** Search by camera name, location name, or alert message */
  search?: string;
  /** Sort by field */
  sort_by?: "created_at" | "camera_name";
  /** Sort order */
  sort_order?: "asc" | "desc";
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
}

export type ReportsListData = DtoListAnalyticReportsResponse;

export type ReportsListError = ErrorsAppError;

export type TelegramWebhookCreateData = string;

export interface AlertsDetailParams {
  /** Group ID */
  group_id: string;
  /** Alert ID */
  id: string;
}

export type AlertsDetailData = DtoAlertDetail;

export type AlertsDetailError = ErrorsAppError;

export interface AlertsDeleteParams {
  /** Group ID */
  group_id: string;
  /** Alert ID */
  id: string;
}

export type AlertsDeleteData = any;

export type AlertsDeleteError = ErrorsAppError;

export interface DifferentDirectionChartListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type DifferentDirectionChartListData =
  DtoDifferentDirectionChartResponse;

export type DifferentDirectionChartListError = ErrorsAppError;

export interface FireSmokeChartListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type FireSmokeChartListData = DtoFireSmokeChartResponse;

export type FireSmokeChartListError = ErrorsAppError;

export interface HseChartListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type HseChartListData = DtoHealthSafetyEnvironmentChartResponse;

export type HseChartListError = ErrorsAppError;

export interface IllegalParkingChartListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type IllegalParkingChartListData = DtoIllegalParkingChartResponse;

export type IllegalParkingChartListError = ErrorsAppError;

export interface InOutCountChartListParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
  /** Chart granularity (days or hours) */
  granularity: "days" | "hours";
  /** Start date (YYYY-MM-DD) - Required for 'days' granularity */
  start_date?: string;
  /** End date (YYYY-MM-DD) - Required for 'days' granularity */
  end_date?: string;
  /** Target date (YYYY-MM-DD) - Required for 'hours' granularity */
  target_date?: string;
  /** Start hour (0-23) - Required for 'hours' granularity */
  start_hour?: number;
  /** End hour (0-23) - Required for 'hours' granularity */
  end_hour?: number;
}

export type InOutCountChartListData = DtoInOutCountingChartResponse;

export type InOutCountChartListError = ErrorsAppError;

export interface InOutCountOverviewListParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
  /** Time granularity (days or hours) */
  granularity: "days" | "hours";
  /** Start date (YYYY-MM-DD) - Required for 'days' granularity */
  start_date?: string;
  /** End date (YYYY-MM-DD) - Required for 'days' granularity */
  end_date?: string;
  /** Target date (YYYY-MM-DD) - Required for 'hours' granularity */
  target_date?: string;
  /** Start hour (0-23) - Required for 'hours' granularity */
  start_hour?: number;
  /** End hour (0-23) - Required for 'hours' granularity */
  end_hour?: number;
}

export type InOutCountOverviewListData = DtoInOutCountingOverviewResponse;

export type InOutCountOverviewListError = ErrorsAppError;

export interface ObjectCountCountingChartListParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
  /** Chart granularity (days or hours) */
  granularity: "days" | "hours";
  /** Start date (YYYY-MM-DD) - Required for 'days' granularity */
  start_date?: string;
  /** End date (YYYY-MM-DD) - Required for 'days' granularity */
  end_date?: string;
  /** Target date (YYYY-MM-DD) - Required for 'hours' granularity */
  target_date?: string;
  /** Start hour (0-23) - Required for 'hours' granularity */
  start_hour?: number;
  /** End hour (0-23) - Required for 'hours' granularity */
  end_hour?: number;
}

export type ObjectCountCountingChartListData = DtoCountingChartResponse;

export type ObjectCountCountingChartListError = ErrorsAppError;

export interface ObjectCountHeatmapListParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
  /** Time granularity (weekly or monthly) */
  granularity?: "weekly" | "monthly";
  /** Time selector (YYYY-MM for monthly, YYYY-MM-DD for weekly) */
  time_selector?: string;
  /** Metric type (average, maximum, or amount) */
  metric_type?: "average" | "maximum" | "amount";
}

export type ObjectCountHeatmapListData = DtoHeatmapAnalyticsResponse;

export type ObjectCountHeatmapListError = ErrorsAppError;

export interface ObjectCountPeopleCountingOverviewListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type ObjectCountPeopleCountingOverviewListData =
  DtoPeopleCountingOverviewResponse;

export type ObjectCountPeopleCountingOverviewListError = ErrorsAppError;

export interface PeopleConvergeChartListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type PeopleConvergeChartListData = DtoPeopleConvergeChartResponse;

export type PeopleConvergeChartListError = ErrorsAppError;

export interface PersonRunningChartListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type PersonRunningChartListData = DtoPersonRunningChartResponse;

export type PersonRunningChartListError = ErrorsAppError;

export interface RestrictedAreaChartListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type RestrictedAreaChartListData = DtoRestrictedAreaChartResponse;

export type RestrictedAreaChartListError = ErrorsAppError;

export interface SearchFaceCreateParams {
  /** Group ID */
  group_id: string;
  /** Image URL to search for */
  image_link?: string;
  /** Maximum number of matches */
  max_data?: number;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
}

export type SearchFaceCreateData = DtoFaceSearchResponse;

export type SearchFaceCreateError = ErrorsAppError;

export interface SurroundingVesselChartListParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
  /** Chart granularity (days or hours) */
  granularity: "days" | "hours";
  /** Start date (YYYY-MM-DD) - Required for 'days' granularity */
  start_date?: string;
  /** End date (YYYY-MM-DD) - Required for 'days' granularity */
  end_date?: string;
  /** Target date (YYYY-MM-DD) - Required for 'hours' granularity */
  target_date?: string;
  /** Start hour (0-23) - Required for 'hours' granularity */
  start_hour?: number;
  /** End hour (0-23) - Required for 'hours' granularity */
  end_hour?: number;
}

export type SurroundingVesselChartListData = DtoSurroundingVesselChartResponse;

export type SurroundingVesselChartListError = ErrorsAppError;

export interface SurroundingVesselOverviewListParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
  /** Time granularity (days or hours) */
  granularity: "days" | "hours";
  /** Start date (YYYY-MM-DD) - Required for 'days' granularity */
  start_date?: string;
  /** End date (YYYY-MM-DD) - Required for 'days' granularity */
  end_date?: string;
  /** Target date (YYYY-MM-DD) - Required for 'hours' granularity */
  target_date?: string;
  /** Start hour (0-23) - Required for 'hours' granularity */
  start_hour?: number;
  /** End hour (0-23) - Required for 'hours' granularity */
  end_hour?: number;
}

export type SurroundingVesselOverviewListData =
  DtoSurroundingVesselOverviewResponse;

export type SurroundingVesselOverviewListError = ErrorsAppError;

export interface UnattendedObjectChartListParams {
  /** Group ID */
  group_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
  /** Location ID */
  location_id?: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** CCTV ID */
  cctv_id?: string;
}

export type UnattendedObjectChartListData = DtoUnattendedObjectChartResponse;

export type UnattendedObjectChartListError = ErrorsAppError;

export type AnalyticTypesListData = DtoAnalyticTypeList;

export type AnalyticTypesListError = ErrorsAppError;

export type GetApiKeyAnalyticTypeData = DtoAnalyticTypeList;

export type GetApiKeyAnalyticTypeError = ErrorsAppError;

export interface AnalyticsListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID (optional) */
  cctv_id?: string;
  /** NVR ID (optional) */
  nvr_id?: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for analytic type name or CCTV name */
  search?: string;
  /**
   * Filter by start date
   * @format date-time
   */
  start_date?: string;
  /**
   * Filter by end date
   * @format date-time
   */
  end_date?: string;
  /** Sort by field */
  sort_by?: "created_at" | "cctv_name" | "analytic_type_name";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type AnalyticsListData = DtoListAnalyticsResponse;

export type AnalyticsListError = ErrorsAppError;

export interface AnalyticsCreateParams {
  /** Group ID */
  group_id: string;
}

export type AnalyticsCreateData = DtoAnalyticDetail;

export type AnalyticsCreateError = ErrorsAppError;

export type EdgeCreateResult = DtoAnalyticEdgeDetail;

export type EdgeCreateFail = ErrorsAppError;

export interface GetApiKeyAnalyticsParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID (optional) */
  cctv_id?: string;
  /** NVR ID (optional) */
  nvr_id?: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for analytic type name or CCTV name */
  search?: string;
  /**
   * Filter by start date
   * @format date-time
   */
  start_date?: string;
  /**
   * Filter by end date
   * @format date-time
   */
  end_date?: string;
  /** Sort by field */
  sort_by?: "created_at" | "cctv_name" | "analytic_type_name";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type GetApiKeyAnalyticsData = DtoListAnalyticsResponse;

export type GetApiKeyAnalyticsError = ErrorsAppError;

export interface PostApiKeyAnalyticsParams {
  /** Group ID */
  group_id: string;
}

export type PostApiKeyAnalyticsData = DtoAnalyticDetail;

export type PostApiKeyAnalyticsError = ErrorsAppError;

export interface GetApiKeyAnalytics2Params {
  /** Group ID */
  group_id: string;
  /** Analytic ID */
  id: string;
}

export type GetApiKeyAnalytics2Data = DtoAnalyticDetail;

export type GetApiKeyAnalytics2Error = ErrorsAppError;

export interface PutApiKeyAnalyticsParams {
  /** Group ID */
  group_id: string;
  /** Analytic ID */
  id: string;
}

export type PutApiKeyAnalyticsData = DtoAnalyticDetail;

export type PutApiKeyAnalyticsError = ErrorsAppError;

export interface DeleteApiKeyAnalyticsParams {
  /** Group ID */
  group_id: string;
  /** Analytic ID */
  id: string;
}

export type DeleteApiKeyAnalyticsData = any;

export type DeleteApiKeyAnalyticsError = ErrorsAppError;

export interface ReportsListParams2 {
  /** Group ID */
  group_id: string;
  /** Start date (YYYY-MM-DD) */
  start_date?: string;
  /** End date (YYYY-MM-DD) */
  end_date?: string;
  /** Analytic type name */
  analytic_type?:
    | "Smoke"
    | "Fire"
    | "Person"
    | "In-Out Restricted Area"
    | "Speed Detection"
    | "Person Running"
    | "Unattended Object"
    | "Object Detection"
    | "Wrong Way Detection"
    | "People Converge"
    | "Fire & Smoke Detection"
    | "Surrounding Vessel"
    | "Health Safety Environment";
  /** Search by camera name, location name, or message */
  search?: string;
  /** Sort by field */
  sort_by?: "created_at" | "camera_name";
  /** Sort order */
  sort_order?: "asc" | "desc";
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
}

export type ReportsListResult = DtoListAnalyticReportsResponse;

export type ReportsListFail = ErrorsAppError;

export interface ReportsNotificationsListParams {
  /** Group ID */
  group_id: string;
  /** Start date (YYYY-MM-DD) */
  start_date?: string;
  /** End date (YYYY-MM-DD) */
  end_date?: string;
  /** Analytic type name */
  analytic_type?:
    | "Smoke"
    | "Fire"
    | "Person"
    | "In-Out Restricted Area"
    | "Speed Detection"
    | "Person Running"
    | "Unattended Object"
    | "Object Detection"
    | "Wrong Way Detection"
    | "People Converge"
    | "Fire & Smoke Detection"
    | "Surrounding Vessel"
    | "Health Safety Environment";
  /** Search by camera name, location name, or message */
  search?: string;
  /** Sort by field */
  sort_by?: "created_at" | "camera_name";
  /** Sort order */
  sort_order?: "asc" | "desc";
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
}

export type ReportsNotificationsListData = DtoListAnalyticNotificationsResponse;

export type ReportsNotificationsListError = ErrorsAppError;

export interface AnalyticsDetailParams {
  /** Group ID */
  group_id: string;
  /** Analytic ID */
  id: string;
}

export type AnalyticsDetailData = DtoAnalyticDetail;

export type AnalyticsDetailError = ErrorsAppError;

export interface AnalyticsUpdateParams {
  /** Group ID */
  group_id: string;
  /** Analytic ID */
  id: string;
}

export type AnalyticsUpdateData = DtoAnalyticDetail;

export type AnalyticsUpdateError = ErrorsAppError;

export interface AnalyticsDeleteParams {
  /** Group ID */
  group_id: string;
  /** Analytic ID */
  id: string;
}

export type AnalyticsDeleteData = any;

export type AnalyticsDeleteError = ErrorsAppError;

export type ForgotPasswordCreateData = DtoForgotPasswordResponse;

export type ForgotPasswordCreateError = ErrorsAppError;

export type LoginCreateData = DtoLoginResponse;

export type LoginCreateError = ErrorsAppError;

export type RegenerateTokenCreateData = DtoRegenerateTokenResponse;

export type RegenerateTokenCreateError = ErrorsAppError;

export type RegisterCreateData = DtoRegisterResponse;

export type RegisterCreateError = ErrorsAppError;

export type ResendVerificationCreateData = DtoRegisterResponse;

export type ResendVerificationCreateError = ErrorsAppError;

export type ResetPasswordCreateData = DtoResetPasswordResponse;

export type ResetPasswordCreateError = ErrorsAppError;

export interface VerifyEmailListParams {
  /** Verification token */
  token: string;
}

export type VerifyEmailListData = DtoRegisterResponse;

export type VerifyEmailListError = ErrorsAppError;

export interface CctvAnalyticsCreateParams {
  /** Group ID */
  group_id: string;
}

export type CctvAnalyticsCreateData = DtoCCTVAnalyticDetail;

export type CctvAnalyticsCreateError = ErrorsAppError;

export interface CctvDetailParams {
  /** Group ID */
  group_id: string;
  /** Search string for analytic type name or description */
  search?: string;
  /** Sort by field */
  sort_by?: "created_at" | "name";
  /** Sort order */
  sort_order?: "asc" | "desc";
  /** CCTV ID */
  cctvId: string;
}

export type CctvDetailData = DtoListCCTVAnalyticsResponse;

export type CctvDetailError = ErrorsAppError;

export interface ConfigDetailParams {
  /** Group ID */
  group_id: string;
  /** CCTV Analytic ID */
  id: string;
}

export type ConfigDetailData = DtoCCTVAnalyticConfigResponse;

export type ConfigDetailError = ErrorsAppError;

export interface ConfigUpdateParams {
  /** Group ID */
  group_id: string;
  /** CCTV Analytic ID */
  id: string;
}

export type ConfigUpdateData = DtoCCTVAnalyticConfigResponse;

export type ConfigUpdateError = ErrorsAppError;

export interface ConfigResetCreateParams {
  /** Group ID */
  group_id: string;
  /** CCTV Analytic ID */
  id: string;
}

export type ConfigResetCreateData = DtoCCTVAnalyticConfigResponse;

export type ConfigResetCreateError = ErrorsAppError;

export type EdgeCreateOutput = DtoCCTVAnalyticDetail;

export type EdgeCreateFails = ErrorsAppError;

export interface EdgeCctvDetailParams {
  /** Search string for analytic type name or description */
  search?: string;
  /** Sort by field */
  sort_by?: "created_at" | "name";
  /** Sort order */
  sort_order?: "asc" | "desc";
  /** CCTV ID */
  cctvId: string;
}

export type EdgeCctvDetailData = DtoListCCTVAnalyticsResponse;

export type EdgeCctvDetailError = ErrorsAppError;

export type EdgeTypesListData = DtoAnalyticTypeList;

export type EdgeTypesListError = ErrorsAppError;

export type EdgeAllCreateData = any;

export type EdgeAllCreateError = ErrorsAppError;

export type EdgeDetailData = DtoCCTVAnalyticDetail;

export type EdgeDetailError = ErrorsAppError;

export type EdgeUpdateData = DtoCCTVAnalyticDetail;

export type EdgeUpdateError = ErrorsAppError;

export type EdgeDeleteData = any;

export type EdgeDeleteError = ErrorsAppError;

export type KeyConfigDetailData = DtoCCTVAnalyticConfigResponse;

export type KeyConfigDetailError = ErrorsAppError;

export type KeyConfigUpdateData = DtoCCTVAnalyticConfigResponse;

export type KeyConfigUpdateError = ErrorsAppError;

export type KeyConfigResetCreateData = DtoCCTVAnalyticConfigResponse;

export type KeyConfigResetCreateError = ErrorsAppError;

export interface PostCctvAnalyticsParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  cctvId: string;
}

export type PostCctvAnalyticsData = any;

export type PostCctvAnalyticsError = ErrorsAppError;

export interface CctvAnalyticsDetailParams {
  /** Group ID */
  group_id: string;
  /** CCTV Analytic ID */
  id: string;
}

export type CctvAnalyticsDetailData = DtoCCTVAnalyticDetail;

export type CctvAnalyticsDetailError = ErrorsAppError;

export interface CctvAnalyticsUpdateParams {
  /** Group ID */
  group_id: string;
  /** CCTV Analytic ID */
  id: string;
}

export type CctvAnalyticsUpdateData = DtoCCTVAnalyticDetail;

export type CctvAnalyticsUpdateError = ErrorsAppError;

export interface CctvAnalyticsDeleteParams {
  /** Group ID */
  group_id: string;
  /** CCTV Analytic ID */
  id: string;
}

export type CctvAnalyticsDeleteData = any;

export type CctvAnalyticsDeleteError = ErrorsAppError;

export interface CctvsListParams {
  /** Group ID */
  group_id: string;
  /** NVR ID */
  nvr_id?: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for CCTV name */
  search?: string;
  /** Filter by brand */
  brand?: string;
  /** Filter by type */
  type?: string;
  /** Filter by status */
  status?: "online" | "offline";
  /**
   * Filter by start date
   * @format date-time
   */
  start_date?: string;
  /**
   * Filter by end date
   * @format date-time
   */
  end_date?: string;
  /** Sort by field */
  sort_by?: "created_at" | "name" | "status" | "last_checked";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type CctvsListData = DtoListCCTVsResponse;

export type CctvsListError = ErrorsAppError;

export interface CctvsCreateParams {
  /** Group ID */
  group_id: string;
}

export type CctvsCreateData = DtoCCTVDetail;

export type CctvsCreateError = ErrorsAppError;

export type EdgeCreateOutput1 = DtoEdgeCCTVConfig;

export type EdgeCreateErrorData = ErrorsAppError;

export type EdgeConfigListData = DtoEdgeCCTVConfig[];

export type EdgeConfigListError = ErrorsAppError;

export type EdgeUpdateResult = DtoCCTVDetail;

export type EdgeUpdateFail = ErrorsAppError;

export type EdgeDeleteResult = any;

export type EdgeDeleteFail = ErrorsAppError;

export type EdgeCheckIntervalListData = Record<string, number>;

export type EdgeCheckIntervalListError = ErrorsAppError;

export type EdgeConfigList2Data = DtoEdgeCCTVConfig;

export type EdgeConfigList2Error = ErrorsAppError;

export type EdgeHeartbeatUpdateData = any;

export type EdgeHeartbeatUpdateError = ErrorsAppError;

export type EdgeScheduleListData = DtoCCTVRecordingScheduleResponse;

export type EdgeScheduleListError = ErrorsAppError;

export type EdgeScheduleUpdateData = DtoCCTVRecordingScheduleResponse;

export type EdgeScheduleUpdateError = ErrorsAppError;

export type EdgeSnapshotUpdateData = any;

export type EdgeSnapshotUpdateError = ErrorsAppError;

export type EdgeStatusListData = DtoCCTVStatusResponse;

export type EdgeStatusListError = ErrorsAppError;

export type EdgeStreamUrlsListData = DtoCCTVStreamURLsResponse;

export type EdgeStreamUrlsListError = ErrorsAppError;

export type EdgeStreamUrlsCreateData = DtoStreamURLResponse;

export type EdgeStreamUrlsCreateError = ErrorsAppError;

export type EdgeStreamUrlsUrlIdDeleteData = any;

export type EdgeStreamUrlsUrlIdDeleteError = ErrorsAppError;

export type GetApiKeyCctvsData = DtoCCTVDetail;

export type GetApiKeyCctvsError = ErrorsAppError;

export interface PostCctvsParams {
  /** Group ID */
  group_id: string;
}

export type PostCctvsData = DtoPTZCommandResponse;

export type PostCctvsError = ErrorsAppError;

export interface SnapshotsDetailParams {
  /** Group ID */
  group_id: string;
  /** CCTV  ID */
  id: string;
}

export type SnapshotsDetailData = DtoCCTVSnapshotResponse;

export type SnapshotsDetailError = ErrorsAppError;

export interface CctvsDetailParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
}

export type CctvsDetailData = DtoCCTVDetail;

export type CctvsDetailError = ErrorsAppError;

export interface CctvsUpdateParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
}

export type CctvsUpdateData = DtoCCTVDetail;

export type CctvsUpdateError = ErrorsAppError;

export interface CctvsDeleteParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
}

export type CctvsDeleteData = any;

export type CctvsDeleteError = ErrorsAppError;

export interface ConnectionListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
}

export type ConnectionListData = DtoCCTVConnectionDetail;

export type ConnectionListError = ErrorsAppError;

export interface ScheduleListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
}

export type ScheduleListData = DtoCCTVRecordingScheduleResponse;

export type ScheduleListError = ErrorsAppError;

export interface ScheduleUpdateParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
}

export type ScheduleUpdateData = DtoCCTVRecordingScheduleResponse;

export type ScheduleUpdateError = ErrorsAppError;

export interface StreamUrlsListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
}

export type StreamUrlsListData = DtoCCTVStreamURLsResponse;

export type StreamUrlsListError = ErrorsAppError;

export interface StreamUrlsCreateParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
}

export type StreamUrlsCreateData = DtoStreamURLResponse;

export type StreamUrlsCreateError = ErrorsAppError;

export interface StreamUrlsUrlIdDeleteParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  id: string;
  /** URL ID */
  urlId: string;
}

export type StreamUrlsUrlIdDeleteData = any;

export type StreamUrlsUrlIdDeleteError = ErrorsAppError;

export interface GroupOverviewListParams {
  /** Group ID */
  group_id: string;
}

export type GroupOverviewListData = DtoGroupOverviewResponse;

export type GroupOverviewListError = ErrorsAppError;

export interface StatsListParams {
  /** Group ID */
  group_id: string;
}

export type StatsListData = DtoDashboardStatsResponse;

export type StatsListError = ErrorsAppError;

export interface StorageDetailsListParams {
  /** Group ID */
  group_id: string;
  /** Range type: last_3_days, last_week, last_4_months, custom */
  range_type: "last_3_days" | "last_week" | "last_4_months" | "custom";
  /**
   * Start date (required for custom range)
   * @format date
   */
  start_date?: string;
  /**
   * End date (required for custom range)
   * @format date
   */
  end_date?: string;
}

export type StorageDetailsListData = DtoStorageDetailsResponse;

export type StorageDetailsListError = ErrorsAppError;

export interface PrivateUploadUrlCreateParams {
  /** Group ID */
  group_id: string;
}

export type PrivateUploadUrlCreateData = DtoPresignedRequest;

export type PrivateUploadUrlCreateError = ErrorsAppError;

export interface PublicUploadUrlCreateParams {
  /** Group ID */
  group_id: string;
}

export type PublicUploadUrlCreateData = DtoPresignedRequest;

export type PublicUploadUrlCreateError = ErrorsAppError;

export interface FilesListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID (optional) */
  cctv_id?: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for file name */
  search?: string;
  /** Filter by file type */
  file_type?: "image" | "sound" | "video" | "recording";
  /**
   * Filter by start date
   * @format date-time
   */
  start_date?: string;
  /**
   * Filter by end date
   * @format date-time
   */
  end_date?: string;
  /** Sort by field */
  sort_by?: "created_at" | "file_name" | "file_type" | "size";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type FilesListData = DtoListFilesResponse;

export type FilesListError = ErrorsAppError;

export interface FilesCreateParams {
  /** Group ID */
  group_id: string;
}

export type FilesCreateData = DtoFileDetail;

export type FilesCreateError = ErrorsAppError;

export interface AccessDownloadUrlListParams {
  /** File URL or path */
  fileUrl: string;
  /** File provider (object_storage or local) */
  provider: string;
}

export type AccessDownloadUrlListError = ErrorsAppError;

export interface AiSummarySummaryDetailParams {
  /** Group ID */
  group_id: string;
  /** Summary ID */
  id: string;
}

export type AiSummarySummaryDetailData = DtoFileAISummaryDetail;

export type AiSummarySummaryDetailError = ErrorsAppError;

export interface AiSummaryDetailParams {
  /** Group ID */
  group_id: string;
  /** File ID */
  fileId: string;
}

export type AiSummaryDetailData = DtoFileAISummaryListItem[];

export type AiSummaryDetailError = ErrorsAppError;

export interface AiSummaryCreateParams {
  /** Group ID */
  group_id: string;
  /** File ID */
  fileId: string;
}

export type AiSummaryCreateData = DtoFileAISummaryResponse;

export type AiSummaryCreateError = ErrorsAppError;

export interface BatchDeleteRecordingDeleteParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  cctv_id: string;
  /** Date (YYYY-MM-DD) */
  date: string;
}

export type BatchDeleteRecordingDeleteData = DtoDeleteFilesResponse;

export type BatchDeleteRecordingDeleteError = ErrorsAppError;

export interface BulkDeleteByRangeDeleteParams {
  /** Group ID */
  group_id: string;
}

export type BulkDeleteByRangeDeleteData = DtoBulkDeleteFilesResponse;

export type BulkDeleteByRangeDeleteError = ErrorsAppError;

export interface BulkDeleteSummaryCreateParams {
  /** Group ID */
  group_id: string;
}

export type BulkDeleteSummaryCreateData = DtoBulkDeleteSummaryResponse;

export type BulkDeleteSummaryCreateError = ErrorsAppError;

export interface DownloadUrlListParams {
  /** Complete file URL */
  "file-url": string;
}

export type DownloadUrlListData = DtoPresignedURLResponse;

export type DownloadUrlListError = ErrorsAppError;

export type EdgeCreateResult1 = DtoEdgeFileDetail;

export type EdgeCreateHttpError = ErrorsAppError;

export type EdgePrivateUploadUrlCreateData = DtoPresignedRequest;

export type EdgePrivateUploadUrlCreateError = ErrorsAppError;

export type EdgePublicUploadUrlCreateData = DtoPresignedRequest;

export type EdgePublicUploadUrlCreateError = ErrorsAppError;

export type EdgeDetailResult = DtoEdgeFileDetail;

export type EdgeDetailFail = ErrorsAppError;

export type EdgeUpdateOutput = DtoEdgeFileDetail;

export type EdgeUpdateFails = ErrorsAppError;

export interface GetApiKeyFileParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID (optional) */
  cctv_id?: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for file name */
  search?: string;
  /** Filter by file type */
  file_type?: "image" | "sound" | "video" | "recording";
  /**
   * Filter by start date
   * @format date-time
   */
  start_date?: string;
  /**
   * Filter by end date
   * @format date-time
   */
  end_date?: string;
  /** Filter by analytic process status */
  analytic_process?: boolean;
  /** Filter by analytic type IDs */
  analytic_type_ids?: string[];
  /** Sort by field */
  sort_by?: "created_at" | "file_name" | "file_type" | "size";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type GetApiKeyFileData = DtoListFilesResponse;

export type GetApiKeyFileError = ErrorsAppError;

export type PostApiKeyFileData = DtoEdgeFileDetail;

export type PostApiKeyFileError = ErrorsAppError;

export interface KeyAccessDownloadUrlListParams {
  /** File URL or path */
  fileUrl: string;
  /** File provider (object_storage or local) */
  provider: string;
}

export type KeyAccessDownloadUrlListError = ErrorsAppError;

export type KeyAnalyticProcessesDetailData = DtoFileAnalyticProcessResponse[];

export type KeyAnalyticProcessesDetailError = ErrorsAppError;

export type KeyAnalyticProcessesCreateData = DtoFileAnalyticProcessResponse;

export type KeyAnalyticProcessesCreateError = ErrorsAppError;

export type KeyPrivateUploadUrlCreateData = DtoPresignedRequest;

export type KeyPrivateUploadUrlCreateError = ErrorsAppError;

export type KeyPublicUploadUrlCreateData = DtoPresignedRequest;

export type KeyPublicUploadUrlCreateError = ErrorsAppError;

export type KeyDetailListData = DtoFileLocationDetail;

export type KeyDetailListError = ErrorsAppError;

export type KeyProcessingStatusUpdateData = any;

export type KeyProcessingStatusUpdateError = ErrorsAppError;

export interface RecordingPlaybackListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID */
  cctv_id: string;
  /**
   * Start time in UTC
   * @format date-time
   */
  start_time: string;
  /**
   * End time in UTC
   * @format date-time
   */
  end_time: string;
}

export type RecordingPlaybackListData = DtoRecordingPlaybackResponse;

export type RecordingPlaybackListError = ErrorsAppError;

export interface RecordingPlaybackMultiListParams {
  /** Group ID */
  group_id: string;
  /** Video Wall ID */
  video_wall_id: string;
  /**
   * Start time in UTC
   * @format date-time
   */
  start_time: string;
  /**
   * End time in UTC
   * @format date-time
   */
  end_time: string;
}

export type RecordingPlaybackMultiListData =
  DtoMultiCCTVRecordingPlaybackResponse;

export type RecordingPlaybackMultiListError = ErrorsAppError;

export interface RecordingStorageBreakdownListParams {
  /** Group ID */
  group_id: string;
}

export type RecordingStorageBreakdownListData =
  DtoRecordingStorageBreakdownResponse;

export type RecordingStorageBreakdownListError = ErrorsAppError;

export interface WithLocationListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID (optional) */
  cctv_id?: string;
  /** Location ID (optional) */
  location_id?: string;
  /** Floor Plan ID (optional) */
  floor_plan_id?: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for file name */
  search?: string;
  /** Filter by file type */
  file_type?: "image" | "sound" | "video" | "recording";
  /**
   * Filter by start date
   * @format date-time
   */
  start_date?: string;
  /**
   * Filter by end date
   * @format date-time
   */
  end_date?: string;
  /** Sort by field */
  sort_by?: "created_at" | "file_name" | "file_type" | "size";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type WithLocationListData = DtoListFilesWithLocationResponse;

export type WithLocationListError = ErrorsAppError;

export interface FilesDetailParams {
  /** Group ID */
  group_id: string;
  /** File ID */
  id: string;
}

export type FilesDetailData = DtoFileDetail;

export type FilesDetailError = ErrorsAppError;

export interface FilesUpdateParams {
  /** Group ID */
  group_id: string;
  /** File ID */
  id: string;
}

export type FilesUpdateData = DtoFileDetail;

export type FilesUpdateError = ErrorsAppError;

export interface FilesDeleteParams {
  /** Group ID */
  group_id: string;
  /** File ID */
  id: string;
}

export type FilesDeleteData = any;

export type FilesDeleteError = ErrorsAppError;

export interface AnalyticsListParams2 {
  /** Group ID */
  group_id: string;
  /** File ID */
  id: string;
}

export type AnalyticsListResult = DtoFileDetailAdvanced;

export type AnalyticsListFail = ErrorsAppError;

export interface FloorPlanObjectsListParams {
  /** Group ID */
  group_id: string;
  /** Filter by Floor Plan ID */
  floor_plan_id?: string;
  /** Filter by Object Type (nvr/cctv) */
  object_type?: string;
  /** Filter by Object ID */
  object_id?: string;
  /** Search term */
  search?: string;
  /**
   * Offset for pagination
   * @default 0
   */
  offset?: number;
  /**
   * Limit for pagination
   * @default 10
   */
  limit?: number;
}

export type FloorPlanObjectsListData = DtoFloorPlanObjectListResponse;

export type FloorPlanObjectsListError = ErrorsAppError;

export interface FloorPlanObjectsCreateParams {
  /** Group ID */
  group_id: string;
}

export type FloorPlanObjectsCreateData = DtoFloorPlanObjectResponse;

export type FloorPlanObjectsCreateError = ErrorsAppError;

export interface AvailableCctvsDetailParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan ID */
  floorPlanId: string;
}

export type AvailableCctvsDetailData = DtoAvailableCCTVsResponse;

export type AvailableCctvsDetailError = ErrorsAppError;

export interface AvailableNvrsDetailParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan ID */
  floorPlanId: string;
}

export type AvailableNvrsDetailData = DtoAvailableNVRsResponse;

export type AvailableNvrsDetailError = ErrorsAppError;

export interface ObjectDetailParams {
  /** Group ID */
  group_id: string;
  /** Object Type (nvr/cctv) */
  objectType: "nvr" | "cctv";
  /** Object ID (NVR ID or CCTV ID) */
  objectId: string;
}

export type ObjectDetailData = DtoFloorPlanObjectResponse;

export type ObjectDetailError = ErrorsAppError;

export interface FloorPlanObjectsDetailParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan Object ID */
  id: string;
}

export type FloorPlanObjectsDetailData = DtoFloorPlanObjectResponse;

export type FloorPlanObjectsDetailError = ErrorsAppError;

export interface FloorPlanObjectsUpdateParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan Object ID */
  id: string;
}

export type FloorPlanObjectsUpdateData = DtoFloorPlanObjectResponse;

export type FloorPlanObjectsUpdateError = ErrorsAppError;

export interface FloorPlanObjectsDeleteParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan Object ID */
  id: string;
}

export type FloorPlanObjectsDeleteData = any;

export type FloorPlanObjectsDeleteError = ErrorsAppError;

export interface FloorPlansListParams {
  /** Group ID */
  group_id: string;
  /** Search term */
  search?: string;
  /** Filter by Location ID */
  location_id?: string;
  /**
   * Offset for pagination
   * @default 0
   */
  offset?: number;
  /**
   * Limit for pagination
   * @default 10
   */
  limit?: number;
}

export type FloorPlansListData = DtoFloorPlanListResponse;

export type FloorPlansListError = ErrorsAppError;

export interface FloorPlansCreateParams {
  /** Group ID */
  group_id: string;
}

export type FloorPlansCreateData = DtoFloorPlanResponse;

export type FloorPlansCreateError = ErrorsAppError;

export type EdgeListData = DtoFloorPlanEdgeListResponse;

export type EdgeListError = ErrorsAppError;

export type EdgeObjectDetailData = DtoFloorPlanObjectResponse;

export type EdgeObjectDetailError = ErrorsAppError;

export type EdgeDetailOutput = DtoFloorPlanResponse;

export type EdgeDetailFails = ErrorsAppError;

export type EdgeDetailListData = DtoFloorPlanDetailResponse;

export type EdgeDetailListError = ErrorsAppError;

export interface FloorPlansDetailParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan ID */
  id: string;
}

export type FloorPlansDetailData = DtoFloorPlanResponse;

export type FloorPlansDetailError = ErrorsAppError;

export interface FloorPlansUpdateParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan ID */
  id: string;
}

export type FloorPlansUpdateData = DtoFloorPlanResponse;

export type FloorPlansUpdateError = ErrorsAppError;

export interface FloorPlansDeleteParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan ID */
  id: string;
}

export type FloorPlansDeleteData = any;

export type FloorPlansDeleteError = ErrorsAppError;

export type GroupsCreateData = DtoGroupDetailDTO;

export type GroupsCreateError = ErrorsAppError;

export type KeyAnalyticsListData = DtoGroupCCTVAnalyticsResponse[];

export type KeyAnalyticsListError = ErrorsAppError;

export interface QuotaAllListParams {
  /** Group ID */
  group_id: string;
}

export type QuotaAllListData = DtoAllQuotasResponseDTO;

export type QuotaAllListError = ErrorsAppError;

export interface QuotaCamerasListParams {
  /** Group ID */
  group_id: string;
}

export type QuotaCamerasListData = DtoQuotaResponseDTO;

export type QuotaCamerasListError = ErrorsAppError;

export interface QuotaFloorPlansListParams {
  /** Group ID */
  group_id: string;
}

export type QuotaFloorPlansListData = DtoQuotaResponseDTO;

export type QuotaFloorPlansListError = ErrorsAppError;

export interface QuotaLocationsListParams {
  /** Group ID */
  group_id: string;
}

export type QuotaLocationsListData = DtoQuotaResponseDTO;

export type QuotaLocationsListError = ErrorsAppError;

export interface QuotaMembersListParams {
  /** Group ID */
  group_id: string;
}

export type QuotaMembersListData = DtoQuotaResponseDTO;

export type QuotaMembersListError = ErrorsAppError;

export interface QuotaNvrsListParams {
  /** Group ID */
  group_id: string;
}

export type QuotaNvrsListData = DtoQuotaResponseDTO;

export type QuotaNvrsListError = ErrorsAppError;

export interface QuotaStorageListParams {
  /** Group ID */
  group_id: string;
}

export type QuotaStorageListData = DtoStorageQuotaResponseDTO;

export type QuotaStorageListError = ErrorsAppError;

export type ResourcesCountListData = DtoGroupResourceCount[];

export type ResourcesCountListError = ErrorsAppError;

export interface StorageSettingsUpdateParams {
  /** Group ID */
  group_id: string;
}

export type StorageSettingsUpdateData = Record<string, string>;

export type StorageSettingsUpdateError = ErrorsAppError;

export interface StorageUsageListParams {
  /** Group ID */
  group_id: string;
}

export type StorageUsageListData = DtoStorageUsageDTO;

export type StorageUsageListError = ErrorsAppError;

export interface LocationsListParams {
  /** Group ID */
  group_id: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string */
  search?: string;
  /** Sort by field */
  sort_by?: "created_at" | "location_name";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type LocationsListData = DtoListLocationsResponse;

export type LocationsListError = ErrorsAppError;

export interface LocationsCreateParams {
  /** Group ID */
  group_id: string;
}

export type LocationsCreateData = DtoLocationDetail;

export type LocationsCreateError = ErrorsAppError;

export interface LocationsDetailParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  id: string;
}

export type LocationsDetailData = DtoLocationDetail;

export type LocationsDetailError = ErrorsAppError;

export interface LocationsUpdateParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  id: string;
}

export type LocationsUpdateData = DtoLocationDetail;

export type LocationsUpdateError = ErrorsAppError;

export interface LocationsDeleteParams {
  /** Group ID */
  group_id: string;
  /** Location ID */
  id: string;
}

export type LocationsDeleteData = any;

export type LocationsDeleteError = ErrorsAppError;

export interface MemberAlertSettingsListParams {
  /** Group ID */
  group_id: string;
  /** CCTV ID to filter alerts */
  cctv_id?: string;
}

export type MemberAlertSettingsListData = DtoListMemberAlertSettingsResponse;

export type MemberAlertSettingsListError = ErrorsAppError;

export interface MemberAlertSettingsCreateParams {
  /** Group ID */
  group_id: string;
}

export type MemberAlertSettingsCreateData = DtoMemberAlertSettingDetail;

export type MemberAlertSettingsCreateError = ErrorsAppError;

export interface CreateAllCreateParams {
  /** Group ID */
  group_id: string;
}

export type CreateAllCreateData = any;

export type CreateAllCreateError = ErrorsAppError;

export interface MemberAlertSettingsDetailParams {
  /** Group ID */
  group_id: string;
  /** Member Alert Setting ID */
  id: string;
}

export type MemberAlertSettingsDetailData = DtoMemberAlertSettingDetail;

export type MemberAlertSettingsDetailError = ErrorsAppError;

export interface MemberAlertSettingsUpdateParams {
  /** Group ID */
  group_id: string;
  /** Member Alert Setting ID */
  id: string;
}

export type MemberAlertSettingsUpdateData = DtoMemberAlertSettingDetail;

export type MemberAlertSettingsUpdateError = ErrorsAppError;

export interface MemberAlertSettingsDeleteParams {
  /** Group ID */
  group_id: string;
  /** Member Alert Setting ID */
  id: string;
}

export type MemberAlertSettingsDeleteData = any;

export type MemberAlertSettingsDeleteError = ErrorsAppError;

export interface MembersListParams {
  /** Group ID */
  group_id: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for member name or email */
  search?: string;
  /** Filter by role */
  role?: "admin" | "member";
  /** Filter by status */
  status?: "active" | "pending" | "banned" | "disabled";
  /** Sort by field */
  sort_by?: "created_at" | "user_name" | "user_email" | "role" | "status";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type MembersListData = DtoListMembersResponse;

export type MembersListError = ErrorsAppError;

export interface MembersCreateParams {
  /** Group ID */
  group_id: string;
}

export type MembersCreateData = DtoMemberDetail;

export type MembersCreateError = ErrorsAppError;

export type JoinCreateData = any;

export type JoinCreateError = ErrorsAppError;

export type GetMembersData = DtoMembershipList;

export type GetMembersError = ErrorsAppError;

export type PasswordUpdateData = any;

export type PasswordUpdateError = ErrorsAppError;

export type UserUpdateData = any;

export type UserUpdateError = ErrorsAppError;

export interface MembersDetailParams {
  /** Group ID */
  group_id: string;
  /** Member ID */
  id: string;
}

export type MembersDetailData = DtoMemberDetail;

export type MembersDetailError = ErrorsAppError;

export interface MembersUpdateParams {
  /** Group ID */
  group_id: string;
  /** Member ID */
  id: string;
}

export type MembersUpdateData = DtoMemberDetail;

export type MembersUpdateError = ErrorsAppError;

export interface MembersDeleteParams {
  /** Group ID */
  group_id: string;
  /** Member ID */
  id: string;
}

export type MembersDeleteData = any;

export type MembersDeleteError = ErrorsAppError;

export interface NvrsListParams {
  /** Group ID */
  group_id: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
  /** Search string for NVR name or CCTV name */
  search?: string;
  /** Filter by location ID */
  location_id?: string;
  /** Filter by status */
  status?: "online" | "offline";
  /** Sort by field */
  sort_by?: "created_at" | "name" | "status" | "last_checked";
  /** Sort order */
  sort_order?: "asc" | "desc";
}

export type NvrsListData = DtoListNVRsResponse;

export type NvrsListError = ErrorsAppError;

export interface NvrsCreateParams {
  /** Group ID */
  group_id: string;
}

export type NvrsCreateData = DtoNVRDetail;

export type NvrsCreateError = ErrorsAppError;

export interface CheckUsernameListParams {
  /** Group ID */
  group_id: string;
  /** Username to check */
  username: string;
}

export type CheckUsernameListData = DtoCheckUsernameResponse;

export type CheckUsernameListError = ErrorsAppError;

export type EdgeCctvSchedulesListData = DtoNVREdgeCCTVSchedulesResponse;

export type EdgeCctvSchedulesListError = ErrorsAppError;

export type EdgeCheckIntervalListResult = DtoNVRCheckIntervalResponse;

export type EdgeCheckIntervalListFail = ErrorsAppError;

export type EdgeConfigListResult = DtoNVREdgeConfig;

export type EdgeConfigListFail = ErrorsAppError;

export type EdgeGroupListData = DtoNVREdgeOrgDetailDto;

export type EdgeGroupListError = ErrorsAppError;

export type EdgeStatusUpdateData = string;

export type EdgeStatusUpdateError = ErrorsAppError;

export type EdgeVersionUpdateData = string;

export type EdgeVersionUpdateError = ErrorsAppError;

export interface ResetTokenPartialUpdateParams {
  /** Group ID */
  group_id: string;
  /** NVR ID */
  id: string;
}

export type ResetTokenPartialUpdateData = DtoResetNVRTokenResponse;

export type ResetTokenPartialUpdateError = ErrorsAppError;

export interface NvrsDetailParams {
  /** Group ID */
  group_id: string;
  /** NVR ID */
  id: string;
}

export type NvrsDetailData = DtoNVRDetail;

export type NvrsDetailError = ErrorsAppError;

export interface NvrsUpdateParams {
  /** Group ID */
  group_id: string;
  /** NVR ID */
  id: string;
}

export type NvrsUpdateData = DtoNVRDetail;

export type NvrsUpdateError = ErrorsAppError;

export interface NvrsDeleteParams {
  /** Group ID */
  group_id: string;
  /** NVR ID */
  id: string;
}

export type NvrsDeleteData = any;

export type NvrsDeleteError = ErrorsAppError;

export interface ConnectionListParams2 {
  /** Group ID */
  group_id: string;
  /** NVR ID */
  id: string;
}

export type ConnectionListResult = DtoNVRConnectionDetail;

export type ConnectionListFail = ErrorsAppError;

export interface TokenListParams {
  /** Group ID */
  group_id: string;
  /** NVR ID */
  id: string;
}

export type TokenListData = DtoNVRTokenResponse;

export type TokenListError = ErrorsAppError;

export interface CamerasListParams {
  /** Group ID */
  group_id: string;
  /** Floor Plan ID */
  floor_plan_id?: string;
  /** Filter by status */
  status?: "all" | "unsigned";
}

export type CamerasListData = DtoCameraSearchResponse;

export type CamerasListError = ErrorsAppError;

export interface FloorPlansListParams2 {
  /** Group ID */
  group_id: string;
  /** Location ID */
  location_id: string;
}

export type FloorPlansListResult = DtoFloorPlanSearchResponse;

export type FloorPlansListFail = ErrorsAppError;

export interface LocationsListParams2 {
  /** Group ID */
  group_id: string;
}

export type LocationsListResult = DtoLocationSearchResponse;

export type LocationsListFail = ErrorsAppError;

export type WellKnownJwksJsonListData = DtoJWKSResponse;

export type WellKnownJwksJsonListError = ErrorsAppError;

export type PublishCreateData = DtoStreamTokenResponse;

export type PublishCreateError = ErrorsAppError;

export type ReadCreateData = DtoStreamTokenResponse;

export type ReadCreateError = ErrorsAppError;

export type VerifyCreateData = DtoValidateStreamTokenResponse;

export type VerifyCreateError = ErrorsAppError;

export interface VideoWallsListParams {
  /** Group ID */
  group_id: string;
  /** Search term */
  search?: string;
  /**
   * Page number
   * @default 1
   */
  page?: number;
  /**
   * Page size
   * @default 10
   */
  size?: number;
}

export type VideoWallsListData = DtoListVideoWallsResponse;

export type VideoWallsListError = ErrorsAppError;

export interface VideoWallsCreateParams {
  /** Group ID */
  group_id: string;
}

export type VideoWallsCreateData = DtoVideoWallDetail;

export type VideoWallsCreateError = Record<string, any>;

export interface VideoWallsDetailParams {
  /** Group ID */
  group_id: string;
  /** Video Wall ID */
  id: string;
}

export type VideoWallsDetailData = DtoVideoWallDetail;

export type VideoWallsDetailError = ErrorsAppError;

export interface VideoWallsUpdateParams {
  /** Group ID */
  group_id: string;
  /** Video Wall ID */
  id: string;
}

export type VideoWallsUpdateData = DtoVideoWallDetail;

export type VideoWallsUpdateError = ErrorsAppError;

export interface VideoWallsDeleteParams {
  /** Group ID */
  group_id: string;
  /** Video Wall ID */
  id: string;
}

export type VideoWallsDeleteData = any;

export type VideoWallsDeleteError = ErrorsAppError;

export type AiSummaryCreate2Payload = Record<string, any>;

export interface AiSummaryCreate2Params {
  /** Webhook authentication key */
  key: string;
}

export type AiSummaryCreate2Data = Record<string, string>;

export type AiSummaryCreate2Error = ErrorsAppError;
