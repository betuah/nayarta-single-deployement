'use client'
import React from "react";
import {SessionProvider} from "next-auth/react";
import Next13ProgressBar from "next13-progressbar";


export function NextAuthSessionProviders({
                              children,
                          }: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <SessionProvider>
            {children}
            <Next13ProgressBar height="2px" color="#973030" options={{showSpinner: true}}
                               showOnShallow/>
        </SessionProvider>
    )
}