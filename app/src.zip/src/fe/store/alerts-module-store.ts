import { create } from 'zustand';
import { toast } from 'react-toastify';
import debounce from 'lodash/debounce';
import {
    AlertsListParams,
    AlertsListData,
    DtoAlertListItemOnAlert,
    AnalyticTypesListData, DtoAnalyticTypeListItem,
} from '@/lib/api/data-contracts';
import { useUserStore } from '@/store/user-store';
import {getAlerts} from "@/actions/alert-actions";
import {getAnalyticsType} from "@/actions/cctv-analytic-actions";

interface AlertsModuleState {
    alerts: DtoAlertListItemOnAlert[];
    isLoading: boolean;
    error: string | null;
    currentPage: number;
    pageSize: number;
    totalItems: number;
    searchTerm: string;
    filterType: string;
    filterSeverity: string;
    filterDateRange: { from?: Date; to?: Date } | undefined;
    analyticsTypes: DtoAnalyticTypeListItem[];
    sortBy: AlertsListParams['sort_by'];
    sortOrder: AlertsListParams['sort_order'];
    fetchAlerts: (params?: Partial<AlertsListParams>) => Promise<void>;
    setSearchTerm: (term: string) => void;
    setFilterType: (type: string) => void;
    setFilterSeverity: (severity: string) => void;
    setFilterDateRange: (range: { from?: Date; to?: Date } | undefined) => void;
    handleSort: (newSortBy: AlertsListParams['sort_by']) => void;
    clearFilters: () => void;
    fetchAnalyticsTypes: () => Promise<void>;
    loadMore: () => Promise<void>;

    debouncedFetchAlerts(): void;
}

export const useAlertsModuleStore = create<AlertsModuleState>((set, get) => ({
    alerts: [],
    isLoading: false,
    error: null,
    currentPage: 1,
    pageSize: 10,
    totalItems: 0,
    searchTerm: '',
    filterType: '',
    filterSeverity: '',
    filterDateRange: undefined,
    analyticsTypes: [],
    sortBy: 'created_at',
    sortOrder: 'desc',

    fetchAlerts: async (params?: Partial<AlertsListParams>) => {
        const { currentPage, pageSize, searchTerm, sortBy, sortOrder, filterType, filterDateRange } = get();
        set({ isLoading: true, error: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const response: AlertsListData = await getAlerts({
                group_id: selectedGroupMember.group_id,
                page: params?.page ?? currentPage,
                size: params?.size ?? pageSize,
                search: searchTerm,
                analytic_type: filterType || undefined,
                start_date: filterDateRange?.from?.toISOString(),
                end_date: filterDateRange?.to?.toISOString(),
                sort_by: params?.sort_by ?? sortBy,
                sort_order: params?.sort_order ?? sortOrder,
                ...params,
            });
            set(state => ({
                alerts: params?.page && params.page > 1 ? [...state.alerts, ...(response.alerts || [])] : response.alerts || [],
                currentPage: response.page || 1,
                pageSize: response.size || 10,
                totalItems: response.total || 0,
                isLoading: false,
            }));
        } catch (error) {
            set({ error: 'Failed to fetch alerts', isLoading: false });
            toast.error('Failed to fetch alerts. Please try again later.');
        }
    },

    debouncedFetchAlerts: debounce(() => {
        set({ currentPage: 1 });
        get().fetchAlerts({ page: 1 });
    }, 300),

    setSearchTerm: (term: string) => {
        set({ searchTerm: term });
        get().debouncedFetchAlerts();
    },



    setFilterType: (type: string) => {
        set({ filterType: type, currentPage: 1 });
        get().fetchAlerts({ page: 1 });
    },

    setFilterSeverity: (severity: string) => {
        set({ filterSeverity: severity, currentPage: 1 });
        get().fetchAlerts({ page: 1 });
    },

    setFilterDateRange: (range: { from?: Date; to?: Date } | undefined) => {
        set({ filterDateRange: range, currentPage: 1 });
        get().fetchAlerts({ page: 1 });
    },

    handleSort: (newSortBy: AlertsListParams['sort_by']) => {
        const { sortBy, sortOrder } = get();
        const newOrder = newSortBy === sortBy && sortOrder === 'asc' ? 'desc' : 'asc';
        set({ sortBy: newSortBy, sortOrder: newOrder, currentPage: 1 });
        get().fetchAlerts({ page: 1, sort_by: newSortBy, sort_order: newOrder });
    },

    clearFilters: () => {
        set({
            searchTerm: '',
            filterType: '',
            filterSeverity: '',
            filterDateRange: undefined,
            sortBy: 'created_at',
            sortOrder: 'desc',
            currentPage: 1,
        });
        get().fetchAlerts({ page: 1 });
    },

    fetchAnalyticsTypes: async () => {
        try {
            const types = await getAnalyticsType();
            set({ analyticsTypes: types.types });
        } catch (error) {
            console.error('Failed to fetch analytics types:', error);
            toast.error('Failed to fetch analytics types. Please try again later.');
        }
    },

    loadMore: async () => {
        const { currentPage, pageSize, totalItems } = get();
        if (currentPage * pageSize < totalItems) {
            await get().fetchAlerts({ page: currentPage + 1 });
        }
    },
}));
