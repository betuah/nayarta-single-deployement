import { create } from 'zustand';
import { toast } from 'react-toastify';
import { useUserStore } from "@/store/user-store";
import {
    DtoCreateVideoWallDTO,
    DtoUpdateVideoWallDTO,
    VideoWallsListData,
    DtoVideoWallDetail,
    VideoWallsListParams,
    RecordingPlaybackMultiListData
} from "@/lib/api/data-contracts";
import {
    getVideoWallList,
    createVideoWall,
    getVideoWallDetail,
    updateVideoWall,
    deleteVideoWall
} from '@/actions/video-wall-actions';
import { VideoWallMode } from "@/components/video-wall/constants";
import { useFileModuleStore } from "@/store/file-module-store";

interface VideoWallModuleState {
    // Data states
    videoWalls: VideoWallsListData | null;
    currentVideoWall: DtoVideoWallDetail | null;

    // Loading states
    isLoading: boolean;
    isLoadingDetail: boolean;
    isCreating: boolean;
    isUpdating: boolean;
    isDeleting: boolean;

    // Error states
    error: string | null;
    detailError: string | null;
    createError: string | null;
    updateError: string | null;
    deleteError: string | null;

    // Filter states
    search: string;
    page: number;
    size: number;

    // Playback states
    videoWallMode: VideoWallMode;
    playbackDate: Date | null;
    playbackStartTime: string | null;
    playbackEndTime: string | null;
    currentPlaybackData: RecordingPlaybackMultiListData | null;
    isLoadingPlaybackData: boolean;
    playbackError: string | null;

    // Actions
    setSearch: (search: string) => void;
    setPage: (page: number) => void;
    setSize: (size: number) => void;
    resetFilters: () => void;
    clearVideoWalls: () => void;
    clearErrors: () => void;

    // API actions
    fetchVideoWalls: () => Promise<void>;
    fetchVideoWallDetail: (id: string) => Promise<void>;
    createVideoWall: (data: DtoCreateVideoWallDTO) => Promise<void>;
    updateVideoWall: (id: string, data: DtoUpdateVideoWallDTO) => Promise<void>;
    deleteVideoWall: (id: string) => Promise<void>;

    // Playback actions
    setVideoWallMode: (mode: VideoWallMode) => void;
    setPlaybackDate: (date: Date) => void;
    loadPlaybackData: (videoWallId: string, startTime: string, endTime: string) => Promise<void>;
    clearPlaybackData: () => void;
}

export const useVideoWallModuleStore = create<VideoWallModuleState>((set, get) => ({
    // Initial data states
    videoWalls: null,
    currentVideoWall: null,

    // Initial loading states
    isLoading: false,
    isLoadingDetail: false,
    isCreating: false,
    isUpdating: false,
    isDeleting: false,

    // Initial error states
    error: null,
    detailError: null,
    createError: null,
    updateError: null,
    deleteError: null,

    // Initial filter states
    search: '',
    page: 1,
    size: 10,

    // Initial playback states
    videoWallMode: 'live',
    playbackDate: null,
    playbackStartTime: null,
    playbackEndTime: null,
    currentPlaybackData: null,
    isLoadingPlaybackData: false,
    playbackError: null,

    // Filter setters
    setSearch: (search) => set({ search, page: 1 }),
    setPage: (page) => set({ page }),
    setSize: (size) => set({ size, page: 1 }),
    resetFilters: () => set({
        search: '',
        page: 1,
        size: 10
    }),

    clearVideoWalls: () => set({
        videoWalls: null,
        currentVideoWall: null
    }),

    clearErrors: () => set({
        error: null,
        detailError: null,
        createError: null,
        updateError: null,
        deleteError: null,
        playbackError: null
    }),

    // API actions
    fetchVideoWalls: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ error: errorMsg });
            toast.error(errorMsg);
            return;
        }

        const { search, page, size } = get();
        const params: VideoWallsListParams = {
            group_id: selectedGroupMember.group_id,
            search: search || undefined,
            page,
            size
        };

        set({ isLoading: true, error: null });
        try {
            const data = await getVideoWallList(params);
            set({ videoWalls: data });
        } catch (error) {
            const errorMsg = 'Failed to fetch video walls';
            set({ error: errorMsg });
            toast.error(errorMsg);
        } finally {
            set({ isLoading: false });
        }
    },

    fetchVideoWallDetail: async (id: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ detailError: errorMsg });
            toast.error(errorMsg);
            return;
        }

        set({ isLoadingDetail: true, detailError: null });
        try {
            const data = await getVideoWallDetail({
                group_id: selectedGroupMember.group_id,
                id
            });
            set({ currentVideoWall: data });
        } catch (error) {
            const errorMsg = 'Failed to fetch video wall details';
            set({ detailError: errorMsg });
            toast.error(errorMsg);
            throw new Error(errorMsg);
        } finally {
            set({ isLoadingDetail: false });
        }
    },

    createVideoWall: async (data: DtoCreateVideoWallDTO) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ createError: errorMsg });
            toast.error(errorMsg);
            return;
        }

        set({ isCreating: true, createError: null });
        try {
            data.group_id = selectedGroupMember.group_id
            await createVideoWall({
                group_id: selectedGroupMember.group_id
            }, data);
            toast.success('Video wall created successfully');
            await get().fetchVideoWalls();
        } catch (error) {
            const errorMsg = 'Failed to create video wall';
            set({ createError: errorMsg });
            toast.error(errorMsg);
        } finally {
            set({ isCreating: false });
        }
    },

    updateVideoWall: async (id: string, data: DtoUpdateVideoWallDTO) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ updateError: errorMsg });
            toast.error(errorMsg);
            return;
        }

        set({ isUpdating: true, updateError: null });
        try {
            await updateVideoWall({
                group_id: selectedGroupMember.group_id,
                id
            }, data);
            toast.success('Video wall updated successfully');
            await get().fetchVideoWalls();
            await get().fetchVideoWallDetail(id);
        } catch (error) {
            const errorMsg = 'Failed to update video wall';
            set({ updateError: errorMsg });
            toast.error(errorMsg);
        } finally {
            set({ isUpdating: false });
        }
    },

    deleteVideoWall: async (id: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ deleteError: errorMsg });
            toast.error(errorMsg);
            return;
        }

        set({ isDeleting: true, deleteError: null });
        try {
            await deleteVideoWall({
                group_id: selectedGroupMember.group_id,
                id
            });
            toast.success('Video wall deleted successfully');
            await get().fetchVideoWalls();
            set({ currentVideoWall: null });
        } catch (error) {
            const errorMsg = 'Failed to delete video wall';
            set({ deleteError: errorMsg });
            toast.error(errorMsg);
        } finally {
            set({ isDeleting: false });
        }
    },

    // Playback actions
    setVideoWallMode: (mode: VideoWallMode) => {
        set({ videoWallMode: mode });

        // Clear playback data when switching to live mode
        if (mode === 'live') {
            set({
                currentPlaybackData: null,
                playbackError: null,
                playbackStartTime: null,
                playbackEndTime: null
            });
        }
    },

    setPlaybackDate: (date: Date) => {
        set({ playbackDate: date });

        // Auto-generate 24-hour time range for the selected date
        const startTime = new Date(date);
        startTime.setHours(0, 0, 0, 0);

        const endTime = new Date(date);
        endTime.setHours(23, 59, 59, 999);

        set({
            playbackStartTime: startTime.toISOString(),
            playbackEndTime: endTime.toISOString()
        });
    },

    loadPlaybackData: async (videoWallId: string, startTime: string, endTime: string) => {
        set({ isLoadingPlaybackData: true, playbackError: null });

        try {
            console.log('VideoWall store calling file store with:', { videoWallId, startTime, endTime });
            await useFileModuleStore.getState().loadPlaybackListMulti(videoWallId, startTime, endTime);
            const freshPlaybackData = useFileModuleStore.getState().currentPlaybackListMulti;
            set({
                currentPlaybackData: freshPlaybackData,
                playbackStartTime: startTime,
                playbackEndTime: endTime
            });
        } catch (error) {
            const errorMsg = 'Failed to load playback data';
            set({ playbackError: errorMsg });
            console.error('VideoWall store error:', error);
        } finally {
            set({ isLoadingPlaybackData: false });
        }
    },

    clearPlaybackData: () => set({
        currentPlaybackData: null,
        playbackError: null,
        playbackStartTime: null,
        playbackEndTime: null
    })
}));
