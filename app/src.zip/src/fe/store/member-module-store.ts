import { create } from 'zustand';
import { toast } from 'react-toastify';
import {DtoCreateGroupDTO, DtoJoinGroupMemberDTO, DtoMembershipList} from "@/lib/api/data-contracts";
import {createGroup, getUserMemberships, joinGroup} from "@/actions/member-action";

interface MemberModuleState {
    memberships: DtoMembershipList['memberships'];
    isLoading: boolean;
    isCreatingOrg: boolean;
    isJoiningOrg: boolean;
    error: string | null;
    showCreateOrgDialog: boolean;
    showJoinOrgDialog: boolean;
    showChangeOrgDialog: boolean;
    fetchMemberships: () => Promise<void>;
    createOrganization: (data: DtoCreateGroupDTO) => Promise<void>;
    joinOrganization: (data: DtoJoinGroupMemberDTO) => Promise<void>;
    setShowCreateOrgDialog: (show: boolean) => void;
    setShowJoinOrgDialog: (show: boolean) => void;
    setShowChangeOrgDialog: (show: boolean) => void;
}

export const useMemberModuleStore = create<MemberModuleState>((set, get) => ({
    memberships: [],
    isLoading: false,
    isCreatingOrg: false,
    isJoiningOrg: false,
    error: null,
    showCreateOrgDialog: false,
    showJoinOrgDialog: false,
    showChangeOrgDialog: false,

    fetchMemberships: async () => {
        set({ isLoading: true, error: null });
        try {
            const response = await getUserMemberships();
            set({
                memberships: response.memberships || [],
                isLoading: false
            });
        } catch (error) {
            set({
                error: 'Failed to fetch memberships',
                isLoading: false
            });
            toast.error('Failed to fetch memberships. Please try again later.');
        }
    },

    createOrganization: async (data: DtoCreateGroupDTO) => {
        set({ isCreatingOrg: true });
        try {
            await createGroup(data);
            toast.success('Organization created successfully!');
            set({ showCreateOrgDialog: false });
            await get().fetchMemberships();
        } catch (error) {
            toast.error('Failed to create organization. Please try again.');
        } finally {
            set({ isCreatingOrg: false });
        }
    },

    joinOrganization: async (data: DtoJoinGroupMemberDTO) => {
        set({ isJoiningOrg: true });
        try {
            await joinGroup(data);
            toast.success('Join request sent successfully! Please check your email for confirmation.');
            set({ showJoinOrgDialog: false });
            await get().fetchMemberships();
        } catch (error) {
            toast.error('Failed to send join request. Make sure organization email registered and organization exist. Please try again.');
        } finally {
            set({ isJoiningOrg: false });
        }
    },

    setShowCreateOrgDialog: (show: boolean) => {
        set({ showCreateOrgDialog: show });
    },

    setShowJoinOrgDialog: (show: boolean) => {
        set({ showJoinOrgDialog: show });
    },

    setShowChangeOrgDialog: (show: boolean) => {
        set({ showChangeOrgDialog: show });
    },
}));
