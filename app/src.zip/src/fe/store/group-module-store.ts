import { create } from 'zustand';
import { toast } from 'react-toastify';
import { useUserStore } from "@/store/user-store";
import {
    DtoUpdateStorageSettingsDTO,
    StorageSettingsUpdateParams,
    StorageSettingsUpdateData,
    StorageUsageListParams,
    StorageUsageListData,
    DtoStorageUsageDTO,
    QuotaAllListParams,
    QuotaAllListData,
    QuotaCamerasListParams,
    QuotaCamerasListData,
    QuotaFloorPlansListParams,
    QuotaFloorPlansListData,
    QuotaLocationsListParams,
    QuotaLocationsListData,
    QuotaMembersListParams,
    QuotaMembersListData,
    QuotaNvrsListParams,
    QuotaNvrsListData,
    QuotaStorageListParams,
    QuotaStorageListData
} from "@/lib/api/data-contracts";
import {
    updateNotificationThreshold,
    getStorageUsageInfo,
    getQuotaAll,
    getQuotaCameras,
    getQuotaFloorPlans,
    getQuotaLocations,
    getQuotaMembers,
    getQuotaNvrs,
    getQuotaStorage
} from '@/actions/group-actions';

interface GroupModuleState {
    // Data states
    storageUsage: DtoStorageUsageDTO | null;
    storageSettings: StorageSettingsUpdateData | null;
    quotaAll: QuotaAllListData | null;
    quotaCameras: QuotaCamerasListData | null;
    quotaFloorPlans: QuotaFloorPlansListData | null;
    quotaLocations: QuotaLocationsListData | null;
    quotaMembers: QuotaMembersListData | null;
    quotaNvrs: QuotaNvrsListData | null;
    quotaStorage: QuotaStorageListData | null;

    // Loading states
    isLoadingStorageUsage: boolean;
    isUpdatingStorageSettings: boolean;
    isLoadingQuotaAll: boolean;
    isLoadingQuotaCameras: boolean;
    isLoadingQuotaFloorPlans: boolean;
    isLoadingQuotaLocations: boolean;
    isLoadingQuotaMembers: boolean;
    isLoadingQuotaNvrs: boolean;
    isLoadingQuotaStorage: boolean;

    // Error states
    storageUsageError: string | null;
    storageSettingsError: string | null;
    quotaAllError: string | null;
    quotaCamerasError: string | null;
    quotaFloorPlansError: string | null;
    quotaLocationsError: string | null;
    quotaMembersError: string | null;
    quotaNvrsError: string | null;
    quotaStorageError: string | null;

    // Actions
    clearGroupData: () => void;
    reset: () => void;

    // API actions
    fetchStorageUsage: () => Promise<void>;
    updateStorageSettings: (threshold: number) => Promise<void>;
    fetchQuotaAll: () => Promise<void>;
    fetchQuotaCameras: () => Promise<void>;
    fetchQuotaFloorPlans: () => Promise<void>;
    fetchQuotaLocations: () => Promise<void>;
    fetchQuotaMembers: () => Promise<void>;
    fetchQuotaNvrs: () => Promise<void>;
    fetchQuotaStorage: () => Promise<void>;
}

export const useGroupModuleStore = create<GroupModuleState>((set, get) => ({
    // Initial states
    storageUsage: null,
    storageSettings: null,
    quotaAll: null,
    quotaCameras: null,
    quotaFloorPlans: null,
    quotaLocations: null,
    quotaMembers: null,
    quotaNvrs: null,
    quotaStorage: null,
    isLoadingStorageUsage: false,
    isUpdatingStorageSettings: false,
    isLoadingQuotaAll: false,
    isLoadingQuotaCameras: false,
    isLoadingQuotaFloorPlans: false,
    isLoadingQuotaLocations: false,
    isLoadingQuotaMembers: false,
    isLoadingQuotaNvrs: false,
    isLoadingQuotaStorage: false,
    storageUsageError: null,
    storageSettingsError: null,
    quotaAllError: null,
    quotaCamerasError: null,
    quotaFloorPlansError: null,
    quotaLocationsError: null,
    quotaMembersError: null,
    quotaNvrsError: null,
    quotaStorageError: null,

    // Clear data
    clearGroupData: () => set({
        storageUsage: null,
        storageSettings: null,
        quotaAll: null,
        quotaCameras: null,
        quotaFloorPlans: null,
        quotaLocations: null,
        quotaMembers: null,
        quotaNvrs: null,
        quotaStorage: null,
        storageUsageError: null,
        storageSettingsError: null,
        quotaAllError: null,
        quotaCamerasError: null,
        quotaFloorPlansError: null,
        quotaLocationsError: null,
        quotaMembersError: null,
        quotaNvrsError: null,
        quotaStorageError: null
    }),

    // Reset all state
    reset: () => set({
        storageUsage: null,
        storageSettings: null,
        quotaAll: null,
        quotaCameras: null,
        quotaFloorPlans: null,
        quotaLocations: null,
        quotaMembers: null,
        quotaNvrs: null,
        quotaStorage: null,
        isLoadingStorageUsage: false,
        isUpdatingStorageSettings: false,
        isLoadingQuotaAll: false,
        isLoadingQuotaCameras: false,
        isLoadingQuotaFloorPlans: false,
        isLoadingQuotaLocations: false,
        isLoadingQuotaMembers: false,
        isLoadingQuotaNvrs: false,
        isLoadingQuotaStorage: false,
        storageUsageError: null,
        storageSettingsError: null,
        quotaAllError: null,
        quotaCamerasError: null,
        quotaFloorPlansError: null,
        quotaLocationsError: null,
        quotaMembersError: null,
        quotaNvrsError: null,
        quotaStorageError: null
    }),

    // Fetch storage usage information
    fetchStorageUsage: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingStorageUsage: true, storageUsageError: null });
        try {
            const params: StorageUsageListParams = {
                group_id: selectedGroupMember.group_id
            };

            const data: StorageUsageListData = await getStorageUsageInfo(params);
            set({
                storageUsage: data,
                isLoadingStorageUsage: false
            });
        } catch (error) {
            const errorMessage = 'Failed to fetch storage usage information';
            set({
                storageUsageError: errorMessage,
                isLoadingStorageUsage: false
            });
            toast.error(errorMessage);
            console.error('Storage usage fetch error:', error);
        }
    },

    // Update storage notification threshold
    updateStorageSettings: async (threshold: number) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        // Validate threshold
        if (threshold < 0 || threshold > 100) {
            toast.error('Threshold must be between 0 and 100');
            return;
        }

        set({ isUpdatingStorageSettings: true, storageSettingsError: null });
        try {
            const params: StorageSettingsUpdateParams = {
                group_id: selectedGroupMember.group_id
            };

            const updateData: DtoUpdateStorageSettingsDTO = {
                storage_notification_threshold: threshold
            };

            const data: StorageSettingsUpdateData = await updateNotificationThreshold(params, updateData);

            set({
                storageSettings: data,
                isUpdatingStorageSettings: false
            });

            toast.success('Storage notification threshold updated successfully');

            // Refresh storage usage to get updated data
            await get().fetchStorageUsage();
        } catch (error) {
            const errorMessage = 'Failed to update storage notification threshold';
            set({
                storageSettingsError: errorMessage,
                isUpdatingStorageSettings: false
            });
            toast.error(errorMessage);
            console.error('Storage settings update error:', error);
        }
    },

    // Fetch all quota information
    fetchQuotaAll: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingQuotaAll: true, quotaAllError: null });
        try {
            const params: QuotaAllListParams = {
                group_id: selectedGroupMember.group_id
            };

            const data: QuotaAllListData = await getQuotaAll(params);
            set({
                quotaAll: data,
                isLoadingQuotaAll: false
            });
        } catch (error) {
            const errorMessage = 'Failed to fetch all quota information';
            set({
                quotaAllError: errorMessage,
                isLoadingQuotaAll: false
            });
            toast.error(errorMessage);
            console.error('Quota all fetch error:', error);
        }
    },

    // Fetch camera quota information
    fetchQuotaCameras: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingQuotaCameras: true, quotaCamerasError: null });
        try {
            const params: QuotaCamerasListParams = {
                group_id: selectedGroupMember.group_id
            };

            const data: QuotaCamerasListData = await getQuotaCameras(params);
            set({
                quotaCameras: data,
                isLoadingQuotaCameras: false
            });
        } catch (error) {
            const errorMessage = 'Failed to fetch camera quota information';
            set({
                quotaCamerasError: errorMessage,
                isLoadingQuotaCameras: false
            });
            toast.error(errorMessage);
            console.error('Quota cameras fetch error:', error);
        }
    },

    // Fetch floor plan quota information
    fetchQuotaFloorPlans: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingQuotaFloorPlans: true, quotaFloorPlansError: null });
        try {
            const params: QuotaFloorPlansListParams = {
                group_id: selectedGroupMember.group_id
            };

            const data: QuotaFloorPlansListData = await getQuotaFloorPlans(params);
            set({
                quotaFloorPlans: data,
                isLoadingQuotaFloorPlans: false
            });
        } catch (error) {
            const errorMessage = 'Failed to fetch floor plan quota information';
            set({
                quotaFloorPlansError: errorMessage,
                isLoadingQuotaFloorPlans: false
            });
            toast.error(errorMessage);
            console.error('Quota floor plans fetch error:', error);
        }
    },

    // Fetch location quota information
    fetchQuotaLocations: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingQuotaLocations: true, quotaLocationsError: null });
        try {
            const params: QuotaLocationsListParams = {
                group_id: selectedGroupMember.group_id
            };

            const data: QuotaLocationsListData = await getQuotaLocations(params);
            set({
                quotaLocations: data,
                isLoadingQuotaLocations: false
            });
        } catch (error) {
            const errorMessage = 'Failed to fetch location quota information';
            set({
                quotaLocationsError: errorMessage,
                isLoadingQuotaLocations: false
            });
            toast.error(errorMessage);
            console.error('Quota locations fetch error:', error);
        }
    },

    // Fetch member quota information
    fetchQuotaMembers: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingQuotaMembers: true, quotaMembersError: null });
        try {
            const params: QuotaMembersListParams = {
                group_id: selectedGroupMember.group_id
            };

            const data: QuotaMembersListData = await getQuotaMembers(params);
            set({
                quotaMembers: data,
                isLoadingQuotaMembers: false
            });
        } catch (error) {
            const errorMessage = 'Failed to fetch member quota information';
            set({
                quotaMembersError: errorMessage,
                isLoadingQuotaMembers: false
            });
            toast.error(errorMessage);
            console.error('Quota members fetch error:', error);
        }
    },

    // Fetch NVR quota information
    fetchQuotaNvrs: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingQuotaNvrs: true, quotaNvrsError: null });
        try {
            const params: QuotaNvrsListParams = {
                group_id: selectedGroupMember.group_id
            };

            const data: QuotaNvrsListData = await getQuotaNvrs(params);
            set({
                quotaNvrs: data,
                isLoadingQuotaNvrs: false
            });
        } catch (error) {
            const errorMessage = 'Failed to fetch NVR quota information';
            set({
                quotaNvrsError: errorMessage,
                isLoadingQuotaNvrs: false
            });
            toast.error(errorMessage);
            console.error('Quota NVRs fetch error:', error);
        }
    },

    // Fetch storage quota information
    fetchQuotaStorage: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingQuotaStorage: true, quotaStorageError: null });
        try {
            const params: QuotaStorageListParams = {
                group_id: selectedGroupMember.group_id
            };

            const data: QuotaStorageListData = await getQuotaStorage(params);
            set({
                quotaStorage: data,
                isLoadingQuotaStorage: false
            });
        } catch (error) {
            const errorMessage = 'Failed to fetch storage quota information';
            set({
                quotaStorageError: errorMessage,
                isLoadingQuotaStorage: false
            });
            toast.error(errorMessage);
            console.error('Quota storage fetch error:', error);
        }
    }
}));
