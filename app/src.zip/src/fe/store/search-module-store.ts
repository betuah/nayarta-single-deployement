import { create } from 'zustand';
import { toast } from 'react-toastify';
import {
    CamerasListParams, CamerasListData,
    FloorPlansListParams2, FloorPlansListResult,
    LocationsListParams2, LocationsListResult,
    DtoCameraSearchResult, DtoFloorPlanSearchResult, DtoLocationSearchResult
} from '@/lib/api/data-contracts';
import {
    getCamerasList,
    getFloorPlansList,
    getLocationsList
} from '@/actions/search-actions';
import { useUserStore } from '@/store/user-store';

interface SearchModuleState {
    // Cameras state
    cameras: DtoCameraSearchResult[];
    isLoadingCameras: boolean;
    camerasError: string | null;

    // Floor plans state
    floorPlans: DtoFloorPlanSearchResult[];
    isLoadingFloorPlans: boolean;
    floorPlansError: string | null;

    // Locations state
    locations: DtoLocationSearchResult[];
    isLoadingLocations: boolean;
    locationsError: string | null;

    // Methods
    fetchCameras: (floorPlanId?: string, status?: string) => Promise<void>;
    fetchFloorPlans: (locationId: string) => Promise<void>;
    fetchLocations: () => Promise<void>;
    reset: () => void;
}

export const useSearchModuleStore = create<SearchModuleState>((set, get) => ({
    // Initial cameras state
    cameras: [],
    isLoadingCameras: false,
    camerasError: null,

    // Initial floor plans state
    floorPlans: [],
    isLoadingFloorPlans: false,
    floorPlansError: null,

    // Initial locations state
    locations: [],
    isLoadingLocations: false,
    locationsError: null,

    // Fetch cameras for a floor plan
    fetchCameras: async (floorPlanId?: string, status?: string) => {
        set({ isLoadingCameras: true, camerasError: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: CamerasListData = await getCamerasList({
                group_id: selectedGroupMember.group_id,
                floor_plan_id: floorPlanId,
                status: status as any
            });

            set({
                cameras: response.cameras || [],
                isLoadingCameras: false
            });
        } catch (error) {
            set({ camerasError: 'Failed to fetch cameras', isLoadingCameras: false });
            toast.error('Failed to fetch cameras. Please try again later.');
        }
    },

    // Fetch floor plans for a location
    fetchFloorPlans: async (locationId: string) => {
        set({ isLoadingFloorPlans: true, floorPlansError: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: FloorPlansListResult = await getFloorPlansList({
                group_id: selectedGroupMember.group_id,
                location_id: locationId
            });

            set({
                floorPlans: response.floor_plans || [],
                isLoadingFloorPlans: false
            });
        } catch (error) {
            set({ floorPlansError: 'Failed to fetch floor plans', isLoadingFloorPlans: false });
            toast.error('Failed to fetch floor plans. Please try again later.');
        }
    },

    // Fetch all locations for a group
    fetchLocations: async () => {
        set({ isLoadingLocations: true, locationsError: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: LocationsListResult = await getLocationsList({
                group_id: selectedGroupMember.group_id
            });

            set({
                locations: response.locations || [],
                isLoadingLocations: false
            });
        } catch (error) {
            set({ locationsError: 'Failed to fetch locations', isLoadingLocations: false });
            toast.error('Failed to fetch locations. Please try again later.');
        }
    },

    // Reset all state
    reset: () => {
        set({
            cameras: [],
            isLoadingCameras: false,
            camerasError: null,

            floorPlans: [],
            isLoadingFloorPlans: false,
            floorPlansError: null,

            locations: [],
            isLoadingLocations: false,
            locationsError: null
        });
    }
}));
