import {create} from 'zustand'
import {siteConfig} from "@/config/site";
import {persist, createJSONStorage} from "zustand/middleware";

interface ThemeStoreState {
    theme: string;
    setTheme: (theme: string) => void;
    radius: number;
    setRadius: (value: number) => void;
}

export const useThemeStore = create<ThemeStoreState>()(
    persist(
        (set) => ({
            theme: siteConfig.theme,
            setTheme: (theme) => set({theme}),
            radius: siteConfig.radius,
            setRadius: (value) => set({radius: value}),
        }),
        {
            name: "theme-store",
            storage: createJSONStorage(() => localStorage),
        },
    ),
)


interface SidebarState {
    collapsed: boolean;
    subMenu: boolean;
    mobileMenu: boolean;
    chatOpen: boolean;
    setCollapsed: (collapsed: boolean) => void;
    setSubMenu: (subMenu: boolean) => void;
    setMobileMenu: (mobileMenu: boolean) => void;
    setChatOpen: (chatOpen: boolean) => void;
}

export const useSidebar = create<SidebarState>()(
    persist(
        (set) => ({
            collapsed: false,
            subMenu: false,
            mobileMenu: false,
            chatOpen: false,
            setCollapsed: (collapsed) => {
                set({collapsed})
                set({chatOpen: false})
            },
            setSubMenu: (subMenu) => set({subMenu}),
            setMobileMenu: (mobileMenu) => set({mobileMenu}),
            setChatOpen: (chatOpen) => {
                // DON'T change collapsed state, just toggle chat
                set({chatOpen});
            },
        }),
        {
            name: 'sidebar-storage',
        }
    )
);
