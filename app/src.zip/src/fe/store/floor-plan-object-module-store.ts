import {create} from 'zustand';
import {toast} from 'react-toastify';
import {useUserStore} from "@/store/user-store";
import {
    DtoCreateFloorPlanObjectRequest,
    DtoUpdateFloorPlanObjectRequest,
    FloorPlanObjectsListData,
    DtoFloorPlanObjectResponse,
    FloorPlanObjectsListParams,
    ObjectDetailData,
    AvailableCctvsDetailParams,
    AvailableCctvsDetailData,
    AvailableNvrsDetailParams,
    AvailableNvrsDetailData,
} from "@/lib/api/data-contracts";
import {
    getFloorPlanList,
    createFloorPlanObjects,
    getFloorPlanObjectDetailByObject,
    getFloorPlanObjectDetailById,
    updateFloorPlanObject,
    deleteFloorPlanObjects,
    getAvailableCCTV,
    getAvailableNVR,
} from '@/actions/floor-plan-object-actions';

interface FloorPlanObjectModuleState {
    // Data states
    floorPlanObjects: FloorPlanObjectsListData | null;
    currentFloorPlanObject: DtoFloorPlanObjectResponse | null;
    objectDetail: ObjectDetailData | null;
    availableCCTVs: AvailableCctvsDetailData | null
    availableNVRs: AvailableNvrsDetailData | null

    // Loading states
    isLoading: boolean;
    isLoadingDetail: boolean;
    isLoadingObjectDetail: boolean;
    isCreating: boolean;
    isUpdating: boolean;
    isDeleting: boolean;
    isLoadingAvailableCCTVs: boolean
    isLoadingAvailableNVRs: boolean

    // Filter states
    search: string;
    floorPlanId: string | null;
    objectType: "nvr" | "cctv" | null;
    objectId: string | null;
    offset: number;
    limit: number;

    // Actions
    setSearch: (search: string) => void;
    setFloorPlanId: (id: string | null) => void;
    setObjectType: (type: "nvr" | "cctv" | null) => void;
    setObjectId: (id: string | null) => void;
    setOffset: (offset: number) => void;
    setLimit: (limit: number) => void;
    resetFilters: () => void;
    fetchAvailableCCTVs: (groupId: string, floorPlanId: string) => Promise<void>
    fetchAvailableNVRs: (groupId: string, floorPlanId: string) => Promise<void>

    // API actions
    fetchFloorPlanObjects: () => Promise<void>;
    fetchFloorPlanObjectDetail: (id: string) => Promise<void>;
    fetchObjectDetail: (objectType: "nvr" | "cctv", objectId: string) => Promise<void>;
    createFloorPlanObject: (data: DtoCreateFloorPlanObjectRequest) => Promise<void>;
    updateFloorPlanObject: (id: string, data: DtoUpdateFloorPlanObjectRequest) => Promise<void>;
    deleteFloorPlanObject: (id: string) => Promise<void>;

    resetAvailableCCTVs: () => void
    resetAvailableNVRs: () => void
}

export const useFloorPlanObjectModuleStore = create<FloorPlanObjectModuleState>((set, get) => ({
    // Initial states
    floorPlanObjects: null,
    currentFloorPlanObject: null,
    objectDetail: null,
    isLoading: false,
    isLoadingDetail: false,
    isLoadingObjectDetail: false,
    isCreating: false,
    isUpdating: false,
    isDeleting: false,
    search: '',
    floorPlanId: null,
    objectType: null,
    objectId: null,
    offset: 0,
    limit: 10,
    availableCCTVs: null,
    availableNVRs: null,
    isLoadingAvailableCCTVs: false,
    isLoadingAvailableNVRs: false,

    // Filter setters
    setSearch: (search) => set({search, offset: 0}),
    setFloorPlanId: (floorPlanId) => set({floorPlanId, offset: 0}),
    setObjectType: (objectType) => set({objectType, offset: 0}),
    setObjectId: (objectId) => set({objectId, offset: 0}),
    setOffset: (offset) => set({offset}),
    setLimit: (limit) => set({limit}),
    resetFilters: () => set({
        search: '',
        floorPlanId: null,
        objectType: null,
        objectId: null,
        offset: 0,
        limit: 10
    }),

    // API actions
    fetchFloorPlanObjects: async () => {
        const {selectedGroupMember} = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        const {search, floorPlanId, objectType, objectId, offset, limit} = get();
        const params: FloorPlanObjectsListParams = {
            group_id: selectedGroupMember.group_id,
            search: search || undefined,
            floor_plan_id: floorPlanId || undefined,
            object_type: objectType || undefined,
            object_id: objectId || undefined,
            offset,
            limit
        };

        set({isLoading: true});
        try {
            const data = await getFloorPlanList(params);
            set({floorPlanObjects: data});
        } catch (error) {
            toast.error('Failed to fetch floor plan objects');
        } finally {
            set({isLoading: false});
        }
    },

    fetchFloorPlanObjectDetail: async (id: string) => {
        const {selectedGroupMember} = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({isLoadingDetail: true});
        try {
            const data = await getFloorPlanObjectDetailById({
                group_id: selectedGroupMember.group_id,
                id
            });
            set({currentFloorPlanObject: data});
        } catch (error) {
            toast.error('Failed to fetch floor plan object details');
        } finally {
            set({isLoadingDetail: false});
        }
    },

    fetchObjectDetail: async (objectType: "nvr" | "cctv", objectId: string) => {
        const {selectedGroupMember} = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({isLoadingObjectDetail: true});
        try {
            const data = await getFloorPlanObjectDetailByObject({
                group_id: selectedGroupMember.group_id,
                objectType,
                objectId
            });
            set({objectDetail: data});
        } catch (error) {
            toast.error('Failed to fetch object details');
        } finally {
            set({isLoadingObjectDetail: false});
        }
    },

    createFloorPlanObject: async (data: DtoCreateFloorPlanObjectRequest) => {
        const {selectedGroupMember} = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({isCreating: true});
        try {
            await createFloorPlanObjects({
                group_id: selectedGroupMember.group_id
            }, data);
            toast.success('Floor plan object created successfully');
            await get().fetchFloorPlanObjects();
        } catch (error) {
            toast.error('Failed to create floor plan object');
        } finally {
            set({isCreating: false});
        }
    },

    updateFloorPlanObject: async (id: string, data: DtoUpdateFloorPlanObjectRequest) => {
        const {selectedGroupMember} = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({isUpdating: true});
        try {
            await updateFloorPlanObject({
                group_id: selectedGroupMember.group_id,
                id
            }, data);
            toast.success('Floor plan object updated successfully');
            await get().fetchFloorPlanObjects();
            await get().fetchFloorPlanObjectDetail(id);
        } catch (error) {
            toast.error('Failed to update floor plan object');
        } finally {
            set({isUpdating: false});
        }
    },

    deleteFloorPlanObject: async (id: string) => {
        const {selectedGroupMember} = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({isDeleting: true});
        try {
            await deleteFloorPlanObjects({
                group_id: selectedGroupMember.group_id,
                id
            });
            toast.success('Floor plan object deleted successfully');
            await get().fetchFloorPlanObjects();
            set({currentFloorPlanObject: null});
        } catch (error) {
            toast.error('Failed to delete floor plan object');
        } finally {
            set({isDeleting: false});
        }
    },

    fetchAvailableCCTVs: async (groupId: string, floorPlanId: string) => {
        set({isLoadingAvailableCCTVs: true})
        try {
            const response = await getAvailableCCTV({
                group_id: groupId,
                floorPlanId
            })
            set({availableCCTVs: response})
        } catch (error) {
            toast.error('Failed to fetch available CCTVs')
            console.error('Error fetching available CCTVs:', error)
        } finally {
            set({isLoadingAvailableCCTVs: false})
        }
    },

    fetchAvailableNVRs: async (groupId: string, floorPlanId: string) => {
        set({isLoadingAvailableNVRs: true})
        try {
            const response = await getAvailableNVR({
                group_id: groupId,
                floorPlanId
            })
            set({availableNVRs: response})
        } catch (error) {
            toast.error('Failed to fetch available NVRs')
            console.error('Error fetching available NVRs:', error)
        } finally {
            set({isLoadingAvailableNVRs: false})
        }
    },

    resetAvailableCCTVs: () => set({availableCCTVs: null}),
    resetAvailableNVRs: () => set({availableNVRs: null}),

}));
