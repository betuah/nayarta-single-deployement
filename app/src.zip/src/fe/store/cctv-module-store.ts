import {create} from 'zustand';
import {toast} from 'react-toastify';
import {
    CctvsListParams,
    DtoListCCTVsResponse,
    DtoCCTVListItem,
    DtoCCTVDetail,
    DtoCCTVConnectionDetail,
    DtoCreateCCTVDTO,
    DtoUpdateCCTVDTO,
    DtoCCTVStreamURLsResponse,
    DtoCreateStreamURLDTO,
    ScheduleUpdateData
} from '@/lib/api/data-contracts';
import {
    addNewCCTV, addNewStreamUrl,
    deleteCctv, deleteStreamUrl,
    editCctv,
    getAllCCTV,
    getCctvConnection,
    getCctvDetail, getScheduleDetail, getSnapshotUrl,
    getStreamUrl, sendPtz, updateSchedule
} from '@/actions/cctv-actions';
import {useUserStore} from '@/store/user-store';

interface CCTVModuleState {
    cctvs: DtoCCTVListItem[];
    isLoading: boolean;
    error: string | null;
    currentPage: number;
    totalPages: number;
    searchTerm: string;
    connectionDetail: DtoCCTVConnectionDetail | null;
    isFetchingConnectionDetail: boolean;
    searchBy: 'name' | 'brand' | 'type';
    sortBy: CctvsListParams['sort_by'];
    sortOrder: CctvsListParams['sort_order'];
    activeTab: 'table' | 'card';
    statusFilter: 'online' | 'offline' | null;

    // Auto-refresh related state
    isAutoRefreshEnabled: boolean;
    refreshInterval: number; // in milliseconds
    lastRefreshTime: Date | null;
    isAutoRefreshing: boolean;

    fetchCCTVs: (params?: Partial<CctvsListParams>) => Promise<void>;
    setSearchTerm: (term: string) => void;
    setSearchBy: (searchBy: 'name' | 'brand' | 'type') => void;
    setActiveTab: (tab: 'table' | 'card') => void;
    handleSort: (newSortBy: CctvsListParams['sort_by']) => void;
    setStatusFilter: (status: 'online' | 'offline' | null) => void;
    reset: () => void;
    deleteCctv: (id: string) => Promise<void>;

    // Auto-refresh methods
    refreshData: () => Promise<void>;
    setAutoRefreshEnabled: (enabled: boolean) => void;
    setRefreshInterval: (interval: number) => void;

    currentCameraDetails: DtoCCTVDetail | null;
    streamUrls: DtoCCTVStreamURLsResponse | null;
    recordingSchedule: ScheduleUpdateData | null;
    isLoadingStreamUrls: boolean;
    isAddingStreamUrl: boolean;
    isDeletingStreamUrl: boolean;
    isLoadingRecordingSchedule: boolean;
    isUpdatingRecordingSchedule: boolean;
    isPtzSendingCommand: boolean;
    addCamera: (data: DtoCreateCCTVDTO) => Promise<void>;
    editCamera: (id: string, data: DtoUpdateCCTVDTO) => Promise<void>;
    fetchCameraDetails: (id: string) => Promise<void>;
    refreshCameraDetails: (id: string) => Promise<void>;
    fetchConnectionDetail: (id: string) => Promise<void>;
    fetchStreamUrls: (id: string) => Promise<void>;
    addStreamUrl: (cctvId: string, data: DtoCreateStreamURLDTO) => Promise<void>;
    deleteStreamUrl: (cctvId: string, urlId: string) => Promise<void>;
    getScheduleDetail: (cctvId: string) => Promise<void>
    updateSchedule: (cctvId: string, schedule: number[], retentionDays: number) => Promise<void>;
    isLoadingSnapshot: boolean;
    getCameraSnapshot: (cctvId: string) => Promise<void>
    cameraSnapshotUrl: string | undefined
    controlPtzCamera: (cctvId: string, direction: "up" | "down" | "left" | "right" | "zoomin" | "zoomout") => Promise<void>
}

export const useCCTVModuleStore = create<CCTVModuleState>((set, get) => ({
    cctvs: [],
    isLoading: false,
    error: null,
    currentPage: 1,
    totalPages: 1,
    searchTerm: '',
    searchBy: 'name',
    sortBy: 'created_at',
    sortOrder: 'desc',
    activeTab: 'table',
    statusFilter: null,

    // Auto-refresh state
    isAutoRefreshEnabled: true,
    refreshInterval: 180000, // 3 minutes in milliseconds
    lastRefreshTime: null,
    isAutoRefreshing: false,

    currentCameraDetails: null,
    connectionDetail: null,
    isFetchingConnectionDetail: false,
    streamUrls: null,
    recordingSchedule: null,
    isLoadingStreamUrls: false,
    isAddingStreamUrl: false,
    isDeletingStreamUrl: false,
    isLoadingRecordingSchedule: false,
    isUpdatingRecordingSchedule: false,
    isLoadingSnapshot: false,
    isPtzSendingCommand: false,
    cameraSnapshotUrl: undefined,

    // Enhanced refresh method that preserves current state
    refreshData: async () => {
        const {
            currentPage,
            searchTerm,
            searchBy,
            sortBy,
            sortOrder,
            statusFilter,
            isLoading
        } = get();

        // Prevent multiple concurrent refreshes
        if (isLoading) return;

        set({ isAutoRefreshing: true, error: null });

        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: DtoListCCTVsResponse = await getAllCCTV({
                group_id: selectedGroupMember.group_id,
                page: currentPage,
                size: 10,
                search: (searchBy === 'name') ? searchTerm : "",
                [searchBy]: searchTerm,
                sort_by: sortBy,
                sort_order: sortOrder,
                status: statusFilter ?? undefined,
            });

            set({
                cctvs: response.cctvs || [],
                currentPage: response.page || currentPage,
                totalPages: response.total ? Math.ceil(response.total / (response.size || 10)) : 1,
                isAutoRefreshing: false,
                lastRefreshTime: new Date(),
            });
        } catch (error) {
            set({
                error: 'Failed to refresh CCTVs',
                isAutoRefreshing: false
            });
            // Don't show toast for auto-refresh errors to avoid spam
            console.error('Auto-refresh failed:', error);
        }
    },

    setAutoRefreshEnabled: (enabled: boolean) => {
        set({ isAutoRefreshEnabled: enabled });
    },

    setRefreshInterval: (interval: number) => {
        set({ refreshInterval: interval });
    },

    getCameraSnapshot: async (cctvId: string) => {
        set({isLoadingSnapshot: true})
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                set({error: 'Failed to fetch Cameras', isLoading: false});
                toast.error('Failed to fetch camera snapshot. Please try again later.');
                return;
            }
            const data = await getSnapshotUrl({
                group_id: selectedGroupMember.group_id,
                id: cctvId
            })

            set({
                isLoadingSnapshot: false,
                cameraSnapshotUrl: data.snapshot_url
            })
        } catch (e) {
            set({
                isLoadingSnapshot: false,
                error: 'Failed to fetch Camera snapshot'
            })
            toast.error('Failed to fetch Camera snapshot. Please try again later.');
        }
    },

    fetchCCTVs: async (params?: Partial<CctvsListParams>) => {
        const {currentPage, searchTerm, searchBy, sortBy, sortOrder, statusFilter} = get();
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                console.error("No group selected");
                set({error: 'Failed to fetch Cameras', isLoading: false});
                toast.error('Failed to fetch cameras. Please try again later.');
                return;
            }
            const response: DtoListCCTVsResponse = await getAllCCTV({
                group_id: selectedGroupMember.group_id,
                page: params?.page ?? currentPage,
                size: 10,
                search: (searchBy === 'name') ? params?.search ?? searchTerm : "",
                [searchBy]: searchTerm,
                sort_by: params?.sort_by ?? sortBy,
                sort_order: params?.sort_order ?? sortOrder,
                status: statusFilter ?? undefined,
                ...params,
            });
            set({
                cctvs: response.cctvs || [],
                currentPage: response.page || 1,
                totalPages: response.total ? Math.ceil(response.total / (response.size || 10)) : 1,
                isLoading: false,
                lastRefreshTime: new Date(),
            });
        } catch (error) {
            set({error: 'Failed to fetch CCTVs', isLoading: false});
            toast.error('Failed to fetch CCTVs. Please try again later.');
        }
    },

    fetchConnectionDetail: async (id: string) => {
        set({isFetchingConnectionDetail: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                console.error("No group selected");
                set({error: 'Failed to fetch Cameras', isLoading: false});
                toast.error('Failed to fetch cameras. Please try again later.');
                return;
            }
            const response: DtoCCTVConnectionDetail = await getCctvConnection({
                group_id: selectedGroupMember.group_id,
                id: id
            })
            set({connectionDetail: response, isFetchingConnectionDetail: false})
        } catch (e) {
            set({error: 'Failed to fetch CCTVs', isFetchingConnectionDetail: false});
            toast.error('Failed to fetch CCTV connection. Please try again later.');
        }
    },

    setSearchTerm: (term: string) => set({searchTerm: term}),

    setSearchBy: (searchBy: 'name' | 'brand' | 'type') => set({searchBy}),

    setActiveTab: (tab: 'table' | 'card') => set({activeTab: tab}),

    handleSort: (newSortBy: CctvsListParams['sort_by']) => {
        const {sortBy, sortOrder} = get();
        if (newSortBy === sortBy) {
            set({sortOrder: sortOrder === 'asc' ? 'desc' : 'asc'});
        } else {
            set({sortBy: newSortBy, sortOrder: 'asc'});
        }
        get().fetchCCTVs();
    },

    setStatusFilter: (status: 'online' | 'offline' | null) => {
        set({statusFilter: status, currentPage: 1});
        get().fetchCCTVs();
    },

    deleteCctv: async (id: string) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                console.error("No group selected");
                set({error: 'Failed to delete Camera', isLoading: false});
                toast.error('Failed to delete camera. Please try again later.');
                return;
            }
            await deleteCctv({
                group_id: selectedGroupMember.group_id,
                id: id
            })
            set({isLoading: false});
            toast.success('Camera deleted successfully');
        } catch (e) {
            set({error: 'Failed to delete Camera', isLoading: false});
            toast.error('Failed to delete camera. Please try again later or the camera may have a relationship with other objects and currently can not be deleted.');
        }
    },

    fetchCameraDetails: async (id: string) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const response = await getCctvDetail({
                group_id: selectedGroupMember.group_id,
                id: id,
            });
            set({currentCameraDetails: response, isLoading: false, lastRefreshTime: new Date()});
        } catch (error) {
            set({error: 'Failed to fetch camera details', isLoading: false});
            toast.error('Failed to fetch camera details. Please try again later.');
        }
    },

    refreshCameraDetails: async (id: string) => {
        set({isAutoRefreshing: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const response = await getCctvDetail({
                group_id: selectedGroupMember.group_id,
                id: id,
            });
            set({currentCameraDetails: response, isAutoRefreshing: false, lastRefreshTime: new Date()});
        } catch (error) {
            set({error: 'Failed to refresh camera details', isAutoRefreshing: false});
            // Don't show toast for auto-refresh errors to avoid spam
            console.error('Auto-refresh camera details failed:', error);
        }
    },

    addCamera: async (data: DtoCreateCCTVDTO) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            await addNewCCTV({group_id: selectedGroupMember.group_id}, data);
            set({isLoading: false});
            toast.success('Camera added successfully');
            await get().fetchCCTVs(); // Refresh the list
        } catch (error) {
            set({error: 'Failed to add camera', isLoading: false});
            toast.error('Failed to add camera. Please try again later.');
        }
    },

    editCamera: async (id: string, data: DtoUpdateCCTVDTO) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            await editCctv({group_id: selectedGroupMember.group_id, id}, data);
            set({isLoading: false});
            toast.success('Camera updated successfully');
            await get().fetchCameraDetails(id)
        } catch (error) {
            set({error: 'Failed to update camera', isLoading: false});
            toast.error('Failed to update camera. Please try again later.');
        }
    },

    fetchStreamUrls: async (id: string) => {
        set({isLoadingStreamUrls: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const response = await getStreamUrl({
                group_id: selectedGroupMember.group_id,
                id: id,
            });
            set({streamUrls: response, isLoadingStreamUrls: false});
        } catch (error) {
            set({error: 'Failed to fetch stream URLs', isLoadingStreamUrls: false});
            toast.error('Failed to fetch stream URLs. Please try again later.');
        }
    },

    addStreamUrl: async (cctvId: string, data: DtoCreateStreamURLDTO) => {
        set({isAddingStreamUrl: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            await addNewStreamUrl(
                {
                    group_id: selectedGroupMember.group_id,
                    id: cctvId
                },
                data
            );

            // Refresh stream URLs list
            await get().fetchStreamUrls(cctvId);

            set({isAddingStreamUrl: false});
            toast.success('Stream URL added successfully');
        } catch (error) {
            set({error: 'Failed to add stream URL', isAddingStreamUrl: false});
            toast.error('Failed to add stream URL. Please try again later.');
        }
    },

    deleteStreamUrl: async (cctvId: string, urlId: string) => {
        set({isDeletingStreamUrl: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            await deleteStreamUrl(
                {
                    group_id: selectedGroupMember.group_id,
                    id: cctvId,
                    urlId: urlId
                },
            );

            // Refresh stream URLs list
            await get().fetchStreamUrls(cctvId);

            set({isDeletingStreamUrl: false});
            toast.success('Stream URL deleted successfully');
        } catch (error) {
            set({error: 'Failed to delete stream URL', isDeletingStreamUrl: false});
            toast.error('Failed to delete stream URL. Please try again later.');
        }
    },

    getScheduleDetail: async (cctvId: string): Promise<void> => {
        set({isLoadingRecordingSchedule: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response = await getScheduleDetail({
                group_id: selectedGroupMember.group_id,
                id: cctvId
            })

            set({isLoadingRecordingSchedule: false, recordingSchedule: response});
        } catch (e) {
            set({error: 'Failed to get recording schedule', isLoadingRecordingSchedule: false});
            toast.error('Failed to get recording schedule. Please try again later.');
        }
    },

    updateSchedule: async (cctvId: string, schedule: number[], retentionDays: number): Promise<void> => {
        set({isUpdatingRecordingSchedule: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const response = await updateSchedule({
                group_id: selectedGroupMember.group_id,
                id: cctvId
            }, {
                enabled_hours: schedule,
                retention_days: retentionDays
            })
            set({isUpdatingRecordingSchedule: false, recordingSchedule: response});
            toast.success('Recording schedule updated successfully');
        } catch (e) {
            set({error: 'Failed to update recording schedule', isUpdatingRecordingSchedule: false});
            toast.error('Failed to update recording schedule. Please try again later.');
        }
    },

    controlPtzCamera: async (cctvId: string, direction: "up" | "down" | "left" | "right" | "zoomin" | "zoomout") => {
        set({isPtzSendingCommand: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const response = await sendPtz({
                group_id: selectedGroupMember.group_id,
            }, {
                cctv_id: cctvId,
                direction: direction
            })
            set({isPtzSendingCommand: false,});
            // Dispatch an event to notify that PTZ command completed
            const event = new CustomEvent('ptz-command-complete', {
                detail: { direction, success: true }
            });
            document.dispatchEvent(event);

            toast.success('PTZ Command sent, please wait a moment to see movement');
        } catch (e) {
            set({error: 'Failed to send PTZ Command to camera', isPtzSendingCommand: false});

            // Dispatch an event with failure
            const event = new CustomEvent('ptz-command-complete', {
                detail: { direction, success: false, error: e }
            });
            document.dispatchEvent(event);

            toast.error('Failed to send PTZ Command to camera. Please try again later.');

            toast.error('Failed to send PTZ Command to camera. Please try again later.');
            throw e;
        }
    },

    reset: () => {
        set({
            cctvs: [],
            isLoading: false,
            error: null,
            currentPage: 1,
            totalPages: 1,
            searchTerm: '',
            searchBy: 'name',
            sortBy: 'created_at',
            sortOrder: 'desc',
            activeTab: 'table',
            statusFilter: null,
            currentCameraDetails: null,
            connectionDetail: null,
            streamUrls: null,
            isLoadingStreamUrls: false,
            cameraSnapshotUrl: undefined,
            // Reset auto-refresh state
            isAutoRefreshEnabled: true,
            refreshInterval: 180000,
            lastRefreshTime: null,
            isAutoRefreshing: false,
        });
    },
}));
