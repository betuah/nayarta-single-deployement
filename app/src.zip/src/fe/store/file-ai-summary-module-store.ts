import { create } from 'zustand';
import { toast } from 'react-toastify';
import { useUserStore } from "@/store/user-store";
import {
    DtoCreateFileAISummaryRequest,
    AiSummaryDetailData,
    AiSummarySummaryDetailData,
    AiSummaryDetailParams
} from "@/lib/api/data-contracts";
import {
    getFileAiSummaryList,
    getFileAiSummaryDetail,
    createFileAiSummary
} from '@/actions/file-ai-summary-actions';

interface FileAiSummaryModuleState {
    // Data states
    fileAiSummaries: AiSummaryDetailData | null;
    currentFileAiSummary: AiSummarySummaryDetailData | null;

    // Loading states
    isLoading: boolean;
    isLoadingDetail: boolean;
    isCreating: boolean;

    // Error states
    error: string | null;
    detailError: string | null;
    createError: string | null;

    // Actions
    clearFileAiSummaries: () => void;
    clearErrors: () => void;

    // API actions
    fetchFileAiSummaries: (fileId: string) => Promise<void>;
    fetchFileAiSummaryDetail: (id: string) => Promise<void>;
    createFileAiSummary: (fileId: string, data: DtoCreateFileAISummaryRequest) => Promise<void>;
    fetchLatestCompletedSummary: (fileId: string) => Promise<void>;
}

export const useFileAiSummaryModuleStore = create<FileAiSummaryModuleState>((set, get) => ({
    // Initial data states
    fileAiSummaries: null,
    currentFileAiSummary: null,

    // Initial loading states
    isLoading: false,
    isLoadingDetail: false,
    isCreating: false,

    // Initial error states
    error: null,
    detailError: null,
    createError: null,

    clearFileAiSummaries: () => set({
        fileAiSummaries: null,
        currentFileAiSummary: null
    }),

    clearErrors: () => set({
        error: null,
        detailError: null,
        createError: null
    }),

    // API actions
    fetchFileAiSummaries: async (fileId: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ error: errorMsg });
            toast.error(errorMsg);
            return;
        }

        const params: AiSummaryDetailParams = {
            group_id: selectedGroupMember.group_id,
            fileId
        };

        set({ isLoading: true, error: null });
        try {
            const data = await getFileAiSummaryList(params);
            set({ fileAiSummaries: data });
        } catch (error) {
            const errorMsg = 'Failed to fetch file AI summaries';
            set({ error: errorMsg });
            toast.error(errorMsg);
        } finally {
            set({ isLoading: false });
        }
    },

    fetchFileAiSummaryDetail: async (id: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ detailError: errorMsg });
            toast.error(errorMsg);
            return;
        }

        set({ isLoadingDetail: true, detailError: null });
        try {
            const data = await getFileAiSummaryDetail({
                group_id: selectedGroupMember.group_id,
                id
            });
            set({ currentFileAiSummary: data });
        } catch (error) {
            const errorMsg = 'Failed to fetch file AI summary details';
            set({ detailError: errorMsg });
            toast.error(errorMsg);
            throw new Error(errorMsg);
        } finally {
            set({ isLoadingDetail: false });
        }
    },

    createFileAiSummary: async (fileId: string, data: DtoCreateFileAISummaryRequest) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ createError: errorMsg });
            toast.error(errorMsg);
            throw new Error(errorMsg);
        }

        set({ isCreating: true, createError: null });
        try {
            await createFileAiSummary({
                group_id: selectedGroupMember.group_id,
                fileId
            }, data);
            toast.success('File AI summary created successfully');
            await get().fetchFileAiSummaries(fileId);
        } catch (error) {
            const errorMsg = 'Failed to create file AI summary';
            set({ createError: errorMsg });
            toast.error(errorMsg);
            throw error;
        } finally {
            set({ isCreating: false });
        }
    },

    fetchLatestCompletedSummary: async (fileId: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            const errorMsg = 'No group selected';
            set({ error: errorMsg });
            toast.error(errorMsg);
            return;
        }

        const params: AiSummaryDetailParams = {
            group_id: selectedGroupMember.group_id,
            fileId
        };

        set({ isLoading: true, error: null });
        try {
            // First get the list of summaries
            const summariesList = await getFileAiSummaryList(params);
            set({ fileAiSummaries: summariesList });

            // Find the latest completed summary
            const completedSummaries = summariesList.filter(summary =>
                summary.status === 'completed'
            );

            if (completedSummaries.length === 0) {
                set({ currentFileAiSummary: null });
                return;
            }

            // Sort by created_at descending to get the latest
            const latestCompleted = completedSummaries.sort((a, b) => {
                const dateA = new Date(a.created_at || '').getTime();
                const dateB = new Date(b.created_at || '').getTime();
                return dateB - dateA;
            })[0];

            // Get the detailed summary
            if (latestCompleted.id) {
                const detailData = await getFileAiSummaryDetail({
                    group_id: selectedGroupMember.group_id,
                    id: latestCompleted.id
                });
                set({ currentFileAiSummary: detailData });
            }
        } catch (error) {
            const errorMsg = 'Failed to fetch latest completed summary';
            set({ error: errorMsg });
            toast.error(errorMsg);
        } finally {
            set({ isLoading: false });
        }
    }
}));
