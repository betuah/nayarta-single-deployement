import { create } from 'zustand';
import { toast } from 'react-toastify';
import { useUserStore } from "@/store/user-store";
import {
    DtoCreateFloorPlanRequest,
    DtoUpdateFloorPlanRequest,
    FloorPlansListData,
    DtoFloorPlanResponse,
    FloorPlansListParams
} from "@/lib/api/data-contracts";
import {
    getFloorPlanList,
    createFloorPlans,
    getFloorPlansDetail,
    updateFloorPlans,
    deleteFloorPlan
} from '@/actions/floor-plan-actions';

interface FloorPlanModuleState {
    // Data states
    floorPlans: FloorPlansListData | null;
    currentFloorPlan: DtoFloorPlanResponse | null;

    // Loading states
    isLoading: boolean;
    isLoadingDetail: boolean;
    isCreating: boolean;
    isUpdating: boolean;
    isDeleting: boolean;

    // Filter states
    search: string;
    locationId: string | null;
    offset: number;
    limit: number;

    // Actions
    setSearch: (search: string) => void;
    setLocationId: (locationId: string | null) => void;
    setOffset: (offset: number) => void;
    setLimit: (limit: number) => void;
    resetFilters: () => void;
    clearFloorPlans: () => void;

    // API actions
    fetchFloorPlans: () => Promise<void>;
    fetchFloorPlanDetail: (id: string) => Promise<void>;
    createFloorPlan: (data: DtoCreateFloorPlanRequest) => Promise<void>;
    updateFloorPlan: (id: string, data: DtoUpdateFloorPlanRequest) => Promise<void>;
    deleteFloorPlan: (id: string) => Promise<void>;
}

export const useFloorPlanModuleStore = create<FloorPlanModuleState>((set, get) => ({
    // Initial states
    floorPlans: null,
    currentFloorPlan: null,
    isLoading: false,
    isLoadingDetail: false,
    isCreating: false,
    isUpdating: false,
    isDeleting: false,
    search: '',
    locationId: null,
    offset: 0,
    limit: 10,

    // Filter setters
    setSearch: (search) => set({ search, offset: 0 }),
    setLocationId: (locationId) => set({ locationId, offset: 0 }),
    setOffset: (offset) => set({ offset }),
    setLimit: (limit) => set({ limit }),
    resetFilters: () => set({
        search: '',
        locationId: null,
        offset: 0,
        limit: 10
    }),

    // API actions
    fetchFloorPlans: async () => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        const { search, locationId, offset, limit } = get();
        const params: FloorPlansListParams = {
            group_id: selectedGroupMember.group_id,
            search: search || undefined,
            location_id: locationId || undefined,
            offset,
            limit
        };

        set({ isLoading: true });
        try {
            const data = await getFloorPlanList(params);
            set({ floorPlans: data });
        } catch (error) {
            toast.error('Failed to fetch floor plans');
        } finally {
            set({ isLoading: false });
        }
    },

    fetchFloorPlanDetail: async (id: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isLoadingDetail: true });
        try {
            const data = await getFloorPlansDetail({
                group_id: selectedGroupMember.group_id,
                id
            });
            set({ currentFloorPlan: data });
        } catch (error) {
            toast.error('Failed to fetch floor plan details');
            throw new Error("Failed to fetch floor plan details")
        } finally {
            set({ isLoadingDetail: false });
        }
    },

    createFloorPlan: async (data: DtoCreateFloorPlanRequest) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isCreating: true });
        try {
            await createFloorPlans({
                group_id: selectedGroupMember.group_id
            }, data);
            toast.success('Floor plan created successfully');
            await get().fetchFloorPlans();
        } catch (error) {
            toast.error('Failed to create floor plan');
        } finally {
            set({ isCreating: false });
        }
    },

    updateFloorPlan: async (id: string, data: DtoUpdateFloorPlanRequest) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isUpdating: true });
        try {
            await updateFloorPlans({
                group_id: selectedGroupMember.group_id,
                id
            }, data);
            toast.success('Floor plan updated successfully');
            await get().fetchFloorPlans();
            await get().fetchFloorPlanDetail(id);
        } catch (error) {
            toast.error('Failed to update floor plan');
        } finally {
            set({ isUpdating: false });
        }
    },

    clearFloorPlans: () => set({
        floorPlans: null,
        currentFloorPlan: null
    }),

    deleteFloorPlan: async (id: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        set({ isDeleting: true });
        try {
            await deleteFloorPlan({
                group_id: selectedGroupMember.group_id,
                id
            });
            toast.success('Floor plan deleted successfully');
            await get().fetchFloorPlans();
            set({ currentFloorPlan: null });
        } catch (error) {
            toast.error('Failed to delete floor plan');
        } finally {
            set({ isDeleting: false });
        }
    }
}));
