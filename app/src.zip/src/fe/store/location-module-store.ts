import create from 'zustand';
import {toast} from 'react-toastify';
import {useUserStore} from "@/store/user-store";
import {
    DtoLocationListItem,
    LocationsListParams,
    DtoLocationDetail,
    LocationsDetailParams,
    LocationsCreateParams,
    DtoCreateLocationDTO,
    LocationsUpdateParams,
    DtoUpdateLocationDTO
} from "@/lib/api/data-contracts";
import {
    deleteLocation,
    getAllLocation,
    getLocationDetails,
    createLocation,
    updateLocation
} from "@/actions/location-actions";

interface Suggestion {
    place_id: number;
    display_name: string;
    lat: string;
    lon: string;
}

interface LocationModuleState {
    locations: DtoLocationListItem[];
    totalLocations: number;
    currentPage: number;
    pageSize: number;
    searchQuery: string;
    sortBy: LocationsListParams["sort_by"];
    sortOrder: LocationsListParams["sort_order"];
    isLoading: boolean;
    currentLocationDetails: DtoLocationDetail | null;
    suggestions: Suggestion[];
    position: [number, number];
    locationName: string;
    isAutomatic: boolean;
    fetchLocations: () => Promise<void>;
    fetchLocationDetails: (locationId: string) => Promise<void>;
    deleteLocation: (locationId: string) => Promise<boolean>;
    createLocation: (data: DtoCreateLocationDTO) => Promise<DtoLocationDetail>;
    updateLocation: (locationId: string, data: DtoUpdateLocationDTO) => Promise<DtoLocationDetail>;
    handleSort: (field: LocationsListParams["sort_by"]) => void;
    handleSearch: (query: string) => void;
    handlePageChange: (page: number) => void;
    handleLocationNameChange: (value: string) => void;
    handleSuggestionSelect: (suggestion: Suggestion) => void;
    handleMarkerDrag: (lat: number, lng: number) => void;
    setAutomatic: (isAutomatic: boolean) => void;
    updateLocationName: (lat: number, lng: number) => Promise<string>;
    fetchSuggestions: (value: string) => Promise<void>;
    reset: () => void
}

export const useLocationModuleStore = create<LocationModuleState>((set, get) => ({
    locations: [],
    totalLocations: 0,
    currentPage: 1,
    pageSize: 10,
    searchQuery: "",
    sortBy: "created_at",
    sortOrder: "desc",
    isLoading: false,
    currentLocationDetails: null,
    suggestions: [],
    position: [51.505, -0.09],
    locationName: "",
    isAutomatic: true,

    reset: () => {
        set({
            locations: [],
            totalLocations: 0,
            currentPage: 1,
            pageSize: 10,
            searchQuery: "",
            sortBy: "created_at",
            sortOrder: "desc",
            isLoading: false,
            currentLocationDetails: null,
            suggestions: [],
            position: [51.505, -0.09],
            locationName: "",
            isAutomatic: true,
        })
    },

    fetchLocations: async () => {
        const {currentPage, pageSize, searchQuery, sortBy, sortOrder} = get();
        const {selectedGroupMember} = useUserStore.getState();
        set({isLoading: true});
        try {
            if (!selectedGroupMember) {
                console.error("No group selected");
                return;
            }
            const params: LocationsListParams = {
                group_id: selectedGroupMember.group_id,
                page: currentPage,
                size: pageSize,
                search: searchQuery,
                sort_by: sortBy,
                sort_order: sortOrder,
            };

            const response = await getAllLocation(params);
            set({locations: response.locations || [], totalLocations: response.total || 0});
        } catch (error) {
            console.error("Error fetching locations:", error);
            toast.error("Failed getting locations, please try again later");
        } finally {
            set({isLoading: false});
        }
    },

    fetchLocationDetails: async (locationId: string) => {
        const {selectedGroupMember} = useUserStore.getState();
        set({isLoading: true});
        try {
            if (!selectedGroupMember) {
                console.error("No group selected");
                return;
            }
            const params = {
                group_id: selectedGroupMember.group_id,
                id: locationId,
            };

            const response = await getLocationDetails(params);
            set({
                currentLocationDetails: response,
                locationName: response.address || "",
                position: [response.latitude || 51.505, response.longitude || -0.09]
            });
        } catch (error) {
            console.error("Error fetching location details:", error);
            toast.error("Failed getting location details, please try again later");
        } finally {
            set({isLoading: false});
        }
    },

    deleteLocation: async (locationId: string) => {
        const {selectedGroupMember} = useUserStore.getState();
        set({isLoading: true});
        try {
            if (!selectedGroupMember) {
                console.error("No group selected");
                return false;
            }
            const params: LocationsDetailParams = {
                group_id: selectedGroupMember.group_id,
                id: locationId,
            };

            await deleteLocation(params);
            toast.success("Location deleted successfully");
            set(state => ({
                locations: state.locations.filter(loc => loc.id !== locationId),
                totalLocations: state.totalLocations - 1,
            }));
            return true;
        } catch (error) {
            console.error("Error deleting location:", error);
            toast.error("Failed to delete location, please try again later");
            return false;
        } finally {
            set({isLoading: false});
        }
    },

    createLocation: async (data: DtoCreateLocationDTO) => {
        const {selectedGroupMember} = useUserStore.getState();
        set({isLoading: true});
        try {
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: LocationsCreateParams = {
                group_id: selectedGroupMember.group_id
            };
            const response = await createLocation(params, data);
            toast.success("Location created successfully");
            set(state => ({
                locations: [...state.locations, response],
                totalLocations: state.totalLocations + 1,
            }));
            return response;
        } catch (error) {
            console.error("Error creating location:", error);
            toast.error("Failed to create location, please try again later");
            throw error;
        } finally {
            set({isLoading: false});
        }
    },

    updateLocation: async (locationId: string, data: DtoUpdateLocationDTO) => {
        const {selectedGroupMember} = useUserStore.getState();
        set({isLoading: true});
        try {
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: LocationsUpdateParams = {
                group_id: selectedGroupMember.group_id,
                id: locationId
            };
            const response = await updateLocation(params, data);
            toast.success("Location updated successfully");
            set(state => ({
                locations: state.locations.map(loc => loc.id === locationId ? response : loc),
            }));
            return response;
        } catch (error) {
            console.error("Error updating location:", error);
            toast.error("Failed to update location, please try again later");
            throw error;
        } finally {
            set({isLoading: false});
        }
    },

    handleSort: (field) => {
        const {sortBy, sortOrder} = get();
        if (field === sortBy) {
            set({sortOrder: sortOrder === "asc" ? "desc" : "asc"});
        } else {
            set({sortBy: field, sortOrder: "asc"});
        }
        get().fetchLocations();
    },

    handleSearch: (query) => {
        set({searchQuery: query, currentPage: 1});
        get().fetchLocations();
    },

    handlePageChange: (page) => {
        set({currentPage: page});
        get().fetchLocations();
    },

    handleLocationNameChange: (value) => {
        set({locationName: value});
        if (value.length <= 2) {
            set({suggestions: []});
        } else {
            get().fetchSuggestions(value);
        }
    },

    handleSuggestionSelect: (suggestion) => {
        set({
            locationName: suggestion.display_name,
            position: [parseFloat(suggestion.lat), parseFloat(suggestion.lon)],
            suggestions: []
        });
    },

    handleMarkerDrag: (lat, lng) => {
        set({position: [lat, lng]});
        if (get().isAutomatic) {
            get().updateLocationName(lat, lng);
        }
    },

    setAutomatic: (isAutomatic) => {
        set({isAutomatic});
    },

    updateLocationName: async (lat, lng) => {
        set({isLoading: true});
        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
            const data = await response.json();
            set({locationName: data.display_name});
            return data.display_name
        } catch (error) {
            console.error('Error fetching location name:', error);
        }finally {
            set({isLoading: false});
        }
    },

    fetchSuggestions: async (value) => {
        if (value.length > 2) {
            set({isLoading: true});
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${value}`);
                const data: Suggestion[] = await response.json();
                set({suggestions: data});
            } catch (error) {
                console.error('Error fetching suggestions:', error);
            } finally {
                set({isLoading: false});
            }
        }
    }
}));
