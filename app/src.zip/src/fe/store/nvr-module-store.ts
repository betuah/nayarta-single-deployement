import {create} from 'zustand';
import {toast} from 'react-toastify';
import {
    DtoCreateNVRDTO,
    DtoListNVRsResponse,
    DtoNVRDetail,
    DtoNVRListItem, DtoUpdateNVRDTO, NvrsCreateParams, NvrsDeleteParams,
    NvrsDetailParams,
    NvrsListParams, NvrsUpdateParams
} from "@/lib/api/data-contracts";
import {
    addNvr,
    checkNVRUsername,
    deleteNVR,
    getAllNvr,
    getNvrDetail,
    getNvrToken,
    updateNvr
} from "@/actions/nvr-actions";
import {useUserStore} from "@/store/user-store";

interface NVRModuleState {
    nvrs: DtoNVRListItem[];
    isLoading: boolean;
    isLoadingToken: boolean;
    error: string | null;
    currentPage: number;
    totalPages: number;
    searchTerm: string;
    sortBy: NvrsListParams['sort_by'];
    sortOrder: NvrsListParams['sort_order'];
    activeTab: 'table' | 'card';
    locationFilter: string[];
    statusFilter: ('online' | 'offline')[];
    fetchNVRs: (params?: Partial<NvrsListParams>) => Promise<void>;
    setSearchTerm: (term: string) => void;
    setActiveTab: (tab: 'table' | 'card') => void;
    handleSort: (newSortBy: NvrsListParams['sort_by']) => void;
    setLocationFilter: (locations: string[]) => void;
    setStatusFilter: (statuses: ('online' | 'offline')[]) => void;
    nvrDetail: DtoNVRDetail | null;
    fetchNVRDetail: (id: string) => Promise<void>;
    formData: NVRFormState;
    resetForm: () => void;
    addNVR: (data: DtoCreateNVRDTO) => Promise<void>;
    getNvrToken: (id: string) => Promise<string|undefined>;
    updateNVR: (id: string, data: DtoUpdateNVRDTO) => Promise<void>;
    deleteNVR: (id: string) => Promise<void>;
    reset: () => void
    setFormData: (data: Partial<NVRFormState>) => void;
    isLoadingCheckUserName: boolean
    isUsernameExist: (userName: string) => Promise<boolean>
}

interface NVRFormState {
    name: string;
    hostname: string;
    port: number;
    user_name: string;
    password: string;
    location_id: string;
    check_interval: number;
    description: string;
}

const initialFormState: NVRFormState = {
    name: '',
    hostname: '',
    port: 0,
    user_name: '',
    password: '',
    location_id: '',
    check_interval: 15,
    description: '',
};

export const useNVRModuleStore = create<NVRModuleState>((set, get) => ({
    nvrs: [],
    isLoading: false,
    isLoadingToken: false,
    error: null,
    currentPage: 1,
    totalPages: 1,
    searchTerm: '',
    sortBy: 'created_at',
    sortOrder: 'desc',
    activeTab: 'table',
    locationFilter: [],
    statusFilter: [],
    nvrDetail: null,
    formData: initialFormState,
    isLoadingCheckUserName: false,
    setFormData: (data: Partial<NVRFormState>) =>
        set((state) => ({formData: {...state.formData, ...data}})),

    resetForm: () => set({formData: initialFormState, nvrDetail: null}),

    reset: () => {
        set({
            nvrs: [],
            isLoading: false,
            error: null,
            currentPage: 1,
            totalPages: 1,
            searchTerm: '',
            sortBy: 'created_at',
            sortOrder: 'desc',
            activeTab: 'table',
            locationFilter: [],
            statusFilter: [],
            nvrDetail: null,
        })
    },

    getNvrToken: async (id: string) => {
        set({isLoadingToken: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                console.error("No group selected");
                return;
            }
            const response = await getNvrToken({
                group_id: selectedGroupMember.group_id, id: id
            })
            return response.token!
        } catch (e) {
            set({error: 'Failed to fetch NVR token'});
            toast.error('Failed to fetch NVR token. Please try again later.');
            throw e
        }finally {
            set({isLoadingToken: false});
        }
    },

    fetchNVRs: async (params?: Partial<NvrsListParams>) => {
        const {currentPage, searchTerm, sortBy, sortOrder, locationFilter, statusFilter} = get();
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                console.error("No group selected");
                return;
            }
            const response: DtoListNVRsResponse = await getAllNvr({
                group_id: selectedGroupMember.group_id,
                page: params?.page ?? currentPage,
                size: 10,
                search: params?.search ?? searchTerm,
                sort_by: params?.sort_by ?? sortBy,
                sort_order: params?.sort_order ?? sortOrder,
                location_id: locationFilter.length > 0 ? locationFilter.join(',') : undefined,
                status: statusFilter.length > 0 ? statusFilter.join(',') as 'online' | 'offline' : undefined,
                ...params,
            });
            set({
                nvrs: response.nvrs || [],
                currentPage: response.page || 1,
                totalPages: response.total ? Math.ceil(response.total / (response.size || 10)) : 1,
                isLoading: false,
            });
        } catch (error) {
            set({error: 'Failed to fetch NVRs', isLoading: false});
            toast.error('Failed to fetch NVRs. Please try again later.');
        }
    },

    setSearchTerm: (term: string) => set({searchTerm: term}),

    setActiveTab: (tab: 'table' | 'card') => set({activeTab: tab}),

    handleSort: (newSortBy: NvrsListParams['sort_by']) => {
        const {sortBy, sortOrder} = get();
        if (newSortBy === sortBy) {
            set({sortOrder: sortOrder === 'asc' ? 'desc' : 'asc'});
        } else {
            set({sortBy: newSortBy, sortOrder: 'asc'});
        }
        get().fetchNVRs();
    },

    setLocationFilter: (locations: string[]) => set({locationFilter: locations, currentPage: 1}),

    setStatusFilter: (statuses: ('online' | 'offline')[]) => {
        if (statuses.length === 2) {
            set({statusFilter: [], currentPage: 1})
            return
        }
        set({statusFilter: statuses, currentPage: 1})
    },

    isUsernameExist: async (userName: string): Promise<boolean> => {
        set({isLoadingCheckUserName: true});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params = {
                group_id: selectedGroupMember.group_id,
                username: userName
            };
            const response = await checkNVRUsername(params);
            set({isLoadingCheckUserName: false});
            return response.exists!
        } catch (error) {
            set({error: 'Failed to fetch NVR details', isLoading: false});
            toast.error('Failed to fetch NVR details. Please try again later.');
            return true
        }
    },
    fetchNVRDetail: async (id: string) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: NvrsDetailParams = {
                group_id: selectedGroupMember.group_id,
                id: id
            };
            const response = await getNvrDetail(params);
            set({nvrDetail: response, isLoading: false});
        } catch (error) {
            set({error: 'Failed to fetch NVR details', isLoading: false});
            toast.error('Failed to fetch NVR details. Please try again later.');
        }
    },

    deleteNVR: async (id: string) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: NvrsDeleteParams = {
                group_id: selectedGroupMember.group_id,
                id: id
            };
            await deleteNVR(params);
            set({isLoading: false});
            toast.success('NVR deleted successfully');
        } catch (error) {
            set({error: 'Failed to delete NVR', isLoading: false});
            toast.error('Failed to delete NVR. Please try again later.');
        }
    },

    addNVR: async (data: DtoCreateNVRDTO) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: NvrsCreateParams = {
                group_id: selectedGroupMember.group_id
            };
            await addNvr(params, data);
            set({isLoading: false});
            toast.success('NVR added successfully');
            get().resetForm();
        } catch (error) {
            set({error: 'Failed to add NVR', isLoading: false});
            toast.error('Failed to add NVR. Please try again later.');
        }
    },

    updateNVR: async (id: string, data: DtoUpdateNVRDTO) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: NvrsUpdateParams = {
                group_id: selectedGroupMember.group_id,
                id: id
            };
            await updateNvr(params, data);
            set({isLoading: false});
            toast.success('NVR updated successfully');
            get().resetForm();
        } catch (error) {
            set({error: 'Failed to update NVR', isLoading: false});
            toast.error('Failed to update NVR. Please try again later.');
        }
    },


}));
