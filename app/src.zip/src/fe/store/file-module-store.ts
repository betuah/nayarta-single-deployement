import {create} from 'zustand';
import {toast} from 'react-toastify';
import {
    FilesListParams,
    FilesListData,
    DtoFileListItem,
    DtoFileDetail,
    WithLocationListData,
    DtoFileListItemWithLocation,
    WithLocationListParams,
    DtoFileDetailAdvanced,
    BatchDeleteRecordingDeleteData,
    RecordingPlaybackListData,
    RecordingStorageBreakdownListData,
    BulkDeleteSummaryCreateData,
    BulkDeleteByRangeDeleteData,
    DtoBulkDeleteSummaryRequest,
    DtoBulkDeleteFilesRequest, RecordingPlaybackMultiListData
} from '@/lib/api/data-contracts';
import {
    BatchDeleteRecordings,
    deleteFile,
    generateDownloadUrl,
    getFileAndAnalyticById,
    getFileById,
    getFileList,
    getFileListWithLocation,
    recordingPlaybackList,
    getRecordingBreakdown,
    bulkDeleteSummary,
    bulkDelete, recordingPlaybackListMulti
} from '@/actions/file-actions';
import {useUserStore} from '@/store/user-store';

interface FileModuleState {
    files: DtoFileListItem[];
    filesWithLocation: DtoFileListItemWithLocation[];
    fileDetailWithAnalytic: DtoFileDetailAdvanced | null;
    currentFileUrl: string | null;
    currentFile: DtoFileDetail | null;
    selectedLocationId: string | null;
    selectedFloorId: string | null;
    isLoading: boolean;
    isLoadingDetailAndAnalytic: boolean;
    isUrlLoading: boolean;
    error: string | null;
    currentPage: number;
    totalPages: number;
    hasMore: boolean;
    searchTerm: string;
    sortBy: FilesListParams['sort_by'];
    sortOrder: FilesListParams['sort_order'];
    fileTypeFilter: FilesListParams['file_type'] | null;
    startDate: string | null;
    endDate: string | null;
    fetchFiles: (params?: Partial<FilesListParams>, append?: boolean) => Promise<void>;
    fetchFilesWithLocation: (params?: Partial<WithLocationListParams>, append?: boolean) => Promise<void>;
    fetchCurrentFile: (id: string) => Promise<void>;
    fetchFileDetailAndAnalytic: (id: string) => Promise<void>;
    setSearchTerm: (term: string) => void;
    handleSort: (newSortBy: FilesListParams['sort_by']) => void;
    setFileTypeFilter: (fileType: FilesListParams['file_type'] | null) => void;
    setDateRange: (start: string | null, end: string | null) => void;
    clearFiles: () => void;
    deleteFile: (id: string) => Promise<void>;
    generateDownloadUrlFile: (rawUrl: string, provider: string) => Promise<string|undefined>;
    reset: () => void;
    isBatchingDeleteLoading: boolean;
    deleteBatchRecording: (date: string, cctvId: string) => Promise<BatchDeleteRecordingDeleteData|null>
    // playlist
    isLoadingPlaybackList: boolean;
    loadPlaybackList: (cctvId: string, startTime: string, endTime: string) => Promise<void>
    currentPlaybackList: null | RecordingPlaybackListData;
    // multi playlist
    isLoadingPlaybackListMulti: boolean;
    loadPlaybackListMulti: (videoWallId: string, startTime: string, endTime: string) => Promise<void>
    currentPlaybackListMulti: null | RecordingPlaybackMultiListData;
    // recording breakdown
    isLoadingRecordingBreakdown: boolean;
    recordingBreakdown: RecordingStorageBreakdownListData | null;
    fetchRecordingBreakdown: () => Promise<void>;
    // bulk delete summary
    isLoadingBulkDeleteSummary: boolean;
    bulkDeleteSummaryData: BulkDeleteSummaryCreateData | null;
    fetchBulkDeleteSummary: (cctvIds: string[], startDate: string, endDate: string) => Promise<void>;
    // bulk delete
    isLoadingBulkDelete: boolean;
    bulkDeleteData: BulkDeleteByRangeDeleteData | null;
    executeBulkDelete: (cctvIds: string[], startDate: string, endDate: string) => Promise<BulkDeleteByRangeDeleteData | null>;
}

export const useFileModuleStore = create<FileModuleState>((set, get) => ({
    files: [],
    filesWithLocation: [],
    fileDetailWithAnalytic: null,
    currentFile: null,
    currentFileUrl: null,
    isUrlLoading: false,
    isLoading: false,
    isLoadingDetailAndAnalytic: false,
    error: null,
    currentPage: 1,
    totalPages: 1,
    hasMore: true,
    searchTerm: '',
    sortBy: 'created_at',
    sortOrder: 'desc',
    fileTypeFilter: null,
    startDate: null,
    endDate: null,
    selectedLocationId: null,
    selectedFloorId: null,
    isBatchingDeleteLoading: false,
    isLoadingPlaybackList: false,
    currentPlaybackList: null,
    isLoadingPlaybackListMulti: false,
    currentPlaybackListMulti: null,
    isLoadingRecordingBreakdown: false,
    recordingBreakdown: null,
    isLoadingBulkDeleteSummary: false,
    bulkDeleteSummaryData: null,
    isLoadingBulkDelete: false,
    bulkDeleteData: null,

    fetchFiles: async (params?: Partial<FilesListParams>, append: boolean = false) => {
        const {currentPage, searchTerm, sortBy, sortOrder, fileTypeFilter, startDate, endDate, files} = get();
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const response: FilesListData = await getFileList({
                group_id: selectedGroupMember.group_id,
                page: append ? currentPage + 1 : 1,
                size: 10,
                search: params?.search ?? searchTerm,
                sort_by: params?.sort_by ?? sortBy,
                sort_order: params?.sort_order ?? sortOrder,
                file_type: params?.file_type ?? fileTypeFilter ?? undefined,
                start_date: params?.start_date ?? startDate ?? undefined,
                end_date: params?.end_date ?? endDate ?? undefined,
                ...params,
            });
            set({
                files: append ? [...files, ...(response.files || [])] : (response.files || []),
                currentPage: response.page || 1,
                totalPages: response.total ? Math.ceil(response.total / (response.size || 10)) : 1,
                hasMore: (response.page || 1) < (response.total ? Math.ceil(response.total / (response.size || 10)) : 1),
                isLoading: false,
            });
        } catch (error) {
            set({error: 'Failed to fetch files', isLoading: false});
            toast.error('Failed to fetch files. Please try again later.');
        }
    },

    fetchFilesWithLocation: async (params?: Partial<WithLocationListParams>, append: boolean = false) => {
        const {currentPage, searchTerm, sortBy, sortOrder, fileTypeFilter, startDate, endDate, files} = get();
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const response: WithLocationListData = await getFileListWithLocation({
                group_id: selectedGroupMember.group_id,
                page: append ? currentPage + 1 : 1,
                size: 10,
                search: params?.search ?? searchTerm,
                sort_by: params?.sort_by ?? sortBy,
                sort_order: params?.sort_order ?? sortOrder,
                file_type: params?.file_type ?? fileTypeFilter ?? undefined,
                start_date: params?.start_date ?? startDate ?? undefined,
                end_date: params?.end_date ?? endDate ?? undefined,
                ...params,
            });
            set({
                filesWithLocation: append ? [...files, ...(response.files || [])] : (response.files || []),
                currentPage: response.page || 1,
                totalPages: response.total ? Math.ceil(response.total / (response.size || 10)) : 1,
                hasMore: (response.page || 1) < (response.total ? Math.ceil(response.total / (response.size || 10)) : 1),
                isLoading: false,
            });
        } catch (error) {
            set({error: 'Failed to fetch files', isLoading: false});
            toast.error('Failed to fetch files. Please try again later.');
        }
    },

    fetchCurrentFile: async (id: string) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const data = await getFileById({
                group_id: selectedGroupMember.group_id,
                id: id
            })
            set({
                isLoading: false,
                currentFile: data,
                error: null
            })
        } catch (e) {
            set({error: 'Failed to fetch file', isLoading: false});
            toast.error('Failed to fetch file. Please try again later.');
        }
    },

    fetchFileDetailAndAnalytic: async (id: string) =>  {
        set({isLoadingDetailAndAnalytic: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const data = await getFileAndAnalyticById({
                group_id: selectedGroupMember.group_id,
                id: id
            })
            set({
                isLoadingDetailAndAnalytic: false,
                fileDetailWithAnalytic: data,
                error: null
            })
        } catch (e) {
            set({error: 'Failed to fetch file', isLoadingDetailAndAnalytic: false});
            toast.error('Failed to fetch file. Please try again later.');
        }
    },

    setSearchTerm: (term: string) => set({searchTerm: term}),

    handleSort: (newSortBy: FilesListParams['sort_by']) => {
        const {sortBy, sortOrder} = get();
        if (newSortBy === sortBy) {
            set({sortOrder: sortOrder === 'asc' ? 'desc' : 'asc'});
        } else {
            set({sortBy: newSortBy, sortOrder: 'asc'});
        }
        get().fetchFiles({}, false);
    },

    setFileTypeFilter: (fileType: FilesListParams['file_type'] | null) => {
        set({fileTypeFilter: fileType, currentPage: 1});
        get().fetchFiles({}, false);
    },

    setDateRange: (start: string | null, end: string | null) => {
        set({startDate: start, endDate: end, currentPage: 1});
        get().fetchFiles({}, false);
    },

    clearFiles: () => set({files: [], currentPage: 1, hasMore: true}),

    generateDownloadUrlFile: async (rawUrl: string, provider: string) => {
        set({isUrlLoading: true, error: null, currentFileUrl: null});
        try {
            const generatedUrl = await generateDownloadUrl(rawUrl, provider)
            set({isUrlLoading: false, error: null, currentFileUrl: generatedUrl})
            return generatedUrl
        } catch (e) {
            set({isUrlLoading: true, error: "failed to get download url, please try again later"});
            toast.error("failed to get download url, please try again later")
        }
    },

    deleteBatchRecording: async (date: string, cctvId: string): Promise<BatchDeleteRecordingDeleteData|null> => {
        set({isBatchingDeleteLoading: true});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const resp = await BatchDeleteRecordings({
                cctv_id: cctvId,
                date: date, group_id: selectedGroupMember.group_id
            })
            set({isBatchingDeleteLoading: false});
            return resp
        } catch (e) {
            set({error: 'Failed to delete recordings', isBatchingDeleteLoading: false});
            toast.error('Failed to delete recordings. Please try again later.');
            return null
        }
    },

    loadPlaybackList: async (cctvId: string, startTime: string, endTime: string) : Promise<void> => {
        set({isLoadingPlaybackList: true});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const resp = await recordingPlaybackList({
                end_time: endTime, group_id: selectedGroupMember.group_id, start_time: startTime,
                cctv_id: cctvId

            })
            set({isLoadingPlaybackList: false, currentPlaybackList: resp});

        } catch (e) {
            set({error: 'Failed to load playlist', isLoadingPlaybackList: false});
            toast.error('Failed to load playlist. Please try again later.');
        }
    },

    loadPlaybackListMulti: async (videoWallId: string, startTime: string, endTime: string) : Promise<void> => {
        set({isLoadingPlaybackListMulti: true});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const resp = await recordingPlaybackListMulti({
                end_time: endTime, group_id: selectedGroupMember.group_id, start_time: startTime,
                video_wall_id: videoWallId

            })
            console.log("resp from api: ", resp)
            set({isLoadingPlaybackListMulti: false, currentPlaybackListMulti: resp});

        } catch (e) {
            set({error: 'Failed to load playlist', isLoadingPlaybackListMulti: false});
            toast.error('Failed to load playlist. Please try again later.');
        }
    },

    deleteFile: async (id: string) => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            await deleteFile({
                group_id: selectedGroupMember.group_id,
                id: id
            })
            set({isLoading: false, error: null})
            toast.success("File deleted")
        } catch (e) {
            set({
                isLoading: false,
                error: "delete file failed, file maybe can not be deleted because it is used by another constrains or please try again later"
            });
            toast.error('Failed to delete file, file maybe can not be deleted because it is used by another constrains or please try again later');
        }
    },

    fetchRecordingBreakdown: async () => {
        set({isLoadingRecordingBreakdown: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const data = await getRecordingBreakdown({
                group_id: selectedGroupMember.group_id
            });
            set({
                isLoadingRecordingBreakdown: false,
                recordingBreakdown: data,
                error: null
            });
        } catch (e) {
            set({error: 'Failed to fetch recording breakdown', isLoadingRecordingBreakdown: false});
            toast.error('Failed to fetch recording breakdown. Please try again later.');
        }
    },

    fetchBulkDeleteSummary: async (cctvIds: string[], startDate: string, endDate: string) => {
        set({isLoadingBulkDeleteSummary: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const requestData: DtoBulkDeleteSummaryRequest = {
                cctv_ids: cctvIds,
                start_date: startDate,
                end_date: endDate
            };
            const data = await bulkDeleteSummary(
                { group_id: selectedGroupMember.group_id },
                requestData
            );
            set({
                isLoadingBulkDeleteSummary: false,
                bulkDeleteSummaryData: data,
                error: null
            });
        } catch (e) {
            set({error: 'Failed to fetch bulk delete summary', isLoadingBulkDeleteSummary: false});
            toast.error('Failed to fetch bulk delete summary. Please try again later.');
        }
    },

    executeBulkDelete: async (cctvIds: string[], startDate: string, endDate: string): Promise<BulkDeleteByRangeDeleteData | null> => {
        set({isLoadingBulkDelete: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const requestData: DtoBulkDeleteFilesRequest = {
                cctv_ids: cctvIds,
                start_date: startDate,
                end_date: endDate
            };
            const data = await bulkDelete(
                { group_id: selectedGroupMember.group_id },
                requestData
            );
            set({
                isLoadingBulkDelete: false,
                bulkDeleteData: data,
                error: null
            });
            toast.success('Bulk delete completed successfully');
            return data;
        } catch (e) {
            set({error: 'Failed to execute bulk delete', isLoadingBulkDelete: false});
            toast.error('Failed to execute bulk delete. Please try again later.');
            return null;
        }
    },

    reset: () => {
        set({
            files: [],
            isLoading: false,
            error: null,
            currentPage: 1,
            totalPages: 1,
            hasMore: true,
            searchTerm: '',
            sortBy: 'created_at',
            sortOrder: 'desc',
            fileTypeFilter: null,
            startDate: null,
            endDate: null,
            // Reset new state
            isLoadingRecordingBreakdown: false,
            recordingBreakdown: null,
            isLoadingBulkDeleteSummary: false,
            bulkDeleteSummaryData: null,
            isLoadingBulkDelete: false,
            bulkDeleteData: null,
        });
    },
}));
