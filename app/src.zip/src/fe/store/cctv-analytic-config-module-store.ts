import { create } from 'zustand';
import { toast } from 'react-toastify';
import { useUserStore } from "@/store/user-store";
import {
    ConfigDetailData,
    DtoUpdateCCTVAnalyticConfigRequest,
    ConfigDetailParams,
    ConfigUpdateParams,
    ConfigResetCreateParams,
} from "@/lib/api/data-contracts";
import {
    getConfig,
    updateConfig,
    resetConfig,
} from '@/actions/cctv-analytic-config-actions';

interface CCTVAnalyticConfigModuleState {
    // Data states
    configDetail: ConfigDetailData | null;

    // Loading states
    isLoading: boolean;
    isUpdating: boolean;
    isResetting: boolean;
    lastErrorMessage: string | null

    // Actions
    fetchConfigDetail: (id: string) => Promise<void>;
    updateConfigDetail: (id: string, data: DtoUpdateCCTVAnalyticConfigRequest) => Promise<void>;
    resetConfigDetail: (id: string) => Promise<void>;
    reset: () => void
}

export const useCCTVAnalyticConfigModuleStore = create<CCTVAnalyticConfigModuleState>((set, get) => ({
    // Initial states
    configDetail: null,
    isLoading: false,
    isUpdating: false,
    isResetting: false,

    lastErrorMessage: null,

    reset: () => {
        set({configDetail: null})
    },

    // API actions
    fetchConfigDetail: async (id: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            set({lastErrorMessage: "No group selected"})
            toast.error('No group selected');
            return;
        }

        const params: ConfigDetailParams = {
            group_id: selectedGroupMember.group_id,
            id
        };

        set({ isLoading: true });
        try {
            const data = await getConfig(params);
            set({ configDetail: data });
        } catch (error) {
            set({lastErrorMessage: "Failed to fetch CCTV analytic config"})
            toast.error('Failed to fetch CCTV analytic config');
        } finally {
            set({ isLoading: false });
        }
    },

    updateConfigDetail: async (id: string, data: DtoUpdateCCTVAnalyticConfigRequest) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        const params: ConfigUpdateParams = {
            group_id: selectedGroupMember.group_id,
            id
        };

        set({ isUpdating: true });
        try {
            const response = await updateConfig(params, data);
            set({ configDetail: response });
            toast.success('CCTV analytic config updated successfully');
        } catch (error) {
            set({lastErrorMessage: "Failed to update CCTV analytic config"})
            toast.error('Failed to update CCTV analytic config');
        } finally {
            set({ isUpdating: false });
        }
    },

    resetConfigDetail: async (id: string) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return;
        }

        const params: ConfigResetCreateParams = {
            group_id: selectedGroupMember.group_id,
            id
        };

        set({ isResetting: true });
        try {
            const response = await resetConfig(params);
            set({ configDetail: response });
            set({lastErrorMessage: "CCTV analytic config reset successfully"})
            toast.success('CCTV analytic config reset successfully');
        } catch (error) {
            toast.error('Failed to reset CCTV analytic config');
        } finally {
            set({ isResetting: false });
        }
    },
}));
