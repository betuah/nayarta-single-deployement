import { create } from 'zustand';
import { toast } from 'react-toastify';
import { useUserStore } from '@/store/user-store';
import {CctvAnalyticsUpdateParams, DtoUpdateCCTVAnalyticDTO, PostCctvAnalyticsParams} from "@/lib/api/data-contracts";
import {syncAnalyticsType, updateAnalytics} from "@/actions/cctv-analytic-actions";

interface CCTVAnalyticsModuleState {
    isUpdating: boolean;
    isSyncing: boolean;
    error: string | null;
    updateAnalytic: (cctvId: string, analyticId: string, enable: boolean) => Promise<void>;
    syncAnalytics: (cctvId: string) => Promise<void>;
}

export const useCCTVAnalyticsModuleStore = create<CCTVAnalyticsModuleState>((set) => ({
    isUpdating: false,
    error: null,
    isSyncing: false,

    updateAnalytic: async (cctvId: string, analyticId: string, enable: boolean) => {
        set({ isUpdating: true, error: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const query: CctvAnalyticsUpdateParams = {
                group_id: selectedGroupMember.group_id,
                id: analyticId
            };

            const data: DtoUpdateCCTVAnalyticDTO = {
                enable: enable
            };

            await updateAnalytics(query, data);
            set({ isUpdating: false });
            toast.success(`Analytic ${enable ? 'enabled' : 'disabled'} successfully`);
        } catch (error) {
            set({ error: 'Failed to update analytic', isUpdating: false });
            toast.error('Failed to update analytic. Please try again later.');
        }
    },

    syncAnalytics: async (cctvId: string) => {
        set({ isSyncing: true, error: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const query: PostCctvAnalyticsParams = {
                group_id: selectedGroupMember.group_id,
                cctvId: cctvId
            };

            await syncAnalyticsType(query);
            set({ isSyncing: false });
            toast.success('Analytics synced successfully');
        } catch (error) {
            set({ error: 'Failed to sync analytics', isSyncing: false });
            toast.error('Failed to sync analytics. Please try again later.');
        }
    },
}));
