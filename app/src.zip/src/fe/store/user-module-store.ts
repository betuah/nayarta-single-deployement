import create from 'zustand';
import {getAllMembers, updateMember, deleteMember, createMember, registerNewUser} from "@/actions/member-action";
import {toast} from 'react-toastify';
import {
    DtoMemberListItem,
    MembersListParams,
    DtoUpdateMemberDTO,
    DtoCreateMemberDTO,
    DtoRegisterRequest
} from "@/lib/api/data-contracts";
import {useUserStore} from "@/store/user-store";


interface UserModuleState {
    members: DtoMemberListItem[];
    totalMembers: number;
    currentPage: number;
    pageSize: number;
    searchQuery: string;
    sortBy: MembersListParams["sort_by"];
    sortOrder: MembersListParams["sort_order"];
    selectedRole: MembersListParams["role"] | "";
    selectedStatus: MembersListParams["status"] | "";
    isLoading: boolean;
    editingMember: DtoMemberListItem | null;
    fetchMembers: () => Promise<void>;
    handleSort: (field: MembersListParams["sort_by"]) => void;
    handleSearch: (query: string) => void;
    handleRoleFilter: (role: MembersListParams["role"] | "") => void;
    handleStatusFilter: (status: MembersListParams["status"] | "") => void;
    handlePageChange: (page: number) => void;
    handleEditMember: (member: DtoMemberListItem) => void;
    handleUpdateMember: () => Promise<void>;
    handleDeleteMember: (memberId: string) => Promise<void>;
    setEditingMember: (member: DtoMemberListItem | null) => void;
    createUserMode: 'existing' | 'new';
    setCreateUserMode: (mode: 'existing' | 'new') => void;
    handleCreateUser: (data: DtoCreateMemberDTO & DtoRegisterRequest) => Promise<boolean>;
}

export const useUserModuleStore = create<UserModuleState>((set, get) => ({
    members: [],
    totalMembers: 0,
    currentPage: 1,
    pageSize: 10,
    searchQuery: "",
    sortBy: "created_at",
    sortOrder: "desc",
    selectedRole: "",
    selectedStatus: "",
    isLoading: false,
    editingMember: null,
    createUserMode: 'existing',

    setCreateUserMode: (mode) => set({createUserMode: mode}),

    handleCreateUser: async (data: DtoCreateMemberDTO & Partial<DtoRegisterRequest>): Promise<boolean> => {
        const {selectedGroupMember} = useUserStore.getState();

        if (!selectedGroupMember) {
            toast.error("No group selected");
            return false;
        }

        set({isLoading: true});

        try {
            if ('password' in data) {
                // This is a new user
                await registerNewUser({
                    email: data.email!,
                    full_name: data.full_name!,
                    password: data.password!
                });
            }

            // Create member for both new and existing users
            await createMember(
                {group_id: selectedGroupMember.group_id},
                {email: data.email, role: data.role}
            );

            toast.success("User added successfully");
            return true
        } catch (error) {
            toast.error("Failed to add user. Make sure the email you entered matches the criteria and try again.");
            return false
        } finally {
            set({isLoading: false});
        }
    },

    fetchMembers: async () => {
        const {currentPage, pageSize, searchQuery, sortBy, sortOrder, selectedRole, selectedStatus} = get();
        const {selectedGroupMember} = useUserStore.getState();
        set({isLoading: true});
        try {
            if (!selectedGroupMember) {
                console.error("No group selected");
                return;
            }
            const params: MembersListParams = {
                group_id: selectedGroupMember.group_id,
                page: currentPage,
                size: pageSize,
                search: searchQuery,
                sort_by: sortBy,
                sort_order: sortOrder,
            };

            if (selectedRole) params.role = selectedRole;
            if (selectedStatus) params.status = selectedStatus;

            const response = await getAllMembers(params);
            set({members: response.members || [], totalMembers: response.total || 0});
        } catch (error) {
            console.error("Error fetching members:", error);
            toast.error("Failed getting users, please try again later");
        } finally {
            set({isLoading: false});
        }
    },

    handleSort: (field) => {
        const {sortBy, sortOrder} = get();
        if (field === sortBy) {
            set({sortOrder: sortOrder === "asc" ? "desc" : "asc"});
        } else {
            set({sortBy: field, sortOrder: "asc"});
        }
        get().fetchMembers();
    },

    handleSearch: (query) => {
        set({searchQuery: query, currentPage: 1});
        // get().fetchMembers();
    },

    handleRoleFilter: (role) => {
        set({selectedRole: role, currentPage: 1});
        get().fetchMembers();
    },

    handleStatusFilter: (status) => {
        set({selectedStatus: status, currentPage: 1});
        get().fetchMembers();
    },

    handlePageChange: (page) => {
        set({currentPage: page});
        get().fetchMembers();
    },

    handleEditMember: (member) => {
        set({editingMember: member});
    },

    setEditingMember: (member) => set({editingMember: member}),

    handleUpdateMember: async () => {
        const {editingMember} = get();
        const {selectedGroupMember} = useUserStore.getState();
        if (!editingMember || !selectedGroupMember) return;
        const data: DtoUpdateMemberDTO = {
            role: editingMember.role as DtoUpdateMemberDTO['role'],
            status: editingMember.status as DtoUpdateMemberDTO['status']
        };
        set({isLoading: true});
        try {
            await updateMember({group_id: selectedGroupMember.group_id, id: editingMember.id || ""}, data);
            set({editingMember: null});
            get().fetchMembers();
            toast.success("Success updating user");
        } catch (error) {
            console.error("Error updating member:", error);
            toast.error("Failed updating user, please try again later");
        } finally {
            set({isLoading: false});
        }
    },

    handleDeleteMember: async (memberId) => {
        const {selectedGroupMember} = useUserStore.getState();
        if (!selectedGroupMember) return;
        set({isLoading: true});
        try {
            await deleteMember({group_id: selectedGroupMember.group_id, id: memberId});
            toast.success("Success remove a user");
            get().fetchMembers();
        } catch (error) {
            console.error("Error deleting member:", error);
            toast.error("Failed deleting user, please try again later");
        } finally {
            set({isLoading: false});
        }
    },
}));
