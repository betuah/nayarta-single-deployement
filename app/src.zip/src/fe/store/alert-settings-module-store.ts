import { create } from 'zustand';
import { toast } from 'react-toastify';
import {
    getAlertSetting,
    addAllSettings, updateAlertSetting
} from '@/actions/alert-settings-action';
import { useUserStore } from "@/store/user-store";
import {
    CreateAllCreateParams, DtoCreateAllMemberAlertSettingsDTO,
    DtoMemberAlertSettingListItem, DtoUpdateMemberAlertSettingDTO,
    MemberAlertSettingsListParams, MemberAlertSettingsUpdateParams
} from "@/lib/api/data-contracts";

interface AlertSettingsState {
    alertSettings: DtoMemberAlertSettingListItem[];
    isLoading: boolean;
    isSyncing: boolean;
    isUpdating: boolean;
    error: string | null;
    fetchAlertSettings: (cctvId: string) => Promise<void>;
    syncAlertSettings: (cctvId: string) => Promise<void>;
    updateAlertSetting: (cctvId: string, settingId: string, enabled: boolean) => Promise<void>;
}

export const useAlertSettingsStore = create<AlertSettingsState>((set, get) => ({
    alertSettings: [],
    isLoading: false,
    isSyncing: false,
    isUpdating: false,
    error: null,

    fetchAlertSettings: async (cctvId: string) => {
        set({ isLoading: true, error: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: MemberAlertSettingsListParams = {
                group_id: selectedGroupMember.group_id,
                cctv_id: cctvId
            };
            const response = await getAlertSetting(params);
            set({ alertSettings: response.member_alert_settings || [], isLoading: false });
        } catch (error) {
            set({ error: 'Failed to fetch alert settings', isLoading: false });
            toast.error('Failed to fetch alert settings. Please try again later.');
        }
    },

    syncAlertSettings: async (cctvId: string) => {
        set({ isSyncing: true, error: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: CreateAllCreateParams = {
                group_id: selectedGroupMember.group_id
            };
            const data: DtoCreateAllMemberAlertSettingsDTO = {
                cctv_id: cctvId
            };
            await addAllSettings(params, data);
            set({ isSyncing: false });
            toast.success('Alert settings synced successfully');
            await get().fetchAlertSettings(cctvId);
        } catch (error) {
            set({ error: 'Failed to sync alert settings', isSyncing: false });
            toast.error('Failed to sync alert settings. Please try again later.');
        }
    },
    updateAlertSetting: async (cctvId: string, settingId: string, enabled: boolean) => {
        set({ isUpdating: true, error: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error("No group selected");
            }
            const params: MemberAlertSettingsUpdateParams = {
                group_id: selectedGroupMember.group_id,
                id: settingId
            };
            const data: DtoUpdateMemberAlertSettingDTO = {
                enabled: enabled
            };
            await updateAlertSetting(params, data);
            set({isUpdating: false});
            toast.success('Alert setting updated successfully');
        } catch (error) {
            set({ error: 'Failed to update alert setting', isUpdating: false });
            toast.error('Failed to update alert setting. Please try again later.');
        }
    },
}));
