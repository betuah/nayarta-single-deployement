import {getDashboardState, getGroupOverview, getStorageDetails} from "@/actions/dashboard-actions";
import {create} from "zustand";
import {toast} from "react-toastify";
import {useUserStore} from "@/store/user-store";
import {DtoStorageDetailsResponse, GroupOverviewListData, StatsListData} from "@/lib/api/data-contracts";
import {undefined} from "zod";

interface DashboardModuleState {
    isLoading: boolean;
    isLoadingGroupOverview: boolean;
    isLoadingStorageOverview: boolean;
    error: string | null;
    groupOverviewError: string | null;

    // Auto-refresh related state
    isAutoRefreshEnabled: boolean;
    refreshInterval: number; // in milliseconds
    lastRefreshTime: Date | null;
    isAutoRefreshing: boolean;

    // Data
    dashboardBasicData: null | StatsListData;
    groupOverviewData: null | GroupOverviewListData;
    storageDetailOverview: null | DtoStorageDetailsResponse;

    // Actions
    getDashboardBasicData: () => Promise<void>;
    getGroupOverviewData: () => Promise<void>;
    getStorageOverviewData: (rangeType: "last_3_days" | "last_week" | "last_4_months" | "custom", customStartDate: string | undefined, customEndDate: string | undefined) => Promise<void>;

    // Auto-refresh actions
    refreshAllData: (enabledSections?: { basicData?: boolean; groupOverview?: boolean; storageOverview?: boolean }) => Promise<void>;
    setAutoRefreshEnabled: (enabled: boolean) => void;
    setRefreshInterval: (interval: number) => void;

    // Reset function
    reset: () => void;
}

export const useCCTVAnalyticsModuleStore = create<DashboardModuleState>((set, get) => ({
    isLoading: false,
    isLoadingGroupOverview: false,
    isLoadingStorageOverview: false,
    error: null,
    groupOverviewError: null,

    // Auto-refresh state
    isAutoRefreshEnabled: true,
    refreshInterval: 300000, // 5 minutes in milliseconds
    lastRefreshTime: null,
    isAutoRefreshing: false,

    // Data
    dashboardBasicData: null,
    groupOverviewData: null,
    storageDetailOverview: null,

    getDashboardBasicData: async () => {
        set({isLoading: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const data = await getDashboardState(selectedGroupMember.group_id);
            set({dashboardBasicData: data, isLoading: false, lastRefreshTime: new Date()});
        } catch (e) {
            set({error: "Failed to get dashboard data", isLoading: false});
            toast.error('Failed to get dashboard data. Please try again later.');
        }
    },

    getGroupOverviewData: async () => {
        set({isLoadingGroupOverview: true, groupOverviewError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const data = await getGroupOverview(selectedGroupMember.group_id);
            set({groupOverviewData: data, isLoadingGroupOverview: false, lastRefreshTime: new Date()});
        } catch (e) {
            set({groupOverviewError: "Failed to get group overview data", isLoadingGroupOverview: false});
            toast.error('Failed to get group overview data. Please try again later.');
        }
    },

    getStorageOverviewData: async (
        rangeType: "last_3_days" | "last_week" | "last_4_months" | "custom",
        customStartDate: string | undefined,
        customEndDate: string | undefined
    ) => {
        set({isLoadingStorageOverview: true, error: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const data = await getStorageDetails({
                end_date: customEndDate,
                group_id: selectedGroupMember.group_id!,
                range_type: rangeType,
                start_date: customStartDate
            });

            set({storageDetailOverview: data, lastRefreshTime: new Date()});
        } catch (e) {
            set({error: "Failed to get storage overview data"});
            toast.error('Failed to get storage overview data. Please try again later.');
        } finally {
            set({isLoadingStorageOverview: false});
        }
    },

    refreshAllData: async (enabledSections = { basicData: true, groupOverview: true, storageOverview: false }) => {
        const {
            isLoading,
            isLoadingGroupOverview,
            isLoadingStorageOverview
        } = get();

        // Prevent multiple concurrent refreshes
        if (isLoading || isLoadingGroupOverview || isLoadingStorageOverview) return;

        set({ isAutoRefreshing: true, error: null, groupOverviewError: null });

        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const promises: Promise<any>[] = [];

            if (enabledSections.basicData) {
                promises.push(getDashboardState(selectedGroupMember.group_id));
            }

            if (enabledSections.groupOverview) {
                promises.push(getGroupOverview(selectedGroupMember.group_id));
            }

            if (enabledSections.storageOverview) {
                promises.push(getStorageDetails({
                    //end_date: undefined,
                    group_id: selectedGroupMember.group_id!,
                    range_type: "last_week",
                    //start_date: undefined
                }));
            }

            const results = await Promise.all(promises);

            // Update the state with results
            const updates: any = {
                isAutoRefreshing: false,
                lastRefreshTime: new Date()
            };

            if (enabledSections.basicData && results[0]) {
                updates.dashboardBasicData = results[0];
            }

            if (enabledSections.groupOverview) {
                const groupIndex = enabledSections.basicData ? 1 : 0;
                if (results[groupIndex]) {
                    updates.groupOverviewData = results[groupIndex];
                }
            }

            if (enabledSections.storageOverview) {
                const storageIndex = (enabledSections.basicData ? 1 : 0) + (enabledSections.groupOverview ? 1 : 0);
                if (results[storageIndex]) {
                    updates.storageDetailOverview = results[storageIndex];
                }
            }

            set(updates);

        } catch (error) {
            set({
                isAutoRefreshing: false,
                error: 'Failed to refresh dashboard data'
            });
            // Don't show toast for auto-refresh errors to avoid spam
            console.error('Dashboard auto-refresh failed:', error);
        }
    },

    setAutoRefreshEnabled: (enabled: boolean) => {
        set({ isAutoRefreshEnabled: enabled });
    },

    setRefreshInterval: (interval: number) => {
        set({ refreshInterval: interval });
    },

    reset: () => {
        set({
            isLoading: false,
            isLoadingGroupOverview: false,
            isLoadingStorageOverview: false,
            error: null,
            groupOverviewError: null,

            // Reset auto-refresh state
            isAutoRefreshEnabled: true,
            refreshInterval: 300000,
            lastRefreshTime: null,
            isAutoRefreshing: false,

            // Reset data
            dashboardBasicData: null,
            groupOverviewData: null,
            storageDetailOverview: null,
        });
    },
}));
