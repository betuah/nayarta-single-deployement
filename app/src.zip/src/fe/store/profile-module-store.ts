import {create} from 'zustand';
import {toast} from 'react-toastify';
import {MembersDetailData, PasswordUpdateData, UserUpdateData} from '@/lib/api/data-contracts';
import {getMemberDetail, updateUser, updateUserPassword} from "@/actions/member-action";
import {useUserStore} from "@/store/user-store";

interface ProfileModuleState {
    userDetails: MembersDetailData | null;
    isLoading: boolean;
    fetchUserDetails: () => Promise<void>;
    updateUserProfile: (data: UserUpdateData) => Promise<void>;
    changePassword: (data: PasswordUpdateData) => Promise<void>;
}

export const useProfileModuleStore = create<ProfileModuleState>((set, get) => ({
    userDetails: null,
    isLoading: false,

    fetchUserDetails: async () => {
        set({isLoading: true});
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            const details = await getMemberDetail({
                group_id: selectedGroupMember.group_id,
                id: selectedGroupMember.member_id
            });
            set({userDetails: details});
        } catch (error) {
            toast.error('Failed to fetch user details');
        } finally {
            set({isLoading: false});
        }
    },

    updateUserProfile: async (data: UserUpdateData) => {
        set({isLoading: true});
        try {
            const { selectedGroupMember, user } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }
            await updateUser(data);
            await get().fetchUserDetails();
            toast.success('Profile updated successfully');
        } catch (error) {
            toast.error('Failed to update profile');
        } finally {
            set({isLoading: false});
        }
    },

    changePassword: async (data: PasswordUpdateData) => {
        set({isLoading: true});
        try {
            await updateUserPassword(data);
            toast.success('Password changed successfully');
        } catch (error) {
            toast.error('Failed to change password');
        } finally {
            set({isLoading: false});
        }
    },
}));
