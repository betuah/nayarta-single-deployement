import {create} from 'zustand';
import {toast} from 'react-toastify';
import {
    ObjectCountCountingChartListData,
    ObjectCountCountingChartListParams,
    ObjectCountHeatmapListData,
    ObjectCountHeatmapListParams,
    ObjectCountPeopleCountingOverviewListData,
    ObjectCountPeopleCountingOverviewListParams,
    InOutCountChartListData,
    InOutCountChartListParams,
    InOutCountOverviewListData,
    InOutCountOverviewListParams,
    SearchFaceCreateParams,
    SearchFaceCreateData,
    DtoSearchFaceRequestBody,
    DifferentDirectionChartListData,
    DifferentDirectionChartListParams,
    FireSmokeChartListData,
    FireSmokeChartListParams,
    PeopleConvergeChartListData,
    PeopleConvergeChartListParams,
    PersonRunningChartListData,
    PersonRunningChartListParams,
    RestrictedAreaChartListData,
    RestrictedAreaChartListParams,
    SurroundingVesselChartListData,
    SurroundingVesselChartListParams,
    SurroundingVesselOverviewListData,
    SurroundingVesselOverviewListParams,
    UnattendedObjectChartListData,
    UnattendedObjectChartListParams,
    HseChartListData,
    HseChartListParams,
    IllegalParkingChartListData, IllegalParkingChartListParams
} from '@/lib/api/data-contracts';
import {
    getObjectCountCountingChart,
    getObjectCountHeatmap,
    getObjectCountPeopleCountingOverview,
    getInOutCountCountingChart,
    getInOutPeopleCountingOverview,
    doFaceSearch,
    getDifferentDirectionChart,
    getFireSmokeChart,
    getPeopleConvergeChart,
    getPersonRunningChart,
    getRestrictedAreaChart,
    getSurroundingVesselChart,
    getSurroundingVesselOverview,
    getUnattendedObjectChart, getHseChart, getIllegalParkingChart
} from '@/actions/analytic-result-actions';
import {useUserStore} from '@/store/user-store';

interface AnalyticResultModuleState {
    // Counting Chart
    countingChartData: ObjectCountCountingChartListData | null;
    isLoadingCountingChart: boolean;
    countingChartError: string | null;

    // Heatmap
    heatmapData: ObjectCountHeatmapListData | null;
    isLoadingHeatmap: boolean;
    heatmapError: string | null;

    // People Counting Overview
    peopleCountingOverviewData: ObjectCountPeopleCountingOverviewListData | null;
    isLoadingPeopleCountingOverview: boolean;
    peopleCountingOverviewError: string | null;

    // In-Out Counting Chart
    inOutCountingChartData: InOutCountChartListData | null;
    isLoadingInOutCountingChart: boolean;
    inOutCountingChartError: string | null;

    // In-Out People Counting Overview
    inOutPeopleCountingOverviewData: InOutCountOverviewListData | null;
    isLoadingInOutPeopleCountingOverview: boolean;
    inOutPeopleCountingOverviewError: string | null;

    // Face Search
    faceSearchData: SearchFaceCreateData | null;
    isLoadingFaceSearch: boolean;
    faceSearchError: string | null;

    // Different Direction Chart
    differentDirectionChartData: DifferentDirectionChartListData | null;
    isLoadingDifferentDirectionChart: boolean;
    differentDirectionChartError: string | null;

    // Fire Smoke Chart
    fireSmokeChartData: FireSmokeChartListData | null;
    isLoadingFireSmokeChart: boolean;
    fireSmokeChartError: string | null;

    // People Converge Chart
    peopleConvergeChartData: PeopleConvergeChartListData | null;
    isLoadingPeopleConvergeChart: boolean;
    peopleConvergeChartError: string | null;

    // Person Running Chart
    personRunningChartData: PersonRunningChartListData | null;
    isLoadingPersonRunningChart: boolean;
    personRunningChartError: string | null;

    // HSE Chart
    healthSafetyEnvironmentChartData: HseChartListData | null;
    isLoadingHealthSafetyEnvironmentChart: boolean;
    healthSafetyEnvironmentChartError: string | null;

    // Restricted Area Chart
    restrictedAreaChartData: RestrictedAreaChartListData | null;
    isLoadingRestrictedAreaChart: boolean;
    restrictedAreaChartError: string | null;

    // Illegal Parking Chart
    illegalParkingChartData: IllegalParkingChartListData | null;
    isLoadingIllegalParkingChart: boolean;
    illegalParkingChartError: string | null;

    // Surrounding Vessel Chart
    surroundingVesselChartData: SurroundingVesselChartListData | null;
    isLoadingSurroundingVesselChart: boolean;
    surroundingVesselChartError: string | null;

    // Surrounding Vessel Overview
    surroundingVesselOverviewData: SurroundingVesselOverviewListData | null;
    isLoadingSurroundingVesselOverview: boolean;
    surroundingVesselOverviewError: string | null;

    // Unattended Object Chart
    unattendedObjectChartData: UnattendedObjectChartListData | null;
    isLoadingUnattendedObjectChart: boolean;
    unattendedObjectChartError: string | null;

    fetchCountingChart: (params: Omit<ObjectCountCountingChartListParams, 'group_id'>) => Promise<void>;
    fetchHeatmap: (params: Omit<ObjectCountHeatmapListParams, 'group_id'>) => Promise<void>;
    fetchPeopleCountingOverview: (params: Omit<ObjectCountPeopleCountingOverviewListParams, 'group_id'>) => Promise<void>;
    fetchInOutCountingChart: (params: Omit<InOutCountChartListParams, 'group_id'>) => Promise<void>;
    fetchInOutPeopleCountingOverview: (params: Omit<InOutCountOverviewListParams, 'group_id'>) => Promise<void>;
    fetchFaceSearch: (params: Omit<SearchFaceCreateParams, 'group_id'>, data: Omit<DtoSearchFaceRequestBody, 'org_id'>) => Promise<void>;

    fetchDifferentDirectionChart: (params: Omit<DifferentDirectionChartListParams, 'group_id'>) => Promise<void>;
    fetchFireSmokeChart: (params: Omit<FireSmokeChartListParams, 'group_id'>) => Promise<void>;
    fetchPeopleConvergeChart: (params: Omit<PeopleConvergeChartListParams, 'group_id'>) => Promise<void>;
    fetchPersonRunningChart: (params: Omit<PersonRunningChartListParams, 'group_id'>) => Promise<void>;
    fetchHealthSafetyEnvironmentChart: (params: Omit<HseChartListParams, 'group_id'>) => Promise<void>;
    fetchRestrictedAreaChart: (params: Omit<RestrictedAreaChartListParams, 'group_id'>) => Promise<void>;
    fetchIllegalParkingChart: (params: Omit<IllegalParkingChartListParams, 'group_id'>) => Promise<void>;
    fetchSurroundingVesselChart: (params: Omit<SurroundingVesselChartListParams, 'group_id'>) => Promise<void>;
    fetchSurroundingVesselOverview: (params: Omit<SurroundingVesselOverviewListParams, 'group_id'>) => Promise<void>;
    fetchUnattendedObjectChart: (params: Omit<UnattendedObjectChartListParams, 'group_id'>) => Promise<void>;

    reset: () => void;
}

export const useAnalyticResultModuleStore = create<AnalyticResultModuleState>((set, get) => ({
    // initial state
    countingChartData: null,
    isLoadingCountingChart: false,
    countingChartError: null,

    heatmapData: null,
    isLoadingHeatmap: false,
    heatmapError: null,

    peopleCountingOverviewData: null,
    isLoadingPeopleCountingOverview: false,
    peopleCountingOverviewError: null,

    inOutCountingChartData: null,
    isLoadingInOutCountingChart: false,
    inOutCountingChartError: null,

    inOutPeopleCountingOverviewData: null,
    isLoadingInOutPeopleCountingOverview: false,
    inOutPeopleCountingOverviewError: null,

    faceSearchData: null,
    isLoadingFaceSearch: false,
    faceSearchError: null,

    differentDirectionChartData: null,
    isLoadingDifferentDirectionChart: false,
    differentDirectionChartError: null,

    fireSmokeChartData: null,
    isLoadingFireSmokeChart: false,
    fireSmokeChartError: null,

    peopleConvergeChartData: null,
    isLoadingPeopleConvergeChart: false,
    peopleConvergeChartError: null,

    personRunningChartData: null,
    isLoadingPersonRunningChart: false,
    personRunningChartError: null,

    healthSafetyEnvironmentChartData: null,
    isLoadingHealthSafetyEnvironmentChart: false,
    healthSafetyEnvironmentChartError: null,

    restrictedAreaChartData: null,
    isLoadingRestrictedAreaChart: false,
    restrictedAreaChartError: null,

    illegalParkingChartData: null,
    isLoadingIllegalParkingChart: false,
    illegalParkingChartError: null,

    surroundingVesselChartData: null,
    isLoadingSurroundingVesselChart: false,
    surroundingVesselChartError: null,

    surroundingVesselOverviewData: null,
    isLoadingSurroundingVesselOverview: false,
    surroundingVesselOverviewError: null,

    unattendedObjectChartData: null,
    isLoadingUnattendedObjectChart: false,
    unattendedObjectChartError: null,

    fetchCountingChart: async (params: Omit<ObjectCountCountingChartListParams, 'group_id'>) => {
        set({isLoadingCountingChart: true, countingChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: ObjectCountCountingChartListData = await getObjectCountCountingChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                countingChartData: response,
                isLoadingCountingChart: false
            });
        } catch (error) {
            set({countingChartError: 'Failed to fetch counting chart data', isLoadingCountingChart: false});
            toast.error('Failed to fetch counting chart data. Please try again later.');
        }
    },

    fetchHeatmap: async (params: Omit<ObjectCountHeatmapListParams, 'group_id'>) => {
        set({isLoadingHeatmap: true, heatmapError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: ObjectCountHeatmapListData = await getObjectCountHeatmap({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                heatmapData: response,
                isLoadingHeatmap: false
            });
        } catch (error) {
            set({heatmapError: 'Failed to fetch heatmap data', isLoadingHeatmap: false});
            toast.error('Failed to fetch heatmap data. Please try again later.');
        }
    },

    fetchPeopleCountingOverview: async (params: Omit<ObjectCountPeopleCountingOverviewListParams, 'group_id'>) => {
        set({isLoadingPeopleCountingOverview: true, peopleCountingOverviewError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: ObjectCountPeopleCountingOverviewListData = await getObjectCountPeopleCountingOverview({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                peopleCountingOverviewData: response,
                isLoadingPeopleCountingOverview: false
            });
        } catch (error) {
            set({
                peopleCountingOverviewError: 'Failed to fetch people counting overview',
                isLoadingPeopleCountingOverview: false
            });
            toast.error('Failed to fetch people counting overview. Please try again later.');
        }
    },

    fetchInOutCountingChart: async (params: Omit<InOutCountChartListParams, 'group_id'>) => {
        set({isLoadingInOutCountingChart: true, inOutCountingChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: InOutCountChartListData = await getInOutCountCountingChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                inOutCountingChartData: response,
                isLoadingInOutCountingChart: false
            });
        } catch (error) {
            set({
                inOutCountingChartError: 'Failed to fetch in-out counting chart data',
                isLoadingInOutCountingChart: false
            });
            toast.error('Failed to fetch in-out counting chart data. Please try again later.');
        }
    },

    fetchInOutPeopleCountingOverview: async (params: Omit<InOutCountOverviewListParams, 'group_id'>) => {
        set({isLoadingInOutPeopleCountingOverview: true, inOutPeopleCountingOverviewError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: InOutCountOverviewListData = await getInOutPeopleCountingOverview({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                inOutPeopleCountingOverviewData: response,
                isLoadingInOutPeopleCountingOverview: false
            });
        } catch (error) {
            set({
                inOutPeopleCountingOverviewError: 'Failed to fetch in-out people counting overview',
                isLoadingInOutPeopleCountingOverview: false
            });
            toast.error('Failed to fetch in-out people counting overview. Please try again later.');
        }
    },

    fetchFaceSearch: async (params: Omit<SearchFaceCreateParams, 'group_id'>, data: Omit<DtoSearchFaceRequestBody, 'org_id'>) => {
        set({isLoadingFaceSearch: true, faceSearchError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: SearchFaceCreateData = await doFaceSearch({
                group_id: selectedGroupMember.group_id,
                ...params
            }, {
                org_id: selectedGroupMember.group_id,
                ...data
            });
            console.log(response)
            set({
                faceSearchData: response,
                isLoadingFaceSearch: false
            });
        } catch (error) {
            set({faceSearchError: 'Failed to search for matching faces', isLoadingFaceSearch: false});
            toast.error('Failed to search for matching faces. Please try again later.');
        }
    },

    fetchDifferentDirectionChart: async (params: Omit<DifferentDirectionChartListParams, 'group_id'>) => {
        set({isLoadingDifferentDirectionChart: true, differentDirectionChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: DifferentDirectionChartListData = await getDifferentDirectionChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                differentDirectionChartData: response,
                isLoadingDifferentDirectionChart: false
            });
        } catch (error) {
            set({
                differentDirectionChartError: 'Failed to fetch different direction chart data',
                isLoadingDifferentDirectionChart: false
            });
            toast.error('Failed to fetch different direction chart data. Please try again later.');
        }
    },

    fetchFireSmokeChart: async (params: Omit<FireSmokeChartListParams, 'group_id'>) => {
        set({isLoadingFireSmokeChart: true, fireSmokeChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: FireSmokeChartListData = await getFireSmokeChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                fireSmokeChartData: response,
                isLoadingFireSmokeChart: false
            });
        } catch (error) {
            set({fireSmokeChartError: 'Failed to fetch fire smoke chart data', isLoadingFireSmokeChart: false});
            toast.error('Failed to fetch fire smoke chart data. Please try again later.');
        }
    },

    fetchPeopleConvergeChart: async (params: Omit<PeopleConvergeChartListParams, 'group_id'>) => {
        set({isLoadingPeopleConvergeChart: true, peopleConvergeChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: PeopleConvergeChartListData = await getPeopleConvergeChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                peopleConvergeChartData: response,
                isLoadingPeopleConvergeChart: false
            });
        } catch (error) {
            set({
                peopleConvergeChartError: 'Failed to fetch people converge chart data',
                isLoadingPeopleConvergeChart: false
            });
            toast.error('Failed to fetch people converge chart data. Please try again later.');
        }
    },

    fetchPersonRunningChart: async (params: Omit<PersonRunningChartListParams, 'group_id'>) => {
        set({isLoadingPersonRunningChart: true, personRunningChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: PersonRunningChartListData = await getPersonRunningChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                personRunningChartData: response,
                isLoadingPersonRunningChart: false
            });
        } catch (error) {
            set({
                personRunningChartError: 'Failed to fetch person running chart data',
                isLoadingPersonRunningChart: false
            });
            toast.error('Failed to fetch person running chart data. Please try again later.');
        }
    },

    fetchHealthSafetyEnvironmentChart: async (params: Omit<HseChartListParams, 'group_id'>) => {
        set({isLoadingHealthSafetyEnvironmentChart: true, healthSafetyEnvironmentChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: HseChartListData = await getHseChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                healthSafetyEnvironmentChartData: response,
                isLoadingHealthSafetyEnvironmentChart: false
            });
        } catch (error) {
            set({
                healthSafetyEnvironmentChartError: 'Failed to fetch HSE chart data',
                isLoadingHealthSafetyEnvironmentChart: false
            });
            toast.error('Failed to fetch HSE chart data. Please try again later.');
        }
    },

    fetchRestrictedAreaChart: async (params: Omit<RestrictedAreaChartListParams, 'group_id'>) => {
        set({isLoadingRestrictedAreaChart: true, restrictedAreaChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: RestrictedAreaChartListData = await getRestrictedAreaChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                restrictedAreaChartData: response,
                isLoadingRestrictedAreaChart: false
            });
        } catch (error) {
            set({
                restrictedAreaChartError: 'Failed to fetch restricted area chart data',
                isLoadingRestrictedAreaChart: false
            });
            toast.error('Failed to fetch restricted area chart data. Please try again later.');
        }
    },

    fetchIllegalParkingChart: async (params: Omit<IllegalParkingChartListParams, 'group_id'>) => {
        set({isLoadingIllegalParkingChart: true, illegalParkingChartData: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: IllegalParkingChartListData = await getIllegalParkingChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                illegalParkingChartData: response,
                isLoadingIllegalParkingChart: false
            });
        } catch (error) {
            set({
                illegalParkingChartError: 'Failed to fetch illegal parking chart data',
                isLoadingIllegalParkingChart: false
            });
            toast.error('Failed to fetch illegal parking chart data. Please try again later.');
        }
    },

    fetchSurroundingVesselChart: async (params: Omit<SurroundingVesselChartListParams, 'group_id'>) => {
        set({isLoadingSurroundingVesselChart: true, surroundingVesselChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: SurroundingVesselChartListData = await getSurroundingVesselChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                surroundingVesselChartData: response,
                isLoadingSurroundingVesselChart: false
            });
        } catch (error) {
            set({
                surroundingVesselChartError: 'Failed to fetch surrounding vessel chart data',
                isLoadingSurroundingVesselChart: false
            });
            toast.error('Failed to fetch surrounding vessel chart data. Please try again later.');
        }
    },

    fetchSurroundingVesselOverview: async (params: Omit<SurroundingVesselOverviewListParams, 'group_id'>) => {
        set({isLoadingSurroundingVesselOverview: true, surroundingVesselOverviewError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: SurroundingVesselOverviewListData = await getSurroundingVesselOverview({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                surroundingVesselOverviewData: response,
                isLoadingSurroundingVesselOverview: false
            });
        } catch (error) {
            set({
                surroundingVesselOverviewError: 'Failed to fetch surrounding vessel overview',
                isLoadingSurroundingVesselOverview: false
            });
            toast.error('Failed to fetch surrounding vessel overview. Please try again later.');
        }
    },

    fetchUnattendedObjectChart: async (params: Omit<UnattendedObjectChartListParams, 'group_id'>) => {
        set({isLoadingUnattendedObjectChart: true, unattendedObjectChartError: null});
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: UnattendedObjectChartListData = await getUnattendedObjectChart({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                unattendedObjectChartData: response,
                isLoadingUnattendedObjectChart: false
            });
        } catch (error) {
            set({
                unattendedObjectChartError: 'Failed to fetch unattended object chart data',
                isLoadingUnattendedObjectChart: false
            });
            toast.error('Failed to fetch unattended object chart data. Please try again later.');
        }
    },

    // Reset all state
    reset: () => {
        set({
            // Existing state reset
            countingChartData: null,
            isLoadingCountingChart: false,
            countingChartError: null,

            heatmapData: null,
            isLoadingHeatmap: false,
            heatmapError: null,

            peopleCountingOverviewData: null,
            isLoadingPeopleCountingOverview: false,
            peopleCountingOverviewError: null,

            inOutCountingChartData: null,
            isLoadingInOutCountingChart: false,
            inOutCountingChartError: null,

            inOutPeopleCountingOverviewData: null,
            isLoadingInOutPeopleCountingOverview: false,
            inOutPeopleCountingOverviewError: null,

            faceSearchData: null,
            isLoadingFaceSearch: false,
            faceSearchError: null,

            differentDirectionChartData: null,
            isLoadingDifferentDirectionChart: false,
            differentDirectionChartError: null,

            fireSmokeChartData: null,
            isLoadingFireSmokeChart: false,
            fireSmokeChartError: null,

            peopleConvergeChartData: null,
            isLoadingPeopleConvergeChart: false,
            peopleConvergeChartError: null,

            personRunningChartData: null,
            isLoadingPersonRunningChart: false,
            personRunningChartError: null,

            restrictedAreaChartData: null,
            isLoadingRestrictedAreaChart: false,
            restrictedAreaChartError: null,

            surroundingVesselChartData: null,
            isLoadingSurroundingVesselChart: false,
            surroundingVesselChartError: null,

            surroundingVesselOverviewData: null,
            isLoadingSurroundingVesselOverview: false,
            surroundingVesselOverviewError: null,

            unattendedObjectChartData: null,
            isLoadingUnattendedObjectChart: false,
            unattendedObjectChartError: null,

            healthSafetyEnvironmentChartData: null,
            isLoadingHealthSafetyEnvironmentChart: false,
            healthSafetyEnvironmentChartError: null,
        });
    }
}));
