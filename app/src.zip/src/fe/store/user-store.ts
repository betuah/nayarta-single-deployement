import create from 'zustand'
import {persist} from "zustand/middleware"

type GroupMember = {
    group_id: string;
    member_id: string;
    group_name: string;
    role: string;
}

interface User {
    id: string | null;
    name: string | null;
    email: string | null;
    profilePicture: string | null;
}

interface UserState {
    user: User | null;
    members: GroupMember[];
    selectedGroupMember: GroupMember | null;
    initializeUser: (user: User) => void;
    setUserProfilePicture: (image: string) => void;
    initializeMembers: (members: GroupMember[]) => void;
    switchMemberByIndex: (index: number) => void;
    switchOrganization: (member: GroupMember) => void;
    setMemberList: (members: GroupMember[]) => void;
    reset: () => void;
}

export const useUserStore = create<UserState>()(
    persist(
        (set, get) => ({
            user: null,
            members: [],
            selectedGroupMember: null,
            initializeUser: (user) => set({user: user}),
            initializeMembers: (members) => set((state) => {
                if (state.members.length === 0) {
                    return {
                        members,
                        selectedGroupMember: members[0] || null,
                    }
                }
                return {}
            }),
            setMemberList: (memberships: GroupMember[]) => {
                set({members: memberships})
            },
            switchMemberByIndex: (index) => set((state) => ({
                selectedGroupMember: state.members[index] || state.selectedGroupMember,
            })),
            switchOrganization: (member: GroupMember) => set((state) => ({
                // set({ selectedGroupMember: state.members.fin });
                selectedGroupMember: state.members.find(m => m.group_id === member.group_id)
            })),
            reset: () => set({user: null, members: [], selectedGroupMember: null}),
            setUserProfilePicture: (image: string) => {
                set({user: {...get().user!, ...{profilePicture: image}}})
            },
        }),
        {
            name: "user-storage",
        }
    )
)
