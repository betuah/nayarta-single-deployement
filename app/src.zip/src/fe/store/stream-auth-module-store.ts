import { create } from 'zustand';
import { toast } from 'react-toastify';
import { useUserStore } from "@/store/user-store";
import {
    DtoGenerateReadTokenRequest,
    DtoValidateStreamTokenRequest,
    ReadCreateData,
    VerifyCreateData
} from "@/lib/api/data-contracts";
import {
    generateReadToken,
    verifyStreamToken
} from '@/actions/stream-auth-actions';

interface StreamAuthModuleState {
    // Data states
    readToken: ReadCreateData | null;
    verificationResult: VerifyCreateData | null;

    // Loading states
    isGeneratingToken: boolean;
    isVerifyingToken: boolean;

    // API actions
    generateToken: (data: DtoGenerateReadTokenRequest) => Promise<ReadCreateData | null>;
    verifyToken: (data: DtoValidateStreamTokenRequest) => Promise<VerifyCreateData | null>;

    // Reset states
    resetTokenData: () => void;
    resetVerificationData: () => void;
}

export const useStreamAuthModuleStore = create<StreamAuthModuleState>((set, get) => ({
    // Initial states
    readToken: null,
    verificationResult: null,
    isGeneratingToken: false,
    isVerifyingToken: false,

    // API actions
    generateToken: async (data: DtoGenerateReadTokenRequest) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return null;
        }

        set({ isGeneratingToken: true });
        try {
            const tokenData = await generateReadToken(data);
            set({ readToken: tokenData });
            return tokenData;
        } catch (error) {
            toast.error('Failed to generate read token');
            return null;
        } finally {
            set({ isGeneratingToken: false });
        }
    },

    verifyToken: async (data: DtoValidateStreamTokenRequest) => {
        const { selectedGroupMember } = useUserStore.getState();
        if (!selectedGroupMember) {
            toast.error('No group selected');
            return null;
        }

        set({ isVerifyingToken: true });
        try {
            const verificationData = await verifyStreamToken(data);
            set({ verificationResult: verificationData });
            return verificationData;
        } catch (error) {
            toast.error('Failed to verify stream token');
            return null;
        } finally {
            set({ isVerifyingToken: false });
        }
    },

    // Reset states
    resetTokenData: () => set({ readToken: null }),
    resetVerificationData: () => set({ verificationResult: null })
}));
