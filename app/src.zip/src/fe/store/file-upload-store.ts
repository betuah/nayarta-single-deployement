import create from 'zustand';
import {toast} from 'react-toastify';
import {
    DtoGetPresignedURLRequest,
    DtoPresignedRequest,
    PublicUploadUrlCreateData,
    PublicUploadUrlCreateParams,
    QuotaStorageListParams
} from "@/lib/api/data-contracts";
import {createPublicPresignedUrl} from "@/actions/object-storage-action";
import {getQuotaStorage} from "@/actions/group-actions";
import {useUserStore} from "@/store/user-store";
import axios from "axios";

interface FileUploadState {
    isUploading: boolean;
    files: File[];
    fileUrl: string | undefined;
    createPresignedUrl: (groupId: string, file: DtoGetPresignedURLRequest) => Promise<DtoPresignedRequest | null>;
    uploadFile: (presignedData: DtoPresignedRequest, file: File) => Promise<boolean>;
    handleFileDrop: (acceptedFiles: File[]) => void;
    clearFiles: () => void;
    setFileUrl: (url: string | undefined) => void;
    reset: () => void;
    checkStorageQuota: (contentLength: number) => Promise<boolean>;
}

const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const useFileUploadStore = create<FileUploadState>((set, get) => ({
    isUploading: false,
    files: [],
    fileUrl: "",

    reset: () => {
        set({
            isUploading: false,
            files: [],
            fileUrl: "",
        });
    },

    checkStorageQuota: async (contentLength: number): Promise<boolean> => {
        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                toast.error('No group selected');
                return false;
            }

            const params: QuotaStorageListParams = {
                group_id: selectedGroupMember.group_id
            };

            const storageQuota = await getQuotaStorage(params);

            console.log(storageQuota)

            if (storageQuota && storageQuota.remaining !== undefined) {
                const remainingBytes = storageQuota.remaining;

                if (contentLength > remainingBytes) {
                    const fileSize = formatBytes(contentLength);
                    const remainingSize = formatBytes(remainingBytes);
                    const maxSize = formatBytes(storageQuota.max || 0);
                    const usedSize = formatBytes(storageQuota.used || 0);

                    toast.error(
                        `Storage quota exceeded! File size (${fileSize}) exceeds remaining storage (${remainingSize}). ` +
                        `Current usage: ${usedSize} / ${maxSize}. Please contact your administrator to increase storage quota or free up space.`,
                        {
                            autoClose: 8000, // Show longer for important message
                        }
                    );
                    return false;
                }
            }

            return true;
        } catch (error) {
            console.error('Error checking storage quota:', error);
            toast.error('Failed to check storage quota. Please try again.');
            return false;
        }
    },

    createPresignedUrl: async (groupId: string, file: DtoGetPresignedURLRequest): Promise<PublicUploadUrlCreateData | null> => {
        set({isUploading: true});

        try {
            const {selectedGroupMember} = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            // Check storage quota before requesting presigned URL
            const hasEnoughStorage = await get().checkStorageQuota(file.content_length);
            if (!hasEnoughStorage) {
                return null;
            }

            const params: PublicUploadUrlCreateParams = {group_id: selectedGroupMember.group_id};
            return await createPublicPresignedUrl(params, file);
        } catch (error: any) {
            if (error.message === 'FORBIDDEN') {
                toast.error("Organization Storage quota exceeded. Cannot upload file.");
                return null;
            } else {
                console.error(error.message);
                toast.error("Failed to generate upload URL, please try again later");
                return null;
            }
        } finally {
            set({isUploading: false});
        }
    },

    uploadFile: async (presignedData: DtoPresignedRequest, file: File) => {
        set({isUploading: true});
        try {
            const response = await fetch(presignedData.url!, {
                method: presignedData.method,
                headers: presignedData.header,
                body: file
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return true;
        } catch (error) {
            console.error("Error uploading file:", error);
            toast.error("Failed to upload file, please try again later");
            return false;
        } finally {
            set({isUploading: false});
        }
    },

    handleFileDrop: (acceptedFiles) => {
        set({files: acceptedFiles.map((file) => Object.assign(file))});
    },

    clearFiles: () => {
        set({files: [], fileUrl: ""});
    },

    setFileUrl: (url) => {
        set({fileUrl: url});
    }
}));
