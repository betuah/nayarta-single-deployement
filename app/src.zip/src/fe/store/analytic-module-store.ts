import { create } from 'zustand';
import { toast } from 'react-toastify';
import {
    ReportsNotificationsListData,
    ReportsNotificationsListParams
} from '@/lib/api/data-contracts';
import { getAnalyticNotificationList } from '@/actions/analytic-action';
import { useUserStore } from '@/store/user-store';

interface AnalyticModuleState {
    // Notification List state
    notificationListData: ReportsNotificationsListData | null;
    isLoadingNotificationList: boolean;
    notificationListError: string | null;

    // Methods
    fetchNotificationList: (params: Omit<ReportsNotificationsListParams, 'group_id'>) => Promise<void>;
    reset: () => void;
}

export const useAnalyticModuleStore = create<AnalyticModuleState>((set, get) => ({
    // Initial Notification List state
    notificationListData: null,
    isLoadingNotificationList: false,
    notificationListError: null,

    // Fetch notification list data with optional filters
    fetchNotificationList: async (params: Omit<ReportsNotificationsListParams, 'group_id'>) => {
        set({ isLoadingNotificationList: true, notificationListError: null });
        try {
            const { selectedGroupMember } = useUserStore.getState();
            if (!selectedGroupMember) {
                throw new Error('No group selected');
            }

            const response: ReportsNotificationsListData = await getAnalyticNotificationList({
                group_id: selectedGroupMember.group_id,
                ...params
            });

            set({
                notificationListData: response,
                isLoadingNotificationList: false
            });
        } catch (error) {
            set({
                notificationListError: 'Failed to fetch notification list data',
                isLoadingNotificationList: false
            });
            toast.error('Failed to fetch notification list data. Please try again later.');
        }
    },

    // Reset all state
    reset: () => {
        set({
            notificationListData: null,
            isLoadingNotificationList: false,
            notificationListError: null
        });
    }
}));
