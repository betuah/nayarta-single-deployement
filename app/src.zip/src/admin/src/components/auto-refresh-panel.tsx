import React from 'react';
import { Button } from '@/components/ui/button';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
    RefreshCw,
    Play,
    Pause,
    Clock,
    AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

export interface RefreshInterval {
    label: string;
    value: number;
}

export interface AutoRefreshPanelProps {
    onRefresh: () => Promise<void>;
    isLoading: boolean;
    lastUpdated?: Date | null;
    error?: string | null;
    interval: number;
    onIntervalChange: (interval: number) => void;
    isEnabled: boolean;
    onEnabledChange: (enabled: boolean) => void;
    intervals?: RefreshInterval[];
    className?: string;
}

const DEFAULT_INTERVALS: RefreshInterval[] = [
    { label: '5 seconds', value: 5 },
    { label: '10 seconds', value: 10 },
    { label: '30 seconds', value: 30 },
    { label: '1 minute', value: 60 },
    { label: '2 minutes', value: 120 },
    { label: '5 minutes', value: 300 },
    { label: 'Manual only', value: 0 },
];

export function AutoRefreshPanel({
                                     onRefresh,
                                     isLoading,
                                     lastUpdated,
                                     error,
                                     interval,
                                     onIntervalChange,
                                     isEnabled,
                                     onEnabledChange,
                                     intervals = DEFAULT_INTERVALS,
                                     className
                                 }: AutoRefreshPanelProps) {
    const formatLastUpdated = (date: Date | null) => {
        if (!date) return 'Never';

        const now = new Date();
        const diff = Math.floor((now.getTime() - date.getTime()) / 1000);

        if (diff < 60) return `${diff}s ago`;
        if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
        return date.toLocaleTimeString();
    };

    const handleIntervalChange = (value: string) => {
        const newInterval = parseInt(value);
        onIntervalChange(newInterval);

        // Disable auto-refresh if manual only is selected
        if (newInterval === 0) {
            onEnabledChange(false);
        } else if (!isEnabled) {
            onEnabledChange(true);
        }
    };

    const handleToggleEnabled = () => {
        if (interval === 0) return; // Can't enable if manual only
        onEnabledChange(!isEnabled);
    };

    return (
        <Card className={cn("border-dashed", className)}>
            <CardContent className="p-4">
                <div className="flex items-center justify-between gap-4">
                    {/* Left side - Status and last updated */}
                    <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground">
                                Last updated: {formatLastUpdated(lastUpdated!)}
                            </span>
                        </div>

                        {error && (
                            <div className="flex items-center gap-1">
                                <AlertCircle className="h-4 w-4 text-destructive" />
                                <span className="text-sm text-destructive">{error}</span>
                            </div>
                        )}
                    </div>

                    {/* Right side - Controls */}
                    <div className="flex items-center gap-3">
                        {/* Auto-refresh status */}
                        {interval > 0 && (
                            <Badge
                                variant={isEnabled ? "default" : "secondary"}
                                className="flex items-center gap-1"
                            >
                                {isEnabled ? <Play className="h-3 w-3" /> : <Pause className="h-3 w-3" />}
                                {isEnabled ? 'Auto' : 'Paused'}
                            </Badge>
                        )}

                        {/* Interval selector */}
                        <Select value={interval.toString()} onValueChange={handleIntervalChange}>
                            <SelectTrigger className="w-36">
                                <SelectValue placeholder="Select interval" />
                            </SelectTrigger>
                            <SelectContent>
                                {intervals.map(({ label, value }) => (
                                    <SelectItem key={value} value={value.toString()}>
                                        {label}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>

                        {/* Toggle auto-refresh */}
                        {interval > 0 && (
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={handleToggleEnabled}
                                className="flex items-center gap-1"
                            >
                                {isEnabled ? (
                                    <>
                                        <Pause className="h-4 w-4" />
                                        Pause
                                    </>
                                ) : (
                                    <>
                                        <Play className="h-4 w-4" />
                                        Start
                                    </>
                                )}
                            </Button>
                        )}

                        {/* Manual refresh */}
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={onRefresh}
                            disabled={isLoading}
                            className="flex items-center gap-1"
                        >
                            <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
                            Refresh
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}
