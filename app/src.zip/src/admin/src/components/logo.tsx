import { SiteLogo } from "@/components/svg";
import React from "react";

const Logo = () => {
    return (
        <div className="px-4 py-4 ">
            <div className=" flex items-center">
                <div className="flex flex-1 items-center gap-x-3  ">
                    <SiteLogo className="text-primary h-[36px] w-[52px]" />
                </div>
            </div>
        </div>
    );
};

export default Logo;
