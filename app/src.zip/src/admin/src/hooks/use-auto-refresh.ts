import { useState, useEffect, useCallback, useRef } from 'react';

export interface UseAutoRefreshOptions {
    refreshFn: () => Promise<void>;
    defaultInterval?: number; // in seconds
    enabled?: boolean;
}

export interface UseAutoRefreshReturn {
    interval: number;
    setInterval: (interval: number) => void;
    isEnabled: boolean;
    setEnabled: (enabled: boolean) => void;
    lastUpdated: Date | null;
    refresh: () => Promise<void>;
    isLoading: boolean;
    error: string | null;
}

export function useAutoRefresh({
                                   refreshFn,
                                   defaultInterval = 30,
                                   enabled = true
                               }: UseAutoRefreshOptions): UseAutoRefreshReturn {
    const [intervalState, setIntervalState] = useState(defaultInterval);
    const [isEnabled, setIsEnabled] = useState(enabled);
    const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const isRefreshingRef = useRef(false);

    const refresh = useCallback(async () => {
        if (isRefreshingRef.current) return;

        isRefreshingRef.current = true;
        setIsLoading(true);
        setError(null);

        try {
            await refreshFn();
            setLastUpdated(new Date());
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'Failed to refresh data';
            setError(errorMessage);
        } finally {
            setIsLoading(false);
            isRefreshingRef.current = false;
        }
    }, [refreshFn]);

    const updateInterval = useCallback((newInterval: number) => {
        setIntervalState(newInterval);
    }, []);

    const setEnabled = useCallback((enabled: boolean) => {
        setIsEnabled(enabled);
    }, []);

    // Setup interval
    useEffect(() => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
        }

        if (isEnabled && intervalState > 0) {
            intervalRef.current = setInterval(() => {
                refresh().then();
            }, intervalState * 1000);
        }

        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
    }, [isEnabled, intervalState, refresh]);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
    }, []);

    return {
        interval: intervalState,
        setInterval: updateInterval, // Return the renamed function
        isEnabled,
        setEnabled,
        lastUpdated,
        refresh,
        isLoading,
        error
    };
}
