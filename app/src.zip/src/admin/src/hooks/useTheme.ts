"use client"

import { useState, useEffect } from 'react'

export function useTheme() {
    const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('system')
    const [mounted, setMounted] = useState(false)

    // Hydration fix
    useEffect(() => {
        setMounted(true)

        // Get saved theme from localStorage or default to 'system'
        const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | 'system' || 'system'
        setTheme(savedTheme)

        // Apply the theme immediately
        applyThemeToDocument(savedTheme)
    }, [])

    const applyThemeToDocument = (newTheme: 'light' | 'dark' | 'system') => {
        const root = document.documentElement

        if (newTheme === 'dark') {
            root.classList.add('dark')
        } else if (newTheme === 'light') {
            root.classList.remove('dark')
        } else {
            // System theme
            const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches
            if (systemDark) {
                root.classList.add('dark')
            } else {
                root.classList.remove('dark')
            }
        }
    }

    const setThemeWithPersistence = (newTheme: 'light' | 'dark' | 'system') => {
        setTheme(newTheme)
        localStorage.setItem('theme', newTheme)
        applyThemeToDocument(newTheme)
    }

    // Listen to system theme changes when theme is set to 'system'
    useEffect(() => {
        if (theme === 'system' && mounted) {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')

            const handleChange = () => {
                applyThemeToDocument('system')
            }

            mediaQuery.addEventListener('change', handleChange)
            return () => mediaQuery.removeEventListener('change', handleChange)
        }
    }, [theme, mounted])

    return {
        theme,
        setTheme: setThemeWithPersistence,
        mounted
    }
}
