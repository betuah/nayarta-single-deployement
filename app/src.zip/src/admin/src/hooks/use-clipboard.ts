import { useState } from 'react';
import { toast } from 'sonner';

export function useClipboard() {
    const [isCopied, setIsCopied] = useState(false);

    const copyToClipboard = async (text: string, successMessage?: string) => {
        try {
            await navigator.clipboard.writeText(text);
            setIsCopied(true);
            toast.success(successMessage || 'Copied to clipboard');

            // Reset the copied state after 2 seconds
            setTimeout(() => setIsCopied(false), 2000);
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (err) {
            toast.error('Failed to copy to clipboard');
        }
    };

    return { copyToClipboard, isCopied };
}
