'use server';

import { getServerSession } from 'next-auth/next';
import {authOptions} from "@/lib/auth-option";

export async function requireAuth() {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
        throw new Error('Authentication required');
    }

    if (!session.user.isAdmin) {
        throw new Error('Admin privileges required');
    }

    return session;
}

export async function getAuthSession() {
    return await getServerSession(authOptions);
}
