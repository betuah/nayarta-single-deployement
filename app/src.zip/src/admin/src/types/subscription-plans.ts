
// Original Prisma type
import {subscription_plans} from "@/generated/prisma";

export type SubscriptionPlan = subscription_plans;

// Client-safe version with Decimal converted to number
export interface SerializableSubscriptionPlan extends Omit<subscription_plans, 'price_monthly' | 'price_yearly'> {
    price_monthly: number | null;
    price_yearly: number | null;
}

// Filter and response types
export interface SubscriptionPlanFilters {
    search?: string;
    isActive?: boolean;
    sortBy?: 'name' | 'price_monthly' | 'price_yearly' | 'created_at';
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
}

export interface SubscriptionPlansResponse {
    data: SerializableSubscriptionPlan[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
}

// Form types for create/update
export interface CreateSubscriptionPlanInput {
    name: string;
    display_name: string;
    description?: string;
    max_cameras: number;
    max_nvrs: number;
    max_locations: number;
    max_members: number;
    max_floor_plans: number;
    max_storage: number;
    analytics: string[];
    desktop_app_access: boolean;
    priority_support: boolean;
    price_monthly?: number;
    price_yearly?: number;
    is_active: boolean;
}

export interface UpdateSubscriptionPlanInput extends Partial<CreateSubscriptionPlanInput> {
    id: string;
}
