'use server';

import prisma from '@/lib/prisma'; // Adjust path to your prisma instance
import {
    SerializableSubscriptionPlan,
    serializeSubscriptionPlan,
    serializeSubscriptionPlans
} from '@/lib/utils/prisma-serializers';
import {Decimal} from '@prisma/client/runtime/library';
import {revalidateTag} from 'next/cache';
import {SubscriptionPlanFormData} from "@/components/subscription-plans/validations/subscription-plans";
import {requireAuth} from "@/lib/auth-utils";

export interface SubscriptionPlanFilters {
    search?: string;
    isActive?: boolean;
    sortBy?: 'name' | 'price_monthly' | 'price_yearly' | 'created_at';
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
}

export interface SubscriptionPlansResponse {
    data: SerializableSubscriptionPlan[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
}

export interface SubscriptionPlanDetails extends SerializableSubscriptionPlan {
    groupsCount: number;
    availableAnalytics: {
        id: string;
        name: string;
        description: string;
        isIncluded: boolean;
    }[];
}

export async function fetchSubscriptionPlans(
    filters: SubscriptionPlanFilters = {}
): Promise<SubscriptionPlansResponse> {
    const {
        search = '',
        isActive,
        sortBy = 'created_at',
        sortOrder = 'desc',
        page = 1,
        limit = 10
    } = filters;

    await requireAuth();

    try {
        // Build where clause
        const whereClause: any = {};

        // Search filter
        if (search) {
            whereClause.OR = [
                {name: {contains: search, mode: 'insensitive'}},
                {display_name: {contains: search, mode: 'insensitive'}},
                {description: {contains: search, mode: 'insensitive'}}
            ];
        }

        // Active filter
        if (isActive !== undefined) {
            whereClause.is_active = isActive;
        }

        // Count total records
        const total = await prisma.subscription_plans.count({
            where: whereClause
        });

        // Fetch paginated data
        const rawData = await prisma.subscription_plans.findMany({
            where: whereClause,
            orderBy: {
                [sortBy]: sortOrder
            },
            skip: (page - 1) * limit,
            take: limit
        });

        // Serialize Decimal fields for client components
        const data = serializeSubscriptionPlans(rawData);

        const totalPages = Math.ceil(total / limit);

        return {
            data,
            total,
            page,
            limit,
            totalPages
        };
    } catch (error) {
        console.error('Error fetching subscription plans:', error);
        throw new Error('Failed to fetch subscription plans');
    }
}


export async function fetchSubscriptionPlanDetails(
    planId: string
): Promise<SubscriptionPlanDetails | null> {
    await requireAuth();
    try {
        // Fetch the subscription plan
        const plan = await prisma.subscription_plans.findUnique({
            where: {id: planId}
        });

        if (!plan) {
            return null;
        }

        // Count groups using this plan
        const groupsCount = await prisma.groups.count({
            where: {subscription_plan_id: planId}
        });

        // Fetch all available analytic types
        const analyticTypes = await prisma.analytic_types.findMany({
            select: {
                id: true,
                name: true,
                description: true
            },
            orderBy: {name: 'asc'}
        });

        // Map analytics with inclusion status
        const availableAnalytics = analyticTypes.map(analytic => ({
            id: analytic.id,
            name: analytic.name,
            description: analytic.description,
            isIncluded: plan.analytics.includes(analytic.name)
        }));

        // Serialize the plan and return with additional data
        const serializedPlan = serializeSubscriptionPlan(plan);

        return {
            ...serializedPlan,
            groupsCount,
            availableAnalytics
        };
    } catch (error) {
        console.error('Error fetching subscription plan details:', error);
        throw new Error('Failed to fetch subscription plan details');
    }
}


export interface UpdateSubscriptionPlanInput {
    id: string;
    name: string;
    display_name: string;
    description?: string;
    max_cameras: number;
    max_nvrs: number;
    max_locations: number;
    max_members: number;
    max_floor_plans: number;
    max_storage: number;
    analytics: string[];
    desktop_app_access: boolean;
    priority_support: boolean;
    price_monthly?: number | null;
    price_yearly?: number | null;
    is_active: boolean;
}


export interface UpdateSubscriptionPlanResponse {
    success: boolean;
    data?: any;
    error?: string;
}

export async function updateSubscriptionPlan(
    input: UpdateSubscriptionPlanInput
): Promise<UpdateSubscriptionPlanResponse> {
    await requireAuth();
    try {
        // Check if plan exists
        const existingPlan = await prisma.subscription_plans.findUnique({
            where: {id: input.id}
        });

        if (!existingPlan) {
            return {
                success: false,
                error: 'Subscription plan not found'
            };
        }

        // Check if name is unique (excluding current plan)
        const nameExists = await prisma.subscription_plans.findFirst({
            where: {
                name: input.name,
                id: {not: input.id}
            }
        });

        if (nameExists) {
            return {
                success: false,
                error: 'A subscription plan with this name already exists'
            };
        }

        const updatedPlan = await prisma.subscription_plans.update({
            where: {id: input.id},
            data: {
                name: input.name,
                display_name: input.display_name,
                description: input.description,
                max_cameras: input.max_cameras,
                max_nvrs: input.max_nvrs,
                max_locations: input.max_locations,
                max_members: input.max_members,
                max_floor_plans: input.max_floor_plans,
                max_storage: input.max_storage,
                analytics: input.analytics,
                desktop_app_access: input.desktop_app_access,
                priority_support: input.priority_support,
                price_monthly: input.price_monthly !== undefined ? new Decimal(input.price_monthly!) : null,
                price_yearly: input.price_yearly !== undefined ? new Decimal(input.price_yearly!) : null,
                is_active: input.is_active,
                updated_at: new Date()
            }
        });

        // Revalidate related queries
        revalidateTag('subscription-plans');

        return {
            success: true,
            data: serializeSubscriptionPlan(updatedPlan)
        };
    } catch (error) {
        console.error('Error updating subscription plan:', error);
        return {
            success: false,
            error: 'Failed to update subscription plan'
        };
    }
}

export async function createSubscriptionPlan(
    input: Omit<SubscriptionPlanFormData, 'id'>
): Promise<UpdateSubscriptionPlanResponse> {
    await requireAuth();
    try {
        // Check if name already exists
        const nameExists = await prisma.subscription_plans.findFirst({
            where: {name: input.name}
        });

        if (nameExists) {
            return {
                success: false,
                error: 'A subscription plan with this name already exists'
            };
        }

        // Create the subscription plan
        const newPlan = await prisma.subscription_plans.create({
            data: {
                name: input.name,
                display_name: input.display_name,
                description: input.description,
                max_cameras: input.max_cameras,
                max_nvrs: input.max_nvrs,
                max_locations: input.max_locations,
                max_members: input.max_members,
                max_floor_plans: input.max_floor_plans,
                max_storage: input.max_storage,
                analytics: input.analytics,
                desktop_app_access: input.desktop_app_access,
                priority_support: input.priority_support,
                price_monthly: input.price_monthly !== undefined ? new Decimal(input.price_monthly!) : null,
                price_yearly: input.price_yearly !== undefined ? new Decimal(input.price_yearly!) : null,
                is_active: input.is_active,
            }
        });

        return {
            success: true,
            data: serializeSubscriptionPlan(newPlan)
        };
    } catch (error) {
        console.error('Error creating subscription plan:', error);
        return {
            success: false,
            error: 'Failed to create subscription plan'
        };
    }
}

export async function fetchAnalyticTypes() {
    await requireAuth();
    try {
        return await prisma.analytic_types.findMany({
            select: {
                id: true,
                name: true,
                description: true
            },
            orderBy: {name: 'asc'}
        });
    } catch (error) {
        console.log(error)
        throw new Error('Failed to fetch analytic types');
    }
}


